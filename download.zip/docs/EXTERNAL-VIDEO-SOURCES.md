# External Cloud Video Sources — Setup & Storage Requirements

ANIME BOY can play videos that live on external cloud storage / a CDN **without
downloading them to the website's hosting**. The site stores only metadata; the
video bytes stream straight from your storage provider (or provider embed) to
the visitor's browser.

---

## 0. Cloud Video Manager (the quick path)

**Admin Dashboard → Cloud Video Manager** is the dedicated section for every
cloud-hosted video — movies and series episodes in one inventory:

- **Add Cloud Video** — one guided form: choose the target (new movie / new
  series + season & episode / existing movie / existing episode), paste the
  cloud URL (provider is auto-detected: Google Drive, Dropbox, Cloudflare R2,
  Bunny, S3, YouTube…), add title / description / poster, multiple quality
  sources and Sinhala & English subtitles, **Preview Video**, then **Publish**
  (or save as a hidden draft).
- The inventory table shows where each video streams from (Direct cloud URL ·
  HLS stream · provider embed · private bucket signed · local upload), quality
  and subtitle counts, and the live/draft state. From there you can publish /
  unpublish, **Edit video** (replace the source without touching metadata) or
  delete the entry.
- The same editor is still available per-title under **Content → Add/Edit →
  Video Source** and per-episode under **Seasons & Episodes**.

**Continue watching** is built in: visitors who stop midway get a
"Continue Watching" row on the home page and a "Resumed from …" hint on the
player, with a **Start over** button. Positions are stored only in the
visitor's browser (localStorage) — nothing is written to the server.

---

## 1. The three video source types

In **Admin → Content → Edit (movie) → Video Source** (or **Manage seasons and
episodes → Edit episode**), pick one of:

| Source type | What it is | Where the file lives |
|---|---|---|
| **Upload file** | Upload through this site (existing pipeline) | Site's own storage (local `db/uploads` or the configured object storage) |
| **External URL** | Direct HTTPS media link: MP4 / WebM or HLS `.m3u8`, or `s3://bucket/key` for private buckets | Your object storage / CDN |
| **Provider embed** | Trusted provider embed (YouTube, Vimeo, Dailymotion, Google Drive, Streamable) | The provider's servers, in their iframe |

You can **switch or replace a source at any time** with the same editor — the
anime/episode entry is never recreated. Use **Preview Video** to test playback
(plus Content-Type and byte-range support) before saving.

---

## 2. Direct media URL requirements (External URL)

The URL must be a **direct video file**, not a cloud file-sharing page.

### 2.1 HTTPS
- Serve the file over `https://…`. Browsers block mixed (HTTP) media on a
  secure site, so plain `http://` URLs are rejected by the admin validation.
- The only non-HTTPS form allowed is the `s3://bucket/key` identifier used for
  private buckets (see §4) — the site turns it into a short-lived signed HTTPS
  URL at playback time.

### 2.2 Correct Content-Type
The storage server must send the right `Content-Type` header:

| File | Content-Type |
|---|---|
| `.mp4` | `video/mp4` |
| `.webm` | `video/webm` |
| `.m3u8` | `application/vnd.apple.mpegurl` (or `application/x-mpegURL`) |
| `.ts` segment | `video/mp2t` |
| `.vtt` subtitle | `text/vtt` |

S3 / R2 / B2 set this from the object's metadata at upload time — if you
uploaded with the wrong type, re-upload or copy the object with the correct
`ContentType`.

### 2.3 Byte-range support (seeking)
Browsers seek MP4 files by requesting ranges (`Range: bytes=…`). Your host must
reply `206 Partial Content` and advertise `Accept-Ranges: bytes`.
- Amazon S3, Cloudflare R2, Backblaze B2 and every major CDN do this by default.
- The admin **Preview** panel reports `Byte-range: bytes` after probing the URL,
  so you can confirm before publishing.

### 2.4 CORS (cross-origin playback)
If the media is served from a different domain than the website (typical for
CDN + HLS + cross-origin subtitles), configure CORS on the bucket/CDN:

Example AWS S3 CORS configuration (`Bucket → Permissions → CORS`):

```json
[
  {
    "AllowedHeaders": ["*"],
    "AllowedMethods": ["GET", "HEAD"],
    "AllowedOrigins": ["https://your-animeboy-domain.com"],
    "ExposeHeaders": ["Content-Length", "Content-Range", "Accept-Ranges"],
    "MaxAgeSeconds": 3600
  }
]
```

- MP4 via plain `<video src>` usually works without CORS; **HLS via hls.js and
  `<track>` subtitles always need it** (they are fetched with XHR/fetch).
- For Cloudflare R2: Settings → CORS policy (same JSON shape).
- Behind a CDN (CloudFront/Cloudflare): forward the `Origin` header and let the
  origin's CORS headers pass through.

### 2.5 HLS specifics
For an `.m3u8` source the player must be able to fetch **all** of:
1. The playlist (master + media playlists),
2. Every video segment it references (`.ts` / `.m4s`),
3. The encryption key, if you use AES-128 (`#EXT-X-KEY:…URI="key.key"`).

If any of these 403s, playback fails with a network error. Keep them in the
same bucket/prefix with the same access policy.

### 2.6 Share-page links are NOT direct URLs
Ordinary file-sharing links serve an HTML page, not video bytes. The admin
validation rejects them with a clear message and, where the provider has an
official embed, offers one-click conversion:

- Google Drive `…/file/d/<id>/view` → use **Provider embed** (auto-converted to
  the official `/preview` embed)
- YouTube / Vimeo / Dailymotion watch pages → **Provider embed**
- Dropbox / OneDrive / Mega / MediaFire / Terabox / WeTransfer → export a real
  direct link from your host/CDN, or use a provider embed

---

## 3. Provider embeds

Accepted providers (allowlist — **arbitrary iframe HTML is never accepted**):

| Provider | Accepted input | Played as |
|---|---|---|
| YouTube | `youtube.com/watch?v=…`, `youtu.be/…`, `/shorts/…`, existing `/embed/…` | `youtube-nocookie.com/embed/<id>` |
| Vimeo | `vimeo.com/<id>`, `player.vimeo.com/video/<id>` | `player.vimeo.com/video/<id>` |
| Dailymotion | `dailymotion.com/video/<id>`, `dai.ly/<id>` | `dailymotion.com/embed/video/<id>` |
| Google Drive | `drive.google.com/file/d/<id>/view` | `drive.google.com/file/d/<id>/preview` |
| Streamable | `streamable.com/<id>` | `streamable.com/e/<id>` |

The video stays on the provider; controls, ads and quality menus are the
provider's own (noted in the admin UI and on the watch page). No provider API
key is required — nothing to configure.

---

## 4. Private bucket playback (signed URLs)

If your bucket is **private** (no public read), the site mints short-lived
signed playback URLs on the server after an access check. Credentials and
signing keys never leave the server and are never sent to the browser; the
database stores only the stable identifier `s3://bucket/key`.

### 4.1 Environment variables

```bash
# Required for object storage (uploads + signed playback)
S3_ENDPOINT=https://<accountid>.r2.cloudflarestorage.com   # or S3 endpoint
S3_REGION=auto                # S3 region / "auto" for R2
S3_BUCKET=animeboy-media      # bucket name
S3_ACCESS_KEY_ID=...          # access key (server-side only)
S3_SECRET_ACCESS_KEY=...      # secret key (server-side only)

# Optional
S3_PUBLIC_BASE_URL=https://cdn.example.com   # public base for uploaded posters/subtitles
S3_PRIVATE_BUCKET=1          # video uploads become private: stored as s3://bucket/key
S3_SIGN_TTL_SEC=14400        # signed URL lifetime (default 4 h)
MAX_VIDEO_MB=512             # upload size cap for the upload pipeline
```

> After changing env vars, restart the server. When S3 is configured, the
> Admin → Overview "File storage" card shows object storage as active.

### 4.2 How playback works
1. Admin saves the source as `External URL` = `s3://animeboy-media/media/ep1.mp4`
   (or uploads with `S3_PRIVATE_BUCKET=1`, which stores that identifier
   automatically).
2. The public API hands the player a **`signUrl`** (e.g.
   `/api/media/play/anime/<id>`) — never a signed URL, never credentials.
3. The player fetches `signUrl`; the server checks that the item is published
   (admins may preview unpublished items), mints a signed GET URL with
   `S3_SIGN_TTL_SEC` lifetime and returns it with `Cache-Control: no-store`.
4. If the signed URL expires mid-session, the player silently re-signs once and
   resumes at the same position, so seeking keeps working.
5. Signed URLs are never stored in the database or in the page.

### 4.3 Bucket policy
Keep the bucket **private** (block public access). Only posters, backdrops and
subtitle uploads need public readability (they go to `S3_PUBLIC_BASE_URL`).

---

## 5. Download buttons below the player

Every movie and every episode can expose two buttons directly under the video
player: **Download Video / වීඩියෝව බාගන්න** and **Download Subtitles /
උපසිරැසි බාගන්න**. They are configured per item in the admin editor's
**Downloads** block:

| Setting | What it does |
|---|---|
| **Enable Video Download** | Shows the video download button on the watch page |
| **Video download URL** | A single downloadable file: HTTPS MP4/WebM, `s3://bucket/key`, or a site upload (`/api/files/…`) |
| **Check link** | Probes the URL (SSRF-safe) and reports availability, size and whether the host forces downloads |
| **Reuse playback URL as download URL** | Copies the direct playback source into the download field (only shown when the playback source is a plain file link) |
| **Per-quality download files** | Optional separate files per quality (480p / 720p / 1080p…), each its own downloadable file |
| **Enable Subtitle Download** | Shows the subtitle download button |
| **Subtitle download files** | SRT / VTT files with a language label each |

### 5.1 What a download must be

A download option is a **single file**. HLS playlists (`.m3u8`), DASH
manifests (`.mpd`) and provider embeds are rejected — they are streams, not
downloadable files. Save a separate MP4/WebM file for the download option.

### 5.2 How downloads are served

- Files are fetched **straight from the storage host / CDN** — the website
  server never proxies or copies a download.
- `s3://bucket/key` entries are resolved to a **short-lived signed URL with
  `Content-Disposition: attachment`** and a meaningful filename
  (`Title-S01E02-1080p.mp4`), minted after an access check.
- Site uploads (`/api/files/…`) download from the site itself with
  `?download=1&name=…`.
- Plain HTTPS links go to the provider directly. When the provider does **not**
  send `Content-Disposition: attachment`, the visitor gets an
  **"Open Download Link"** dialog (open in a new tab / copy link) instead of a
  forced download — the HTML `download` attribute cannot force downloads
  cross-origin.
- Missing files (404), expired links (403/410) and storage errors surface as
  clear messages on the button.
- Series always download **the currently selected episode's** file.

### 5.3 Pasting your own site's URLs

Upload results are stored as relative `/api/files/…` paths. If you paste the
absolute form (`https://your-domain.com/api/files/…`), the admin validation
recognises it as a site-hosted file and stores the relative path
automatically.

---

## 6. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Preview says "HTML page, not a video file" | You pasted a share-page link | Use a direct media URL or Provider embed |
| "Internal hostnames are not allowed" | URL points to localhost/private IP (SSRF guard) | Use the public CDN/storage URL |
| 403 in Preview | Object private or URL is an expiring link | Make it public-read or use `s3://bucket/key` |
| Playback error mentioning CORS | Bucket/CDN lacks CORS for the site origin | Apply §2.4 |
| Plays but seeking jumps/stalls | Host ignores byte-range requests | Use a host/CDN with `Accept-Ranges: bytes` |
| HLS network error | Segments or key unreachable | Check playlist + segments + key share the same access policy |
| "Private object storage is not configured" | `S3_*` env vars missing | Set §4.1 and restart |
| Download button missing on the watch page | Toggle off or no file configured | Enable in the Downloads block and set a downloadable file |
| Download opens in a new tab instead of saving | Host does not send `Content-Disposition: attachment` | Expected cross-origin behaviour — use the "Open Download Link" fallback, or host the file on S3/R2 (signed URLs force attachment) |

---

## 7. Security notes

- Only signed-in admins can change video sources (every admin API route checks
  the session; anonymous requests get 401).
- Direct URLs must be HTTPS; embeds must match the provider allowlist.
- The admin "check URL" probe resolves DNS first and refuses private, loopback,
  link-local and cloud-metadata addresses, and re-validates every redirect hop
  (SSRF protection). It fetches only the first byte.
- Object identifiers (`s3://bucket/key`) are stripped from public API responses
  for visitors; admins keep them for editing.
