/**
 * ANIME BOY — database seed
 * Creates: admin + demo users, demo anime library (movies/series/seasons/episodes),
 * sample requests and site config. Safe to re-run (idempotent by slug/email).
 *
 * Run: bun prisma/seed.ts
 * Admin credentials come from ADMIN_EMAIL / ADMIN_PASSWORD env vars.
 */
import { PrismaClient } from "@prisma/client";
import { mkdirSync, writeFileSync } from "fs";
import path from "path";

const db = new PrismaClient();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@animeboy.lk";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "AnimeBoy@2024";
const DEMO_EMAIL = process.env.DEMO_EMAIL || "viewer@animeboy.lk";
const DEMO_PASSWORD = process.env.DEMO_PASSWORD || "anime1234";

const V = (n: number) => `/api/files/videos/sample-ep-${n}.mp4`;

type SeedAnime = {
  slug: string;
  type: "MOVIE" | "SERIES";
  titleEn: string;
  titleSi?: string;
  descriptionSi: string;
  descriptionEn: string;
  genres: string[];
  releaseYear: number;
  rating?: number;
  languageLabel: "SINHALA_DUBBED" | "SINHALA_SUB" | "ANIME_REVIEW";
  availability: string;
  status: "RELEASED" | "UPCOMING";
  posterUrl: string;
  backdropUrl?: string;
  videoUrl?: string;
  subtitleUrl?: string;
  downloadEnabled?: boolean;
  downloadUrl?: string;
  subtitleDownloadEnabled?: boolean;
  subtitleDownloads?: string;
  featured?: boolean;
  featuredOrder?: number;
  homeRank?: number;
  seasons?: { number: number; title?: string; episodes: { title: string; durationSec: number; videoUrl: string; subtitleUrl?: string; description?: string; downloadEnabled?: boolean; downloadUrl?: string; subtitleDownloadEnabled?: boolean; subtitleDownloads?: string }[] }[];
};

const LIBRARY: SeedAnime[] = [
  {
    slug: "blade-of-the-emerald-dawn",
    type: "MOVIE",
    titleEn: "Blade of the Emerald Dawn",
    titleSi: "එමරල්ඩ් කතුර: අලුත් උදාව",
    descriptionSi:
      "ප්‍රබල මායා කතුරක් උරුම කරගත් තරුණියක්, තම ගම්මානය ආරක්ෂා කිරීම සඳහා මහා යුද්ධයකට මුහුණ දෙයි. සිංහලෙන් හඬ කැවූ සම්පූර්ණ චිත්‍රපටය ANIME BOY වෙතින්ම නරඹන්න.",
    descriptionEn:
      "A young warrior inherits a legendary emerald blade and must master its power before the shadow legion consumes her homeland.",
    genres: ["Action", "Fantasy", "Adventure"],
    releaseYear: 2024,
    rating: 8.7,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ",
    status: "RELEASED",
    posterUrl: "/art/poster-blade-dawn.png",
    videoUrl: "/api/files/videos/sample-ep-1.mp4",
    subtitleUrl: "/api/files/subtitles/demo-si.vtt",
    downloadEnabled: true,
    downloadUrl: "/api/files/videos/sample-ep-1.mp4",
    subtitleDownloadEnabled: true,
    subtitleDownloads: JSON.stringify([{ label: "සිංහල", lang: "si", url: "/api/files/subtitles/demo-si.vtt" }]),
    backdropUrl: "/art/backdrop-blade-dawn.png",
    featured: true,
    featuredOrder: 1,
    homeRank: 1,
  },
  {
    slug: "sky-ronin-the-last-flight",
    type: "MOVIE",
    titleEn: "Sky Ronin: The Last Flight",
    titleSi: "අහස් රණශූරයා: අවසාන පියාසරය",
    descriptionSi:
      "අහසේ පියාසර තලයෙකු පිට ගමන් කරන තනි රණශූරයෙක්, විනාශ වූ රාජධානියක් නැවත ගොඩනැගීමට සිය අවසාන පියාසරය ආරම්භ කරයි.",
    descriptionEn:
      "A wandering ronin rides a giant sky whale across the clouds in search of the fragments of a fallen kingdom.",
    genres: ["Adventure", "Fantasy", "Drama"],
    releaseYear: 2022,
    rating: 8.9,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ",
    status: "RELEASED",
    posterUrl: "/art/poster-sky-ronin.png",
    videoUrl: "/api/files/videos/sample-ep-2.mp4",
    backdropUrl: "/art/backdrop-sky-ronin.png",
    featured: true,
    featuredOrder: 2,
    homeRank: 2,
  },
  {
    slug: "neon-sakura",
    type: "MOVIE",
    titleEn: "Neon Sakura",
    titleSi: "නියොන් සකුරා",
    descriptionSi:
      "නියොන් එළියෙන් දිලෙන අනාගත ටෝකියෝ නුවර, සකුරා මල් පිපෙන රහස් සැඟවුණු ලෝකයක්. සිංහල උපසිරැසි සමඟ නරඹන්න.",
    descriptionEn:
      "In neon-lit future Tokyo, a courier girl discovers flowers that bloom with memories of a vanished world.",
    genres: ["Sci-Fi", "Romance", "Mystery"],
    releaseYear: 2023,
    rating: 8.2,
    languageLabel: "SINHALA_SUB",
    availability: "සිංහල උපසිරැසි",
    status: "RELEASED",
    posterUrl: "/art/poster-neon-sakura.png",
    videoUrl: "/api/files/videos/sample-ep-3.mp4",
    homeRank: 3,
  },
  {
    slug: "whisper-of-the-fox-spirit",
    type: "MOVIE",
    titleEn: "Whisper of the Fox Spirit",
    titleSi: "නරි ආත්මයාගේ රහස් හඬ",
    descriptionSi:
      "පුරාණ වනාන්තරයක වාසය කරන නව වලිග සහිත නරි ආත්මයක් හා බැඳුණු පුංචි ගැහැණු ළමයෙකුගේ අපූරු මිතුරප්පු කතාව.",
    descriptionEn:
      "A village girl befriends an ancient nine-tailed fox spirit and learns the forest's oldest secret.",
    genres: ["Fantasy", "Supernatural", "Family"],
    releaseYear: 2024,
    rating: 8.4,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ",
    status: "RELEASED",
    posterUrl: "/art/poster-fox-spirit.png",
    videoUrl: "/api/files/videos/sample-ep-1.mp4",
    backdropUrl: "/art/backdrop-fox-spirit.png",
    featured: true,
    featuredOrder: 4,
    homeRank: 4,
  },
  {
    slug: "crimson-horizon",
    type: "MOVIE",
    titleEn: "Crimson Horizon",
    titleSi: "රතු ක්ෂිතිජය",
    descriptionSi:
      "රතු අහස යට පියාසර නෞකාවකින් ලෝකය වටා යන කුරුළු සැරිසරුන් කණ්ඩායමක්, පැරණි රහස් සොයා යන ගමනේ කතාව.",
    descriptionEn:
      "An airship crew of young pirates races a rival fleet to find the compass that points to yesterday.",
    genres: ["Adventure", "Action", "Steampunk"],
    releaseYear: 2021,
    rating: 8.0,
    languageLabel: "SINHALA_SUB",
    availability: "සිංහල උපසිරැසි",
    status: "RELEASED",
    posterUrl: "/art/poster-crimson-horizon.png",
    videoUrl: "/api/files/videos/sample-ep-2.mp4",
    homeRank: 5,
  },
  {
    slug: "the-alchemists-garden",
    type: "MOVIE",
    titleEn: "The Alchemist's Garden",
    titleSi: "රසායනඥයාගේ උයන",
    descriptionSi:
      "මහා රසායනඥයෙකු වීමට සිහින දකින පුංචි පිරිමි ළමයෙක්, ඔහුගේ උයනේ වැඩෙන මායාකාරී ශාක සමඟ අපූරු ජීවිතයක් ගොඩනඟයි.",
    descriptionEn:
      "A gentle fantasy about a boy whose garden of glowing alchemical plants hides a doorway to spring itself.",
    genres: ["Fantasy", "Slice of Life"],
    releaseYear: 2023,
    rating: 7.9,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ",
    status: "RELEASED",
    posterUrl: "/art/poster-alchemist.png",
    videoUrl: "/api/files/videos/sample-ep-3.mp4",
    homeRank: 6,
  },
  {
    slug: "star-voyager-hoshi",
    type: "MOVIE",
    titleEn: "Star Voyager Hoshi",
    titleSi: "තරු සැරිකරු හෝෂි",
    descriptionSi:
      "තරු අතරින් ගමන් කරන අභ්‍යවකාශ ගවේෂක හෝෂි, නව ග්‍රහලෝක සොයා ගන්නා සුන්දර සඹායාත්‍රයක කතාව.",
    descriptionEn:
      "Cadet Hoshi charts an uncharted nebula and finds a star that hums her grandmother's lullaby.",
    genres: ["Sci-Fi", "Adventure"],
    releaseYear: 2022,
    rating: 8.1,
    languageLabel: "SINHALA_SUB",
    availability: "සිංහල උපසිරැසි",
    status: "RELEASED",
    posterUrl: "/art/poster-star-voyager.png",
    videoUrl: "/api/files/videos/sample-ep-1.mp4",
    homeRank: 7,
  },
  {
    slug: "ocean-song",
    type: "MOVIE",
    titleEn: "Ocean Song",
    titleSi: "සාගර ගීතය",
    descriptionSi:
      "මුහුදු පතුලේ ගීතයක් ගායනා කරන යුවතියක් සහ ඇයගේ හඬ, සුන්දර මුහුදේ රහසක් හෙළි කරන ආකාරය.",
    descriptionEn:
      "Every song the tide girl sings returns to the shore with a pearl of the ocean's memory.",
    genres: ["Fantasy", "Music", "Drama"],
    releaseYear: 2020,
    rating: 8.3,
    languageLabel: "SINHALA_SUB",
    availability: "සිංහල උපසිරැසි",
    status: "RELEASED",
    posterUrl: "/art/poster-ocean-song.png",
    videoUrl: "/api/files/videos/sample-ep-2.mp4",
    homeRank: 8,
  },
  {
    slug: "emerald-blade-final-chapter",
    type: "MOVIE",
    titleEn: "Emerald Blade: Final Chapter",
    titleSi: "එමරල්ඩ් කතුර: අවසාන පරිච්ඡේදය",
    descriptionSi:
      "එමරල්ඩ් කතුර විනාශ වීමට පෙර අවසාන සටන ආරම්භ වේ. 2026 දී සිංහල හඬ කැවූ චිත්‍රපටය ලබා එයි.",
    descriptionEn:
      "The saga concludes: the last bearer of the emerald blade faces the shadow legion at the end of the world.",
    genres: ["Action", "Fantasy"],
    releaseYear: 2026,
    rating: 8.9,
    languageLabel: "SINHALA_DUBBED",
    availability: "ඉක්මනින් සිංහල හඬ කැවූ",
    status: "UPCOMING",
    posterUrl: "/art/poster-emerald-final.png",
    homeRank: 1,
  },
  {
    slug: "dragon-tide",
    type: "MOVIE",
    titleEn: "Dragon Tide",
    titleSi: "ඩ්‍රැගන් රැල්ල",
    descriptionSi:
      "මහා මුහුදු ඩ්‍රැගන් නැවත අවදි වන විට, කුඩා ධීවර ගම්මානයක දරුවන්ගේ ඉරණම සදහටම වෙනස් වේ.",
    descriptionEn:
      "When the sea dragon wakes, a fishing village's bravest child must ride the tide to meet it.",
    genres: ["Fantasy", "Adventure"],
    releaseYear: 2026,
    rating: 8.2,
    languageLabel: "SINHALA_SUB",
    availability: "ඉක්මනින් සිංහල උපසිරැසි සමඟ",
    status: "UPCOMING",
    posterUrl: "/art/poster-dragon-tide.png",
    homeRank: 2,
  },
  {
    slug: "emerald-blade-chronicles",
    type: "SERIES",
    titleEn: "Emerald Blade Chronicles",
    titleSi: "එමරල්ඩ් කතුර කථා මාලාව",
    descriptionSi:
      "තරුණ යෝධයන් තිදෙනෙකු මායා වනාන්තරයේ පෞරාණික දේවාලය ආරක්ෂා කරමින් තම ශක්තීන් අවදි කරති. සෑම සතියකම නව කථාංග ANIME BOY වෙතින්.",
    descriptionEn:
      "Three young warriors awaken the emerald spirits and defend the ancient forest temple, season after season.",
    genres: ["Action", "Fantasy", "Shounen"],
    releaseYear: 2024,
    rating: 8.6,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ | නව කථාංග සෑම සතියකම",
    status: "RELEASED",
    posterUrl: "/art/poster-emerald-chronicles.png",
    backdropUrl: "/art/backdrop-emerald-chronicles.png",
    featured: true,
    featuredOrder: 3,
    homeRank: 1,
    seasons: [
      {
        number: 1,
        title: "වනාන්තරයේ අවදිය",
        episodes: [
          { title: "නව ගමනක් මුල", durationSec: 14, videoUrl: V(1), subtitleUrl: "/api/files/subtitles/demo-si.vtt", description: "කයිටෝ වනාන්තරයට පිවිසෙන පළමු දිනය.", downloadEnabled: true, downloadUrl: V(1), subtitleDownloadEnabled: true, subtitleDownloads: JSON.stringify([{ label: "සිංහල", lang: "si", url: "/api/files/subtitles/demo-si.vtt" }]) },
          { title: "සැඟවුණු ශක්තිය", durationSec: 14, videoUrl: V(2), description: "පුරාණ දේවාලයේ රහසක් හෙළි වේ." },
          { title: "කුහක මිතුරා", durationSec: 14, videoUrl: V(3), description: "අමුතුම මිතුරෙක් කණ්ඩායමට එක් වේ." },
          { title: "කොළ පැහැති දිලිසුම", durationSec: 14, videoUrl: V(1), description: "පළමු සටන ආරම්භ වේ." },
          { title: "අඳුරු සෙවනැල්ල", durationSec: 14, videoUrl: V(2), description: "සෙවනැලි කණ්ඩායම දේවාලයට ළඟා වේ." },
          { title: "පළමු ජයග්‍රහණය", durationSec: 14, videoUrl: V(3), description: "කණ්ඩායම පළමු විශාල ජයග්‍රහණය ලබා ගනී." },
        ],
      },
      {
        number: 2,
        title: "දේවාලයේ රහස්",
        episodes: [
          { title: "නව අවදියක්", durationSec: 14, videoUrl: V(2), description: "දේවාලයේ ගැඹුරු මහල් විවෘත වේ." },
          { title: "පරීක්ෂණය", durationSec: 14, videoUrl: V(3), description: "ආත්ම වනාන්තරයේ පරීක්ෂණයක්." },
          { title: "පැරණි සතුරා", durationSec: 14, videoUrl: V(1), description: "අතීතයෙන් පැමිණි සතුරෙක්." },
          { title: "එකමුතුව", durationSec: 14, videoUrl: V(2), description: "කණ්ඩායම නැවත එකතු වේ." },
        ],
      },
    ],
  },
  {
    slug: "moonlit-academy",
    type: "SERIES",
    titleEn: "Moonlit Academy",
    titleSi: "සඳ එළි අකඩමිය",
    descriptionSi:
      "සඳ එළියේ දිලෙන පාසලක සිසුන්, රහස් පාසල් ගොඩනැගිල්ල තුළ සැඟවුණු අද්භූත ශක්තීන් සොයා ගනිති.",
    descriptionEn:
      "At a boarding school that only appears under full moons, students master impossible subjects.",
    genres: ["Supernatural", "School", "Mystery"],
    releaseYear: 2023,
    rating: 8.3,
    languageLabel: "SINHALA_SUB",
    availability: "සිංහල උපසිරැසි",
    status: "RELEASED",
    posterUrl: "/art/poster-moonlit-academy.png",
    homeRank: 2,
    seasons: [
      {
        number: 1,
        episodes: [
          { title: "පුරවැසි ප්‍රවේශය", durationSec: 14, videoUrl: V(1), description: "නව සිසුවා පාසලට පිවිසෙයි." },
          { title: "මධ්‍යම රාත්‍රී පන්තිය", durationSec: 14, videoUrl: V(2), description: "අලුයම 3ට පන්තියක් තිබේ." },
          { title: "පුස්තකාලයේ රහස", durationSec: 14, videoUrl: V(3), description: "පොත් රාත්‍රියේ පිටු හරවයි." },
          { title: "සඳ ග්‍රහණය", durationSec: 14, videoUrl: V(1), description: "සඳ ග්‍රහණය අවස්ථාවේ අද්භූත දෙයක්." },
          { title: "විභාගය", durationSec: 14, videoUrl: V(2), description: "වසරේ ලොකුම විභාගය." },
        ],
      }
    ],
  },
  {
    slug: "spirit-hunter-yuki",
    type: "SERIES",
    titleEn: "Spirit Hunter Yuki",
    titleSi: "ආත්ම දඩයක්කාර යුකි",
    descriptionSi:
      "ආත්ම වේදිකාවක් සමඟ අඳුරු යකා දඩයම් කරන යුකිගේ රාත්‍රී ගමන් මාලාව.",
    descriptionEn:
      "By day Yuki is an ordinary student; by night she hunts the spirits that slip through the city's cracks.",
    genres: ["Action", "Supernatural"],
    releaseYear: 2022,
    rating: 8.5,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ",
    status: "RELEASED",
    posterUrl: "/art/poster-spirit-hunter.png",
    homeRank: 3,
    seasons: [
      {
        number: 1,
        episodes: [
          { title: "පළමු දඩයම", durationSec: 14, videoUrl: V(3), description: "යුකිගේ පළමු රාත්‍රී දඩයම." },
          { title: "රිදී මිටිය", durationSec: 14, videoUrl: V(1), description: "නව ආයුධයක් ලැබේ." },
          { title: "වීදියේ යකා", durationSec: 14, videoUrl: V(2), description: "නගරය පීඩාවට පත් වේ." },
          { title: "අවසාන සටන", durationSec: 14, videoUrl: V(3), description: "යුකි විශාලම යකා මුහුණ දී සිටී." },
        ],
      }
    ],
  },
  {
    slug: "ronin-high",
    type: "SERIES",
    titleEn: "Ronin High",
    titleSi: "රණශූර පාසල",
    descriptionSi:
      "පාසල් නිල ඇඳුමින් සැරසී ලී කතුරක් අතට ගත් සමුරායි සිසුන්ගේ විහිළු සහිත දෛනික ජීවිතය.",
    descriptionEn:
      "Samurai club, school festivals and a wooden sword with an attitude — the funniest classroom on the hill.",
    genres: ["Comedy", "School", "Action"],
    releaseYear: 2024,
    rating: 7.8,
    languageLabel: "SINHALA_DUBBED",
    availability: "සිංහල හඬ කැවූ",
    status: "RELEASED",
    posterUrl: "/art/poster-ronin-high.png",
    homeRank: 4,
    seasons: [
      {
        number: 1,
        episodes: [
          { title: "සමුරායි ක්ලබ් එකට සාදාගන්න", durationSec: 14, videoUrl: V(2), description: "නව ක්ලබ් එකක් පටන් ගනී." },
          { title: "ලී කතුරේ කුසලතා", durationSec: 14, videoUrl: V(3), description: "පළමු තරගය." },
          { title: "පාසල් උත්සවය", durationSec: 14, videoUrl: V(1), description: "වාර්ෂික උත්සවයේ විපත්." },
          { title: "සුබ නිවාඩු", durationSec: 14, videoUrl: V(2), description: "නිවාඩුවේ සිදුවීම්." },
        ],
      }
    ],
  },
  {
    slug: "neon-sakura-zero",
    type: "SERIES",
    titleEn: "Neon Sakura: Zero",
    titleSi: "නියොන් සකුරා: ශූන්‍යයා",
    descriptionSi:
      "නියොන් සකුරා ලෝකයේ මුල් කතාව — ඇන්ඩ්‍රොයිඩ් තරුණියක් නැවත උපදින ආකාරය. 2026 දී ලබා එයි.",
    descriptionEn:
      "The prequel: the first android to dream of cherry blossoms awakens in a sealed laboratory.",
    genres: ["Sci-Fi", "Action"],
    releaseYear: 2026,
    rating: 8.3,
    languageLabel: "SINHALA_SUB",
    availability: "ඉක්මනින් සිංහල උපසිරැසි සමඟ",
    status: "UPCOMING",
    posterUrl: "/art/poster-neon-zero.png",
    homeRank: 1,
  },
  {
    slug: "dragon-tide-legacy",
    type: "SERIES",
    titleEn: "Dragon Tide: Legacy",
    titleSi: "ඩ්‍රැගන් රැල්ල: උරුමය",
    descriptionSi:
      "ඩ්‍රැගන් රයිඩර් කෙල්ලක් සහ ඇගේ පුංචි ඩ්‍රැගන් මිතුරාගේ නව පරම්පරාවේ කතාව.",
    descriptionEn:
      "A new generation of dragon riders takes to the skies above the emerald archipelago.",
    genres: ["Fantasy", "Adventure", "Family"],
    releaseYear: 2026,
    rating: 8.2,
    languageLabel: "SINHALA_DUBBED",
    availability: "ඉක්මනින් සිංහල හඬ කැවූ",
    status: "UPCOMING",
    posterUrl: "/art/poster-dragon-legacy.png",
    homeRank: 2,
  },
];

async function main() {
  // --- users ---
  const { hash } = await import("bcryptjs");
  const adminHash = await hash(ADMIN_PASSWORD, 10);
  const demoHash = await hash(DEMO_PASSWORD, 10);

  const admin = await db.user.upsert({
    where: { email: ADMIN_EMAIL },
    update: { role: "ADMIN", passwordHash: adminHash },
    create: { email: ADMIN_EMAIL, name: "ANIME BOY Admin", passwordHash: adminHash, role: "ADMIN" },
  });
  const viewer = await db.user.upsert({
    where: { email: DEMO_EMAIL },
    update: {},
    create: { email: DEMO_EMAIL, name: "Chathura (Demo)", passwordHash: demoHash, role: "USER" },
  });
  console.log(`admin: ${admin.email} | demo viewer: ${viewer.email}`);

  // --- sample subtitle file (VTT with Sinhala cues) ---
  const subDir = path.join(process.cwd(), "db", "uploads", "subtitles");
  mkdirSync(subDir, { recursive: true });
  writeFileSync(
    path.join(subDir, "demo-si.vtt"),
    `WEBVTT

1
00:00:00.500 --> 00:00:04.000
එමරල්ඩ් කතුරේ බලය අවදි වෙනවා...

2
00:00:04.500 --> 00:00:08.000
මේ වනාන්තරය අපේ උරුමයයි!

3
00:00:08.500 --> 00:00:12.000
අපි එකට සටන් කළ යුතුයි!

4
00:00:12.500 --> 00:00:14.000
ANIME BOY — සිංහල උපසිරැසි
`
  );

  // --- anime library ---
  for (const item of LIBRARY) {
    const { seasons, genres, ...rest } = item;
    const data = { ...rest, genres: genres.join(",") };
    const row = await db.anime.upsert({
      where: { slug: item.slug },
      update: data,
      create: data,
    });
    if (seasons?.length) {
      for (const s of seasons) {
        const season = await db.season.upsert({
          where: { animeId_number: { animeId: row.id, number: s.number } },
          update: { title: s.title || null },
          create: { animeId: row.id, number: s.number, title: s.title || null },
        });
        for (let i = 0; i < s.episodes.length; i++) {
          const ep = s.episodes[i];
          const createdAt = new Date(Date.now() - (i + s.number) * 36 * 3600 * 1000);
          await db.episode.upsert({
            where: { seasonId_number: { seasonId: season.id, number: i + 1 } },
            update: ep,
            create: { ...ep, seasonId: season.id, number: i + 1, createdAt },
          });
        }
      }
    }
  }
  console.log(`library: ${LIBRARY.length} titles seeded`);

  // --- sample anime requests ---
  const reqCount = await db.animeRequest.count();
  if (reqCount === 0) {
    await db.animeRequest.createMany({
      data: [
        { title: "Solo Leveling Season 2", type: "SERIES", message: "සිංහල හඬ කැව්වම ලස්සනයි! 😍", userId: viewer.id, status: "PENDING" },
        { title: "Demon Slayer: Infinity Castle", type: "MOVIE", message: "Please add with Sinhala subs 🙏", status: "PENDING" },
        { title: "Vinland Saga", type: "SERIES", status: "APPROVED", userId: viewer.id },
      ],
    });
  }

  // --- site config (channel URL intentionally empty — admin sets it) ---
  await db.siteConfig.upsert({
    where: { key: "youtubeChannelUrl" },
    update: {},
    create: { key: "youtubeChannelUrl", value: "" },
  });
  await db.siteConfig.upsert({
    where: { key: "channelHandle" },
    update: {},
    create: { key: "channelHandle", value: "" },
  });

  console.log("seed complete ✔");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
