"use client";

import { create } from "zustand";
import type {
  AltSource,
  DownloadInfo,
  PlayableSource,
  QualityTrack,
  SubtitleTrack,
  VideoSourceKind,
} from "@/lib/media-types";

export type SessionUser = {
  id: string;
  email: string;
  name: string | null;
  role: string;
};

export type SiteConfig = {
  youtubeChannelUrl?: string;
  channelHandle?: string;
};

export type HashRoute = {
  path: string; // e.g. "/anime/slug"
  segments: string[];
  query: URLSearchParams;
  raw: string;
};

export function parseHash(raw: string): HashRoute {
  let hash = raw.replace(/^#/, "");
  if (!hash.startsWith("/")) hash = "/" + hash;
  const [pathPart, queryPart] = hash.split("?");
  const segments = pathPart.split("/").filter(Boolean);
  return {
    path: pathPart,
    segments,
    query: new URLSearchParams(queryPart || ""),
    raw: hash,
  };
}

export function navigate(to: string) {
  const target = to.startsWith("#") ? to : `#${to.startsWith("/") ? to : "/" + to}`;
  if (window.location.hash === target) {
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = target;
  }
}

/**
 * Route matching for nav highlighting. Segment-boundary aware so that
 * "/donghua" is NOT active while browsing "/donghua-series".
 */
export function isRouteActive(path: string, hash: string): boolean {
  if (hash === "/") return path === "/";
  return path === hash || path.startsWith(`${hash}/`);
}

type AppState = {
  route: HashRoute;
  user: SessionUser | null;
  userLoaded: boolean;
  config: SiteConfig;
  mobileMenuOpen: boolean;
  watchlistIds: Set<string>;
  setRoute: (r: HashRoute) => void;
  setUser: (u: SessionUser | null) => void;
  setUserLoaded: (b: boolean) => void;
  setConfig: (c: SiteConfig) => void;
  setMobileMenuOpen: (b: boolean) => void;
  setWatchlistIds: (ids: string[]) => void;
  toggleWatchlistLocal: (animeId: string, inList: boolean) => void;
};

export const useAppStore = create<AppState>((set) => ({
  // SSR-safe initial route. The real hash (deep link) is synced on mount by
  // AppShell — reading window.location.hash here would diverge from the
  // server-rendered HTML and cause a hydration mismatch on shared deep links.
  route: parseHash("#/"),
  user: null,
  userLoaded: false,
  config: {},
  mobileMenuOpen: false,
  watchlistIds: new Set<string>(),
  setRoute: (r) => set({ route: r, mobileMenuOpen: false }),
  setUser: (u) => set({ user: u }),
  setUserLoaded: (b) => set({ userLoaded: b }),
  setConfig: (c) => set({ config: c }),
  setMobileMenuOpen: (b) => set({ mobileMenuOpen: b }),
  setWatchlistIds: (ids) => set({ watchlistIds: new Set(ids) }),
  toggleWatchlistLocal: (animeId, inList) =>
    set((state) => {
      const next = new Set(state.watchlistIds);
      if (inList) next.add(animeId);
      else next.delete(animeId);
      return { watchlistIds: next };
    }),
}));

export type AnimeType = {
  id: string;
  slug: string;
  type: "MOVIE" | "SERIES";
  category: "ANIME" | "DONGHUA" | "OTHERS";
  /** Optional season/episode labels — only used by the flexible "Others" category. */
  seasonNumber: number | null;
  episodeNumber: number | null;
  titleEn: string;
  titleSi: string | null;
  descriptionSi: string | null;
  descriptionEn: string | null;
  genres: string[];
  releaseYear: number | null;
  rating: number | null;
  languageLabel: "SINHALA_DUBBED" | "SINHALA_SUB" | "ANIME_REVIEW";
  availability: string | null;
  status: "RELEASED" | "UPCOMING";
  posterUrl: string | null;
  backdropUrl: string | null;
  videoUrl: string | null;
  videoSource: VideoSourceKind;
  embedUrl: string | null;
  videoProvider: string | null;
  videoQualities: QualityTrack[];
  subtitleTracks: SubtitleTrack[];
  videoThumb: string | null;
  subtitleUrl: string | null;
  downloadEnabled: boolean;
  downloadUrl: string | null;
  downloadQualities: QualityTrack[];
  subtitleDownloadEnabled: boolean;
  subtitleDownloads: SubtitleTrack[];
  featured: boolean;
  featuredOrder: number;
  homeRank: number;
  published: boolean;
  createdAt: string;
  updatedAt: string;
  video?: PlayableSource;
  /** Primary + backup sources for the watch-page switcher (movies). */
  sources?: PlayableSource[];
  /** Raw backup rows — admin edit forms only. */
  altSources?: AltSource[];
  downloads?: DownloadInfo;
  seasons?: SeasonType[];
};

export type SeasonType = {
  id: string;
  number: number;
  title: string | null;
  episodes: EpisodeType[];
};

export type EpisodeType = {
  id: string;
  number: number;
  title: string | null;
  videoUrl: string | null;
  videoSource: VideoSourceKind;
  embedUrl: string | null;
  videoProvider: string | null;
  videoQualities: QualityTrack[];
  subtitleTracks: SubtitleTrack[];
  subtitleUrl: string | null;
  thumbnailUrl: string | null;
  durationSec: number | null;
  description: string | null;
  downloadEnabled: boolean;
  downloadUrl: string | null;
  downloadQualities: QualityTrack[];
  subtitleDownloadEnabled: boolean;
  subtitleDownloads: SubtitleTrack[];
  video?: PlayableSource;
  /** Primary + backup sources for the watch-page switcher (episodes). */
  sources?: PlayableSource[];
  /** Raw backup rows — admin edit forms only. */
  altSources?: AltSource[];
  downloads?: DownloadInfo;
};

export type EpisodeCardType = EpisodeType & {
  seasonNumber: number;
  anime: { slug: string; titleEn: string; posterUrl: string | null; type: string; category?: string; rating: number | null };
};
