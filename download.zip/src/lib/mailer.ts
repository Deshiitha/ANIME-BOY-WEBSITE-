import nodemailer from "nodemailer";
import { resolveSmtp } from "@/lib/donation-config";

/**
 * Transactional email (password reset). SMTP credentials come from admin
 * Settings (SiteConfig) with environment-variable fallback.
 */

function resetEmailHtml(link: string, minutes: number): string {
  return `<!doctype html>
<html><body style="margin:0;padding:0;background:#050816;font-family:Segoe UI,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#050816;padding:32px 16px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#101827;border-radius:16px;border:1px solid rgba(255,255,255,0.08);padding:36px;">
        <tr><td style="text-align:center;">
          <div style="font-size:22px;font-weight:800;color:#ffffff;letter-spacing:1px;">ANIME <span style="color:#4ADE80;">BOY</span></div>
          <h1 style="margin:22px 0 8px;font-size:20px;color:#ffffff;">Password Reset Request</h1>
          <p style="margin:0;color:#94a3b8;font-size:14px;line-height:1.6;">
            We received a request to reset the password for your ANIME BOY account.<br/>
            Click the button below to choose a new password. This link is valid for <strong style="color:#4ADE80;">${minutes} minutes</strong> and can be used only once.
          </p>
          <div style="margin:28px 0;">
            <a href="${link}" style="display:inline-block;background:#22C55E;color:#04220f;font-weight:700;font-size:15px;padding:14px 30px;border-radius:999px;text-decoration:none;">Reset Password</a>
          </div>
          <p style="margin:0 0 6px;color:#64748b;font-size:12px;">Or copy this link into your browser:</p>
          <p style="margin:0;word-break:break-all;color:#4ADE80;font-size:12px;">${link}</p>
          <p style="margin:26px 0 0;color:#64748b;font-size:12px;line-height:1.6;">
            If you did not request a password reset, you can safely ignore this email — your current password will keep working.
          </p>
        </td></tr>
      </table>
      <p style="margin:18px 0 0;color:#475569;font-size:11px;">© ${new Date().getFullYear()} ANIME BOY · Sinhala anime community</p>
    </td></tr>
  </table>
</body></html>`;
}

export async function sendPasswordResetEmail(to: string, token: string, origin: string): Promise<void> {
  const smtp = await resolveSmtp();
  if (!smtp) {
    throw new Error("SMTP_NOT_CONFIGURED");
  }
  const transporter = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.secure,
    auth: smtp.auth,
  });
  const minutes = Math.round(RESET_TOKEN_TTL_MS / 60_000);
  const link = `${origin}/#/reset-password?token=${encodeURIComponent(token)}`;
  await transporter.sendMail({
    from: smtp.from,
    to,
    subject: `ANIME BOY — Password reset link (valid ${minutes} minutes)`,
    text: `You requested a password reset for your ANIME BOY account. Open this link to choose a new password (valid ${minutes} minutes, single use):\n\n${link}\n\nIf you did not request this, you can safely ignore this email.`,
    html: resetEmailHtml(link, minutes),
  });
}

export const RESET_TOKEN_TTL_MS = 60 * 60_000; // 1 hour
