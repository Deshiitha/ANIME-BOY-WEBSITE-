/**
 * Server-side helper that turns stored video-source fields (DB rows) into a
 * PlayableSource for the public API. Video bytes are never proxied: direct
 * URLs stream straight from the external storage/CDN, embeds load in the
 * provider's own iframe, and private-bucket objects get a short-lived signed
 * URL minted by /api/media/play endpoints after an access check.
 */
import { GetObjectCommand, HeadObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { getS3Config } from "./storage";
import {
  isS3ObjectUrl,
  normalizeSelfFileUrl,
  parseS3Url,
  providerIdFromEmbedUrl,
  safeUrl,
  validateDirectMediaUrl,
  validateDownloadUrl,
  validateEmbedUrl,
  validateSubtitleDownloadUrl,
} from "./media-validate";
import {
  EMBED_PROVIDERS,
  extFromUrl,
  formatFromUrl,
  isTeraBoxHost,
  type AltSource,
  type DownloadInfo,
  type DownloadOptionMeta,
  type PlayableSource,
  type QualityTrack,
  type SubtitleTrack,
} from "./media-types";

export const S3_SIGN_TTL_SEC = Number(process.env.S3_SIGN_TTL_SEC) || 4 * 60 * 60; // 4h

export type VideoSourceFields = {
  id: string;
  videoSource?: string | null;
  videoUrl?: string | null;
  embedUrl?: string | null;
  videoProvider?: string | null;
  videoQualities?: string | null;
  subtitleTracks?: string | null;
  subtitleUrl?: string | null;
  videoThumb?: string | null;
  videoKey?: string | null;
  altSources?: string | null;
};

export function parseJsonArray<T>(raw: string | null | undefined): T[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as T[]) : [];
  } catch {
    return [];
  }
}

function kindOfUrl(url: string): "mp4" | "hls" | "dash" {
  if (/\.m3u8(\?|$)/i.test(url) || /format=m3u8/i.test(url)) return "hls";
  if (/\.mpd(\?|$)/i.test(url) || /format=mpd/i.test(url)) return "dash";
  return "mp4";
}

/**
 * Resolve a stable object key (bucket + key) for signed playback.
 * Accepts s3://bucket/key in videoUrl or a bare videoKey (bucket from env).
 */
export function resolveObjectKey(item: VideoSourceFields): { bucket: string; key: string } | null {
  const fromUrl = item.videoUrl && isS3ObjectUrl(item.videoUrl) ? parseS3Url(item.videoUrl) : null;
  if (fromUrl) return fromUrl;
  if (item.videoKey) {
    const bucket = getS3Config()?.bucket;
    if (bucket) return { bucket, key: item.videoKey.replace(/^\/+/, "") };
  }
  return null;
}

/** Mint a short-lived signed GET URL for a private-bucket object. */
export async function createSignedPlaybackUrl(
  bucket: string,
  key: string
): Promise<{ url: string; expiresAt: string; kind: "mp4" | "hls" | "dash" }> {
  const cfg = getS3Config();
  if (!cfg) throw new Error("Object storage is not configured on this server.");
  const client = new (await import("@aws-sdk/client-s3")).S3Client({
    endpoint: cfg.endpoint,
    region: cfg.region,
    forcePathStyle: true,
    credentials: { accessKeyId: cfg.accessKeyId, secretAccessKey: cfg.secretAccessKey },
  });
  const url = await getSignedUrl(client, new GetObjectCommand({ Bucket: bucket, Key: key }), {
    expiresIn: S3_SIGN_TTL_SEC,
  });
  const kind: "mp4" | "hls" | "dash" = /\.m3u8(\?|$)/i.test(key)
    ? "hls"
    : /\.mpd(\?|$)/i.test(key)
      ? "dash"
      : "mp4";
  return { url, expiresAt: new Date(Date.now() + S3_SIGN_TTL_SEC * 1000).toISOString(), kind };
}

/** Escape a filename for the Content-Disposition header value. */
function dispositionFilename(name: string): string {
  return name.replace(/[^\w.\-]+/g, "-").replace(/^-+|-+$/g, "") || "download";
}

/**
 * Mint a short-lived signed DOWNLOAD URL for a private-bucket object with
 * `Content-Disposition: attachment` so the browser saves (not plays) the file.
 * Also HEADs the object for its size; a missing object rejects with a 404-ish
 * error while other HEAD failures still allow the download to be attempted.
 */
export async function createSignedDownloadUrl(
  bucket: string,
  key: string,
  filename: string
): Promise<{ url: string; expiresAt: string; sizeBytes?: number }> {
  const cfg = getS3Config();
  if (!cfg) throw new Error("Object storage is not configured on this server.");
  const { S3Client } = await import("@aws-sdk/client-s3");
  const client = new S3Client({
    endpoint: cfg.endpoint,
    region: cfg.region,
    forcePathStyle: true,
    credentials: { accessKeyId: cfg.accessKeyId, secretAccessKey: cfg.secretAccessKey },
  });

  let sizeBytes: number | undefined;
  try {
    const head = await client.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
    if (typeof head.ContentLength === "number") sizeBytes = head.ContentLength;
  } catch (e) {
    const name = e instanceof Error ? e.name : "";
    if (name === "NotFound" || name === "NoSuchKey" || name === "NoSuchBucket") {
      throw new Error("NOT_FOUND");
    }
    // HEAD may be denied by the bucket policy while GET is allowed — continue.
  }

  const url = await getSignedUrl(
    client,
    new GetObjectCommand({
      Bucket: bucket,
      Key: key,
      ResponseContentDisposition: `attachment; filename="${dispositionFilename(filename)}"`,
    }),
    { expiresIn: S3_SIGN_TTL_SEC }
  );
  return { url, expiresAt: new Date(Date.now() + S3_SIGN_TTL_SEC * 1000).toISOString(), sizeBytes };
}

/** Format a byte count as a short human label ("842.3 MB"). */
export function formatSizeLabel(bytes?: number): string | undefined {
  if (!bytes || bytes <= 0) return undefined;
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

/* -------------------------------- downloads ------------------------------- */

/** DB columns that describe the (optional) download options of a movie/episode. */
export type DownloadFields = {
  downloadEnabled?: boolean | null;
  downloadUrl?: string | null;
  downloadQualities?: string | null;
  subtitleDownloadEnabled?: boolean | null;
  subtitleDownloads?: string | null;
  subtitleTracks?: string | null; // playback tracks — download fallback (spec: same source)
  subtitleUrl?: string | null; // legacy single playback track
};

export type PickedDownload = {
  url: string;
  label: string;
  lang?: string;
  format: string;
};

/**
 * Enumerate the selectable download options. Index 0 is the main "Video
 * Download URL" (labelled "Original"), followed by any per-quality files.
 * Mirrors buildDownloadInfo — keep both in sync.
 */
export function downloadVideoOptions(item: DownloadFields): { index: number; label: string; url: string; format: string }[] {
  const out: { index: number; label: string; url: string; format: string }[] = [];
  const main = (item.downloadUrl || "").trim();
  if (main) out.push({ index: out.length, label: "Original", url: main, format: formatFromUrl(main) });
  for (const row of parseJsonArray<QualityTrack>(item.downloadQualities)) {
    const url = (row?.url || "").trim();
    if (!url) continue;
    out.push({
      index: out.length,
      label: (row?.label || "").trim() || formatFromUrl(url),
      url,
      format: formatFromUrl(url),
    });
  }
  return out;
}

/**
 * The subtitle tracks configured for PLAYBACK (with the legacy single-track
 * fallback). Downloads reuse this exact list when the admin has not uploaded
 * separate download files, so the downloaded subtitle and the subtitle used
 * for playback always come from the same configured source (spec §7).
 */
export function playbackSubtitleRows(item: Pick<DownloadFields, "subtitleTracks" | "subtitleUrl">): SubtitleTrack[] {
  const rows = parseJsonArray<SubtitleTrack>(item.subtitleTracks).filter((t) => t && (t.url || "").trim());
  if (!rows.length) {
    const legacy = (item.subtitleUrl || "").trim();
    if (legacy) rows.push({ label: "සිංහල", lang: "si", url: legacy });
  }
  return rows;
}

export function downloadSubtitleOptions(item: DownloadFields): { index: number; label: string; lang: string; url: string; format: string }[] {
  const explicit = parseJsonArray<SubtitleTrack>(item.subtitleDownloads).filter((t) => t && (t.url || "").trim());
  const playback = playbackSubtitleRows(item);
  // Union by language: every language that can be PLAYED is downloadable, and
  // an explicitly configured download file overrides the playback file of the
  // same language. The downloaded subtitle therefore always comes from the
  // same configured source that plays over the video (spec §7).
  const byLang = new Map<string, SubtitleTrack>();
  for (const t of playback) byLang.set((t.lang || "si").toLowerCase(), t);
  for (const t of explicit) byLang.set((t.lang || "si").toLowerCase(), t);
  return [...byLang.values()].map((t, i) => {
    const url = (t.url || "").trim();
    return {
      index: i,
      label: (t.label || "").trim() || t.lang || `Track ${i + 1}`,
      lang: (t.lang || "si").trim() || "si",
      url,
      format: formatFromUrl(url, "SRT"),
    };
  });
}

/**
 * Download summary for API responses. Option metadata only — never URLs — so
 * private-bucket identifiers stay server-side until /api/media/download signs
 * one for the current viewer.
 */
export function buildDownloadInfo(item: DownloadFields): DownloadInfo {
  const videoOptions: DownloadOptionMeta[] = item.downloadEnabled
    ? downloadVideoOptions(item).map((o) => ({ index: o.index, label: o.label, format: o.format }))
    : [];
  // Subtitle downloads: admin-configured files when the toggle is on; when no
  // separate download files exist, the playback subtitle tracks are offered
  // automatically (identical source as what plays over the video).
  const explicitSubs = parseJsonArray<SubtitleTrack>(item.subtitleDownloads).filter((t) => t && (t.url || "").trim());
  const subtitlesAllowed = explicitSubs.length ? !!item.subtitleDownloadEnabled : playbackSubtitleRows(item).length > 0;
  const subOptions: (DownloadOptionMeta & { lang: string })[] = subtitlesAllowed
    ? downloadSubtitleOptions(item).map((o) => ({ index: o.index, label: o.label, lang: o.lang, format: o.format }))
    : [];
  return {
    video: { enabled: videoOptions.length > 0, options: videoOptions },
    subtitles: { enabled: subOptions.length > 0, options: subOptions },
  };
}

/** Fetch one download option by kind+index (used by the resolve endpoint). */
export function pickDownloadOption(
  item: DownloadFields,
  kind: "video" | "subtitle",
  index: number
): PickedDownload | null {
  if (kind === "video") {
    if (!item.downloadEnabled) return null;
    const opt = downloadVideoOptions(item).find((o) => o.index === index);
    return opt ? { url: opt.url, label: opt.label, format: opt.format } : null;
  }
  const explicitSubs = parseJsonArray<SubtitleTrack>(item.subtitleDownloads).filter((t) => t && (t.url || "").trim());
  const allowed = explicitSubs.length ? !!item.subtitleDownloadEnabled : playbackSubtitleRows(item).length > 0;
  if (!allowed) return null;
  const opt = downloadSubtitleOptions(item).find((o) => o.index === index);
  return opt ? { url: opt.url, label: opt.label, lang: opt.lang, format: opt.format } : null;
}

/**
 * Shared admin-API normaliser for per-quality download files. Unlike playback
 * quality variants, s3:// private-bucket keys are allowed and .m3u8 streams
 * are rejected (a download must be a single file).
 */
export function normalizeDownloadQualityList(
  input: QualityTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: QualityTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateDownloadUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Download quality "${row?.label || "?"}": ${problem}` };
    clean.push({ label: (row?.label || "").trim() || formatFromUrl(url), url });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

/** Shared admin-API normaliser for downloadable subtitle files (SRT/VTT). */
export function normalizeSubtitleDownloadList(
  input: SubtitleTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: SubtitleTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateSubtitleDownloadUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Subtitle download "${row?.label || "?"}": ${problem}` };
    clean.push({
      label: (row?.label || "").trim() || "Subtitles",
      lang: (row?.lang || "si").trim() || "si",
      url,
    });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

/** Validate the enabled download toggles against the configured files. */
export function downloadConfigErrors(
  input: {
    downloadEnabled?: boolean;
    downloadUrl?: string | null;
    downloadQualities?: string | null;
    subtitleDownloadEnabled?: boolean;
    subtitleDownloads?: string | null;
  },
  raw?: { downloadUrl?: string; downloadQualities?: unknown; subtitleDownloads?: unknown }
): string[] {
  const errors: string[] = [];
  const hasVideoFile =
    !!input.downloadUrl || parseJsonArray<QualityTrack>(input.downloadQualities).length > 0;
  if (input.downloadEnabled && !hasVideoFile) {
    errors.push("Video download is enabled but no download URL is set. Add a downloadable MP4/WebM file URL.");
  }
  const hasSubs = parseJsonArray<SubtitleTrack>(input.subtitleDownloads).length > 0;
  if (input.subtitleDownloadEnabled && !hasSubs) {
    errors.push("Subtitle download is enabled but no subtitle download file is configured.");
  }
  // Validate the raw main URL even when the toggle is off, so a typo cannot be saved silently.
  const mainUrl = normalizeSelfFileUrl((raw?.downloadUrl ?? input.downloadUrl ?? "").trim());
  if (mainUrl) {
    const problem = validateDownloadUrl(mainUrl);
    if (problem && !problem.startsWith("warn:")) errors.push(`Download URL: ${problem}`);
  }
  return errors;
}

/** Build a meaningful, attachment-safe download filename. */
export function buildDownloadFilename(opts: {
  titleEn: string;
  seasonNumber?: number | null;
  episodeNumber?: number | null;
  label?: string;
  url: string;
  format: string;
  lang?: string;
}): string {
  const ascii = (s: string) =>
    s
      .normalize("NFKD")
      .replace(/[^\x20-\x7E]/g, "")
      .replace(/[^\w.\-]+/g, "-")
      .replace(/^-+|-+$/g, "");
  const parts = [ascii(opts.titleEn) || "anime"];
  if (opts.seasonNumber && opts.episodeNumber) {
    parts.push(`S${String(opts.seasonNumber).padStart(2, "0")}E${String(opts.episodeNumber).padStart(2, "0")}`);
  }
  const label = ascii(opts.label || "");
  if (label && !/^(original|file)$/i.test(label)) parts.push(label);
  if (opts.lang) parts.push(ascii(opts.lang) || "sub");
  const ext = extFromUrl(opts.url, opts.format);
  return `${parts.join("-")}${ext ? `.${ext.replace(".", "")}` : ""}`;
}

/**
 * Build the playable source the client player consumes. `scope` is used for
 * the signed-playback endpoint path; `posterFallback` is used when no
 * dedicated video thumbnail exists.
 */
export function buildPlayableSource(
  item: VideoSourceFields,
  scope: "anime" | "episode",
  posterFallback?: string | null
): PlayableSource {
  const source = (item.videoSource || "upload").toLowerCase();
  // Only admin-enabled tracks reach the viewer (see also enabledTracks() client-side).
  const subtitles: SubtitleTrack[] = parseJsonArray<SubtitleTrack>(item.subtitleTracks).filter(
    (t) => t && t.url && t.enabled !== false
  );
  if (!subtitles.length && item.subtitleUrl) {
    subtitles.push({ label: "සිංහල", lang: "si", url: item.subtitleUrl });
  }
  const qualities = parseJsonArray<QualityTrack>(item.videoQualities).filter((q) => q && q.url);
  const poster = item.videoThumb || posterFallback || null;

  if (source === "embed") {
    if (!item.embedUrl) return { kind: "none" };
    const provider = item.videoProvider || providerIdFromEmbedUrl(item.embedUrl) || "embed";
    const def = EMBED_PROVIDERS[provider];

    // No-iframe providers (TeraBox): never render a broken iframe. Play an
    // authorized direct streaming URL when the admin saved one; otherwise
    // hand the viewer a clearly labelled "Watch on <provider>" button.
    if (def?.noIframe) {
      const page = {
        provider,
        providerLabel: def.label,
        pageUrl: item.embedUrl,
        note: `This ${def.label} file is streamed/played from ${def.label} — playback and download follow ${def.label}'s own player and permissions.`,
      };
      const direct = directSourceOrNull(item, qualities, subtitles, poster, scope);
      if (direct) return { ...direct, externalPage: page, sourceId: "primary" };
      return { kind: "external_page", ...page, sourceId: "primary" };
    }

    // Embeds carry their subtitle list too: the player shows the CC menu with
    // the languages available for this title, and for Google Drive it can
    // switch to the official HTML5 stream where the site renders subtitles.
    return {
      kind: "embed",
      provider,
      providerLabel: def?.label || provider,
      embedUrl: item.embedUrl,
      subtitles,
      sourceId: "primary",
    };
  }

  if (source === "external" && item.videoUrl) {
    if (isS3ObjectUrl(item.videoUrl)) {
      return { kind: "signed", signUrl: `/api/media/play/${scope}/${item.id}`, subtitles, poster, sourceId: "primary" };
    }
    return { kind: kindOfUrl(item.videoUrl), url: item.videoUrl, qualities, subtitles, poster, sourceId: "primary" };
  }

  // "upload" — file uploaded through this site (local /api/files path or a
  // previously stored absolute URL, e.g. public object-storage URL).
  if (item.videoUrl) {
    return { kind: kindOfUrl(item.videoUrl), url: item.videoUrl, qualities, subtitles, poster, sourceId: "primary" };
  }

  // Private-bucket key stored without an s3:// URL.
  if (item.videoKey && resolveObjectKey(item)) {
    return { kind: "signed", signUrl: `/api/media/play/${scope}/${item.id}`, subtitles, poster, sourceId: "primary" };
  }

  return { kind: "none" };
}

/**
 * For no-iframe providers: turn the optional authorized streaming URL
 * (item.videoUrl) into a playable direct/signed source, ignoring values that
 * are just the provider's own share page.
 */
function directSourceOrNull(
  item: VideoSourceFields,
  qualities: QualityTrack[],
  subtitles: SubtitleTrack[],
  poster: string | null,
  scope: "anime" | "episode"
): Extract<PlayableSource, { kind: "mp4" | "hls" | "dash" | "signed" }> | null {
  const url = (item.videoUrl || "").trim();
  if (!url) return null;
  if (isS3ObjectUrl(url)) {
    return { kind: "signed", signUrl: `/api/media/play/${scope}/${item.id}`, subtitles, poster };
  }
  // Site uploads are referenced as relative /api/files/… paths — playable.
  if (url.startsWith("/api/files/")) {
    return { kind: kindOfUrl(url), url, qualities, subtitles, poster };
  }
  const u = safeUrl(url);
  if (!u) return null; // relative/invalid — not a usable stream
  if (isTeraBoxHost(u.hostname)) return null; // share page, not a stream
  return { kind: kindOfUrl(url), url, qualities, subtitles, poster };
}

function safeUrlOf(raw: string): URL | null {
  try {
    return new URL(raw);
  } catch {
    return null;
  }
}

/* --------------------------- backup/alt sources --------------------------- */

const ALT_LABEL_FALLBACKS: Record<string, string> = {
  youtube: "YouTube",
  vimeo: "Vimeo",
  dailymotion: "Dailymotion",
  gdrive: "Google Drive",
  streamable: "Streamable",
  terabox: "TeraBox",
};

/**
 * Shared admin-API normaliser for the backup/alternative source list.
 * Each row must resolve to exactly one usable playback method:
 *  - "external": a direct HTTPS media URL (MP4/HLS/DASH) or s3://bucket/key
 *  - "embed":    a trusted provider embed/share URL (TeraBox included —
 *                it resolves to the honest watch-on-provider fallback)
 * Share-page URLs from other providers are auto-converted to their official
 * embed where one exists (Google Drive, YouTube…), never saved as streams.
 */
export function normalizeAltSourceList(
  input: AltSource[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: AltSource[] = [];
  const seenIds = new Set<string>();
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const label = (row?.label || "").trim();
    const sourceType = row?.sourceType === "embed" ? "embed" : "external";

    if (sourceType === "embed") {
      const parsed = validateEmbedUrl((row?.embedUrl || "").trim());
      if ("error" in parsed)
        return { value: null, error: `Backup source "${label || `#${i + 1}`}": ${parsed.error}` };
      const id = (row?.id || "").trim() || `alt-${clean.length + 1}-${parsed.provider}`;
      if (seenIds.has(id)) return { value: null, error: `Backup source ids must be unique ("${id}" is duplicated).` };
      seenIds.add(id);
      clean.push({
        id,
        label: label || ALT_LABEL_FALLBACKS[parsed.provider] || parsed.provider,
        sourceType: "embed",
        embedUrl: parsed.embedUrl,
        provider: parsed.provider,
        url: null,
      });
      continue;
    }

    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url)
      return {
        value: null,
        error: `Backup source "${label || `#${i + 1}`}" has no URL. Add a direct media URL or switch it to a provider embed.`,
      };
    if (isS3ObjectUrl(url)) {
      if (!parseS3Url(url))
        return { value: null, error: `Backup source "${label || `#${i + 1}`}": use s3://bucket/key for private-bucket objects.` };
    } else {
      const problem = validateDirectMediaUrl(url);
      if (problem && !problem.startsWith("warn:"))
        return { value: null, error: `Backup source "${label || `#${i + 1}`}": ${problem}` };
    }
    const id = (row?.id || "").trim() || `alt-${clean.length + 1}-direct`;
    if (seenIds.has(id)) return { value: null, error: `Backup source ids must be unique ("${id}" is duplicated).` };
    seenIds.add(id);
    clean.push({ id, label: label || "Server", sourceType: "external", url, embedUrl: null, provider: null });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

/**
 * Resolve every backup source of a movie/episode into playable sources for
 * the watch page. Each result carries its alt id + admin label so the client
 * can render the source switcher. Entries that would not actually play
 * (empty/invalid URL, share page saved as a stream) are skipped — the player
 * never receives a fake source.
 */
export function buildAltSources(
  item: VideoSourceFields,
  scope: "anime" | "episode",
  posterFallback?: string | null
): PlayableSource[] {
  const rows = parseJsonArray<AltSource>(item.altSources);
  if (!rows.length) return [];
  const subtitles: SubtitleTrack[] = parseJsonArray<SubtitleTrack>(item.subtitleTracks).filter(
    (t) => t && t.url && t.enabled !== false
  );
  if (!subtitles.length && item.subtitleUrl) {
    subtitles.push({ label: "සිංහල", lang: "si", url: item.subtitleUrl });
  }
  const out: PlayableSource[] = [];

  for (const row of rows) {
    const label = (row.label || "").trim();
    if (row.sourceType === "embed" && row.embedUrl) {
      const provider = row.provider || providerIdFromEmbedUrl(row.embedUrl) || "embed";
      const def = EMBED_PROVIDERS[provider];
      if (def?.noIframe) {
        // TeraBox-style: authorized direct stream when configured, else the
        // official share page — exactly like the primary embed flow.
        const page = {
          provider,
          providerLabel: def.label,
          pageUrl: row.embedUrl,
          note: `This ${def.label} file is streamed/played from ${def.label} — playback and download follow ${def.label}'s own player and permissions.`,
        };
        const direct = altDirectSourceOrNull(row.url || "", scope, item.id, row.id);
        if (direct) {
          if (direct.kind === "signed") {
            out.push({ kind: "signed", signUrl: direct.signUrl, subtitles, externalPage: page, sourceId: row.id, sourceLabel: label });
          } else {
            out.push({ kind: direct.kind, url: direct.url, subtitles, externalPage: page, sourceId: row.id, sourceLabel: label });
          }
        } else {
          out.push({ kind: "external_page", ...page, sourceId: row.id, sourceLabel: label });
        }
        continue;
      }
      out.push({
        kind: "embed",
        provider,
        providerLabel: def?.label || provider,
        embedUrl: row.embedUrl,
        subtitles,
        sourceId: row.id,
        sourceLabel: label,
      });
      continue;
    }

    if (row.sourceType === "external" && row.url) {
      const direct = altDirectSourceOrNull(row.url, scope, item.id, row.id);
      if (direct) {
        if (direct.kind === "signed") {
          out.push({ kind: "signed", signUrl: direct.signUrl, subtitles, sourceId: row.id, sourceLabel: label });
        } else {
          out.push({
            kind: direct.kind,
            url: direct.url,
            qualities: parseJsonArray<QualityTrack>(item.videoQualities).filter((q) => q && q.url),
            subtitles,
            poster: item.videoThumb || posterFallback || null,
            sourceId: row.id,
            sourceLabel: label,
          });
        }
      }
    }
  }
  return out;
}

/** Turn one alt-source URL into a playable direct/signed source (null when it cannot play). */
function altDirectSourceOrNull(
  url: string,
  scope: "anime" | "episode",
  itemId: string,
  altId: string
): { kind: "mp4" | "hls" | "dash"; url: string } | { kind: "signed"; signUrl: string } | null {
  const clean = (url || "").trim();
  if (!clean) return null;
  if (isS3ObjectUrl(clean)) {
    return { kind: "signed", signUrl: `/api/media/play/${scope}/${itemId}?src=${encodeURIComponent(altId)}` };
  }
  // Site uploads are referenced as relative /api/files/… paths — always playable.
  if (clean.startsWith("/api/files/")) return { kind: kindOfUrl(clean), url: clean };
  const u = safeUrl(clean);
  if (!u) return null;
  if (isTeraBoxHost(u.hostname)) return null; // share page stored in the wrong field — never a stream
  if (u.protocol !== "https:") return null;
  return { kind: kindOfUrl(clean), url: clean };
}
