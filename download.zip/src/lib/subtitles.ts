/**
 * Shared subtitle utilities for the ANIME BOY player and admin editor.
 *
 * - SRT → WebVTT conversion (browsers only render WebVTT TextTracks).
 * - Cue parsing for the admin "Preview" panel (first cues + timings).
 * - Per-session subtitle preference (ON/OFF + language) — sessionStorage, so
 *   the choice survives episode navigation but resets with a new browsing
 *   session.
 * - Per-device display styling (size / colour / background opacity / position)
 *   — localStorage, applied instantly by the player's custom overlay.
 *
 * No server-only imports — this file is used by both client components and
 * server routes.
 */
import type { SubtitleTrack } from "./media-types";

/* ------------------------------- conversion -------------------------------- */

/** True when the payload is already WebVTT (header allowed to be preceded by BOM/whitespace). */
export function looksLikeVtt(text: string): boolean {
  return text.replace(/^\uFEFF/, "").trimStart().startsWith("WEBVTT");
}

/**
 * Convert SRT subtitle text into WebVTT.
 * Handles BOM, CRLF, `HH:MM:SS,mmm` → `HH:MM:SS.mmm`, adds the WEBVTT header,
 * strips SRT cue coordinates (`X1:…`) that WebVTT does not understand.
 * Already-WebVTT input is returned unchanged (header normalised).
 */
export function srtToVtt(input: string): string {
  const body = input
    .replace(/^\uFEFF/, "")
    .replace(/\r+/g, "")
    .replace(/^WEBVTT.*$/im, "") // drop an existing header block, we re-add it
    .replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, "$1.$2")
    .replace(/^\s*X1:\d+.*$/gim, ""); // SRT image coordinates — invalid in VTT
  const trimmed = body.replace(/^\s+/, "");
  return `WEBVTT\n\n${trimmed}`;
}

/** Normalise any supported subtitle payload (SRT / VTT / WebVTT) into WebVTT text. */
export function toVtt(raw: string): string {
  return looksLikeVtt(raw) ? raw : srtToVtt(raw);
}

/** Human format label from a subtitle URL/file name ("SRT" / "VTT"). */
export function subtitleFormatFromUrl(url: string): string {
  const clean = url.split(/[?#]/)[0].toLowerCase();
  if (clean.endsWith(".srt")) return "SRT";
  if (clean.endsWith(".vtt")) return "VTT";
  return "SUB";
}

/* ------------------------------ cue parsing -------------------------------- */

export type ParsedCue = { start: string; end: string; lines: string[] };

const TS_RE =
  /^(\d{1,2}:)?\d{1,2}:\d{2}[.,]\d{3}\s+-->\s+(\d{1,2}:)?\d{1,2}:\d{2}[.,]\d{3}/;

/**
 * Minimal cue parser used by the admin preview: returns the first `max` cues
 * of an SRT or VTT payload with readable timings and plain-text lines
 * (VTT voice/span tags stripped).
 */
export function parseCuePreview(raw: string, max = 3): ParsedCue[] {
  const vtt = toVtt(raw);
  const blocks = vtt
    .replace(/^\uFEFF/, "")
    .split(/\n{2,}/)
    .map((b) => b.trim())
    .filter(Boolean);
  const cues: ParsedCue[] = [];
  for (const block of blocks) {
    const lines = block.split("\n");
    const tsIdx = lines.findIndex((l) => TS_RE.test(l));
    if (tsIdx === -1) continue;
    const [rawStart, rawEnd] = lines[tsIdx].split("-->");
    const fmt = (t: string | undefined) => {
      if (!t) return "";
      const m = t.trim().match(/((\d{1,2}:)?\d{1,2}:\d{2})[.,]\d{3}/);
      return m ? m[1] : t.trim().slice(0, 8);
    };
    const text = lines
      .slice(tsIdx + 1)
      .join("\n")
      .replace(/<[^>]+>/g, "") // strip VTT inline tags
      .trim();
    if (!text) continue;
    cues.push({ start: fmt(rawStart), end: fmt(rawEnd), lines: text.split("\n") });
    if (cues.length >= max) break;
  }
  return cues;
}

/* --------------------------- session preference ----------------------------- */

const PREF_KEY = "animeboy:sub-pref:v1";
const STYLE_KEY = "animeboy:sub-style:v1";

export type SubPref = { on: boolean; lang: string | null };

/** Subtitle ON/OFF + language remembered for this browsing session. */
export function readSubPref(): SubPref {
  try {
    const raw = sessionStorage.getItem(PREF_KEY);
    if (raw) {
      const p = JSON.parse(raw) as SubPref;
      if (typeof p.on === "boolean") return { on: p.on, lang: p.lang || null };
    }
  } catch {
    /* private mode / blocked storage — defaults apply */
  }
  return { on: false, lang: null };
}

export function writeSubPref(pref: SubPref): void {
  try {
    sessionStorage.setItem(PREF_KEY, JSON.stringify(pref));
  } catch {
    /* ignore */
  }
}

/* ------------------------- file validation (shared) ------------------------ */

export type SubtitleValidation = { ok: boolean; cueCount: number; error?: string };

/**
 * Validate an SRT / WebVTT payload before it is attached anywhere: the admin
 * upload flow refuses invalid files (they are never marked as uploaded) and
 * the player's "Load Subtitle File" feature uses the same check for files the
 * visitor picks from their own device.
 */
export function validateSubtitleText(raw: string): SubtitleValidation {
  const text = raw.replace(/^\uFEFF/, "");
  if (!text.trim()) return { ok: false, cueCount: 0, error: "The file is empty." };

  const vtt = toVtt(text);
  const blocks = vtt
    .split(/\n{2,}/)
    .map((b) => b.trim())
    .filter(Boolean);

  let cueCount = 0;
  let firstProblem: string | null = null;
  for (const block of blocks) {
    const lines = block.split("\n");
    const tsIdx = lines.findIndex((l) => TS_RE.test(l));
    if (tsIdx === -1) continue;
    const [rawStart, rawEnd] = lines[tsIdx].split("-->");
    const toMs = (t: string | undefined): number | null => {
      if (!t) return null;
      const m = t.trim().match(/^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{3})$/);
      if (!m) return null;
      return ((Number(m[1]) || 0) * 3600 + Number(m[2]) * 60 + Number(m[3])) * 1000 + Number(m[4]);
    };
    const body = lines
      .slice(tsIdx + 1)
      .join("\n")
      .replace(/<[^>]+>/g, "")
      .trim();
    if (!body) {
      firstProblem = firstProblem || "A cue has a timestamp but no text.";
      continue;
    }
    const startMs = toMs(rawStart);
    const endMs = toMs(rawEnd);
    if (startMs == null || endMs == null) {
      firstProblem = firstProblem || `Unreadable timestamp: “${lines[tsIdx].trim()}”.`;
      continue;
    }
    if (endMs <= startMs) {
      firstProblem = firstProblem || "A cue ends before it starts — check the timestamps.";
      continue;
    }
    cueCount++;
  }

  if (cueCount === 0) {
    return {
      ok: false,
      cueCount: 0,
      error:
        firstProblem ||
        "No valid cues found — expected SRT or WebVTT cues (e.g. 00:00:01,000 --> 00:00:03,000 followed by text).",
    };
  }
  return { ok: true, cueCount };
}

/* ---------------------------- display settings ------------------------------ */

export type SubStyle = {
  size: "sm" | "md" | "lg" | "xl";
  color: string; // text colour
  bg: number; // background opacity 0 – 1
  position: "bottom" | "mid" | "top";
  font: "sans" | "serif" | "mono"; // font family
  bold: boolean; // font weight
};

export const DEFAULT_SUB_STYLE: SubStyle = {
  size: "md",
  color: "#FFFFFF",
  bg: 0.55,
  position: "bottom",
  font: "sans",
  bold: false,
};

/** Font stacks per style option (Cyrillic/Sinhala-safe system fallbacks). */
export const SUB_FONT_STACKS: Record<SubStyle["font"], string> = {
  sans: "'Noto Sans', 'Noto Sans Sinhala', system-ui, -apple-system, 'Segoe UI', sans-serif",
  serif: "'Noto Serif', 'Noto Serif Sinhala', Georgia, 'Times New Roman', serif",
  mono: "'Noto Sans Mono', ui-monospace, Menlo, Consolas, monospace",
};

export const SUB_SIZES: { id: SubStyle["size"]; label: string; px: number }[] = [
  { id: "sm", label: "S", px: 15 },
  { id: "md", label: "M", px: 20 },
  { id: "lg", label: "L", px: 27 },
  { id: "xl", label: "XL", px: 36 },
];

export const SUB_COLORS: { id: string; label: string }[] = [
  { id: "#FFFFFF", label: "White" },
  { id: "#FFE066", label: "Yellow" },
  { id: "#7FDBFF", label: "Cyan" },
  { id: "#4ADE80", label: "Green" },
];

export const SUB_BG_LEVELS: { id: number; label: string }[] = [
  { id: 0, label: "0%" },
  { id: 0.25, label: "25%" },
  { id: 0.5, label: "50%" },
  { id: 0.75, label: "75%" },
  { id: 1, label: "100%" },
];

export const SUB_POSITIONS: { id: SubStyle["position"]; label: string }[] = [
  { id: "bottom", label: "Bottom" },
  { id: "mid", label: "Middle" },
  { id: "top", label: "Top" },
];

export const SUB_FONTS: { id: SubStyle["font"]; label: string }[] = [
  { id: "sans", label: "Sans" },
  { id: "serif", label: "Serif" },
  { id: "mono", label: "Mono" },
];

export function readSubStyle(): SubStyle {
  try {
    const raw = localStorage.getItem(STYLE_KEY);
    if (raw) {
      const s = JSON.parse(raw) as Partial<SubStyle>;
      return {
        size: SUB_SIZES.some((x) => x.id === s.size) ? (s.size as SubStyle["size"]) : DEFAULT_SUB_STYLE.size,
        color: typeof s.color === "string" ? s.color : DEFAULT_SUB_STYLE.color,
        bg: typeof s.bg === "number" ? Math.min(1, Math.max(0, s.bg)) : DEFAULT_SUB_STYLE.bg,
        position: SUB_POSITIONS.some((x) => x.id === s.position)
          ? (s.position as SubStyle["position"])
          : DEFAULT_SUB_STYLE.position,
        font: SUB_FONTS.some((x) => x.id === s.font) ? (s.font as SubStyle["font"]) : DEFAULT_SUB_STYLE.font,
        bold: typeof s.bold === "boolean" ? s.bold : DEFAULT_SUB_STYLE.bold,
      };
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_SUB_STYLE;
}

export function writeSubStyle(style: SubStyle): void {
  try {
    localStorage.setItem(STYLE_KEY, JSON.stringify(style));
  } catch {
    /* ignore */
  }
}

/* --------------------------- track list helpers ----------------------------- */

/** Only subtitle rows the admin has not disabled are shown to viewers. */
export function enabledTracks(tracks: SubtitleTrack[] | undefined | null): SubtitleTrack[] {
  return (tracks || []).filter((t) => t && (t.url || "").trim() && t.enabled !== false);
}

/** Index of the track matching the session language preference (else first). */
export function trackIndexForLang(tracks: SubtitleTrack[], lang: string | null): number {
  if (lang) {
    const i = tracks.findIndex((t) => (t.lang || "").toLowerCase() === lang.toLowerCase());
    if (i >= 0) return i;
  }
  return tracks.length ? 0 : -1;
}
