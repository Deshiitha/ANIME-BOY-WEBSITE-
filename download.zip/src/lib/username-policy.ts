/**
 * Username policy shared by the Change Username UI, the availability API,
 * the change-username API and registration — single source of truth.
 *
 * Rules (per spec):
 *  - 3–20 characters (after trimming)
 *  - letters, numbers and underscores only
 *  - never empty
 *  - unique across accounts (checked against the database, case-insensitively)
 *  - reserved / staff-impersonating names are blocked for regular users
 *    (the site administrator is exempt — it is their own site identity)
 */

export const USERNAME_MIN = 3;
export const USERNAME_MAX = 20;
export const USERNAME_PATTERN = /^[A-Za-z0-9_]+$/;

/** Case-insensitively reserved usernames (regular users cannot claim these). */
const RESERVED_EXACT = new Set([
  "admin",
  "administrator",
  "system",
  "sysadmin",
  "root",
  "superuser",
  "moderator",
  "mod",
  "staff",
  "official",
  "owner",
  "webmaster",
  "hostmaster",
  "postmaster",
  "support",
  "help",
  "helpdesk",
  "security",
  "abuse",
  "api",
  "animeboy",
  "anime_boy",
  "animeboy_admin",
  "null",
  "undefined",
  "none",
  "anonymous",
  "guest",
  "user",
  "users",
  "account",
]);

/** Reserved prefixes (regular users cannot start a username with these). */
const RESERVED_PREFIXES = ["admin"];

export type UsernameCheck = {
  ok: boolean;
  message: string;
  /** The cleaned value (trimmed) — only meaningful for format checks. */
  value: string;
};

/** Format-only validation (no database involvement). */
export function validateUsernameFormat(raw: string): UsernameCheck {
  const value = (raw || "").trim().replace(/\s+/g, " ");
  if (!value) {
    return { ok: false, message: "Please enter a username — it cannot be empty.", value };
  }
  if (value.includes(" ")) {
    return { ok: false, message: "Usernames can only contain letters, numbers and underscores.", value };
  }
  if (value.length < USERNAME_MIN || value.length > USERNAME_MAX) {
    return {
      ok: false,
      message: `Username must be between ${USERNAME_MIN} and ${USERNAME_MAX} characters.`,
      value,
    };
  }
  if (!USERNAME_PATTERN.test(value)) {
    return { ok: false, message: "Usernames can only contain letters, numbers and underscores.", value };
  }
  return { ok: true, message: "", value };
}

/** Is this username reserved for the given role? (Admins are exempt.) */
export function isReservedUsername(value: string, isAdmin: boolean): boolean {
  if (isAdmin) return false;
  const lower = value.toLowerCase();
  if (RESERVED_EXACT.has(lower)) return true;
  return RESERVED_PREFIXES.some((p) => lower.startsWith(p));
}

export function reservedUsernameMessage(): string {
  return "That username is reserved and cannot be used. Please choose another one.";
}

/**
 * Full client-side validation. Database uniqueness is checked separately by
 * the availability API / change endpoint (the DB unique index is the final
 * authority), so this stays usable offline and at registration time.
 */
export function validateUsername(raw: string, isAdmin = false): UsernameCheck {
  const check = validateUsernameFormat(raw);
  if (!check.ok) return check;
  if (isReservedUsername(check.value, isAdmin)) {
    return { ok: false, message: reservedUsernameMessage(), value: check.value };
  }
  return check;
}
