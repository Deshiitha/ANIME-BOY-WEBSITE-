/**
 * Shared video-source types used by both the server (API serialisation)
 * and the client (player + admin UI). No server-only imports here.
 */

export type VideoSourceKind = "upload" | "external" | "embed";

export type QualityTrack = { label: string; url: string };

export type SubtitleTrack = {
  label: string;
  lang: string;
  url: string;
  /** Admin availability switch — `false` hides the track from viewers. Default: enabled. */
  enabled?: boolean;
};

/**
 * One admin-configured backup/alternative playback source stored in the
 * `altSources` JSON column (movies and episodes). The PRIMARY source lives in
 * the classic videoSource/videoUrl/embedUrl columns; everything else —
 * "Server 2", "Google Drive", "TeraBox", direct MP4/HLS backups — lives here.
 * TeraBox share links are stored as-is (sourceType "embed", provider
 * "terabox") and always resolve to an honest watch-on-TeraBox fallback unless
 * the admin also configures a streamable source for the same title.
 */
export type AltSource = {
  id: string; // stable id used by the player switcher and signed playback (?src=)
  label: string; // button label on the watch page ("Server 2", "Google Drive", …)
  sourceType: "external" | "embed";
  url?: string | null; // direct MP4/HLS/DASH or s3://bucket/key (external only)
  embedUrl?: string | null; // provider embed/share URL (embed only)
  provider?: string | null; // youtube | vimeo | dailymotion | gdrive | streamable | terabox
};

/** What the watch-page player receives from the public API. */
export type ExternalPage = {
  provider: string;
  providerLabel: string;
  pageUrl: string;
  note?: string;
};

/**
 * Identity of one entry in the watch-page source switcher ("Server 1", "TeraBox"…).
 * Present (optionally) on EVERY PlayableSource so the client can render the
 * switcher without narrowing the union.
 */
export type SourceTag = {
  /** Alt-source id, or "primary" for the main source. */
  sourceId?: string;
  /** Admin-configured button label (backup sources only). */
  sourceLabel?: string;
};

export type PlayableSource = SourceTag &
  (
    | { kind: "none" }
    /** Progressive direct file (MP4 / WebM / …) streamed from its origin. */
    | {
        kind: "mp4";
        url: string;
        qualities?: QualityTrack[];
        subtitles?: SubtitleTrack[];
        poster?: string | null;
        externalPage?: ExternalPage;
      }
    /** HTTP Live Streaming playlist (.m3u8). */
    | {
        kind: "hls";
        url: string;
        qualities?: QualityTrack[];
        subtitles?: SubtitleTrack[];
        poster?: string | null;
        externalPage?: ExternalPage;
      }
    /** MPEG-DASH manifest (.mpd) — played through dash.js where supported. */
    | {
        kind: "dash";
        url: string;
        qualities?: QualityTrack[];
        subtitles?: SubtitleTrack[];
        poster?: string | null;
        externalPage?: ExternalPage;
      }
    /** Trusted provider iframe embed (YouTube, Vimeo, …). */
    | {
        kind: "embed";
        provider: string;
        providerLabel: string;
        embedUrl: string;
        /** Languages configured for this title — powers the CC menu on the embed shell. */
        subtitles?: SubtitleTrack[];
      }
    /**
     * Provider that does not permit in-site embedding (e.g. TeraBox). The watch
     * page shows a clearly labelled "Watch on <provider>" button instead of a
     * broken player.
     */
    | ({ kind: "external_page" } & ExternalPage)
    /**
     * Private-bucket object. `signUrl` is a same-origin endpoint that mints a
     * short-lived signed GET URL after checking the viewer's access. The player
     * re-fetches it when the signed URL expires so seeking keeps working.
     */
    | {
        kind: "signed";
        signUrl: string;
        subtitles?: SubtitleTrack[];
        poster?: string | null;
        externalPage?: ExternalPage;
      }
  );

export type MediaProbeResult = {
  ok: boolean;
  status?: number;
  finalUrl?: string;
  contentType?: string;
  contentLength?: string;
  acceptRanges?: string;
  contentDisposition?: string;
  looksLikeHls?: boolean;
  looksLikeHtml?: boolean;
  isHtml?: boolean;
  error?: string;
};

/* -------------------------------- downloads ------------------------------- */

/** One selectable download entry as exposed to the watch page (never carries URLs). */
export type DownloadOptionMeta = { index: number; label: string; format: string };

/** Download availability summary attached to anime/episode API responses. */
export type DownloadInfo = {
  video: { enabled: boolean; options: DownloadOptionMeta[] };
  subtitles: { enabled: boolean; options: (DownloadOptionMeta & { lang: string })[] };
};

/** Response of the /api/media/download resolver: where the browser should fetch the file. */
export type ResolvedDownload = {
  /** direct = provider forces the download; open = show the download dialog. */
  mode: "direct" | "open";
  url: string;
  filename: string;
  format: string;
  sizeBytes?: number;
  sizeLabel?: string;
  note?: string;
  /**
   * Which storage host serves this file — the download dialog adapts to it
   * (Google Drive gets its own branded "Download Your Video" dialog, TeraBox
   * explains its official-page handoff, anything else gets a neutral dialog).
   */
  provider?: "googledrive" | "terabox" | "other";
  /**
   * The download URL exactly as the admin stored it for this title. The
   * "Copy Download Link" button always copies this — never the derived
   * direct-download URL that the primary button navigates to.
   */
  copyUrl?: string;
};

/**
 * Google Drive hosts that serve or gate downloads. Covers the classic
 * drive.google.com / docs.google.com endpoints, the drive.usercontent.google.com
 * download endpoint (where uc?export=download redirects for large files) and
 * googleusercontent.com CDN hosts. Drives the provider-aware download dialog.
 */
export function isGoogleDriveHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^www\./, "");
  return (
    h === "drive.google.com" ||
    h === "docs.google.com" ||
    h === "drive.usercontent.google.com" ||
    h.endsWith(".drive.google.com") ||
    h.endsWith(".docs.google.com") ||
    h.endsWith(".googleusercontent.com") ||
    h.endsWith(".usercontent.google.com")
  );
}

/** Storage-provider identity for a download URL, used by the download dialog. */
export function downloadProviderFromHost(hostname: string): "googledrive" | "terabox" | "other" {
  if (isGoogleDriveHost(hostname)) return "googledrive";
  if (isTeraBoxHost(hostname)) return "terabox";
  return "other";
}

/**
 * Extract the file id from any Google Drive URL form the admin may have
 * stored:
 *  - /file/d/FILE_ID/view?usp=sharing   (the "Copy link" share form)
 *  - uc?export=download&id=FILE_ID      (the direct download endpoint)
 *  - open?id=FILE_ID                    (legacy Drive open endpoint)
 *  - drive.usercontent.google.com/download?id=FILE_ID&…
 * Returns null when the URL is not a recognisable Drive file link.
 */
export function driveFileIdFromUrl(rawUrl: string): string | null {
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase().replace(/^www\./, "");
    if (!isGoogleDriveHost(host)) return null;
    const byPath = u.pathname.match(/\/d\/([A-Za-z0-9_-]{10,})/);
    if (byPath) return byPath[1];
    const byQuery = u.searchParams.get("id");
    if (byQuery && /^[A-Za-z0-9_-]{10,}$/.test(byQuery)) return byQuery;
    return null;
  } catch {
    return null;
  }
}

/**
 * Canonical Google Drive direct-download endpoint for a stored Drive link,
 * built ONLY from the file id the admin already stored — nothing is hardcoded
 * and the stored link itself is never modified. The endpoint answers with
 * `Content-Disposition: attachment`, so a browser navigation on it saves the
 * file straight away: no Drive preview page, no virus-scan interstitial and
 * no hand-off to the Google Drive app on Android (it is not a
 * drive.google.com link, so mobile browsers never offer to "open in Drive").
 * Returns null for non-Drive URLs or links without an extractable id.
 */
export function driveDirectDownloadUrl(rawUrl: string): string | null {
  const id = driveFileIdFromUrl(rawUrl);
  return id
    ? `https://drive.usercontent.google.com/download?id=${encodeURIComponent(id)}&export=download&confirm=t`
    : null;
}

/**
 * Format label derived from a response MIME type — used when the stored URL
 * carries no usable file extension (Google Drive links never do), so the
 * download dialog still shows "MP4" and the download filename ends with the
 * right extension. Returns null when the MIME type is not a known
 * downloadable media type.
 */
export function formatFromContentType(contentType?: string): string | null {
  if (!contentType) return null;
  const ct = contentType.toLowerCase();
  if (ct.startsWith("video/mp4")) return "MP4";
  if (ct.startsWith("video/webm")) return "WEBM";
  if (ct.startsWith("video/x-matroska")) return "MKV";
  if (ct.startsWith("video/quicktime")) return "MOV";
  if (ct.startsWith("video/ogg")) return "OGG";
  if (ct.startsWith("text/vtt")) return "VTT";
  if (ct.includes("subrip")) return "SRT";
  return null;
}

const FORMAT_BY_EXT: Record<string, string> = {
  ".mp4": "MP4",
  ".mpd": "DASH",
  ".m4v": "M4V",
  ".webm": "WEBM",
  ".mkv": "MKV",
  ".mov": "MOV",
  ".ogv": "OGG",
  ".ogg": "OGG",
  ".srt": "SRT",
  ".vtt": "VTT",
};

/** Human format label from a URL's file extension ("MP4", "SRT", …). */
export function formatFromUrl(url: string, fallback = "FILE"): string {
  const clean = url.split(/[?#]/)[0];
  const dot = clean.lastIndexOf(".");
  if (dot === -1) return fallback;
  return FORMAT_BY_EXT[clean.slice(dot).toLowerCase()] || fallback;
}

/** Best-effort file extension for a generated download filename. */
export function extFromUrl(url: string, format: string): string {
  const clean = url.split(/[?#]/)[0];
  const dot = clean.lastIndexOf(".");
  // Only trust the path extension when it is a REAL media extension — host
  // fragments like drive.google.co"m" in "/uc" paths must not become ".com"
  // filenames.
  if (dot !== -1 && /^\.[a-z0-9]{1,5}$/i.test(clean.slice(dot))) {
    const ext = clean.slice(dot).toLowerCase();
    if (FORMAT_BY_EXT[ext]) return ext;
  }
  const known = Object.entries(FORMAT_BY_EXT).find(([, label]) => label === format);
  return known ? known[0] : "";
}

export const EMBED_PROVIDERS: Record<
  string,
  { label: string; hosts: string[]; noIframe?: boolean; sharePage?: boolean }
> = {
  youtube: { label: "YouTube", hosts: ["www.youtube.com", "www.youtube-nocookie.com"] },
  vimeo: { label: "Vimeo", hosts: ["player.vimeo.com"] },
  dailymotion: { label: "Dailymotion", hosts: ["www.dailymotion.com", "dailymotion.com"] },
  gdrive: { label: "Google Drive", hosts: ["drive.google.com"] },
  streamable: { label: "Streamable", hosts: ["streamable.com"] },
  // TeraBox does not offer a permitted public iframe embed for shared files —
  // playback falls back to the official share page ("Watch on TeraBox") or an
  // authorized direct streaming URL configured by the admin.
  terabox: { label: "TeraBox", hosts: ["www.terabox.com", "terabox.com"], noIframe: true, sharePage: true },
};

/**
 * TeraBox brands/shares never serve video bytes directly — any URL on one of
 * these hosts is a share page (HTML), no matter what the path looks like.
 * Kept separate from EMBED_PROVIDERS so the check also guards "external" URLs.
 */
export function noIframeProviderForHost(hostname: string): string | null {
  for (const [id, def] of Object.entries(EMBED_PROVIDERS)) {
    if (!def.noIframe) continue;
    const h = hostname.toLowerCase().replace(/^www\./, "");
    if (def.hosts.includes(h) || def.hosts.includes(hostname.toLowerCase()) || (id === "terabox" && isTeraBoxHost(hostname)))
      return id;
  }
  return null;
}

/** Every known TeraBox sharing domain (they rebrand often). */
export const TERABOX_HOSTS = [
  "terabox.com",
  "www.terabox.com",
  "teraboxapp.com",
  "dubox.com", // legacy Dubox brand of the same service
  "1024tera.com",
  "1024terabox.com",
  "teraboxlink.com",
  "terasharelink.com",
  "teraboxshare.com",
  "freeterabox.com",
  "4funbox.com",
  "mirrobox.com",
  "nephobox.com",
  "momerybox.com",
  "tibibox.com",
  "terabox.club",
];

export function isTeraBoxHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^www\./, "");
  return TERABOX_HOSTS.includes(hostname.toLowerCase()) || TERABOX_HOSTS.includes(h) || h === "terabox.com";
}

export const DIRECT_MEDIA_EXTS = [
  ".mp4",
  ".m3u8",
  ".mpd",
  ".webm",
  ".ogg",
  ".ogv",
  ".mov",
  ".mkv",
  ".m4v",
];

/** Extensions that represent one downloadable file (streaming manifests excluded). */
export const DOWNLOADABLE_EXTS = [
  ".mp4",
  ".m4v",
  ".webm",
  ".mkv",
  ".mov",
  ".ogv",
  ".ogg",
  ".srt",
  ".vtt",
];
