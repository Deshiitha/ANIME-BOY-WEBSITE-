/**
 * Minimal in-memory sliding-window rate limiter.
 *
 * Keyed by action + client identity (IP / user id). Suited to the single-node
 * deployments this app targets (Railway/Vercel single instance). Each API route
 * picks its own limits — see the call sites.
 */

type Bucket = number[]; // timestamps (ms) of recent hits

const buckets = new Map<string, Bucket>();
let lastSweep = 0;

function sweep(now: number) {
  // Opportunistic cleanup every ~5 minutes to keep memory bounded.
  if (now - lastSweep < 5 * 60_000) return;
  lastSweep = now;
  for (const [key, hits] of buckets) {
    const filtered = hits.filter((t) => now - t < 60 * 60_000);
    if (filtered.length === 0) buckets.delete(key);
    else buckets.set(key, filtered);
  }
}

export type RateLimitResult = {
  allowed: boolean;
  remaining: number;
  retryAfterSec: number;
};

export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = Date.now();
  sweep(now);
  const hits = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  if (hits.length >= limit) {
    const oldest = Math.min(...hits);
    const retryAfterSec = Math.max(1, Math.ceil((oldest + windowMs - now) / 1000));
    buckets.set(key, hits);
    return { allowed: false, remaining: 0, retryAfterSec };
  }
  hits.push(now);
  buckets.set(key, hits);
  return { allowed: true, remaining: limit - hits.length, retryAfterSec: 0 };
}

/** Best-effort client IP from proxy headers (first hop of x-forwarded-for). */
export function clientIp(req: Request): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim().toLowerCase() || "unknown";
  return req.headers.get("x-real-ip")?.trim().toLowerCase() || "unknown";
}

/** Uniform 429 response helper. */
export function tooMany(retryAfterSec: number) {
  return new Response(
    JSON.stringify({
      error: `Too many attempts. Please try again in ${retryAfterSec < 60 ? `${retryAfterSec}s` : `${Math.ceil(retryAfterSec / 60)} min`}.`,
    }),
    { status: 429, headers: { "Content-Type": "application/json", "Retry-After": String(retryAfterSec) } }
  );
}
