import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

export const SESSION_COOKIE = "ab_session";
const SESSION_DAYS = 30;

function secret(): string {
  // Configured via env; falls back to a generated-per-boot secret in dev so
  // sessions still work out of the box in the sandbox preview.
  return (
    process.env.AUTH_SECRET ||
    process.env.NEXTAUTH_SECRET ||
    "animeboy-dev-secret-change-me"
  );
}

function b64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

function fromB64url(input: string): Buffer {
  return Buffer.from(input.replace(/-/g, "+").replace(/_/g, "/"), "base64");
}

export type SessionPayload = {
  sub: string;
  email: string;
  name: string | null;
  role: string;
  tv?: number; // tokenVersion — bumped on password change to kill all sessions
  iat: number;
  exp: number;
};

export function signSession(
  payload: Omit<SessionPayload, "iat" | "exp"> & { tokenVersion?: number }
): string {
  const iat = Math.floor(Date.now() / 1000);
  const exp = iat + SESSION_DAYS * 24 * 60 * 60;
  const { tokenVersion, ...rest } = payload;
  const body = b64url(JSON.stringify({ ...rest, tv: tokenVersion ?? 0, iat, exp }));
  const sig = b64url(createHmac("sha256", secret()).update(body).digest());
  return `${body}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expected = createHmac("sha256", secret()).update(body).digest();
  const given = fromB64url(sig);
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    const payload = JSON.parse(fromB64url(body).toString("utf8")) as SessionPayload;
    if (!payload?.sub || payload.exp * 1000 < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

/** A session is valid only if it was issued against the user's current tokenVersion. */
function tokenVersionValid(payloadTv: number | undefined, userTv: number): boolean {
  return (payloadTv ?? 0) === userTv;
}

export function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/** Read the signed session cookie and load the fresh user from the DB. */
export async function getSessionUser() {
  const store = await cookies();
  const payload = verifySessionToken(store.get(SESSION_COOKIE)?.value);
  if (!payload) return null;
  const user = await db.user.findUnique({
    where: { id: payload.sub },
    select: { id: true, email: true, name: true, role: true, createdAt: true, tokenVersion: true },
  });
  if (!user || !tokenVersionValid(payload.tv, user.tokenVersion)) return null;
  const { tokenVersion: _tv, ...safe } = user;
  return safe;
}

/** Session payload from a plain Request (used by route handlers). */
export async function getSessionFromRequest(req: Request) {
  const cookieHeader = req.headers.get("cookie") || "";
  const match = cookieHeader
    .split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${SESSION_COOKIE}=`));
  const token = match ? decodeURIComponent(match.slice(SESSION_COOKIE.length + 1)) : null;
  const payload = verifySessionToken(token);
  if (!payload) return null;
  const user = await db.user.findUnique({
    where: { id: payload.sub },
    select: { id: true, email: true, name: true, role: true, tokenVersion: true },
  });
  if (!user || !tokenVersionValid(payload.tv, user.tokenVersion)) return null;
  const { tokenVersion: _tv, ...safe } = user;
  return safe;
}

export async function requireAdmin(req: Request) {
  const user = await getSessionFromRequest(req);
  if (!user || user.role !== "ADMIN") {
    return { ok: false as const, error: "Admin authorization required" };
  }
  return { ok: true as const, user };
}

export async function requireUser(req: Request) {
  const user = await getSessionFromRequest(req);
  if (!user) return { ok: false as const, error: "Please sign in to continue" };
  return { ok: true as const, user };
}

/** Session payload for the currently authenticated user (with fresh role/name). */
export function sessionPayloadFor(user: { id: string; email: string; name: string | null; role: string; tokenVersion: number }) {
  return {
    sub: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    tokenVersion: user.tokenVersion,
  };
}

export function sessionCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production" && process.env.FORCE_INSECURE_COOKIE !== "1",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  };
}
