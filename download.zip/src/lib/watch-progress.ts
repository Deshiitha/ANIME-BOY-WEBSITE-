"use client";

/**
 * Continue-watching store.
 *
 * Persists playback positions in localStorage (per browser, no account needed)
 * so visitors can resume a movie or episode where they left off — on the
 * player itself and via the "Continue Watching" row on the home page.
 *
 * Only URLs/titles/metadata and the position are kept here; nothing is sent
 * to the server and no video data is stored.
 */

const STORAGE_KEY = "animeboy:continue-watching:v1";
const UPDATED_EVENT = "animeboy:watch-progress";

/** Max entries kept on the device (newest first). */
const MAX_ENTRIES = 20;
/** Positions below this many seconds are not worth remembering. */
const MIN_SECONDS = 15;
/** Past this fraction of the video the entry counts as finished and is dropped. */
const FINISHED_FRACTION = 0.95;

export type WatchProgressEntry = {
  /** Stable video identity: `movie:<animeId>` or `ep:<episodeId>`. */
  key: string;
  /** Parent anime slug — used to build the watch deep-link. */
  slug: string;
  /** Season/episode numbers for series (omitted for movies). */
  s?: number;
  e?: number;
  /** Display title saved at watch time ("Title" or "Title — S1 E2 · Name"). */
  title: string;
  /** Best available poster/backdrop URL (may be null). */
  poster: string | null;
  /** Short context label ("Movie" / "Season 1 · Episode 2"). */
  label: string;
  /** Playback position in seconds. */
  seconds: number;
  /** Duration in seconds when known (0 = unknown). */
  duration: number;
  updatedAt: number;
};

type Store = Record<string, WatchProgressEntry>;

function readStore(): Store {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const out: Store = {};
    for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
      const e = v as Partial<WatchProgressEntry> | null;
      if (e && typeof e.key === "string" && typeof e.seconds === "number" && typeof e.slug === "string") {
        out[k] = e as WatchProgressEntry;
      }
    }
    return out;
  } catch {
    return {};
  }
}

function writeStore(store: Store) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch {
    // Storage full / private mode — continue-watching is best-effort.
  }
  window.dispatchEvent(new CustomEvent(UPDATED_EVENT));
}

/** Newest first, finished/partial entries pruned, capped at MAX_ENTRIES. */
export function getWatchProgressList(): WatchProgressEntry[] {
  const store = readStore();
  return Object.values(store)
    .filter((e) => {
      if (!e.slug || typeof e.seconds !== "number") return false;
      if (e.seconds < MIN_SECONDS) return false;
      if (e.duration > 0 && e.seconds >= e.duration * FINISHED_FRACTION) return false;
      return true;
    })
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, MAX_ENTRIES);
}

export function getWatchProgress(key: string): WatchProgressEntry | null {
  return readStore()[key] ?? null;
}

/** Seconds to resume from for this key (0 = start from the beginning). */
export function resumeSecondsFor(key: string): number {
  const e = getWatchProgress(key);
  if (!e) return 0;
  if (e.seconds < MIN_SECONDS) return 0;
  if (e.duration > 0 && e.seconds >= e.duration * FINISHED_FRACTION) return 0;
  return e.seconds;
}

export function saveWatchProgress(entry: Omit<WatchProgressEntry, "updatedAt">) {
  if (!entry.key || !entry.slug) return;
  const store = readStore();
  const prev = store[entry.key];

  // Never let a stale write (e.g. a player unmounting after a later save)
  // move the position backwards.
  const seconds =
    prev && entry.seconds < prev.seconds && entry.seconds - prev.seconds < 30
      ? prev.seconds
      : entry.seconds;

  store[entry.key] = { ...entry, seconds, updatedAt: Date.now() };

  // Drop finished entries and prune to the newest MAX_ENTRIES.
  const keep = Object.values(store)
    .filter((e) => !(e.duration > 0 && e.seconds >= e.duration * FINISHED_FRACTION))
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, MAX_ENTRIES);
  writeStore(Object.fromEntries(keep.map((e) => [e.key, e])));
}

/** Forget one video (or everything when no key is given). */
export function removeWatchProgress(key?: string) {
  if (typeof window === "undefined") return;
  if (!key) {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    window.dispatchEvent(new CustomEvent(UPDATED_EVENT));
    return;
  }
  const store = readStore();
  if (store[key]) {
    delete store[key];
    writeStore(store);
  }
}

/** Subscribe to progress changes (same tab + other tabs). */
export function onWatchProgressChange(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const onCustom = () => cb();
  const onStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) cb();
  };
  window.addEventListener(UPDATED_EVENT, onCustom);
  window.addEventListener("storage", onStorage);
  return () => {
    window.removeEventListener(UPDATED_EVENT, onCustom);
    window.removeEventListener("storage", onStorage);
  };
}

/** 1:23 style clock label used by the resume chip and home cards. */
export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = h > 0 ? String(m).padStart(2, "0") : String(m);
  return h > 0
    ? `${h}:${mm}:${String(sec).padStart(2, "0")}`
    : `${mm}:${String(sec).padStart(2, "0")}`;
}

/* ------------------------ last watched (per series) ----------------------- */

/**
 * Remembers the season + episode the visitor watched last for every series so
 * the watch page can reopen exactly where they left off (even for episodes
 * that were fully watched — those are dropped from continue-watching).
 * Stored in localStorage per browser; nothing is sent to the server.
 */
const LAST_WATCHED_KEY = "animeboy:last-watched:v1";
const MAX_LAST_WATCHED = 60;

export type LastWatchedEntry = {
  s: number; // season number
  e: number; // episode number
  updatedAt: number;
};

function readLastWatched(): Record<string, LastWatchedEntry> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(LAST_WATCHED_KEY);
    if (!raw) return {};
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const out: Record<string, LastWatchedEntry> = {};
    for (const [slug, v] of Object.entries(parsed as Record<string, unknown>)) {
      const e = v as Partial<LastWatchedEntry> | null;
      if (e && typeof e.s === "number" && typeof e.e === "number" && slug) {
        out[slug] = { s: e.s, e: e.e, updatedAt: e.updatedAt || 0 };
      }
    }
    return out;
  } catch {
    return {};
  }
}

/** Last watched season/episode for a series slug (null = never watched here). */
export function getLastWatched(slug: string): LastWatchedEntry | null {
  return readLastWatched()[slug] ?? null;
}

export function saveLastWatched(slug: string, s: number, e: number) {
  if (!slug || typeof window === "undefined") return;
  try {
    const map = readLastWatched();
    map[slug] = { s, e, updatedAt: Date.now() };
    // Cap the map so it never grows without bound (keep newest series).
    const keep = Object.entries(map)
      .sort(([, a], [, b]) => b.updatedAt - a.updatedAt)
      .slice(0, MAX_LAST_WATCHED);
    window.localStorage.setItem(LAST_WATCHED_KEY, JSON.stringify(Object.fromEntries(keep)));
  } catch {
    // Storage full / private mode — best effort only.
  }
}
