import { createHash, timingSafeEqual } from "crypto";

/**
 * PayHere Hosted Checkout integration (Sri Lankan payment gateway).
 *
 * Security model:
 *  - The merchant secret NEVER leaves the server. The client only receives
 *    the pre-signed parameter set needed for the browser form POST.
 *  - A donation is marked VERIFIED exclusively by the server-to-server
 *    notify callback whose `md5sig` we recompute and compare.
 *  - We never trust the browser return (return_url) as proof of payment.
 *
 * Docs: https://support.payhere.lk/ (Hosted Checkout / payhere.lk API v1)
 */

export const PAYHERE_CHECKOUT_URLS: Record<string, string> = {
  sandbox: "https://sandbox.payhere.lk/pay/checkout",
  live: "https://www.payhere.lk/pay/checkout",
};

export type PayHereCreds = {
  merchantId: string;
  merchantSecret: string;
  mode: string; // "sandbox" | "live"
};

export type PayHereCheckoutParams = {
  merchant_id: string;
  return_url: string;
  cancel_url: string;
  notify_url: string;
  order_id: string;
  items: string;
  currency: string;
  amount: string; // 2 decimal places
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  custom_1: string; // donation id
  custom_2: string; // order id
  hash: string;
};

function md5Upper(input: string): string {
  return createHash("md5").update(input).digest("hex").toUpperCase();
}

/**
 * Checkout hash per PayHere spec:
 * UPPER(MD5(merchant_id + order_id + amount + currency + UPPER(MD5(merchant_secret))))
 */
export function buildCheckoutHash(merchantId: string, orderId: string, amount: string, currency: string, merchantSecret: string): string {
  return md5Upper(merchantId + orderId + amount + currency + md5Upper(merchantSecret));
}

/**
 * Notify (IPN) signature per PayHere spec:
 * UPPER(MD5(merchant_id + order_id + payhere_amount + payhere_currency + status_code + UPPER(MD5(merchant_secret))))
 */
export function verifyNotifySignature(params: {
  merchant_id: string;
  order_id: string;
  payhere_amount: string;
  payhere_currency: string;
  status_code: string;
  md5sig: string;
}, merchantId: string, merchantSecret: string): boolean {
  const expected = md5Upper(
    params.merchant_id + params.order_id + params.payhere_amount + params.payhere_currency + params.status_code + md5Upper(merchantSecret)
  );
  const given = (params.md5sig || "").toUpperCase();
  if (!given) return false;
  const a = Buffer.from(expected);
  const b = Buffer.from(given);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/** Split an optional donor name into first/last for the gateway form. */
export function splitDonorName(name?: string | null): { firstName: string; lastName: string } {
  const clean = (name || "").trim();
  if (!clean) return { firstName: "Supporter", lastName: "ANIME BOY" };
  const parts = clean.split(/\s+/);
  if (parts.length === 1) return { firstName: parts[0].slice(0, 40), lastName: "Donor" };
  return {
    firstName: parts.slice(0, -1).join(" ").slice(0, 40),
    lastName: parts.slice(-1)[0].slice(0, 40),
  };
}

export function formatAmount(amountCents: number): string {
  return (amountCents / 100).toFixed(2);
}

/** Human-readable status code mapping from PayHere notify callbacks. */
export function notifyStatus(statusCode: number): { status: string; message: string } {
  switch (statusCode) {
    case 2:
      return { status: "VERIFIED", message: "Payment success" };
    case 0:
      return { status: "PENDING", message: "Payment pending at gateway" };
    case -1:
      return { status: "CANCELED", message: "Payment canceled by user" };
    case -2:
      return { status: "FAILED", message: "Payment failed or declined" };
    case -3:
      return { status: "FAILED", message: "Payment charged back" };
    default:
      return { status: "PENDING", message: `Unknown gateway status ${statusCode}` };
  }
}
