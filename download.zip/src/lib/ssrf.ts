/**
 * Server-side, SSRF-safe media URL inspection for the admin "Preview / Check"
 * action. Resolves DNS first and refuses private, loopback, link-local and
 * cloud-metadata addresses, follows redirects manually (re-checking every
 * hop) and fetches only the first byte to read response headers.
 */
import dns from "dns/promises";
import net from "net";

const PRIVATE_V4 = [
  { net: "0.0.0.0", bits: 8 },
  { net: "10.0.0.0", bits: 8 },
  { net: "100.64.0.0", bits: 10 }, // CGNAT
  { net: "127.0.0.0", bits: 8 },
  { net: "169.254.0.0", bits: 16 }, // link-local incl. cloud metadata
  { net: "172.16.0.0", bits: 12 },
  { net: "192.0.0.0", bits: 24 },
  { net: "192.0.2.0", bits: 24 }, // TEST-NET-1
  { net: "192.88.99.0", bits: 24 },
  { net: "192.168.0.0", bits: 16 },
  { net: "198.18.0.0", bits: 15 },
  { net: "198.51.100.0", bits: 24 }, // TEST-NET-2
  { net: "203.0.113.0", bits: 24 }, // TEST-NET-3
  { net: "224.0.0.0", bits: 4 },
  { net: "240.0.0.0", bits: 4 },
];

function v4ToInt(ip: string): number {
  return ip.split(".").reduce((acc, o) => (acc << 8) + Number(o), 0) >>> 0;
}

export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const n = v4ToInt(ip);
    return PRIVATE_V4.some(({ net: base, bits }) => {
      const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
      return (n & mask) === (v4ToInt(base) & mask);
    });
  }
  const low = ip.toLowerCase();
  if (low === "::" || low === "::1") return true;
  if (low.startsWith("fe80:") || low.startsWith("fc") || low.startsWith("fd")) return true;
  if (low.startsWith("::ffff:")) return isPrivateIp(low.slice(7)); // IPv4-mapped
  return false;
}

function blockReason(hostname: string): string | null {
  const h = hostname.toLowerCase();
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal"))
    return "Internal hostnames are not allowed.";
  if (net.isIP(h)) return isPrivateIp(h) ? "Private/internal IP addresses are not allowed." : null;
  return null;
}

async function assertPublicHost(hostname: string): Promise<void> {
  const reason = blockReason(hostname);
  if (reason) throw new Error(reason);
  let records: { address: string }[];
  try {
    records = await dns.lookup(hostname, { all: true, verbatim: true });
  } catch {
    throw new Error(`Could not resolve host "${hostname}". Check the URL.`);
  }
  if (!records.length) throw new Error(`Could not resolve host "${hostname}".`);
  const bad = records.find((r) => isPrivateIp(r.address));
  if (bad) throw new Error("That URL points to a private/internal network address and is not allowed.");
}

export type ProbeResult = {
  ok: boolean;
  status?: number;
  finalUrl?: string;
  contentType?: string;
  contentLength?: string;
  acceptRanges?: string;
  contentDisposition?: string;
  /** Access-Control-Allow-Origin advertised by the host ("*" or a specific origin). */
  cors?: string;
  error?: string;
};

const PROBE_TIMEOUT_MS = 8000;
const MAX_REDIRECTS = 4;

/** Inspect a public HTTPS media URL without downloading the file. */
export async function probeMediaUrl(rawUrl: string): Promise<ProbeResult> {
  let current = rawUrl.trim();
  try {
    for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
      const u = new URL(current);
      if (u.protocol !== "https:" && u.protocol !== "http:") {
        return { ok: false, error: "Only http(s) URLs can be inspected." };
      }
      await assertPublicHost(u.hostname);

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), PROBE_TIMEOUT_MS);
      let res: Response;
      try {
        res = await fetch(current, {
          method: "GET",
          headers: { Range: "bytes=0-0", "User-Agent": "ANIMEBOY-MediaCheck/1.0" },
          redirect: "manual",
          signal: controller.signal,
        });
      } catch (e) {
        const msg = e instanceof Error && e.name === "AbortError" ? "The server took too long to respond." : "The server could not be reached.";
        return { ok: false, error: msg };
      } finally {
        clearTimeout(timer);
      }

      if ([301, 302, 303, 307, 308].includes(res.status)) {
        const loc = res.headers.get("location");
        if (!loc) return { ok: false, error: `Server returned ${res.status} without a redirect target.` };
        res.body?.cancel().catch(() => {});
        const next = new URL(loc, current).toString();
        if (hop === MAX_REDIRECTS) return { ok: false, error: "Too many redirects while checking the URL." };
        current = next;
        continue;
      }

      const contentType = res.headers.get("content-type") || "";
      return {
        ok: res.status === 200 || res.status === 206,
        status: res.status,
        finalUrl: current,
        contentType,
        contentLength: res.headers.get("content-range")?.split("/")[1] || res.headers.get("content-length") || undefined,
        acceptRanges: res.headers.get("accept-ranges") || undefined,
        contentDisposition: res.headers.get("content-disposition") || undefined,
        cors: res.headers.get("access-control-allow-origin") || undefined,
        error:
          res.status === 403
            ? "The storage server replied 403 Forbidden — the object may be private or the URL may be an expiring link."
            : res.status === 404
              ? "The server replied 404 Not Found — the file does not exist at that URL."
              : res.ok
                ? undefined
                : `The server replied HTTP ${res.status}.`,
      };
    }
    return { ok: false, error: "Too many redirects while checking the URL." };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "URL check failed." };
  }
}
