import { NextResponse } from "next/server";
import {
  buildAltSources,
  buildDownloadInfo,
  buildPlayableSource,
  parseJsonArray,
} from "./media-source";
import type {
  AltSource,
  DownloadInfo,
  PlayableSource,
  QualityTrack,
  SubtitleTrack,
} from "./media-types";
import type { VideoSourceFields } from "./media-source";

export function ok<T>(data: T, init?: number) {
  return NextResponse.json(data as object, { status: init ?? 200 });
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ error: message, ...extra }, { status });
}

export function slugify(input: string): string {
  const base = input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^\p{Letter}\p{Number}]+/gu, "-")
    .replace(/^-+|-+$/g, "");
  return base || `anime-${Date.now()}`;
}

export async function readJson<T>(req: Request): Promise<T | null> {
  try {
    return (await req.json()) as T;
  } catch {
    return null;
  }
}

export type EpisodeRow = {
  id: string;
  number: number;
  title: string | null;
  videoUrl: string | null;
  videoSource: string | null;
  embedUrl: string | null;
  videoProvider: string | null;
  videoQualities: string | null;
  subtitleTracks: string | null;
  altSources: string | null;
  videoKey: string | null;
  subtitleUrl: string | null;
  thumbnailUrl: string | null;
  durationSec: number | null;
  description: string | null;
  downloadEnabled: boolean | null;
  downloadUrl: string | null;
  downloadQualities: string | null;
  subtitleDownloadEnabled: boolean | null;
  subtitleDownloads: string | null;
};

/** Raw (admin-facing) download fields attached to anime/episode serialisations. */
function publicDownloadFields(e: {
  downloadEnabled: boolean | null;
  downloadUrl: string | null;
  downloadQualities: string | null;
  subtitleDownloadEnabled: boolean | null;
  subtitleDownloads: string | null;
}) {
  return {
    downloadEnabled: !!e.downloadEnabled,
    downloadUrl: e.downloadUrl,
    downloadQualities: parseJsonArray<QualityTrack>(e.downloadQualities),
    subtitleDownloadEnabled: !!e.subtitleDownloadEnabled,
    subtitleDownloads: parseJsonArray<SubtitleTrack>(e.subtitleDownloads),
  };
}

/**
 * Serialise an Episode row for the public/admin API with its playable source.
 *
 * `fallback` (optional) is the parent Anime row: when the episode has no video
 * source of its own, the series-level Cloud Video Source saved on the series
 * form plays instead — so a cloud link pasted on an Anime/Donghua Series is
 * never a dead end. Episodes WITH their own source are never touched.
 */
export function publicEpisode(e: EpisodeRow, fallback?: VideoSourceFields | null) {
  const primary = buildPlayableSource(e, "episode", e.thumbnailUrl) as PlayableSource;
  const alts = buildAltSources(e, "episode", e.thumbnailUrl);
  let video = primary;
  let sources = (primary.kind === "none" ? alts : [primary, ...alts]) as PlayableSource[];
  if (primary.kind === "none" && fallback) {
    const fbPrimary = buildPlayableSource(fallback, "anime", fallback.videoThumb || e.thumbnailUrl || null);
    if (fbPrimary.kind !== "none") {
      const fbAlts = buildAltSources(fallback, "anime", fallback.videoThumb || e.thumbnailUrl || null);
      video = fbPrimary;
      sources = [fbPrimary, ...fbAlts, ...alts] as PlayableSource[];
    }
  }
  return {
    id: e.id,
    number: e.number,
    title: e.title,
    videoUrl: e.videoUrl,
    videoSource: e.videoSource || "upload",
    embedUrl: e.embedUrl,
    videoProvider: e.videoProvider,
    videoQualities: parseJsonArray<QualityTrack>(e.videoQualities),
    subtitleTracks: parseJsonArray<SubtitleTrack>(e.subtitleTracks),
    subtitleUrl: e.subtitleUrl,
    thumbnailUrl: e.thumbnailUrl,
    durationSec: e.durationSec,
    description: e.description,
    ...publicDownloadFields(e),
    downloads: buildDownloadInfo(e) as DownloadInfo,
    video,
    /** Primary first, then every admin-configured backup source (switcher). */
    sources,
    /** Raw backup rows — admin edit forms only; scrubbed for visitors. */
    altSources: parseJsonArray<AltSource>(e.altSources),
  };
}

/** Serialise an Anime row for the public API (parses genres into an array). */
export function publicAnime(a: {
  id: string;
  slug: string;
  type: string;
  category: string;
  seasonNumber?: number | null;
  episodeNumber?: number | null;
  titleEn: string;
  titleSi: string | null;
  descriptionSi: string | null;
  descriptionEn: string | null;
  genres: string;
  releaseYear: number | null;
  rating: number | null;
  languageLabel: string;
  availability: string | null;
  status: string;
  posterUrl: string | null;
  backdropUrl: string | null;
  videoUrl: string | null;
  videoSource: string | null;
  embedUrl: string | null;
  videoProvider: string | null;
  videoQualities: string | null;
  subtitleTracks: string | null;
  altSources: string | null;
  videoThumb: string | null;
  videoKey: string | null;
  subtitleUrl: string | null;
  downloadEnabled: boolean | null;
  downloadUrl: string | null;
  downloadQualities: string | null;
  subtitleDownloadEnabled: boolean | null;
  subtitleDownloads: string | null;
  featured: boolean;
  featuredOrder: number;
  homeRank: number;
  published: boolean;
  createdAt: Date;
  updatedAt: Date;
  seasons?: { id: string; number: number; title: string | null; episodes: EpisodeRow[] }[];
}) {
  return {
    id: a.id,
    slug: a.slug,
    type: a.type,
    category: a.category || "ANIME",
    seasonNumber: a.seasonNumber ?? null,
    episodeNumber: a.episodeNumber ?? null,
    titleEn: a.titleEn,
    titleSi: a.titleSi,
    descriptionSi: a.descriptionSi,
    descriptionEn: a.descriptionEn,
    genres: a.genres ? a.genres.split(",").map((g) => g.trim()).filter(Boolean) : [],
    releaseYear: a.releaseYear,
    rating: a.rating,
    languageLabel: a.languageLabel,
    availability: a.availability,
    status: a.status,
    posterUrl: a.posterUrl,
    backdropUrl: a.backdropUrl,
    videoUrl: a.videoUrl,
    videoSource: a.videoSource || "upload",
    embedUrl: a.embedUrl,
    videoProvider: a.videoProvider,
    videoQualities: parseJsonArray<QualityTrack>(a.videoQualities),
    subtitleTracks: parseJsonArray<SubtitleTrack>(a.subtitleTracks),
    videoThumb: a.videoThumb,
    subtitleUrl: a.subtitleUrl,
    ...publicDownloadFields(a),
    downloads: buildDownloadInfo(a) as DownloadInfo,
    featured: a.featured,
    featuredOrder: a.featuredOrder,
    homeRank: a.homeRank,
    published: a.published,
    createdAt: a.createdAt,
    updatedAt: a.updatedAt,
    video:
      a.type === "MOVIE"
        ? buildPlayableSource(a, "anime", a.backdropUrl || a.posterUrl)
        : ({ kind: "none" } as PlayableSource),
    /** Movie backup sources for the watch-page switcher (movies only). */
    sources:
      a.type === "MOVIE"
        ? (() => {
            const primary = buildPlayableSource(a, "anime", a.backdropUrl || a.posterUrl);
            const alts = buildAltSources(a, "anime", a.backdropUrl || a.posterUrl);
            return (primary.kind === "none" ? alts : [primary, ...alts]) as PlayableSource[];
          })()
        : [],
    /** Raw backup rows — admin edit forms only; scrubbed for visitors. */
    altSources: parseJsonArray<AltSource>(a.altSources),
    seasons: a.seasons?.map((s) => ({
      id: s.id,
      number: s.number,
      title: s.title,
      // Episodes without their own source fall back to the series-level
      // Cloud Video Source (movies never map seasons, but stay guarded).
      episodes: s.episodes.map((e) => publicEpisode(e, a.type === "MOVIE" ? undefined : a)),
    })),
  };
}
