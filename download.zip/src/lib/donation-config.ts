import { db } from "@/lib/db";
import { PAYHERE_METHODS, WEBXPAY_METHODS } from "./webxpay";

/**
 * Donation settings live in the SiteConfig key-value store (server side only).
 * Secrets (PayHere merchant secret, WebXPay secret/public keys, SMTP password)
 * are stored here but are NEVER returned by any public API; admin endpoints
 * only return a "configured" flag and a masked hint, never the value itself.
 *
 * The receiving/payout account is the merchant's own bank account that the
 * payment provider settles into — full card numbers, CVVs, PINs and OTPs are
 * never collected anywhere in this system.
 */

export type DonationPresets = number[];

export type DonationProvider = "PAYHERE" | "WEBXPAY" | "NONE";

export type DonationConfig = {
  donationEnabled: boolean;
  donationHeading: string;
  donationDescription: string;
  donationThankYouNote: string;
  donationPresets: DonationPresets;
  donationPublicRecognition: boolean;
  provider: DonationProvider; // PAYHERE | WEBXPAY | NONE
  gatewayEnabled: boolean; // master switch for gateway checkout
  gatewayMode: string; // sandbox|staging vs live (per provider naming)
  gatewayCurrency: string; // settlement/process currency, e.g. LKR
  payhereMerchantId: string;
  payhereMerchantSecretSet: boolean;
  webxpayMerchantId: string;
  webxpayGatewayId: string;
  webxpaySecretKeySet: boolean;
  webxpayPublicKeySet: boolean;
  // Payout / receiving account (where the provider settles donation funds)
  payoutBankName: string;
  payoutAccountHolder: string;
  payoutAccountNumber: string;
  payoutCurrency: string;
  // Donor-facing manual bank transfer option (separate from payouts)
  bankEnabled: boolean;
  bankName: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankBranch: string;
  bankInstructions: string;
};

export type SmtpConfig = {
  smtpHost: string;
  smtpPort: string;
  smtpUser: string;
  smtpPassSet: boolean;
  smtpFrom: string;
  smtpSecure: boolean;
};

export const DONATION_DEFAULTS = {
  donationEnabled: "false",
  donationHeading: "Support ANIME BOY 💚",
  donationDescription:
    "Enjoying ANIME BOY? Support us with a small donation to help keep the website running!",
  donationThankYouNote:
    "Every rupee goes towards hosting, storage and bringing more Sinhala anime to you. Thank you for supporting the community! 🌱",
  donationPresets: "100,250,500,1000,2000,5000",
  donationPublicRecognition: "true",
  paymentProvider: "PAYHERE",
  gatewayEnabled: "false",
  gatewayMode: "sandbox",
  gatewayCurrency: "LKR",
  payhereMerchantId: "",
  payhereMerchantSecret: "",
  webxpayMerchantId: "",
  webxpayGatewayId: "",
  webxpaySecretKey: "",
  webxpayPublicKey: "",
  payoutBankName: "",
  payoutAccountHolder: "",
  payoutAccountNumber: "",
  payoutCurrency: "LKR",
  bankEnabled: "false",
  bankName: "",
  bankAccountName: "",
  bankAccountNumber: "",
  bankBranch: "",
  bankInstructions: "",
};

export const SMTP_KEYS = ["smtpHost", "smtpPort", "smtpUser", "smtpPass", "smtpFrom", "smtpSecure"] as const;

function bool(value: string | undefined, fallback = false): boolean {
  if (value === undefined) return fallback;
  return value === "true" || value === "1";
}

async function loadConfigMap(keys: string[]): Promise<Record<string, string>> {
  const rows = await db.siteConfig.findMany({ where: { key: { in: keys } } });
  const map: Record<string, string> = {};
  for (const row of rows) map[row.key] = row.value;
  return map;
}

export async function getDonationConfig(): Promise<DonationConfig> {
  const map = await loadConfigMap(Object.keys(DONATION_DEFAULTS));
  let presets: DonationPresets = [];
  try {
    const parsed = JSON.parse(map.donationPresets || DONATION_DEFAULTS.donationPresets);
    if (Array.isArray(parsed)) {
      presets = parsed
        .map((n: unknown) => Math.round(Number(n)))
        .filter((n) => Number.isFinite(n) && n > 0)
        .slice(0, 12);
    }
  } catch {
    presets = DONATION_DEFAULTS.donationPresets.split(",").map(Number);
  }
  if (presets.length === 0) presets = [100, 250, 500, 1000, 2000, 5000];

  const provider: DonationProvider = map.paymentProvider === "WEBXPAY" ? "WEBXPAY" : map.paymentProvider === "NONE" ? "NONE" : "PAYHERE";

  return {
    donationEnabled: bool(map.donationEnabled),
    donationHeading: map.donationHeading || DONATION_DEFAULTS.donationHeading,
    donationDescription: map.donationDescription || DONATION_DEFAULTS.donationDescription,
    donationThankYouNote: map.donationThankYouNote || DONATION_DEFAULTS.donationThankYouNote,
    donationPresets: presets,
    donationPublicRecognition: bool(map.donationPublicRecognition, true),
    provider,
    gatewayEnabled: bool(map.gatewayEnabled),
    gatewayMode: map.gatewayMode === "live" ? "live" : "sandbox",
    gatewayCurrency: (map.gatewayCurrency || "LKR").toUpperCase() === "USD" ? "USD" : (map.gatewayCurrency || "LKR").toUpperCase(),
    payhereMerchantId: map.payhereMerchantId || "",
    payhereMerchantSecretSet: !!map.payhereMerchantSecret,
    webxpayMerchantId: map.webxpayMerchantId || "",
    webxpayGatewayId: map.webxpayGatewayId || "",
    webxpaySecretKeySet: !!map.webxpaySecretKey,
    webxpayPublicKeySet: !!map.webxpayPublicKey,
    payoutBankName: map.payoutBankName || "",
    payoutAccountHolder: map.payoutAccountHolder || "",
    payoutAccountNumber: map.payoutAccountNumber || "",
    payoutCurrency: (map.payoutCurrency || "LKR").toUpperCase(),
    bankEnabled: bool(map.bankEnabled),
    bankName: map.bankName || "",
    bankAccountName: map.bankAccountName || "",
    bankAccountNumber: map.bankAccountNumber || "",
    bankBranch: map.bankBranch || "",
    bankInstructions: map.bankInstructions || "",
  };
}

/** Provider-specific credential completeness. */
export function providerCredsReady(cfg: DonationConfig): boolean {
  if (!cfg.gatewayEnabled) return false;
  if (cfg.provider === "PAYHERE") return !!cfg.payhereMerchantId && cfg.payhereMerchantSecretSet;
  if (cfg.provider === "WEBXPAY") return cfg.webxpaySecretKeySet && cfg.webxpayPublicKeySet;
  return false;
}

/** True when the gateway can accept live checkout requests. */
export function gatewayReady(cfg: DonationConfig): boolean {
  return cfg.donationEnabled && providerCredsReady(cfg);
}

/** Currencies the configured provider officially supports for checkout. */
export function providerCurrencies(cfg: DonationConfig): string[] {
  if (cfg.provider === "WEBXPAY") return ["LKR", "USD", "GBP", "AUD"];
  return ["LKR"]; // PayHere checkout settles in LKR
}

/** Payment methods the configured provider officially supports. */
export function providerMethods(cfg: DonationConfig): string[] {
  if (cfg.provider === "WEBXPAY") return [...WEBXPAY_METHODS];
  if (cfg.provider === "PAYHERE") return [...PAYHERE_METHODS];
  return [];
}

export async function getSmtpConfig(): Promise<SmtpConfig> {
  const map = await loadConfigMap([...SMTP_KEYS]);
  return {
    smtpHost: map.smtpHost || "",
    smtpPort: map.smtpPort || "587",
    smtpUser: map.smtpUser || "",
    smtpPassSet: !!map.smtpPass,
    smtpFrom: map.smtpFrom || "",
    smtpSecure: bool(map.smtpSecure),
  };
}

/** SMTP creds resolved for nodemailer: DB config first, env fallback. */
export async function resolveSmtp(): Promise<{ host: string; port: number; secure: boolean; auth?: { user: string; pass: string }; from: string } | null> {
  const cfg = await getSmtpConfig();
  const map = await loadConfigMap(["smtpPass"]);
  const envHost = process.env.SMTP_HOST || "";
  const host = cfg.smtpHost || envHost;
  if (!host) return null;
  const port = Number(cfg.smtpPort || process.env.SMTP_PORT || 587) || 587;
  const user = cfg.smtpUser || process.env.SMTP_USER || "";
  const pass = map.smtpPass || process.env.SMTP_PASS || "";
  const from = cfg.smtpFrom || process.env.SMTP_FROM || (user ? user : "");
  if (!from) return null;
  return {
    host,
    port,
    secure: cfg.smtpSecure || port === 465,
    auth: user && pass ? { user, pass } : undefined,
    from,
  };
}

export async function setConfigValues(values: Record<string, string>): Promise<void> {
  for (const [key, value] of Object.entries(values)) {
    await db.siteConfig.upsert({ where: { key }, update: { value }, create: { key, value } });
  }
}

/** Mask a secret for display in the admin UI: shows only the last 3 chars. */
export function maskHint(value: string): string {
  if (!value) return "";
  if (value.length <= 3) return "•••";
  return `••••••••${value.slice(-3)}`;
}

/** Mask a bank/payout account number: keep only the last 4 digits visible. */
export function maskAccountNumber(value: string): string {
  const clean = (value || "").trim();
  if (!clean) return "";
  const last4 = clean.slice(-4);
  return `${"•".repeat(Math.max(4, Math.min(10, clean.length - 4)))}${last4}`;
}
