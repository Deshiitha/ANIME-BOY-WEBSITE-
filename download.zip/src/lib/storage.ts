import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

/** Directory the upload root resolves to when UPLOAD_DIR is not set. */
function defaultUploadRoot(): string {
  const cwd = process.cwd();
  // Next.js standalone chdirs into .next/standalone — build output that is
  // wiped on every rebuild. Climb back to the project root so db/uploads
  // (and everything users upload) persists across deploys.
  if (cwd.endsWith(`${path.sep}.next${path.sep}standalone`)) {
    return path.resolve(cwd, "..", "..");
  }
  return cwd;
}

// Upload directory. Override with UPLOAD_DIR when the database and uploaded
// files live on a persistent volume (e.g. /data/uploads on Railway).
export const UPLOAD_ROOT = process.env.UPLOAD_DIR
  ? path.resolve(process.env.UPLOAD_DIR)
  : path.join(defaultUploadRoot(), "db", "uploads");

export type UploadKind = "video" | "poster" | "backdrop" | "subtitle" | "thumbnail";

const IMAGE_TYPES: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/avif": "avif",
  "image/gif": "gif",
};
const VIDEO_TYPES: Record<string, string> = {
  "video/mp4": "mp4",
  "video/webm": "webm",
  "video/ogg": "ogv",
  "video/quicktime": "mov",
  "video/x-matroska": "mkv",
};
const SUBTITLE_TYPES: Record<string, string> = {
  "text/vtt": "vtt",
  "application/x-subrip": "srt",
  "text/plain": "vtt",
};

export const LIMITS = {
  imageBytes: 10 * 1024 * 1024, // 10 MB
  videoBytes: (Number(process.env.MAX_VIDEO_MB) || 512) * 1024 * 1024,
  subtitleBytes: 2 * 1024 * 1024,
};

export type S3Config = {
  endpoint: string;
  region: string;
  bucket: string;
  accessKeyId: string;
  secretAccessKey: string;
  publicBaseUrl?: string;
};

/** Object storage is used when all required S3 env vars are present. */
export function getS3Config(): S3Config | null {
  const endpoint = process.env.S3_ENDPOINT;
  const region = process.env.S3_REGION || "us-east-1";
  const bucket = process.env.S3_BUCKET;
  const accessKeyId = process.env.S3_ACCESS_KEY_ID;
  const secretAccessKey = process.env.S3_SECRET_ACCESS_KEY;
  if (!endpoint || !bucket || !accessKeyId || !secretAccessKey) return null;
  return {
    endpoint,
    region,
    bucket,
    accessKeyId,
    secretAccessKey,
    publicBaseUrl: process.env.S3_PUBLIC_BASE_URL,
  };
}

export function validateFile(kind: UploadKind, mime: string, size: number): string | null {
  if (kind === "video") {
    if (!VIDEO_TYPES[mime]) return "Unsupported video type. Use MP4, WebM, MOV or MKV.";
    if (size > LIMITS.videoBytes)
      return `Video is too large. Maximum ${(LIMITS.videoBytes / 1024 / 1024).toFixed(0)} MB.`;
    return null;
  }
  if (kind === "poster" || kind === "backdrop" || kind === "thumbnail") {
    if (!IMAGE_TYPES[mime]) return "Unsupported image type. Use JPG, PNG, WebP or AVIF.";
    if (size > LIMITS.imageBytes) return "Image is too large. Maximum 10 MB.";
    return null;
  }
  if (kind === "subtitle") {
    if (!SUBTITLE_TYPES[mime]) return "Unsupported subtitle type. Use VTT or SRT.";
    if (size > LIMITS.subtitleBytes) return "Subtitle file is too large. Maximum 2 MB.";
    return null;
  }
  return "Unknown upload kind.";
}

export type StoredFile = { key: string; url: string; storage: "s3" | "local" };

/** Store a file in object storage when configured, otherwise on local disk. */
export async function storeFile(
  kind: UploadKind,
  originalName: string,
  mime: string,
  data: Buffer
): Promise<StoredFile> {
  const extMap =
    kind === "video" ? VIDEO_TYPES : kind === "subtitle" ? SUBTITLE_TYPES : IMAGE_TYPES;
  const ext = extMap[mime] || path.extname(originalName).replace(".", "").toLowerCase() || "bin";
  const key = `${kind}/${new Date().toISOString().slice(0, 10)}/${randomUUID()}.${ext}`;

  const s3 = getS3Config();
  if (s3) {
    // Private-bucket mode (S3_PRIVATE_BUCKET=1): video objects are addressed
    // by their stable s3://bucket/key identifier. The public upload URL is
    // NOT returned — playback URLs are minted server-side after an access
    // check (see /api/media/play/*). Posters/subtitles stay on public URLs
    // so the browser can load them directly.
    if (kind === "video" && process.env.S3_PRIVATE_BUCKET === "1") {
      return { key, url: `s3://${s3.bucket}/${key}`, storage: "s3" };
    }
    const client = new S3Client({
      endpoint: s3.endpoint,
      region: s3.region,
      forcePathStyle: true,
      credentials: {
        accessKeyId: s3.accessKeyId,
        secretAccessKey: s3.secretAccessKey,
      },
    });
    await client.send(
      new PutObjectCommand({ Bucket: s3.bucket, Key: key, Body: data, ContentType: mime })
    );
    const base = s3.publicBaseUrl || `${s3.endpoint.replace(/\/$/, "")}/${s3.bucket}`;
    return { key, url: `${base}/${key}`, storage: "s3" };
  }

  const dest = path.join(UPLOAD_ROOT, key);
  await mkdir(path.dirname(dest), { recursive: true });
  await writeFile(dest, data);
  return { key, url: `/api/files/${key}`, storage: "local" };
}
