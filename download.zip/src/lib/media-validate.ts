/**
 * Isomorphic video-source validation: direct media URLs, provider embeds,
 * share-page detection. Used by the admin UI (instant feedback) and by the
 * admin API (authoritative server-side validation).
 */
import { DIRECT_MEDIA_EXTS, DOWNLOADABLE_EXTS, EMBED_PROVIDERS, isTeraBoxHost } from "./media-types";

export function safeUrl(raw: string): URL | null {
  try {
    return new URL(raw);
  } catch {
    return null;
  }
}

/**
 * Normalise an absolute URL that points at this site's own /api/files/ paths
 * into the relative form the rest of the system stores (admins often paste
 * the full URL they see in the browser bar; uploads are always referenced as
 * /api/files/… so the download route can stat the local file).
 */
export function normalizeSelfFileUrl(raw: string): string {
  const url = raw.trim();
  if (!/^https?:\/\//i.test(url)) return url;
  const u = safeUrl(url);
  if (u && (u.pathname === "/api/files" || u.pathname.startsWith("/api/files/"))) {
    return `${u.pathname}${u.search}`;
  }
  return url;
}

/* ------------------------- direct media (MP4/HLS) ------------------------- */

export function isS3ObjectUrl(raw: string): boolean {
  return /^s3:\/\//i.test(raw.trim());
}

/** Parse `s3://bucket/key` into its parts (null when not that format). */
export function parseS3Url(raw: string): { bucket: string; key: string } | null {
  const m = /^s3:\/\/([^/]+)\/(.+)$/i.exec(raw.trim());
  if (!m) return null;
  return { bucket: decodeURIComponent(m[1]), key: m[2].replace(/^\/+/, "") };
}

export function looksLikeHls(raw: string): boolean {
  const u = safeUrl(raw);
  if (!u) return /\.m3u8(\?|$)/i.test(raw);
  return /\.m3u8(\?|$)/i.test(u.pathname) || /format=m3u8/i.test(u.search);
}

/**
 * Validate a direct HTTPS media URL. Returns an error message, or a warning
 * string prefixed with "warn:" for playable-but-noteworthy links, or null.
 */
export function validateDirectMediaUrl(raw: string): string | null {
  const url = normalizeSelfFileUrl(raw.trim());
  if (!url) return "Video URL is required for the External URL source.";
  if (isS3ObjectUrl(url)) {
    return parseS3Url(url)
      ? null
      : 'Use the format s3://bucket-name/path/to/video.mp4 for private object storage keys.';
  }
  if (url.startsWith("/api/files/")) return null; // uploaded through this site
  const u = safeUrl(url);
  if (!u) return "That is not a valid URL. Example: https://cdn.example.com/video.mp4";
  if (u.protocol === "http:") {
    return "External video URLs must use HTTPS so browsers allow playback on a secure site.";
  }
  if (u.protocol !== "https:") return "Only https:// media URLs are supported.";

  const share = detectSharePage(url);
  if (share) return share;

  const lower = u.pathname.toLowerCase();
  const hasKnownExt = DIRECT_MEDIA_EXTS.some((e) => lower.endsWith(e));
  if (!hasKnownExt) {
    // Extension-less CDN URLs are common; the probe confirms the Content-Type.
    return "warn:No video file extension detected (.mp4 / .m3u8 / .webm …). Preview will verify the Content-Type.";
  }
  return null;
}

/**
 * Detect ordinary cloud file-sharing page links — these serve an HTML page,
 * not video bytes, and must not be saved as a direct MP4 source.
 * Returns a helpful message when the link is a share page.
 */
export function detectSharePage(raw: string): string | null {
  const u = safeUrl(raw);
  if (!u) return null;
  const h = u.hostname.replace(/^www\./, "");
  const p = u.pathname;

  // Google Drive share page → official /preview embed exists, so redirect the admin there.
  if (h === "drive.google.com" || h === "docs.google.com") {
    if (/^\/file\/d\/[^/]+/.test(p)) {
      const id = p.split("/")[3];
      if (id) return `share:Google Drive share page detected. Use the “Provider embed” source — we convert it automatically (file id ${id}).`;
    }
    return "share:Google Drive links are not direct video files. Use the Provider embed source with a Drive share link.";
  }
  if (h === "youtube.com" || h === "m.youtube.com" || h === "youtu.be" || h === "music.youtube.com") {
    return "share:YouTube watch pages cannot be played as a direct file. Use the “Provider embed” source — we convert it automatically.";
  }
  if (h === "vimeo.com") {
    return "share:Vimeo page links cannot be played as a direct file. Use the “Provider embed” source — we convert it automatically.";
  }
  if (h === "dailymotion.com" || h === "dai.ly") {
    return "share:Dailymotion page links cannot be played as a direct file. Use the “Provider embed” source — we convert it automatically.";
  }
  if (h === "dropbox.com") {
    return "share:Dropbox share links serve an HTML viewer, not video bytes. Export a direct link from your host/CDN, or use a provider embed.";
  }
  if (h === "onedrive.live.com" || h === "1drv.ms" || h === "sharepoint.com") {
    return "share:OneDrive/SharePoint links are share pages, not direct video URLs. Use the official embed where available or a direct CDN URL.";
  }
  if (h === "wetransfer.com" || h === "we.tl" || h === "mega.nz" || h === "mediafire.com") {
    return `share:${h} links are download pages, not playable video URLs. Upload the file to object storage / a CDN with HTTPS and paste that direct link.`;
  }
  // TeraBox share links are routed to the Provider embed flow, where they get
  // a "Watch on TeraBox" button or an authorized streaming URL.
  if (isTeraBoxHost(u.hostname)) {
    return "share:TeraBox share links are not direct video files. Use the “Provider embed” source — we detect them automatically (visitors get a “Watch on TeraBox” button unless you add an authorized streaming URL).";
  }
  if (h === "t.me" || h === "telegram.me") {
    return "share:Telegram links are not direct video URLs.";
  }
  return null;
}

/* ------------------------------ embed providers --------------------------- */

export function providerIdFromEmbedUrl(raw: string): string | null {
  const u = safeUrl(raw);
  if (!u) return null;
  const h = u.hostname.replace(/^www\./, "");
  for (const [id, def] of Object.entries(EMBED_PROVIDERS)) {
    if (def.hosts.includes(h) || def.hosts.includes(u.hostname)) return id;
  }
  // Stricter path checks for hosts that also serve non-embed pages.
  if (h === "youtube.com" || h === "youtube-nocookie.com") return u.pathname.startsWith("/embed/") ? "youtube" : null;
  if (h === "dailymotion.com") return u.pathname.startsWith("/embed/") ? "dailymotion" : null;
  if (h === "drive.google.com") return /^\/file\/d\/[^/]+\/preview/.test(u.pathname) ? "gdrive" : null;
  if (h === "streamable.com") return u.pathname.startsWith("/e/") ? "streamable" : null;
  if (isTeraBoxHost(u.hostname))
    return u.pathname.startsWith("/sharing/link") || u.searchParams.has("surl") || u.pathname.startsWith("/s/") ? "terabox" : null;
  return null;
}

/**
 * Accept either an official embed URL or a normal watch/share URL from a
 * trusted provider and return the official embed URL. Non-trusted providers
 * are rejected — arbitrary iframe HTML is never accepted.
 */
export function toEmbedUrl(raw: string): { embedUrl: string; provider: string } | { error: string } {
  const url = raw.trim();
  if (!url) return { error: "Embed URL is required for the Provider embed source." };
  const u = safeUrl(url);
  if (!u) return { error: "That is not a valid URL." };
  if (u.protocol !== "https:" && u.protocol !== "http:")
    return { error: "Only http(s) provider URLs are supported." };

  const h = u.hostname.replace(/^www\./, "");
  const p = u.pathname;

  // YouTube — watch, youtu.be, shorts, existing embeds.
  if (h === "youtube.com" || h === "m.youtube.com" || h === "youtube-nocookie.com") {
    const shorts = p.startsWith("/shorts/") ? p.split("/")[2] : null;
    const embedId = p.startsWith("/embed/") ? p.split("/")[2] : null;
    const id = embedId || shorts || u.searchParams.get("v");
    if (id) return { embedUrl: `https://www.youtube-nocookie.com/embed/${id}?rel=0`, provider: "youtube" };
    return { error: "Could not find a video ID in that YouTube URL." };
  }
  if (h === "youtu.be") {
    const id = p.split("/")[1];
    if (id) return { embedUrl: `https://www.youtube-nocookie.com/embed/${id}?rel=0`, provider: "youtube" };
    return { error: "Could not find a video ID in that youtu.be URL." };
  }

  // Vimeo.
  if (h === "vimeo.com" || h === "player.vimeo.com") {
    const id = (p.match(/(\d{6,})/) || [])[1];
    if (id) return { embedUrl: `https://player.vimeo.com/video/${id}`, provider: "vimeo" };
    return { error: "Could not find a video ID in that Vimeo URL." };
  }

  // Dailymotion.
  if (h === "dailymotion.com" || h === "dai.ly") {
    const id = p.startsWith("/embed/") ? p.split("/")[3] : p.startsWith("/video/") ? p.split("/")[2] : h === "dai.ly" ? p.split("/")[1] : null;
    if (id) return { embedUrl: `https://www.dailymotion.com/embed/video/${id}`, provider: "dailymotion" };
    return { error: "Could not find a video ID in that Dailymotion URL." };
  }

  // Google Drive official preview embed.
  if (h === "drive.google.com" || h === "docs.google.com") {
    const id = (p.match(/\/file\/d\/([^/]+)/) || [])[1] || u.searchParams.get("id");
    if (id) return { embedUrl: `https://drive.google.com/file/d/${id}/preview`, provider: "gdrive" };
    return { error: "Could not find a file ID in that Google Drive URL." };
  }

  // TeraBox — normalise every brand domain to the canonical share URL.
  // No sanctioned public iframe embed exists, so playback uses the official
  // share page ("Watch on TeraBox") or an admin-configured streaming URL.
  if (isTeraBoxHost(u.hostname)) {
    const code = u.searchParams.get("surl") || (p.match(/^\/s\/([A-Za-z0-9_-]{8,})/) || [])[1] || (p.match(/^\/sharing\/link\/surl=([A-Za-z0-9_-]+)/) || [])[1];
    if (code) {
      return { embedUrl: `https://www.terabox.com/sharing/link?surl=${encodeURIComponent(code)}`, provider: "terabox" };
    }
    return {
      error:
        "Could not find a share code in that TeraBox URL. Copy the full share link, e.g. https://terabox.com/s/1AbC… or …/sharing/link?surl=…",
    };
  }

  // Streamable.
  if (h === "streamable.com") {
    if (p.startsWith("/e/")) {
      const id = p.split("/")[2];
      if (id) return { embedUrl: `https://streamable.com/e/${id}`, provider: "streamable" };
    }
    const id = p.split("/")[1];
    if (id) return { embedUrl: `https://streamable.com/e/${id}`, provider: "streamable" };
    return { error: "Could not find a video ID in that Streamable URL." };
  }

  const supported = Object.values(EMBED_PROVIDERS)
    .map((d) => d.label)
    .join(", ");
  return {
    error: `"${u.hostname}" is not a supported embed provider. Supported: ${supported}. For anything else, use a direct HTTPS media URL.`,
  };
}

/** Final server-side check before saving an embed URL. */
export function validateEmbedUrl(raw: string): { embedUrl: string; provider: string } | { error: string } {
  const converted = toEmbedUrl(raw);
  if ("error" in converted) return converted;
  const id = providerIdFromEmbedUrl(converted.embedUrl);
  if (!id) return { error: "That embed URL is not on the trusted provider list." };
  return { embedUrl: converted.embedUrl, provider: id };
}

/** Extract a Google Drive file id from a share/embed URL (null when none). */
export function extractGdriveFileId(raw: string): string | null {
  const u = safeUrl(raw);
  if (!u) return null;
  const h = u.hostname.replace(/^www\./, "");
  if (h !== "drive.google.com" && h !== "docs.google.com") return null;
  return (u.pathname.match(/\/file\/d\/([^/]+)/) || [])[1] || u.searchParams.get("id") || null;
}

/* -------------------------------- subtitles ------------------------------- */

export function validateSubtitleUrl(raw: string): string | null {
  const url = normalizeSelfFileUrl(raw.trim());
  if (!url) return "Subtitle URL is required once a language label is filled in.";
  if (url.startsWith("/api/files/")) return null; // uploaded through this site
  const u = safeUrl(url);
  if (!u) return "That subtitle URL is not a valid URL.";
  if (u.protocol !== "https:") return "Subtitle URLs must use HTTPS (uploaded files are fine).";
  if (!/\.vtt(\?|$)/i.test(u.pathname) && !/\.srt(\?|$)/i.test(u.pathname)) {
    return "warn:Subtitle does not end in .vtt/.srt — make sure the server sends text/vtt with CORS enabled.";
  }
  return null;
}

/* -------------------------------- downloads ------------------------------- */

/**
 * Validate a video DOWNLOAD url. Unlike a playback URL this must be a single
 * downloadable file: HLS playlists (.m3u8) and provider embeds are rejected —
 * they are streams, not files. Accepted: HTTPS direct file, /api/files/…
 * uploads, or s3://bucket/key for private-bucket objects (signed per viewer).
 * Returns an error message, a "warn:" string, or null.
 */
export function validateDownloadUrl(raw: string): string | null {
  const url = normalizeSelfFileUrl(raw.trim());
  if (!url) return "A download file URL is required.";
  if (isS3ObjectUrl(url)) {
    return parseS3Url(url)
      ? null
      : 'Use the format s3://bucket-name/path/to/video.mp4 for private object storage downloads.';
  }
  if (url.startsWith("/api/files/")) return null; // uploaded through this site
  const u = safeUrl(url);
  if (!u) return "That is not a valid URL. Example: https://cdn.example.com/movie.mp4";
  if (u.protocol === "http:") return "Download URLs must use HTTPS so browsers allow secure downloads.";
  if (u.protocol !== "https:") return "Only https:// download URLs are supported.";

  // Official Google Drive direct-download endpoint (the "Download anyway" link,
  // https://drive.google.com/uc?export=download&id=FILE_ID). This is Drive's
  // own download functionality — permitted; the file's sharing permissions and
  // any scan interstitial are enforced by Google itself.
  const dlHost = u.hostname.replace(/^www\./, "");
  if (
    (dlHost === "drive.google.com" || dlHost === "docs.google.com") &&
    u.searchParams.has("id") &&
    u.search.includes("export=download")
  ) {
    return null;
  }

  // TeraBox share pages ARE the provider's official download page. Allowed as
  // a download target, but the download continues on TeraBox's own site —
  // flagged as a warning so the admin knows visitors get an honest
  // "Open Download Link" handoff, never a scraped private URL.
  if (isTeraBoxHost(u.hostname)) {
    return "warn:TeraBox share page saved as the download target — visitors will get an “Open Download Link” button that opens TeraBox’s official page, where the download continues.";
  }

  const share = detectSharePage(url);
  if (share) return share;

  const lower = u.pathname.toLowerCase();
  if (/\.m3u8(\?|$)/i.test(lower) || /format=m3u8/i.test(u.search)) {
    return "HLS playlists (.m3u8) are streaming manifests, not a single downloadable file. Provide a separate MP4/WebM file URL for the download option.";
  }
  if (/\.mpd(\?|$)/i.test(lower)) {
    return "MPEG-DASH manifests (.mpd) are streaming manifests, not a single downloadable file. Provide a separate MP4/WebM file URL for the download option.";
  }
  const hasKnownExt = DOWNLOADABLE_EXTS.some((e) => lower.endsWith(e));
  if (!hasKnownExt) {
    return "warn:No .mp4 / .webm / .srt / .vtt file extension detected. “Check link” will verify the file and its download headers.";
  }
  return null;
}

/**
 * Validate a subtitle DOWNLOAD url (SRT / VTT file). Same rules as playback
 * subtitles, plus s3:// private-bucket support.
 */
export function validateSubtitleDownloadUrl(raw: string): string | null {
  const url = normalizeSelfFileUrl(raw.trim());
  if (!url) return "Subtitle download URL is required once a language label is filled in.";
  if (isS3ObjectUrl(url)) {
    return parseS3Url(url)
      ? null
      : 'Use the format s3://bucket-name/path/to/subs.srt for private object storage downloads.';
  }
  if (url.startsWith("/api/files/")) return null;
  const u = safeUrl(url);
  if (!u) return "That subtitle URL is not a valid URL.";
  if (u.protocol !== "https:") return "Subtitle download URLs must use HTTPS (uploaded files are fine).";
  if (!/\.vtt(\?|$)/i.test(u.pathname) && !/\.srt(\?|$)/i.test(u.pathname)) {
    return "warn:Subtitle does not end in .srt/.vtt — verify it with “Check link” so visitors get a real subtitle file.";
  }
  return null;
}
