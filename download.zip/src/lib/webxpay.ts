import { createPublicKey, constants, publicEncrypt, publicDecrypt } from "crypto";

/**
 * WEBXPAY Redirect Integration (official spec: developers.webxpay.com →
 * Guides → Redirect Integration).
 *
 * Security model:
 *  - The checkout request carries `payment` = base64(RSA-PKCS1 public-key
 *    encrypt("unique_order_id|total_amount")) using the merchant public key
 *    WEBXPAY issues — no card data ever passes through this website.
 *  - The donor completes payment on WEBXPAY's hosted billing page.
 *  - A donation becomes VERIFIED exclusively through the server-to-server
 *    callback whose `payment` + `signature` payloads are RSA-verified with
 *    the merchant public key (publicDecrypt equality — per the official doc)
 *    and whose amount is re-checked against the stored donation record.
 *
 * Supported currencies (official): LKR, USD, GBP, AUD.
 * Payment methods (official gateway list): international cards
 * (Visa/Mastercard/AMEX), eZ Cash, mCash, FriMi, Genie, Upay, DFCC Wallet,
 * Lanka QR and bank internet-banking gateways.
 */

export const WEBXPAY_CHECKOUT_URLS: Record<string, string> = {
  staging: "https://stagingxpay.info/index.php?route=checkout/billing",
  live: "https://webxpay.com/index.php?route=checkout/billing",
};

export type WebXPayCreds = {
  secretKey: string; // provided upon registration (server side only)
  publicKey: string; // PEM public key from the WEBXPAY dashboard
  mode: string; // "staging" | "live"
};

/** Official gateway method list shown on the donation page for WEBXPAY. */
export const WEBXPAY_METHODS = [
  "VISA",
  "MASTERCARD",
  "AMEX",
  "EZCASH",
  "MCASH",
  "FRIMI",
  "GENIE",
  "UPAY",
  "DFCC_WALLET",
  "LANKA_QR",
  "INTERNET_BANKING",
] as const;

/** Official method list from PayHere's published integration materials. */
export const PAYHERE_METHODS = ["VISA", "MASTERCARD", "AMEX", "EZCASH", "MCASH", "INTERNET_BANKING"] as const;

export function isValidPublicKey(pem: string): boolean {
  try {
    createPublicKey(pem);
    return pem.includes("PUBLIC KEY");
  } catch {
    return false;
  }
}

/**
 * Build the `payment` parameter for the checkout POST:
 * base64(openssl_public_encrypt("unique_order_id|total_amount")).
 */
export function encryptPaymentParam(orderId: string, amount: string, publicKeyPem: string): string {
  const plain = `${orderId}|${amount}`;
  return publicEncrypt({ key: publicKeyPem, padding: constants.RSA_PKCS1_PADDING }, Buffer.from(plain, "utf8")).toString("base64");
}

export type WebXPayCallback = {
  ok: boolean;
  reason?: string;
  orderId?: string;
  gatewayReference?: string;
  transactionDate?: string;
  statusCode?: string;
  comment?: string;
  gatewayUsed?: string;
};

/**
 * Verify + parse the callback POST (`payment`, `signature`, `custom_fields`).
 *
 * Per the official guide both parameters are base64 + RSA signatures that we
 * decrypt with the merchant public key; authenticity is confirmed when the
 * decrypted `payment` equals the decrypted `signature` (anti-MITM), and the
 * payment string parses to the documented 6-part format.
 */
export function verifyCallback(body: { payment?: string; signature?: string }, publicKeyPem: string): WebXPayCallback {
  const paymentB64 = (body.payment || "").trim();
  const signatureB64 = (body.signature || "").trim();
  if (!paymentB64 || !signatureB64) return { ok: false, reason: "Missing payment/signature" };

  let paymentStr: string;
  let signatureStr: string;
  try {
    paymentStr = publicDecrypt({ key: publicKeyPem, padding: constants.RSA_PKCS1_PADDING }, Buffer.from(paymentB64, "base64")).toString("utf8");
    signatureStr = publicDecrypt({ key: publicKeyPem, padding: constants.RSA_PKCS1_PADDING }, Buffer.from(signatureB64, "base64")).toString("utf8");
  } catch {
    return { ok: false, reason: "Signature decryption failed" };
  }

  // The two decrypted payloads must match — tamper protection required by the spec.
  if (paymentStr.trim() !== signatureStr.trim()) return { ok: false, reason: "Signature mismatch" };

  const parts = paymentStr.split("|");
  if (parts.length < 6) return { ok: false, reason: "Malformed payment payload" };

  return {
    ok: true,
    orderId: parts[0],
    gatewayReference: parts[1],
    transactionDate: parts[2],
    statusCode: parts[3],
    comment: parts[4],
    gatewayUsed: parts[5],
  };
}

/** Map a WEBXPAY status code to our donation status. 0/00 approved, 15 declined. */
export function mapStatus(code: string, comment: string): { status: string; message: string } {
  const normalized = (code || "").trim();
  if (normalized === "0" || normalized === "00") return { status: "VERIFIED", message: "Payment approved by WEBXPAY" };
  if (normalized === "15") return { status: "FAILED", message: `Payment declined by WEBXPAY${comment ? `: ${comment}` : ""}` };
  return { status: "FAILED", message: `WEBXPAY status ${normalized || "unknown"}${comment ? `: ${comment}` : ""}` };
}
