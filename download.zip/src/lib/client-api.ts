"use client";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function handle(res: Response) {
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }
  if (!res.ok) {
    throw new ApiError(errorMessage(data, `Request failed (${res.status})`), res.status);
  }
  return data;
}

function errorMessage(data: unknown, fallback: string): string {
  if (data && typeof data === "object" && "error" in data) {
    const msg = (data as { error?: unknown }).error;
    if (typeof msg === "string" && msg) return msg;
  }
  return fallback;
}

export const api = {
  async get<T>(url: string): Promise<T> {
    const res = await fetch(url, { credentials: "same-origin" });
    return handle(res) as Promise<T>;
  },
  async send<T>(method: string, url: string, body?: unknown): Promise<T> {
    const res = await fetch(url, {
      method,
      credentials: "same-origin",
      headers: body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    return handle(res) as Promise<T>;
  },
  post<T>(url: string, body?: unknown) {
    return this.send<T>("POST", url, body);
  },
  put<T>(url: string, body?: unknown) {
    return this.send<T>("PUT", url, body);
  },
  patch<T>(url: string, body?: unknown) {
    return this.send<T>("PATCH", url, body);
  },
  delete<T>(url: string) {
    return this.send<T>("DELETE", url);
  },
  /** Multipart upload with progress callback (XMLHttpRequest for progress events). */
  upload<T>(
    url: string,
    form: FormData,
    onProgress?: (pct: number) => void
  ): { promise: Promise<T>; abort: () => void } {
    const xhr = new XMLHttpRequest();
    const promise = new Promise<T>((resolve, reject) => {
      xhr.open("POST", url);
      xhr.withCredentials = true;
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onload = () => {
        let data: unknown = null;
        try {
          data = JSON.parse(xhr.responseText);
        } catch {
          /* ignore */
        }
        if (xhr.status >= 200 && xhr.status < 300) resolve(data as T);
        else {
          reject(new ApiError(errorMessage(data, `Upload failed (${xhr.status})`), xhr.status));
        }
      };
      xhr.onerror = () => reject(new ApiError("Network error during upload", 0));
      xhr.onabort = () => reject(new ApiError("Upload cancelled", 0));
      xhr.send(form);
    });
    return { promise, abort: () => xhr.abort() };
  },
};

export function fmtDuration(sec?: number | null): string {
  if (!sec || sec <= 0) return "";
  if (sec < 60) return `${Math.round(sec)}s`;
  const h = Math.floor(sec / 3600);
  const m = Math.round((sec % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export const LANGUAGE_LABELS: Record<string, string> = {
  SINHALA_DUBBED: "සිංහල Dubbed",
  SINHALA_SUB: "සිංහල Sub",
  ANIME_REVIEW: "Anime Review",
};
