/**
 * Password policy shared by the client (live validation hints) and the server
 * (authoritative enforcement). Keep both sides in sync via this module.
 */

export const PASSWORD_MIN_LENGTH = 8;

export type PasswordCheck = { ok: boolean; message: string };

export function validatePassword(password: string): PasswordCheck {
  if (!password || password.length < PASSWORD_MIN_LENGTH) {
    return { ok: false, message: `Password must be at least ${PASSWORD_MIN_LENGTH} characters long.` };
  }
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
    return { ok: false, message: "Password must contain at least one letter and one number." };
  }
  // Reject control characters (anything not printable, incl. tabs/newlines).
  if (/[\u0000-\u001F\u007F]/.test(password)) {
    return { ok: false, message: "Password contains unsupported characters." };
  }
  return { ok: true, message: "" };
}

/** Rough strength score 0–4 for the UI strength meter. */
export function passwordStrength(password: string): 0 | 1 | 2 | 3 | 4 {
  if (!password) return 0;
  let score = 0;
  if (password.length >= PASSWORD_MIN_LENGTH) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password) && /[^A-Za-z0-9]/.test(password)) score++;
  return Math.min(4, score) as 0 | 1 | 2 | 3 | 4;
}
