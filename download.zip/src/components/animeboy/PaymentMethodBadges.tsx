"use client";

/**
 * Payment method badges — secure, brand-accurate text chips rendered with the
 * site's own styling (no third-party images, no fake methods: the lists come
 * from the configured provider's official capabilities via the API).
 */

export const PAYMENT_METHOD_LABELS: Record<string, string> = {
  VISA: "Visa",
  MASTERCARD: "Mastercard",
  AMEX: "American Express",
  DISCOVER: "Discover",
  EZCASH: "eZ Cash",
  MCASH: "mCash",
  FRIMI: "FriMi",
  GENIE: "Genie",
  UPAY: "Upay",
  DFCC_WALLET: "DFCC Wallet",
  LANKA_QR: "Lanka QR",
  INTERNET_BANKING: "Internet Banking",
  BANK_TRANSFER: "Bank Transfer",
};

export function methodLabel(m: string): string {
  return PAYMENT_METHOD_LABELS[m] || m;
}

/** Row of small brand chips used on the donation page + admin panels. */
export function MethodChips({ methods, className = "" }: { methods: string[]; className?: string }) {
  return (
    <span className={`flex flex-wrap gap-1 ${className}`} aria-label="Supported payment methods">
      {methods.map((m) => (
        <span
          key={m}
          className="inline-flex items-center rounded-md border border-white/12 bg-[#0b1120] px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-slate-300"
        >
          {methodLabel(m)}
        </span>
      ))}
    </span>
  );
}
