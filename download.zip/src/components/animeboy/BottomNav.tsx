"use client";

import { Home, Clapperboard, MonitorPlay, Brush, Search } from "lucide-react";
import { navigate, isRouteActive, useAppStore } from "@/store/useAppStore";

const ITEMS = [
  { label: "Home", hash: "/", icon: Home },
  { label: "Movies", hash: "/movies", icon: Clapperboard },
  { label: "Series", hash: "/series", icon: MonitorPlay },
  { label: "Donghua Movie", hash: "/donghua", icon: Brush },
  { label: "Search", hash: "/search", icon: Search },
];

/** Fixed bottom navigation for mobile — highlights active item in green. */
export function BottomNav() {
  const { route } = useAppStore();

  const isActive = (hash: string) => isRouteActive(route.path, hash);

  return (
    <nav
      aria-label="Bottom navigation"
      className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/10 bg-[#070b1a]/95 backdrop-blur-xl md:hidden"
    >
      <div className="pb-safe-nav mx-auto grid max-w-lg grid-cols-5">
        {ITEMS.map((item) => {
          const active = isActive(item.hash);
          return (
            <button
              key={item.hash}
              onClick={() => navigate(item.hash)}
              aria-current={active ? "page" : undefined}
              aria-label={item.label}
              className={`relative flex min-h-[56px] flex-col items-center justify-center gap-1 pt-1.5 transition-colors ${
                active ? "text-[#4ADE80]" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <item.icon
                className={`h-[22px] w-[22px] transition-transform ${active ? "scale-110 drop-shadow-[0_0_8px_rgba(74,222,128,0.6)]" : ""}`}
                strokeWidth={active ? 2.4 : 1.8}
              />
              <span className={`max-w-full text-center text-[10.5px] leading-tight ${active ? "font-bold" : "font-medium"}`}>{item.label}</span>
              {active && (
                <span className="absolute bottom-0.5 h-1 w-1 rounded-full bg-[#4ADE80] shadow-[0_0_6px_rgba(74,222,128,0.9)]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
