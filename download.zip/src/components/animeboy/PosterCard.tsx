"use client";

import { useState } from "react";
import { Star, Play, CalendarDays, Film, MonitorPlay, Brush, TvMinimalPlay, Info } from "lucide-react";
import { navigate, type AnimeType, type EpisodeCardType } from "@/store/useAppStore";
import { LANGUAGE_LABELS } from "@/lib/client-api";

type PosterAnime = Pick<
  AnimeType,
  | "id" | "slug" | "type" | "titleEn" | "genres" | "releaseYear" | "rating" | "status"
  | "posterUrl" | "languageLabel"
> & { episodeBadge?: string; category?: "ANIME" | "DONGHUA" | "OTHERS" };

const GRADIENTS = [
  "from-emerald-900/70 via-[#101827] to-[#050816]",
  "from-teal-900/60 via-[#101827] to-[#050816]",
  "from-lime-900/50 via-[#101827] to-[#050816]",
  "from-green-900/60 via-[#0b1120] to-[#050816]",
];

export function PosterCard({ anime, episodeBadge }: { anime: PosterAnime; episodeBadge?: string }) {
  const [overlay, setOverlay] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);
  const upcoming = anime.status === "UPCOMING";
  const genres = Array.isArray(anime.genres) ? anime.genres : [];
  const gradient = GRADIENTS[anime.id.charCodeAt(anime.id.length - 1) % GRADIENTS.length];

  const open = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/anime/${anime.slug}`);
  };

  const watch = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(upcoming ? `/anime/${anime.slug}` : `/watch/${anime.slug}`);
  };

  const detailHref = `/anime/${anime.slug}`;

  return (
    <div
      className="group/card w-[150px] shrink-0 sm:w-[168px] lg:w-[176px]"
      onMouseEnter={() => setOverlay(true)}
      onMouseLeave={() => setOverlay(false)}
    >
      <button
        onClick={(e) => {
          // Touch: first tap reveals overlay actions; second tap opens details.
          if (window.matchMedia("(hover: none)").matches && !overlay) {
            e.preventDefault();
            setOverlay(true);
            return;
          }
          setOverlay(false);
          open(e);
        }}
        onBlur={() => setOverlay(false)}
        onFocus={() => setOverlay(true)}
        aria-label={`${anime.titleEn} — ${upcoming ? "coming soon" : "view details"}`}
        className={`relative block w-full overflow-hidden rounded-xl border border-white/8 bg-[#101827] text-left shadow-lg shadow-black/40 transition-all duration-300 hover:border-[#22C55E]/45 hover:shadow-[0_0_28px_rgba(34,197,94,0.18)] focus-visible:border-[#22C55E] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#22C55E]/60`}
      >
        <div className="relative aspect-[2/3] w-full">
          {anime.posterUrl && !imgFailed ? (
            <img
              src={anime.posterUrl}
              alt={`${anime.titleEn} poster`}
              loading="lazy"
              decoding="async"
              onError={() => setImgFailed(true)}
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover/card:scale-[1.06]"
            />
          ) : (
            <div className={`absolute inset-0 flex items-center justify-center bg-gradient-to-br ${gradient} p-4`}>
              <span className="text-center text-sm font-bold text-[#4ADE80]/90">{anime.titleEn}</span>
            </div>
          )}

          {/* darkening + gradient overlay for legibility */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-black/25" />

          {/* type badge top-left — donghua titles carry the Donghua Movie / Donghua Series badge */}
          {anime.category === "DONGHUA" ? (
            <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-md bg-[#22C55E]/85 px-1.5 py-0.5 text-[9.5px] font-bold uppercase tracking-wide text-[#04220f] backdrop-blur-sm">
              {anime.type === "MOVIE" ? <Brush className="h-2.5 w-2.5" /> : <TvMinimalPlay className="h-2.5 w-2.5" />}
              {anime.type === "MOVIE" ? "Donghua Movie" : "Donghua Series"}
            </span>
          ) : anime.category === "OTHERS" ? (
            <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-md bg-[#22C55E]/85 px-1.5 py-0.5 text-[9.5px] font-bold uppercase tracking-wide text-[#04220f] backdrop-blur-sm">
              <Film className="h-2.5 w-2.5" />
              Others
            </span>
          ) : (
            <span
              className={`absolute left-2 top-2 inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[9.5px] font-bold uppercase tracking-wide backdrop-blur-sm ${
                anime.type === "MOVIE"
                  ? "bg-[#22C55E]/85 text-[#04220f]"
                  : "bg-white/15 text-white border border-white/20"
              }`}
            >
              {anime.type === "MOVIE" ? <Film className="h-2.5 w-2.5" /> : <MonitorPlay className="h-2.5 w-2.5" />}
              {anime.type === "MOVIE" ? "Movie" : "Series"}
            </span>
          )}

          {/* rating top-right (gold star) */}
          {typeof anime.rating === "number" && (
            <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-md bg-black/65 px-1.5 py-0.5 text-[11px] font-bold text-white backdrop-blur-sm">
              <Star className="h-3 w-3 fill-[#FACC15] text-[#FACC15]" />
              {anime.rating.toFixed(1)}
            </span>
          )}

          {episodeBadge && (
            <span className="absolute bottom-2 left-2 rounded-md bg-[#22C55E] px-1.5 py-0.5 text-[10px] font-black text-[#04220f]">
              {episodeBadge}
            </span>
          )}

          {/* COMING SOON overlay */}
          {upcoming && (
            <div className="pointer-events-none absolute inset-0 flex items-end justify-center bg-gradient-to-t from-[#050816]/90 via-transparent to-transparent">
              <span className="mb-3 rounded-md bg-[#F59E0B]/95 px-2.5 py-1 text-[11px] font-black tracking-widest text-[#1c1002] shadow-lg">
                COMING SOON
              </span>
            </div>
          )}

          {/* hover / focus / tap overlay with actions */}
          <div
            className={`poster-overlay absolute inset-0 flex flex-col items-center justify-center gap-2.5 px-3 pb-5 transition-opacity duration-300 ${
              overlay && !upcoming ? "opacity-100" : "opacity-0"
            }`}
            aria-hidden={!overlay || upcoming}
          >
            {!upcoming && (
              <>
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#22C55E] text-[#04220f] shadow-xl shadow-[#22C55E]/40 transition-transform hover:scale-110">
                  <Play className="h-5 w-5 fill-current" />
                </span>
                <span className="text-sm font-bold text-white drop-shadow">{episodeBadge ? "Watch Episode" : "Watch Now"}</span>
                <span className="flex flex-wrap justify-center gap-1">
                  {genres.slice(0, 2).map((g) => (
                    <span key={g} className="rounded-full bg-white/12 px-2 py-0.5 text-[10px] font-semibold text-slate-100">
                      {g}
                    </span>
                  ))}
                </span>
                <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[10px] font-medium text-slate-200">
                  {LANGUAGE_LABELS[anime.languageLabel] || anime.languageLabel}
                </span>
                <span
                  role="button"
                  tabIndex={-1}
                  onClick={watch}
                  className="mt-0.5 inline-flex items-center gap-1 rounded-full bg-[#22C55E]/90 px-3 py-1 text-[11px] font-bold text-[#04220f]"
                >
                  <Play className="h-3 w-3 fill-current" /> {episodeBadge ? "Play" : "Watch"}
                </span>
                <span
                  role="button"
                  tabIndex={-1}
                  onClick={open}
                  className="inline-flex items-center gap-1 rounded-full bg-white/12 px-3 py-1 text-[11px] font-semibold text-white"
                >
                  <Info className="h-3 w-3" /> More Info
                </span>
              </>
            )}
          </div>
        </div>
      </button>

      {/* title + year */}
      <button onClick={open} className="mt-2 block w-full text-left">
        <h3 className="line-clamp-2 text-[13.5px] font-semibold leading-snug text-slate-100 transition-colors group-hover/card:text-[#4ADE80]">
          {anime.titleEn}
        </h3>
        <p className="mt-0.5 flex items-center gap-1.5 text-[12px]">
          {upcoming ? (
            <CalendarDays className="h-3.5 w-3.5 text-[#F59E0B]" />
          ) : (
            <CalendarDays className="h-3.5 w-3.5 text-slate-500" />
          )}
          {episodeBadge ? (
            <span className="font-bold text-[#4ADE80]">Episode {episodeBadge.replace(/^EP ?/i, "")}</span>
          ) : (
            <span className={upcoming ? "font-semibold text-[#F59E0B]" : "text-slate-500"}>
              {anime.releaseYear || "TBA"}
            </span>
          )}
        </p>
      </button>
    </div>
  );
}

/** Latest-episode card variant (shows EP + anime title). */
export function EpisodeCard({ item }: { item: EpisodeCardType }) {
  return (
    <PosterCard
      anime={{
        id: item.id,
        slug: item.anime.slug,
        type: item.anime.type === "SERIES" ? "SERIES" : "MOVIE",
        category: item.anime.category === "DONGHUA" ? "DONGHUA" : "ANIME",
        titleEn: item.anime.titleEn,
        genres: [],
        releaseYear: null,
        rating: item.anime.rating,
        status: "RELEASED",
        posterUrl: item.anime.posterUrl,
        languageLabel: "SINHALA_DUBBED",
        episodeBadge: `EP ${item.number}`,
      }}
      episodeBadge={`EP ${item.number}`}
    />
  );
}
