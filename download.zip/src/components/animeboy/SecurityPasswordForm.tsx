"use client";

/**
 * Shared "Security & Password" form used by BOTH the user Account Settings
 * page and the Admin Dashboard settings — each account can only ever change
 * its own password (the server targets the session user exclusively).
 *
 *  - Current password required (reauthentication for a sensitive change).
 *  - Strong-password policy with a live strength meter.
 *  - Show/hide toggles on every field.
 *  - Success notification, then re-sign-in (all other sessions are revoked).
 */
import { useState } from "react";
import { Eye, EyeOff, KeyRound, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { passwordStrength, validatePassword } from "@/lib/password-policy";
import { navigate, useAppStore, type SessionUser } from "@/store/useAppStore";

const inputCls =
  "h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] pl-11 pr-11 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25";

const STRENGTH_LABELS = ["", "Weak", "Fair", "Good", "Strong"];
const STRENGTH_COLORS = ["", "bg-red-500", "bg-amber-500", "bg-[#FACC15]", "bg-[#22C55E]"];

export function SecurityPasswordForm({ isAdmin = false }: { isAdmin?: boolean }) {
  const { setUser } = useAppStore();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const strength = passwordStrength(next);
  const clientCheck = next ? validatePassword(next) : { ok: true, message: "" };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!current) return setError("Please enter your current password.");
    if (!clientCheck.ok) return setError(clientCheck.message);
    if (next !== confirm) return setError("The new password and confirmation do not match.");

    setBusy(true);
    try {
      await api.post("/api/auth/change-password", { currentPassword: current, newPassword: next });
      toast.success("Password updated successfully ✓", {
        description: "All other devices were signed out. Please sign in with your new password.",
      });
      // tokenVersion was bumped — this device's new session is already set by
      // the server; simply reset local form state. Keep the user signed in.
      setCurrent("");
      setNext("");
      setConfirm("");
      // Refresh the session user (role/name unchanged, but keeps state honest).
      try {
        const me = await api.get<{ user: SessionUser | null }>("/api/auth/me");
        setUser(me.user);
      } catch {
        /* ignore */
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Password change failed";
      setError(msg);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section
      className="rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-7"
      aria-labelledby="security-password-heading"
    >
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#22C55E]/12">
          <KeyRound className="h-5.5 w-5.5 text-[#4ADE80]" />
        </span>
        <div>
          <h2 id="security-password-heading" className="text-lg font-black text-white">
            Security &amp; Password
          </h2>
          <p className="text-xs text-slate-400">
            {isAdmin
              ? "Change your admin password — your dashboard, content and user records stay untouched."
              : "Change your account password — your watchlist and requests stay untouched."}
          </p>
        </div>
      </div>

      <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
        <PasswordField
          label="Current Password"
          value={current}
          onChange={setCurrent}
          visible={showCurrent}
          onToggle={() => setShowCurrent((v) => !v)}
          autoComplete="current-password"
          placeholder="Your current password"
        />

        <div>
          <PasswordField
            label="New Password"
            value={next}
            onChange={setNext}
            visible={showNext}
            onToggle={() => setShowNext((v) => !v)}
            autoComplete="new-password"
            placeholder="At least 8 characters with a letter and a number"
          />
          {next && (
            <div className="mt-2" aria-live="polite">
              <div className="flex items-center gap-2">
                <div className="flex h-1.5 flex-1 gap-1" aria-hidden="true">
                  {[1, 2, 3, 4].map((i) => (
                    <span
                      key={i}
                      className={`h-full flex-1 rounded-full transition-colors ${i <= strength ? STRENGTH_COLORS[strength] : "bg-white/10"}`}
                    />
                  ))}
                </div>
                <span className={`text-[11px] font-bold ${strength >= 3 ? "text-[#4ADE80]" : strength === 2 ? "text-[#FACC15]" : "text-amber-400"}`}>
                  {STRENGTH_LABELS[strength]}
                </span>
              </div>
              {!clientCheck.ok && <p className="mt-1 text-[11px] text-amber-300">{clientCheck.message}</p>}
            </div>
          )}
        </div>

        <PasswordField
          label="Confirm New Password"
          value={confirm}
          onChange={setConfirm}
          visible={showConfirm}
          onToggle={() => setShowConfirm((v) => !v)}
          autoComplete="new-password"
          placeholder="Type the new password again"
          error={confirm && next !== confirm ? "Passwords do not match" : ""}
        />

        {error && (
          <p role="alert" className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
            {error}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={busy}
            className="inline-flex h-12 items-center gap-2 rounded-full bg-[#22C55E] px-7 text-sm font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
            Save New Password
          </button>
          <p className="text-[11px] leading-relaxed text-slate-500">
            Passwords are stored as bcrypt hashes — never in plain text. All other devices are signed out after a change.
          </p>
        </div>
      </form>
    </section>
  );
}

function PasswordField({
  label,
  value,
  onChange,
  visible,
  onToggle,
  autoComplete,
  placeholder,
  error,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  visible: boolean;
  onToggle: () => void;
  autoComplete: string;
  placeholder: string;
  error?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-bold text-slate-200">{label}</span>
      <span className="relative block">
        <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
        <input
          type={visible ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className={inputCls}
          aria-label={label}
          aria-invalid={!!error}
        />
        <button
          type="button"
          onClick={onToggle}
          aria-label={visible ? `Hide ${label}` : `Show ${label}`}
          className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white/5 hover:text-[#4ADE80]"
        >
          {visible ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
        </button>
      </span>
      {error && <span className="mt-1 block text-[11px] text-red-300">{error}</span>}
    </label>
  );
}
