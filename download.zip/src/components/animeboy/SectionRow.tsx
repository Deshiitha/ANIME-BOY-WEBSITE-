"use client";

import { useRef } from "react";
import { ChevronLeft, ChevronRight, ArrowRight, Hourglass, Star } from "lucide-react";
import { navigate } from "@/store/useAppStore";
import { PosterCard, EpisodeCard } from "./PosterCard";
import type { AnimeType, EpisodeCardType } from "@/store/useAppStore";

type Tone = "green" | "amber" | "gold";

const TONE_CLASSES: Record<Tone, { divider: string; count: string }> = {
  green: { divider: "from-[#22C55E] to-transparent", count: "text-slate-400" },
  amber: { divider: "from-[#F59E0B] to-transparent", count: "text-[#F59E0B]/90" },
  gold: { divider: "from-[#FACC15] to-transparent", count: "text-[#FACC15]/90" },
};

type SectionRowProps = {
  icon: React.ReactNode;
  title: string;
  tone?: Tone;
  count?: number;
  viewAllHash?: string;
  upcomingBadge?: boolean;
  items?: AnimeType[];
  episodeItems?: EpisodeCardType[];
};

/**
 * Homepage row: icon + bold heading + divider + count + View All,
 * with a horizontally scrollable poster strip and desktop arrows.
 */
export function SectionRow({
  icon,
  title,
  tone = "green",
  count,
  viewAllHash,
  upcomingBadge,
  items,
  episodeItems,
}: SectionRowProps) {
  const scroller = useRef<HTMLDivElement>(null);
  if (!items?.length && !episodeItems?.length) return null; // hide empty sections gracefully

  const toneCls = TONE_CLASSES[tone];
  const scroll = (dir: 1 | -1) => {
    scroller.current?.scrollBy({ left: dir * Math.round((scroller.current?.clientWidth || 600) * 0.85), behavior: "smooth" });
  };

  const cardCount = count ?? items?.length ?? episodeItems?.length ?? 0;
  const countLabel = items
    ? `${cardCount} ${items[0]?.type === "SERIES" ? (cardCount === 1 ? "series" : "series") : cardCount === 1 ? "movie" : "movies"}`
    : `${cardCount} ${cardCount === 1 ? "episode" : "episodes"}`;

  return (
    <section aria-label={title} className="fade-up">
      {/* header: icon + heading + divider + count + view all */}
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 sm:px-6">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/[0.04] text-lg">
          {icon}
        </span>
        <h2 className="whitespace-nowrap text-lg font-extrabold text-white sm:text-xl">{title}</h2>
        {upcomingBadge && (
          <span className="hidden shrink-0 items-center gap-1 rounded-md border border-[#F59E0B]/40 bg-[#F59E0B]/10 px-2 py-0.5 text-[10.5px] font-black uppercase tracking-wider text-[#F59E0B] sm:inline-flex">
            <Hourglass className="h-3 w-3" /> Upcoming
          </span>
        )}
        <span className={`hidden h-[3px] min-w-10 flex-1 rounded-full bg-gradient-to-r sm:block ${toneCls.divider}`} />
        <span className={`hidden shrink-0 text-[13px] font-medium sm:block ${toneCls.count}`}>{countLabel}</span>
        {viewAllHash && (
          <button
            onClick={() => navigate(viewAllHash)}
            className="ml-auto inline-flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[13px] font-bold text-[#4ADE80] transition-colors hover:bg-[#22C55E]/10 sm:ml-0"
          >
            View All <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {/* scroller */}
      <div className="relative mt-4">
        <div
          ref={scroller}
          className="no-scrollbar flex snap-x snap-mandatory gap-3.5 overflow-x-auto scroll-smooth px-4 pb-2 sm:px-6"
          role="list"
        >
          {items?.map((a) => (
            <div role="listitem" key={a.id} className="snap-start">
              <PosterCard anime={a} />
            </div>
          ))}
          {episodeItems?.map((e) => (
            <div role="listitem" key={e.id} className="snap-start">
              <EpisodeCard item={e} />
            </div>
          ))}
        </div>

        {/* desktop arrows */}
        <button
          onClick={() => scroll(-1)}
          aria-label={`Scroll ${title} left`}
          className="absolute -left-1 top-[38%] hidden h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-white/10 bg-[#0b1120]/90 text-white shadow-xl backdrop-blur transition-all hover:border-[#22C55E]/50 hover:text-[#4ADE80] lg:flex"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          onClick={() => scroll(1)}
          aria-label={`Scroll ${title} right`}
          className="absolute -right-1 top-[38%] hidden h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-white/10 bg-[#0b1120]/90 text-white shadow-xl backdrop-blur transition-all hover:border-[#22C55E]/50 hover:text-[#4ADE80] lg:flex"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>
    </section>
  );
}

export function TopRatedIcon() {
  return <Star className="h-5 w-5 fill-[#FACC15] text-[#FACC15]" />;
}
