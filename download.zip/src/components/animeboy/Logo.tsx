"use client";

import { navigate } from "@/store/useAppStore";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <button
      onClick={() => navigate("/")}
      aria-label="ANIME BOY — Home"
      className="flex items-center gap-2.5 group select-none"
    >
      {/* Original shuriken-play emblem */}
      <span className="relative inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#0a0f24] border border-[#22C55E]/40 glow-green transition-transform duration-300 group-hover:rotate-6 group-hover:scale-105">
        <svg viewBox="0 0 64 64" className="h-7 w-7" aria-hidden="true">
          <defs>
            <linearGradient id="ab-shuriken-g" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#4ADE80" />
              <stop offset="1" stopColor="#16A34A" />
            </linearGradient>
          </defs>
          <path
            fill="url(#ab-shuriken-g)"
            d="M32 4 L38 23 Q39.8 21.2 41.4 19.4 L44.6 23 Q42.8 24.8 41 26.5 L60 32 L41 37.5 Q42.8 39.2 44.6 41 L41.4 44.6 Q39.8 42.8 38 41 L32 60 L26 41 Q24.2 42.8 22.6 44.6 L19.4 41 Q21.2 39.2 23 37.5 L4 32 L23 26.5 Q21.2 24.8 19.4 23 L22.6 19.4 Q24.2 21.2 26 23 Z"
          />
          <circle cx="32" cy="32" r="9" fill="#050816" />
          <path fill="url(#ab-shuriken-g)" d="M29 27 L38.5 32 L29 37 Z" />
        </svg>
      </span>
      {!compact && (
        <span className="flex flex-col items-start leading-none">
          <span className="text-xl font-black tracking-wide text-white">
            ANIME <span className="text-[#4ADE80] text-glow-green">BOY</span>
          </span>
          <span className="text-[10px] font-medium tracking-[0.22em] text-slate-400 mt-1">
            සිංහල ANIME ස්ට්‍රීමින්
          </span>
        </span>
      )}
    </button>
  );
}
