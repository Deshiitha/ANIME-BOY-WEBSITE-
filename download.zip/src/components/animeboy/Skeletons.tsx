"use client";

export function PosterSkeleton() {
  return (
    <div className="w-[150px] shrink-0 sm:w-[168px] lg:w-[176px]" aria-hidden="true">
      <div className="aspect-[2/3] w-full animate-pulse rounded-xl bg-white/[0.05]" />
      <div className="mt-2 h-3.5 w-4/5 animate-pulse rounded bg-white/[0.06]" />
      <div className="mt-1.5 h-3 w-1/3 animate-pulse rounded bg-white/[0.04]" />
    </div>
  );
}

export function PosterGridSkeleton({ count = 12 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-x-3.5 gap-y-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6" aria-label="Loading">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} aria-hidden="true">
          <div className="aspect-[2/3] w-full animate-pulse rounded-xl bg-white/[0.05]" />
          <div className="mt-2 h-3.5 w-4/5 animate-pulse rounded bg-white/[0.06]" />
          <div className="mt-1.5 h-3 w-1/3 animate-pulse rounded bg-white/[0.04]" />
        </div>
      ))}
    </div>
  );
}

export function HeroSkeleton() {
  return (
    <div className="relative h-[68vh] min-h-[440px] w-full overflow-hidden sm:h-[76vh] lg:h-[82vh] lg:max-h-[720px]" aria-hidden="true">
      <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-[#0a1128] via-[#0d1526] to-[#050816]" />
      <div className="absolute inset-x-0 bottom-0 mx-auto max-w-7xl px-4 pb-20 sm:px-6">
        <div className="h-8 w-64 animate-pulse rounded-full bg-white/[0.06]" />
        <div className="mt-4 h-10 w-80 animate-pulse rounded-lg bg-white/[0.08]" />
        <div className="mt-3 h-5 w-56 animate-pulse rounded bg-white/[0.05]" />
        <div className="mt-4 flex gap-2">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-7 w-20 animate-pulse rounded-full bg-white/[0.06]" />
          ))}
        </div>
        <div className="mt-5 h-4 w-full max-w-lg animate-pulse rounded bg-white/[0.05]" />
        <div className="mt-2 h-4 w-3/4 max-w-md animate-pulse rounded bg-white/[0.05]" />
        <div className="mt-6 flex gap-3">
          <div className="h-12 w-36 animate-pulse rounded-full bg-[#22C55E]/20" />
          <div className="h-12 w-32 animate-pulse rounded-full bg-white/[0.07]" />
        </div>
      </div>
    </div>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-14" role="status" aria-live="polite">
      <span className="h-7 w-7 animate-spin rounded-full border-2 border-[#22C55E]/25 border-t-[#22C55E]" />
      {label && <span className="text-sm text-slate-400">{label}</span>}
    </div>
  );
}
