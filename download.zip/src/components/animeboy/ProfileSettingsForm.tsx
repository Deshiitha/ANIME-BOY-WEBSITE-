"use client";

/**
 * Shared "Profile Settings" (Change Username) form used by BOTH the user
 * Account Settings page and the Admin Dashboard settings — each account can
 * only ever change its own username (the server targets the session user
 * exclusively; a client-supplied id is never accepted).
 *
 *  - Current Username shown read-only; New Username is editable.
 *  - Live availability indicator (debounced check against the database).
 *  - Admin accounts additionally reauthenticate with their current password
 *    (sensitive profile change) — regular users only need their session.
 *  - Success and error notifications (inline + toast).
 *  - The store user is updated on success, so the navigation bar, account
 *    dropdown and profile card all show the new username immediately.
 */
import { useEffect, useRef, useState } from "react";
import {
  AtSign,
  CheckCircle2,
  Eye,
  EyeOff,
  Info,
  Loader2,
  Lock,
  UserRound,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { validateUsername } from "@/lib/username-policy";
import { useAppStore, type SessionUser } from "@/store/useAppStore";

const inputCls =
  "h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] pl-11 pr-11 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25";

type Availability =
  | { state: "idle" | "checking" | "current" | "available"; message: string }
  | { state: "unavailable"; message: string };

export function ProfileSettingsForm({ isAdmin = false }: { isAdmin?: boolean }) {
  const { user, setUser } = useAppStore();
  const [next, setNext] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [avail, setAvail] = useState<Availability>({ state: "idle", message: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const checkId = useRef(0);

  const currentName = user?.name || "";
  const sameAsCurrent = !!next.trim() && next.trim().toLowerCase() === currentName.toLowerCase();

  // Debounced availability indicator: local policy first (instant feedback),
  // then a single database check per settled value.
  useEffect(() => {
    const value = next.trim();
    setError("");
    if (!value) {
      setAvail({ state: "idle", message: "" });
      return;
    }
    if (value.toLowerCase() === currentName.toLowerCase()) {
      setAvail({ state: "current", message: "This is your current username — pick a new one to change it." });
      return;
    }
    const local = validateUsername(value, isAdmin);
    if (!local.ok) {
      setAvail({ state: "unavailable", message: local.message });
      return;
    }
    setAvail({ state: "checking", message: "" });
    const id = ++checkId.current;
    const timer = setTimeout(async () => {
      try {
        const res = await api.get<{ available: boolean; reason?: string; current?: boolean }>(
          `/api/auth/username-available?u=${encodeURIComponent(value)}`
        );
        if (checkId.current !== id) return;
        if (res.current) setAvail({ state: "current", message: "This is your current username — pick a new one to change it." });
        else if (res.available) setAvail({ state: "available", message: `“${value}” is available` });
        else setAvail({ state: "unavailable", message: res.reason || "This username is already taken. Please choose another one." });
      } catch (err) {
        if (checkId.current !== id) return;
        setAvail({
          state: "unavailable",
          message: err instanceof Error ? err.message : "Could not check availability right now.",
        });
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [next, isAdmin, currentName]);

  const canSave =
    !busy &&
    !!next.trim() &&
    !sameAsCurrent &&
    avail.state === "available" &&
    (!isAdmin || !!currentPassword);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const value = next.trim();
    if (sameAsCurrent) return setError("Please choose a username different from your current one.");
    const local = validateUsername(value, isAdmin);
    if (!local.ok) return setError(local.message);
    if (avail.state === "checking") return setError("Checking availability — one moment…");
    if (avail.state !== "available") return setError(avail.message || "Please choose an available username.");
    if (isAdmin && !currentPassword) return setError("Please enter your current password to confirm this change.");

    setBusy(true);
    try {
      const res = await api.post<{ success: boolean; user: SessionUser }>("/api/auth/change-username", {
        newUsername: value,
        ...(isAdmin ? { currentPassword } : {}),
      });
      setUser(res.user);
      setNext("");
      setCurrentPassword("");
      setShowPassword(false);
      setAvail({ state: "idle", message: "" });
      setSuccess(`Your username is now “${res.user.name}” — it has been updated across the site.`);
      toast.success("Username updated ✓", {
        description: "Your new username is shown in the navigation bar, dropdown and profile.",
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Username change failed";
      setError(msg);
      toast.error("Username change failed", { description: msg });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section
      className="rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-7"
      aria-labelledby="profile-settings-heading"
    >
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#22C55E]/12">
          <UserRound className="h-5.5 w-5.5 text-[#4ADE80]" />
        </span>
        <div>
          <h2 id="profile-settings-heading" className="text-lg font-black text-white">
            Profile Settings
          </h2>
          <p className="text-xs text-slate-400">
            {isAdmin
              ? "Change your admin username — reauthenticate with your password. Dashboard access and privileges stay unchanged."
              : "Change your public username — your password, watchlist, requests and donations stay untouched."}
          </p>
        </div>
      </div>

      <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
        {/* Current Username — display only */}
        <label className="block">
          <span className="mb-1.5 block text-sm font-bold text-slate-200">Current Username</span>
          <span className="relative block">
            <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={currentName || "Not set"}
              disabled
              readOnly
              aria-readonly="true"
              aria-label="Current Username (display only)"
              className={`${inputCls} cursor-not-allowed pr-11 opacity-60`}
            />
          </span>
          {!currentName && (
            <span className="mt-1 block text-[11px] text-slate-500">
              You haven&apos;t set a username yet — your email is shown around the site. Set one below.
            </span>
          )}
        </label>

        {/* New Username + live availability indicator */}
        <div>
          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">New Username</span>
            <span className="relative block">
              <AtSign className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={next}
                onChange={(e) => {
                  setNext(e.target.value);
                  setSuccess("");
                }}
                placeholder="3–20 letters, numbers or underscores"
                maxLength={20}
                autoComplete="username"
                spellCheck={false}
                className={inputCls}
                aria-label="New Username"
                aria-invalid={avail.state === "unavailable"}
              />
              {avail.state === "checking" && (
                <Loader2 className="absolute right-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 animate-spin text-slate-400" />
              )}
              {avail.state === "available" && (
                <CheckCircle2 className="absolute right-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-[#4ADE80]" />
              )}
              {avail.state === "unavailable" && (
                <XCircle className="absolute right-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-red-400" />
              )}
            </span>
          </label>
          <div aria-live="polite">
            {avail.state === "current" && (
              <p className="mt-1.5 flex items-start gap-1.5 text-[12px] text-slate-400">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {avail.message}
              </p>
            )}
            {avail.state === "available" && (
              <p className="mt-1.5 flex items-start gap-1.5 text-[12px] font-semibold text-[#4ADE80]">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {avail.message}
              </p>
            )}
            {avail.state === "unavailable" && (
              <p role="alert" className="mt-1.5 flex items-start gap-1.5 text-[12px] text-red-300">
                <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {avail.message}
              </p>
            )}
          </div>
        </div>

        {/* Admin reauthentication */}
        {isAdmin && (
          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">
              Current Password <span className="font-normal text-slate-500">(required to confirm)</span>
            </span>
            <span className="relative block">
              <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
              <input
                type={showPassword ? "text" : "password"}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Your current password"
                autoComplete="current-password"
                className={inputCls}
                aria-label="Current Password (required to confirm username change)"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-white/5 hover:text-[#4ADE80]"
              >
                {showPassword ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
              </button>
            </span>
          </label>
        )}

        {error && (
          <p role="alert" className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
            {error}
          </p>
        )}
        {success && !error && (
          <p role="status" className="rounded-lg border border-[#22C55E]/25 bg-[#22C55E]/10 px-4 py-2.5 text-sm text-[#4ADE80]">
            {success}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={!canSave}
            className="inline-flex h-12 items-center gap-2 rounded-full bg-[#22C55E] px-7 text-sm font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserRound className="h-4 w-4" />}
            Save Username
          </button>
          <p className="text-[11px] leading-relaxed text-slate-500">
            3–20 characters · letters, numbers and underscores · must be unique. You stay signed in — your
            watchlist, requests and donations are linked to your account ID, not your username.
          </p>
        </div>
      </form>
    </section>
  );
}
