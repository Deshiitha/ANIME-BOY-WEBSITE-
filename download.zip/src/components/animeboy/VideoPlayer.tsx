"use client";

/**
 * ANIME BOY video player.
 *
 * - Direct MP4/WebM streams natively (preload="metadata" — never the whole file).
 * - HLS (.m3u8) plays natively on Safari/iOS and via hls.js elsewhere.
 * - DASH (.mpd) plays via dash.js where MSE is available.
 * - Trusted provider embeds render in a responsive iframe.
 * - Private-bucket sources ("signed") fetch a short-lived URL from the server
 *   and silently re-sign on expiry so playback and seeking keep working.
 *
 * Video traffic is never proxied through this website: direct sources stream
 * straight from the external storage/CDN.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type HlsType from "hls.js";
import type { MediaPlayerClass } from "dashjs";
import {
  AlertTriangle,
  ChevronDown,
  Download,
  Gauge,
  History,
  Loader2,
  ExternalLink,
  Maximize,
  Minimize,
  Pause,
  Play,
  RotateCcw,
  SkipForward,
  Subtitles as SubtitlesIcon,
  Upload as UploadIcon,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { api } from "@/lib/client-api";
import type { PlayableSource, SubtitleTrack } from "@/lib/media-types";
import {
  enabledTracks,
  readSubPref,
  readSubStyle,
  trackIndexForLang,
  toVtt,
  validateSubtitleText,
  writeSubPref,
  writeSubStyle,
  SUB_BG_LEVELS,
  SUB_COLORS,
  SUB_FONTS,
  SUB_FONT_STACKS,
  SUB_POSITIONS,
  SUB_SIZES,
  type SubStyle,
} from "@/lib/subtitles";
import { formatClock, removeWatchProgress, resumeSecondsFor, saveWatchProgress } from "@/lib/watch-progress";

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

/** Seconds shown on the "Up next" countdown before the next episode auto-plays. */
const NEXT_EPISODE_DELAY = 5;

type Status = "loading" | "ok" | "error";

function fmt(sec: number): string {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    : `${m}:${String(s).padStart(2, "0")}`;
}

/**
 * Google Drive playback limitation (verified by testing):
 *
 * Drive's content endpoints (drive.usercontent.google.com/download,
 * lh3.googleusercontent.com/d/…) refuse cross-site video fetches from
 * browsers — requests carrying Sec-Fetch metadata get HTTP 403 and requests
 * with a third-party Referer get a virus-scan interstitial instead of media.
 * The /preview iframe is Google's only supported in-site playback and it does
 * not expose its internal player, so external subtitle tracks cannot be
 * attached to it. Per the product spec the CC control therefore explains this
 * limitation honestly (subtitles stay fully functional on every direct
 * source — upload / external URL / HLS — and subtitle files remain
 * downloadable below the player) instead of showing fake controls.
 */

export type WatchProgressMeta = {
  slug: string;
  title: string;
  poster?: string | null;
  label?: string;
  s?: number;
  e?: number;
};

/* ----------------------------- subtitle menu ------------------------------- */

function MenuRow({
  active,
  onClick,
  children,
  disabled = false,
  onRemove,
  trailing,
}: {
  active?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
  disabled?: boolean;
  /** Optional per-row remove action (locally loaded subtitle files). */
  onRemove?: () => void;
  /** Optional right-side badge instead of the check mark. */
  trailing?: React.ReactNode;
}) {
  return (
    <div className={`flex items-center ${disabled ? "" : "hover:bg-white/10"}`}>
      <button
        type="button"
        role={disabled ? undefined : "menuitemradio"}
        aria-checked={disabled ? undefined : active}
        disabled={disabled}
        onClick={onClick}
        className={`flex flex-1 items-center justify-between gap-2 px-3 py-1.5 text-left text-xs font-semibold ${
          disabled ? "cursor-default italic text-slate-500" : active ? "text-[#4ADE80]" : "text-slate-200"
        }`}
      >
        {children}
        {trailing !== undefined ? trailing : active && !disabled && <span className="text-[#4ADE80]">✓</span>}
      </button>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          aria-label="Remove loaded subtitle"
          title="Remove this subtitle"
          className="mr-2 rounded p-1 text-slate-500 transition-colors hover:bg-red-500/15 hover:text-red-300"
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
  title,
}: {
  active?: boolean;
  onClick: () => void;
  children: React.ReactNode;
  title?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-pressed={active}
      className={`flex h-6 min-w-6 items-center justify-center rounded-md border px-1.5 text-[10px] font-bold transition-colors ${
        active
          ? "border-[#22C55E] bg-[#22C55E]/20 text-[#4ADE80]"
          : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-white/25 hover:text-white"
      }`}
    >
      {children}
    </button>
  );
}

function StyleGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[10px] font-bold uppercase tracking-wide text-slate-500">{label}</span>
      <div className="flex items-center gap-1">{children}</div>
    </div>
  );
}

/** A subtitle file the visitor picked from their own device (never uploaded). */
type LocalSubtitleTrack = SubtitleTrack & { local: true };

/**
 * The subtitle settings menu: language list (Off / Sinhala / English / other
 * configured languages), "Load Subtitle File" (the visitor's own .srt/.vtt)
 * and display settings (size, colour, background opacity, position, font).
 *
 * `embedMode` renders the menu for provider iframes (Google Drive …): the
 * configured languages appear as DOWNLOAD-ONLY entries and no toggles are
 * offered, because an embedded player does not expose its internals — the
 * honest limitation note is displayed instead of fake controls.
 */
function SubtitleMenu({
  tracks,
  localTracks,
  activeSub,
  onSelect,
  onLoadFile,
  onRemoveLocal,
  style,
  onStyle,
  note,
  embedMode = false,
  error,
  onClose,
}: {
  tracks: SubtitleTrack[] | null;
  localTracks: LocalSubtitleTrack[];
  activeSub: number;
  onSelect: (idx: number) => void;
  onLoadFile: (file: File) => void;
  onRemoveLocal: (label: string) => void;
  style: SubStyle;
  onStyle: (patch: Partial<SubStyle>) => void;
  note?: string | null;
  embedMode?: boolean;
  error?: string | null;
  onClose: () => void;
}) {
  const adminCount = tracks?.length ?? 0;
  return (
    <div
      className="absolute bottom-11 right-0 max-h-[70vh] w-64 overflow-y-auto rounded-xl border border-white/10 bg-[#0b1120] py-2 shadow-xl"
      role="menu"
      data-testid="subtitle-menu"
    >
      <div className="flex items-center justify-between px-3 pb-1.5">
        <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-slate-400">
          <SubtitlesIcon className="h-3.5 w-3.5" /> Subtitles
        </span>
        <button
          onClick={onClose}
          aria-label="Close subtitle menu"
          className="rounded p-0.5 text-slate-400 hover:bg-white/10 hover:text-white"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {note && (
        <p className="mx-2.5 mb-1.5 rounded-lg bg-amber-400/10 px-2 py-1.5 text-[11px] leading-relaxed text-amber-200">{note}</p>
      )}

      {(!tracks || tracks.length === 0) && localTracks.length === 0 && (
        <p className="px-3 py-1.5 text-xs font-semibold italic text-slate-500">Subtitles Not Available</p>
      )}

      {((tracks && tracks.length > 0) || localTracks.length > 0) && (
        <>
          {!embedMode && <MenuRow active={activeSub === -1} onClick={() => onSelect(-1)}>Off</MenuRow>}
          {(tracks || []).map((t, i) =>
            embedMode ? (
              // Embedded players cannot render external tracks — these rows
              // point at the download buttons below the player instead.
              <MenuRow
                key={`${t.lang}-${i}`}
                disabled
                trailing={
                  <span
                    className="flex items-center gap-1 rounded bg-white/10 px-1 py-0.5 text-[9px] font-bold uppercase text-slate-400"
                    title="Downloadable below the player"
                  >
                    <Download className="h-2.5 w-2.5" /> DL
                  </span>
                }
              >
                <span className="truncate">{t.label || t.lang}</span>
              </MenuRow>
            ) : (
              <MenuRow key={`${t.lang}-${i}`} active={activeSub === i} onClick={() => onSelect(i)}>
                <span className="truncate">{t.label || t.lang}</span>
                <span className="rounded bg-white/10 px-1 py-0.5 text-[9px] font-bold uppercase text-slate-400">{t.lang}</span>
              </MenuRow>
            )
          )}
          {localTracks.map((t, i) => {
            const idx = adminCount + i;
            return (
              <MenuRow
                key={`local-${t.label}-${i}`}
                active={!embedMode && activeSub === idx}
                onClick={embedMode ? undefined : () => onSelect(idx)}
                onRemove={embedMode ? undefined : () => onRemoveLocal(t.label)}
                trailing={
                  <span
                    className="rounded bg-[#22C55E]/15 px-1 py-0.5 text-[9px] font-bold uppercase text-[#4ADE80]"
                    title="Loaded from this device"
                  >
                    device
                  </span>
                }
              >
                <span className="truncate" title={t.label}>
                  {t.label}
                </span>
              </MenuRow>
            );
          })}

          {!embedMode && (
            <div className="mt-1.5 space-y-2 border-t border-white/10 px-3 pb-1 pt-2">
              <span className="block text-[10px] font-black uppercase tracking-wider text-slate-500">Display</span>
              <StyleGroup label="Size">
                {SUB_SIZES.map((s) => (
                  <Chip key={s.id} active={style.size === s.id} onClick={() => onStyle({ size: s.id })} title={`Font size ${s.label}`}>
                    {s.label}
                  </Chip>
                ))}
              </StyleGroup>
              <StyleGroup label="Font">
                {SUB_FONTS.map((f) => (
                  <Chip key={f.id} active={style.font === f.id} onClick={() => onStyle({ font: f.id })} title={`${f.label} font`}>
                    {f.label}
                  </Chip>
                ))}
                <Chip active={style.bold} onClick={() => onStyle({ bold: !style.bold })} title="Bold text">
                  B
                </Chip>
              </StyleGroup>
              <StyleGroup label="Colour">
                {SUB_COLORS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    title={c.label}
                    aria-pressed={style.color === c.id}
                    onClick={() => onStyle({ color: c.id })}
                    className={`h-5 w-5 rounded-full border-2 transition-transform hover:scale-110 ${
                      style.color === c.id ? "border-[#22C55E]" : "border-white/20"
                    }`}
                    style={{ backgroundColor: c.id }}
                  />
                ))}
              </StyleGroup>
              <StyleGroup label="Background">
                {SUB_BG_LEVELS.map((b) => (
                  <Chip key={b.id} active={style.bg === b.id} onClick={() => onStyle({ bg: b.id })} title={`Background opacity ${b.label}`}>
                    {b.label}
                  </Chip>
                ))}
              </StyleGroup>
              <StyleGroup label="Position">
                {SUB_POSITIONS.map((p) => (
                  <Chip key={p.id} active={style.position === p.id} onClick={() => onStyle({ position: p.id })}>
                    {p.label}
                  </Chip>
                ))
                }
              </StyleGroup>
            </div>
          )}
        </>
      )}

      {/* Load Subtitle File — reads the visitor's own .srt/.vtt locally in
          the browser; nothing is uploaded to the server. Only offered on
          direct playback where the custom overlay can actually render it. */}
      {!embedMode && (
        <div className="mt-1.5 border-t border-white/10 px-3 pb-1 pt-2">
          <label
            className="flex w-full cursor-pointer items-center gap-2 rounded-lg px-1 py-1.5 text-xs font-semibold text-slate-200 transition-colors hover:bg-white/10 hover:text-[#4ADE80]"
            data-testid="load-subtitle"
          >
            <UploadIcon className="h-3.5 w-3.5 shrink-0" />
            <span className="flex-1">Load Subtitle File</span>
            <input
              type="file"
              accept=".srt,.vtt,text/vtt,application/x-subrip"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onLoadFile(f);
                e.target.value = "";
              }}
            />
          </label>
          <p className="px-1 pb-0.5 text-[10px] leading-relaxed text-slate-500">
            Read from your device — never uploaded. SRT is converted to WebVTT automatically.
          </p>
          {error && (
            <p className="mx-1 mt-1 rounded-lg bg-red-500/10 px-2 py-1.5 text-[11px] leading-relaxed text-red-300" role="alert">
              {error}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

export function VideoPlayer({
  source,
  title,
  autoPlay = false,
  testId,
  progressKey,
  progressMeta,
  onNext,
}: {
  source: PlayableSource;
  title: string;
  autoPlay?: boolean;
  testId?: string;
  /** Stable video identity ("movie:<id>" / "ep:<id>") — enables continue-watching. */
  progressKey?: string;
  /** Display metadata saved alongside the resume position. */
  progressMeta?: WatchProgressMeta;
  /** When provided (series with a following episode), shows a Next Episode button. */
  onNext?: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const shellRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<HlsType | null>(null);
  const dashRef = useRef<MediaPlayerClass | null>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const blobUrls = useRef<string[]>([]);
  const resumeAt = useRef<number | null>(null);
  const reSignedOnce = useRef(false);

  const [status, setStatus] = useState<Status>("loading");
  const [errorMsg, setErrorMsg] = useState("");
  const [signed, setSigned] = useState<{ url: string; kind: "mp4" | "hls" } | null>(null);
  const [playing, setPlaying] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [scrubbing, setScrubbing] = useState(false);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [fullscreen, setFullscreen] = useState(false);
  const [controlsShown, setControlsShown] = useState(true);
  const [menu, setMenu] = useState<"none" | "speed" | "subs" | "quality">("none");

  // hls.js quality levels & chosen level (-1 = auto)
  const [levels, setLevels] = useState<{ i: number; label: string }[]>([]);
  const [level, setLevel] = useState(-1);
  // separate per-quality files (direct sources)
  const [qualityIdx, setQualityIdx] = useState(-1);

  const [activeSub, setActiveSub] = useState(-1); // -1 = off

  // Auto-advance: when an episode ends, count down from NEXT_EPISODE_DELAY and
  // then call onNext — visitors can cancel or start immediately.
  const [nextIn, setNextIn] = useState<number | null>(null);
  const onNextRef = useRef(onNext);
  onNextRef.current = onNext;

  // --- subtitle display system --------------------------------------------
  // cues currently shown by the custom overlay (one string per line)
  const [cueText, setCueText] = useState<string[]>([]);
  // user display settings (size / colour / background / position / font)
  const [subStyle, setSubStyle] = useState<SubStyle>(() => readSubStyle());
  // subtitle files the visitor loaded from their own device (never uploaded)
  const [localTracks, setLocalTracks] = useState<LocalSubtitleTrack[]>([]);
  // inline error for the "Load Subtitle File" feature (invalid file etc.)
  const [subError, setSubError] = useState<string | null>(null);

  // Continue-watching: position restored from the last session (seconds) and
  // whether the "Resumed…" chip is still shown.
  const [resumeChip, setResumeChip] = useState<number | null>(null);
  const lastSaveAt = useRef(0);
  const progressRef = useRef<{ key?: string; meta?: WatchProgressMeta }>({});
  progressRef.current = { key: progressKey, meta: progressMeta };

  const subtitles = useMemo(() => {
    if (
      source.kind === "mp4" ||
      source.kind === "hls" ||
      source.kind === "signed" ||
      source.kind === "embed"
    ) {
      return enabledTracks(source.subtitles);
    }
    return [];
  }, [source]);

  /** Every selectable subtitle track: admin-configured first, then device-loaded. */
  const allTracks = useMemo<SubtitleTrack[]>(() => [...subtitles, ...localTracks], [subtitles, localTracks]);
  const allTracksRef = useRef<SubtitleTrack[]>(allTracks);
  allTracksRef.current = allTracks;

  const src = source;

  const poster =
    src.kind === "mp4" || src.kind === "hls" || src.kind === "signed" ? src.poster : null;

  /* ------------------------- signed source resolution ------------------------- */

  const resolveSigned = useCallback(
    async (restore: boolean): Promise<{ url: string; kind: "mp4" | "hls" } | null> => {
      try {
        const data = await api.get<{ url: string; kind?: string }>(
          (source as { kind: "signed"; signUrl: string }).signUrl
        );
        reSignedOnce.current = restore;
        if (restore && videoRef.current) resumeAt.current = videoRef.current.currentTime;
        const kind = data.kind === "hls" ? "hls" : "mp4";
        setSigned({ url: data.url, kind });
        return { url: data.url, kind };
      } catch (e) {
        setStatus("error");
        setErrorMsg(
          e instanceof Error
            ? `Could not start playback: ${e.message}`
            : "Could not start playback — the media link could not be signed."
        );
        return null;
      }
    },
    [source]
  );

  const srcKey =
    src.kind === "none"
      ? "none"
      : src.kind === "embed"
        ? src.embedUrl
        : src.kind === "signed"
          ? src.signUrl
          : src.kind === "external_page"
            ? src.pageUrl
            : `${src.kind}:${src.url}`;

  /* ------------------------- continue-watching store ------------------------ */

  /** Persist the current position (throttled) into the local continue-watching store. */
  const persistProgress = useCallback((force = false) => {
    const { key, meta } = progressRef.current;
    const v = videoRef.current;
    if (!key || !meta || !v) return;
    if (!isFinite(v.duration) || v.duration <= 0 || v.currentTime <= 0) return;
    const now = Date.now();
    if (!force && now - lastSaveAt.current < 5000) return;
    lastSaveAt.current = now;
    saveWatchProgress({
      key,
      slug: meta.slug,
      s: meta.s,
      e: meta.e,
      title: meta.title,
      poster: meta.poster ?? null,
      label: meta.label || "",
      seconds: v.currentTime,
      duration: v.duration,
    });
  }, []);

  const startOver = useCallback(() => {
    const v = videoRef.current;
    if (v) {
      v.currentTime = 0;
      v.play().catch(() => {});
    }
    const { key } = progressRef.current;
    if (key) removeWatchProgress(key);
    setResumeChip(null);
  }, []);

  // Auto-dismiss the resume chip after a while.
  useEffect(() => {
    if (resumeChip == null) return;
    const t = setTimeout(() => setResumeChip(null), 12_000);
    return () => clearTimeout(t);
  }, [resumeChip]);

  // "Up next" countdown — fires onNext when it reaches zero.
  useEffect(() => {
    if (nextIn == null) return;
    if (nextIn <= 0) {
      setNextIn(null);
      onNextRef.current?.();
      return;
    }
    const t = setTimeout(() => setNextIn((n) => (n == null ? null : n - 1)), 1000);
    return () => clearTimeout(t);
  }, [nextIn]);

  // Episode auto-start: when the watch page requests autoplay (playlist pick,
  // Prev/Next, auto-advance), begin playback as soon as the new episode can
  // play. Runs on every src change so it also covers in-place episode swaps.
  useEffect(() => {
    if (!autoPlay) return;
    const v = videoRef.current;
    if (!v || !v.paused) return;
    let cancelled = false;
    const tryPlay = () => {
      if (!cancelled) v.play().catch(() => {});
    };
    if (v.readyState >= 3) {
      tryPlay();
      return;
    }
    v.addEventListener("canplay", tryPlay, { once: true });
    return () => {
      cancelled = true;
      v.removeEventListener("canplay", tryPlay);
    };
  }, [autoPlay, srcKey]);

  // Save the final position when the player goes away (route change, episode switch).
  useEffect(() => {
    return () => persistProgress(true);
  }, [persistProgress]);

  /* ------------------------------ media setup ------------------------------- */

  useEffect(() => {
    setStatus("loading");
    setErrorMsg("");
    setSigned(null);
    setLevels([]);
    setLevel(-1);
    setActiveSub(-1);
    reSignedOnce.current = false;
    resumeAt.current = null;

    // Cross-session resume: continue where the visitor left off.
    if (progressKey) {
      const saved = resumeSecondsFor(progressKey);
      if (saved > 0) {
        resumeAt.current = saved;
        setResumeChip(saved);
      } else {
        setResumeChip(null);
      }
    } else {
      setResumeChip(null);
    }

    if (src.kind === "embed" || src.kind === "none" || src.kind === "external_page") {
      setStatus(src.kind === "external_page" ? "ok" : src.kind === "embed" ? "ok" : "error");
      if (src.kind === "none") setErrorMsg("No playable video source is attached.");
      return;
    }

    let cancelled = false;
    const start = async () => {
      let url: string;
      let kind: "mp4" | "hls" | "dash";
      if (src.kind === "signed") {
        const resolved = await resolveSigned(false);
        if (!resolved || cancelled) return;
        url = resolved.url;
        kind = resolved.kind;
      } else {
        url = src.url;
        kind = src.kind === "hls" ? "hls" : src.kind === "dash" ? "dash" : "mp4";
      }
      if (cancelled) return;
      setupMedia(url, kind);
    };

    const setupMedia = (url: string, kind: "mp4" | "hls" | "dash", forceHls = false) => {
      const video = videoRef.current;
      if (!video) return;
      hlsRef.current?.destroy();
      hlsRef.current = null;
      dashRef.current?.reset();
      dashRef.current = null;
      delete video.dataset.hlsFallback;

      const initDash = () => {
        import("dashjs")
          .then((mod) => {
            if (cancelled) return;
            const player = mod.MediaPlayer().create();
            dashRef.current = player;
            player.updateSettings({
              streaming: { abr: { autoSwitchBitrate: { video: true } } },
            });
            player.initialize(video, url, false);
            player.on(mod.MediaPlayer.events.STREAM_INITIALIZED, () => {
              if (cancelled) return;
              try {
                const reps = player.getRepresentationsByType("video") || [];
                const list = reps
                  .map((r, i) => ({
                    i, // dash.js switches by array index — keep the mapping
                    label: r?.height ? `${r.height}p` : `${Math.round(r?.bitrateInKbit || 0)}k`,
                  }))
                  .filter((l) => l.label && l.label !== "0k")
                  .sort((a, b) => (b.label > a.label ? 1 : -1));
                setLevels(list);
              } catch {
                /* bitrate list unavailable — quality menu stays hidden */
              }
            });
            player.on(mod.MediaPlayer.events.ERROR, (e: { error?: { message?: string } }) => {
              if (cancelled) return;
              setStatus("error");
              setErrorMsg(
                e?.error?.message
                  ? `The DASH stream could not be played: ${e.error.message}`
                  : "The DASH stream could not be loaded. The manifest may be unreachable, expired or missing CORS permissions."
              );
            });
          })
          .catch(() => {
            setStatus("error");
            setErrorMsg("The player library failed to load. Please refresh the page.");
          });
      };

      const initHls = () => {
        import("hls.js")
          .then((mod) => {
            if (cancelled) return;
            const Hls = mod.default;
            if (!Hls.isSupported()) {
              video.src = url; // last resort — let the browser try
              return;
            }
            const hls = new Hls({ enableWorker: true, backBufferLength: 90, maxBufferLength: 30 });
            hlsRef.current = hls;
            hls.loadSource(url);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, () => {
              const list = hls.levels
                .map((l, i) => ({ i, label: l.height ? `${l.height}p` : `${Math.round((l.bitrate || 0) / 1000)}k` }))
                .sort((a, b) => (b.label > a.label ? 1 : -1));
              setLevels(list);
            });
            hls.on(Hls.Events.ERROR, (_evt, data) => {
              if (!data.fatal) return;
              if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
                hls.recoverMediaError();
                return;
              }
              if (
                src.kind === "signed" &&
                data.type === Hls.ErrorTypes.NETWORK_ERROR &&
                !reSignedOnce.current
              ) {
                // Signed URL probably expired mid-session — mint a fresh one.
                hls.destroy();
                hlsRef.current = null;
                resolveSigned(true).then((r) => r && setupMedia(r.url, r.kind));
                return;
              }
              setStatus("error");
              setErrorMsg(
                data.type === Hls.ErrorTypes.NETWORK_ERROR
                  ? "The video stream could not be loaded. The link may have expired, the file may have moved, or the storage server may be blocking playback (CORS)."
                  : "The video could not be decoded. The file may be corrupt or in an unsupported format."
              );
            });
          })
          .catch(() => {
            setStatus("error");
            setErrorMsg("The player library failed to load. Please refresh the page.");
          });
      };

      const isHls = kind === "hls";
      const isDash = kind === "dash";
      const nativeHls = video.canPlayType("application/vnd.apple.mpegurl") !== "";
      if (isDash) {
        initDash();
      } else if (isHls && !nativeHls) {
        initHls();
      } else {
        // Native playback (Safari/iOS HLS, Chromium native HLS, any MP4).
        delete video.dataset.nativeHls;
        video.src = url;
        if (isHls && !forceHls) {
          // Some engines advertise native HLS but fail to stream it — fall
          // back to hls.js exactly once before showing an error. The flag is
          // cleared once real data arrives so later errors surface normally.
          video.dataset.nativeHls = "1";
          video.addEventListener("loadeddata", () => delete video.dataset.nativeHls, { once: true });
          const onNativeError = () => {
            video.removeEventListener("error", onNativeError);
            if (cancelled || video.dataset.hlsFallback || !video.dataset.nativeHls) return;
            video.dataset.hlsFallback = "1";
            setStatus("loading");
            initHls();
          };
          video.addEventListener("error", onNativeError);
        }
      }
    };

    start();
    return () => {
      cancelled = true;
      hlsRef.current?.destroy();
      hlsRef.current = null;
      dashRef.current?.reset();
      dashRef.current = null;
    };
  }, [srcKey]);

  /* --------------------------- video element events -------------------------- */

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => {
      if (!scrubbing) setCurrent(video.currentTime);
      if (video.buffered.length) setBuffered(video.buffered.end(video.buffered.length - 1));
      persistProgress(false);
    };
    const onMeta = () => {
      setDuration(video.duration || 0);
      if (resumeAt.current != null) {
        video.currentTime = resumeAt.current;
        resumeAt.current = null;
      }
    };
    const onPlay = () => {
      setPlaying(true);
      setStatus("ok");
      // The visitor (re)started playback — any pending auto-advance is moot.
      setNextIn(null);
    };
    const onPause = () => {
      setPlaying(false);
      persistProgress(true);
    };
    const onWaiting = () => setBuffering(true);
    const onPlaying = () => setBuffering(false);
    const onVolume = () => {
      setVolume(video.volume);
      setMuted(video.muted);
    };
    const onEnded = () => {
      setPlaying(false);
      const { key } = progressRef.current;
      if (key) removeWatchProgress(key);
      // Finished — offer the next episode automatically (cancellable).
      if (onNextRef.current) setNextIn(NEXT_EPISODE_DELAY);
    };
    const onError = () => {
      const code = video.error?.code;
      // Native-HLS engines that claim support but fail immediately are handled
      // by the setup effect (hls.js fallback) — don't double-report.
      if (video.dataset.nativeHls && !video.dataset.hlsFallback) return;
      if (
        src.kind === "signed" &&
        !reSignedOnce.current &&
        (code === 2 || code === 4)
      ) {
        // Signed URL likely expired — re-sign once and resume.
        resolveSigned(true).then((r) => {
          if (r && videoRef.current) videoRef.current.src = r.url;
        });
        return;
      }
      setStatus("error");
      setErrorMsg(
        code === 2
          ? "Network error while loading the video. The link may have expired or the storage host may be unreachable."
          : code === 3
            ? "The video could not be decoded. The file may be corrupt or in an unsupported format."
            : "This video could not be played. The URL may be unavailable or not a direct media file."
      );
    };
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("progress", onTime);
    video.addEventListener("loadedmetadata", onMeta);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("playing", onPlaying);
    video.addEventListener("volumechange", onVolume);
    video.addEventListener("ended", onEnded);
    video.addEventListener("error", onError);
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("progress", onTime);
      video.removeEventListener("loadedmetadata", onMeta);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("volumechange", onVolume);
      video.removeEventListener("ended", onEnded);
      video.removeEventListener("error", onError);
    };
  }, [scrubbing, src, resolveSigned, persistProgress]);

  /* ------------------------------ subtitles --------------------------------- */

  // Cue rendering uses the HTML5 TextTrack API with mode="hidden": the browser
  // parses the file and fires cuechange, and the site draws the cues itself in
  // an overlay div. That gives instant OFF (hide the overlay), language
  // switching without restarting, and full control over size/colour/background.
  const cueListenerRef = useRef<{ tt: TextTrack; fn: () => void } | null>(null);
  const subTokenRef = useRef(0); // guards against stale async track loads
  const lastLangRef = useRef<string | null>(null);
  // label of the last active device-loaded file (session-local CC restore)
  const lastLocalLabelRef = useRef<string | null>(null);

  const detachSubListener = useCallback(() => {
    const cur = cueListenerRef.current;
    if (cur) {
      cur.tt.removeEventListener("cuechange", cur.fn);
      cueListenerRef.current = null;
    }
  }, []);

  const loadSubTrack = useCallback(
    async (track: SubtitleTrack | null, idx: number) => {
      const video = videoRef.current;
      const token = ++subTokenRef.current;
      const isLocal = !!(track as LocalSubtitleTrack | null)?.local;

      // OFF (or missing track): remove dynamic tracks, kill listeners, clear
      // the overlay — subtitles disappear immediately, playback continues.
      setActiveSub(track && idx >= 0 ? idx : -1);
      setCueText([]);
      detachSubListener();
      if (video) {
        video.querySelectorAll("track[data-dynamic-sub]").forEach((n) => n.remove());
        for (let i = 0; i < video.textTracks.length; i++) video.textTracks[i].mode = "disabled";
      }
      if (!track || idx < 0 || !video) {
        writeSubPref({ on: false, lang: lastLangRef.current });
        return;
      }

      // ON: remember the language for this browsing session (episode navigation
      // re-applies it automatically). Device-loaded files stay per-video — the
      // preference keeps the last ADMIN language so the next episode still
      // opens subtitles when the loaded file is no longer attached.
      if (!isLocal) {
        lastLangRef.current = track.lang || null;
        writeSubPref({ on: true, lang: track.lang || null });
      } else {
        lastLocalLabelRef.current = track.label;
        writeSubPref({ on: true, lang: lastLangRef.current });
      }

      // Fetch through the browser so SRT is converted to WebVTT and so cues
      // work even when cross-origin <track> rules would block them.
      let trackSrc = track.url;
      try {
        const res = await fetch(track.url, { credentials: "omit" });
        if (res.ok) {
          const vtt = toVtt(await res.text());
          const blob = URL.createObjectURL(new Blob([vtt], { type: "text/vtt" }));
          blobUrls.current.push(blob);
          trackSrc = blob;
        }
      } catch {
        // Cross-origin without CORS — fall back to the raw URL (works when the
        // host is same-origin or sends Access-Control-Allow-Origin).
      }
      if (token !== subTokenRef.current) return; // a newer selection took over

      const el = document.createElement("track");
      el.setAttribute("data-dynamic-sub", "1");
      el.kind = "subtitles";
      el.label = track.label;
      el.srclang = track.lang;
      el.src = trackSrc;
      video.appendChild(el);

      // HTMLTrackElement.track is the TextTrack — available synchronously after
      // insertion. "hidden" = parse cues but never paint natively; we render.
      const tt = el.track;
      if (!tt) return;
      tt.mode = "hidden";
      const onCue = () => {
        const lines: string[] = [];
        const cues = tt.activeCues;
        if (!cues) {
          setCueText([]);
          return;
        }
        for (let i = 0; i < cues.length; i++) {
          const text = (cues[i] as VTTCue | null)?.text || "";
          text
            .replace(/<[^>]+>/g, "")
            .split("\n")
            .map((l) => l.trim())
            .filter(Boolean)
            .forEach((l) => lines.push(l));
        }
        setCueText(lines);
      };
      tt.addEventListener("cuechange", onCue);
      cueListenerRef.current = { tt, fn: onCue };

      // Wait for cues to finish loading (bounded) so rapid toggles stay sane,
      // then paint the cue at the current playhead (mid-video selection).
      await new Promise<void>((resolve) => {
        let done = false;
        const finish = () => {
          if (!done) {
            done = true;
            resolve();
          }
        };
        el.addEventListener("load", finish);
        el.addEventListener("error", finish);
        setTimeout(finish, 4000);
      });
      if (token !== subTokenRef.current) {
        el.remove();
        tt.removeEventListener("cuechange", onCue);
        if (cueListenerRef.current?.tt === tt) cueListenerRef.current = null;
        return;
      }
      onCue();
    },
    [detachSubListener]
  );

  // Revoke blob track URLs, drop listeners and FORGET device-loaded subtitle
  // files when the source changes — a locally loaded file belongs to the video
  // it was attached to, never to the next movie/episode.
  useEffect(() => {
    return () => {
      blobUrls.current.forEach((u) => URL.revokeObjectURL(u));
      blobUrls.current = [];
      detachSubListener();
      setCueText([]);
      setLocalTracks([]);
      setSubError(null);
    };
  }, [srcKey, detachSubListener]);

  // Session preference: re-apply the remembered ON/OFF + language when the
  // visitor navigates between episodes (same browsing session).
  useEffect(() => {
    if (!subtitles.length) return;
    const pref = readSubPref();
    if (!pref.on) return;
    if (src.kind === "embed") {
      // Provider iframes do not expose their internal players, so external
      // tracks cannot be attached — the CC menu explains this honestly and
      // downloads remain available below the player.
      return;
    }
    const t = setTimeout(() => {
      const list = allTracksRef.current;
      const idx = trackIndexForLang(subtitles, pref.lang);
      loadSubTrack(list[idx] ?? null, idx);
    }, 150);
    return () => clearTimeout(t);
  }, [srcKey, subtitles, loadSubTrack, src.kind]);

  const updateSubStyle = useCallback((patch: Partial<SubStyle>) => {
    setSubStyle((prev) => {
      const next = { ...prev, ...patch };
      writeSubStyle(next);
      return next;
    });
  }, []);

  /** CC button quick toggle: ON shows the remembered language, OFF hides instantly. */
  const toggleCc = useCallback(() => {
    if (activeSub >= 0) {
      loadSubTrack(null, -1);
      return;
    }
    const list = allTracksRef.current;
    if (!list.length) {
      setMenu((m) => (m === "subs" ? "none" : "subs")); // shows "Subtitles Not Available"
      return;
    }
    // A device-loaded file that was the last active track comes back first
    // (it is session-local and cannot be restored by the stored language).
    const locals = list.filter((t) => (t as LocalSubtitleTrack).local) as LocalSubtitleTrack[];
    if (lastLocalLabelRef.current) {
      const li = locals.findIndex((t) => t.label === lastLocalLabelRef.current);
      if (li >= 0) {
        loadSubTrack(locals[li], subtitles.length + li);
        return;
      }
    }
    const pref = readSubPref();
    const idx = trackIndexForLang(list, pref.lang);
    loadSubTrack(list[idx] ?? null, idx);
  }, [activeSub, loadSubTrack, subtitles.length]);

  /**
   * "Load Subtitle File": parse the visitor's .srt/.vtt entirely in the
   * browser (no upload), convert SRT → WebVTT, attach it to the current video
   * and show it immediately. Invalid files are rejected with an inline error
   * instead of being attached.
   */
  const handleLocalFile = useCallback(
    async (file: File) => {
      setSubError(null);
      let text: string;
      try {
        text = await file.text();
      } catch {
        setSubError("The file could not be read. Pick a valid .srt or .vtt file.");
        return;
      }
      const v = validateSubtitleText(text);
      if (!v.ok) {
        setSubError(v.error || "Invalid subtitle file — not attached.");
        return;
      }
      const blob = URL.createObjectURL(new Blob([toVtt(text)], { type: "text/vtt" }));
      blobUrls.current.push(blob);
      const track: LocalSubtitleTrack = { label: file.name, lang: "custom", url: blob, local: true };
      const currentLocal = allTracksRef.current.filter((t) => (t as LocalSubtitleTrack).local) as LocalSubtitleTrack[];
      const existingIdx = currentLocal.findIndex((t) => t.label === file.name);
      const localIdx = existingIdx >= 0 ? existingIdx : currentLocal.length;
      setLocalTracks((prev) => {
        const i = prev.findIndex((t) => t.label === file.name);
        if (i >= 0) {
          const next = [...prev];
          next[i] = track;
          return next;
        }
        return [...prev, track];
      });
      loadSubTrack(track, subtitles.length + localIdx);
    },
    [loadSubTrack, subtitles.length]
  );

  /** Remove a device-loaded subtitle file (stops showing it immediately). */
  const removeLocalTrack = useCallback(
    (label: string) => {
      const currentLocal = allTracksRef.current.filter((t) => (t as LocalSubtitleTrack).local) as LocalSubtitleTrack[];
      const idx = subtitles.length + currentLocal.findIndex((t) => t.label === label);
      setLocalTracks((prev) => prev.filter((t) => t.label !== label));
      if (activeSub === idx) loadSubTrack(null, -1);
      else if (activeSub > idx) setActiveSub((s) => s - 1);
    },
    [activeSub, loadSubTrack, subtitles.length]
  );

  /* ------------------------------- controls --------------------------------- */

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => setStatus("error"));
    else v.pause();
  }, []);

  const seekBy = useCallback((delta: number) => {
    const v = videoRef.current;
    if (!v || !isFinite(v.duration)) return;
    v.currentTime = Math.min(Math.max(0, v.currentTime + delta), v.duration);
  }, []);

  const toggleFullscreen = useCallback(async () => {
    const shell = shellRef.current;
    const video = videoRef.current;
    if (!shell) return;
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else if (shell.requestFullscreen) {
        await shell.requestFullscreen();
      } else {
        const w = video as (HTMLVideoElement & { webkitEnterFullscreen?: () => void }) | null;
        w?.webkitEnterFullscreen?.();
      }
    } catch {
      /* fullscreen refused — ignore */
    }
  }, []);

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const revealControls = useCallback(() => {
    setControlsShown(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      const v = videoRef.current;
      if (v && !v.paused && menu === "none") setControlsShown(false);
    }, 2600);
  }, [menu]);

  useEffect(
    () => () => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
    },
    []
  );

  const applySpeed = (s: number) => {
    const v = videoRef.current;
    if (v) v.playbackRate = s;
    setSpeed(s);
    setMenu("none");
  };

  const setHlsLevel = (i: number) => {
    const hls = hlsRef.current;
    if (hls) {
      hls.currentLevel = i;
    } else if (dashRef.current) {
      dashRef.current.updateSettings({
        streaming: { abr: { autoSwitchBitrate: { video: i === -1 } } },
      });
      if (i >= 0) dashRef.current.setRepresentationForTypeByIndex("video", i);
    }
    setLevel(i);
    setMenu("none");
  };

  const switchQualityFile = (idx: number) => {
    if (src.kind !== "mp4" && src.kind !== "hls") return;
    const qualities = src.qualities || [];
    const v = videoRef.current;
    if (!v) return;
    const time = v.currentTime;
    const wasPlaying = !v.paused;
    const nextUrl = idx < 0 ? src.url : qualities[idx]?.url || src.url;
    setQualityIdx(idx);
    setMenu("none");
    hlsRef.current?.destroy();
    hlsRef.current = null;
    v.pause();
    v.src = nextUrl;
    v.addEventListener(
      "loadedmetadata",
      () => {
        v.currentTime = time;
        if (wasPlaying) v.play().catch(() => {});
      },
      { once: true }
    );
    v.load();
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (k === " " || k === "k") {
      e.preventDefault();
      togglePlay();
    } else if (k === "arrowright") {
      e.preventDefault();
      seekBy(10);
    } else if (k === "arrowleft") {
      e.preventDefault();
      seekBy(-10);
    } else if (k === "f") {
      e.preventDefault();
      toggleFullscreen();
    } else if (k === "m") {
      e.preventDefault();
      if (videoRef.current) videoRef.current.muted = !videoRef.current.muted;
    } else if (k === "c") {
      e.preventDefault();
      toggleCc();
    }
  };

  /* -------------------------------- render ---------------------------------- */

  if (src.kind === "embed") {
    // Provider iframes (incl. Google Drive /preview) do not expose their
    // internal players, so external subtitle tracks cannot be attached or
    // toggled here. The CC control opens an honest menu instead of fake
    // toggles; downloads below the player always work.
    const embedNote = !subtitles.length
      ? null
      : src.provider === "gdrive"
        ? "Google Drive only allows playback through its own embedded player, which does not support external subtitles. Switch to a direct video source (Server 1/2) if one is available — subtitle files can always be downloaded below the player."
        : `Subtitles cannot be displayed inside the embedded ${src.providerLabel} player. Subtitle files can still be downloaded below the player.`;
    return (
      <div ref={shellRef} data-video-player data-testid={testId} className="relative h-full w-full bg-black">
        <iframe
          src={src.embedUrl}
          title={title}
          className="absolute inset-0 h-full w-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
          loading="lazy"
        />

        {/* CC control for embedded playback — informational menu, no fake toggles */}
        <div className="absolute bottom-9 right-3 z-20">
          <div className="flex items-center overflow-hidden rounded-full border border-white/20 bg-black/70 shadow-lg backdrop-blur">
            <button
              onClick={() => setMenu(menu === "subs" ? "none" : "subs")}
              aria-label="Subtitles"
              aria-expanded={menu === "subs"}
              data-testid="cc-button"
              className="px-3 py-1.5 text-[11px] font-black tracking-wide text-white transition-colors hover:text-[#4ADE80]"
            >
              CC
            </button>
            <button
              onClick={() => setMenu(menu === "subs" ? "none" : "subs")}
              aria-label="Subtitle settings"
              aria-expanded={menu === "subs"}
              className="px-2 py-1.5 text-white hover:text-[#4ADE80]"
            >
              <ChevronDown className="h-3.5 w-3.5" />
            </button>
          </div>
          {menu === "subs" && (
            <SubtitleMenu
              tracks={subtitles.length ? subtitles : null}
              localTracks={[]}
              activeSub={-1}
              onSelect={() => {}}
              onLoadFile={() => {}}
              onRemoveLocal={() => {}}
              style={subStyle}
              onStyle={updateSubStyle}
              note={embedNote}
              embedMode
              onClose={() => setMenu("none")}
            />
          )}
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="absolute right-3 top-3 z-20 inline-flex h-9 items-center gap-1.5 rounded-full border border-white/20 bg-black/70 px-3 text-xs font-bold text-white shadow-lg backdrop-blur transition-colors hover:border-[#4ADE80]/60 hover:text-[#4ADE80]"
          >
            <SkipForward className="h-3.5 w-3.5" /> Next episode
          </button>
        )}
        <p className="pointer-events-none absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-3 pb-1.5 pt-6 text-[11px] text-slate-300">
          Playback & controls are provided by {src.providerLabel}
        </p>
      </div>
    );
  }

  // No-iframe providers (e.g. TeraBox): an honest, functional fallback card
  // instead of a broken player — the provider does not permit in-site
  // embedding, so the viewer continues on the provider's official page.
  if (src.kind === "external_page") {
    return (
      <div
        ref={shellRef}
        data-video-player
        data-testid={testId}
        className="relative flex h-full w-full items-center justify-center bg-black"
      >
        {src.pageUrl ? (
          <div className="flex w-full max-w-md flex-col items-center px-6 py-10 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/15">
              <ExternalLink className="h-8 w-8 text-[#4ADE80]" />
            </span>
            <h3 className="mt-4 text-lg font-black text-white">
              This video plays on {src.providerLabel}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              {src.providerLabel} does not allow its videos to be embedded on other websites.
              {src.note ? ` ${src.note}` : ""}
            </p>
            <a
              href={src.pageUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex h-12 items-center gap-2 rounded-full bg-[#22C55E] px-7 text-sm font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80]"
            >
              <ExternalLink className="h-4.5 w-4.5" /> Watch on {src.providerLabel}
            </a>
            <p className="mt-3 text-[11px] text-slate-500">Opens {src.providerLabel} in a new tab</p>
            {onNext && (
              <button
                onClick={onNext}
                className="mt-4 inline-flex h-10 items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.04] px-5 text-sm font-bold text-slate-200 transition-colors hover:border-[#22C55E]/50 hover:text-[#4ADE80]"
              >
                <SkipForward className="h-4 w-4" /> Next episode
              </button>
            )}
          </div>
        ) : (
          <div className="px-6 text-center text-sm text-slate-400">No playable video source is attached.</div>
        )}
      </div>
    );
  }

  const showLevels = levels.length > 1;
  const fileQualities = src.kind === "mp4" || src.kind === "hls" ? src.qualities || [] : [];
  const hasQualityMenu = showLevels || fileQualities.length > 0;

  return (
    <div
      ref={shellRef}
      data-video-player
      data-testid={testId}
      data-levels={levels.length}
      tabIndex={0}
      onKeyDown={onKeyDown}
      onMouseMove={revealControls}
      onMouseLeave={() => playing && setControlsShown(false)}
      onTouchStart={revealControls}
      aria-label={`Video player — ${title}`}
      className={`relative h-full w-full bg-black outline-none ${!controlsShown && playing ? "cursor-none" : ""}`}
    >
      <video
        ref={videoRef}
        key={srcKey}
        className="h-full w-full bg-black"
        playsInline
        preload="metadata"
        poster={poster || undefined}
        autoPlay={autoPlay}
        onClick={togglePlay}
        aria-label={title}
      />

      {/* "Up next" — auto-plays the next episode when the countdown ends */}
      {nextIn != null && (
        <div
          data-testid="next-episode-overlay"
          className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 px-4"
        >
          <div className="w-full max-w-xs rounded-2xl border border-white/10 bg-[#0b1120]/95 p-5 text-center shadow-2xl">
            <p className="text-[11px] font-black uppercase tracking-widest text-[#4ADE80]">Up next</p>
            <p className="mt-1 text-lg font-extrabold text-white">Next episode in {nextIn}s</p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <button
                onClick={() => {
                  setNextIn(null);
                  onNextRef.current?.();
                }}
                className="inline-flex h-10 items-center gap-1.5 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
              >
                <Play className="h-4 w-4 fill-current" /> Play now
              </button>
              <button
                onClick={() => setNextIn(null)}
                className="h-10 rounded-full border border-white/15 px-4 text-sm font-semibold text-slate-300 transition-colors hover:text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* custom subtitle overlay — rendered from the TextTrack API so OFF is
          instant and size/colour/background/position are fully controllable */}
      {activeSub >= 0 && cueText.length > 0 && (
        <div
          data-testid="subtitle-overlay"
          className="pointer-events-none absolute left-0 right-0 z-10 flex justify-center px-[4%]"
          style={
            subStyle.position === "bottom"
              ? { bottom: 64 }
              : subStyle.position === "mid"
                ? { top: "50%", transform: "translateY(-50%)" }
                : { top: "8%" }
          }
        >
          <div
            className="max-w-full rounded-md px-3 py-1 text-center"
            style={{
              fontSize: SUB_SIZES.find((s) => s.id === subStyle.size)?.px,
              color: subStyle.color,
              backgroundColor: `rgba(0, 0, 0, ${subStyle.bg})`,
              textShadow: "0 1px 2px rgba(0, 0, 0, 0.9)",
              lineHeight: 1.35,
              fontFamily: SUB_FONT_STACKS[subStyle.font] || SUB_FONT_STACKS.sans,
              fontWeight: subStyle.bold ? 700 : 400,
            }}
          >
            {cueText.map((line, i) => (
              <p key={i} style={{ margin: 0 }}>
                {line}
              </p>
            ))}
          </div>
        </div>
      )}

      {/* continue-watching resume hint */}
      {resumeChip != null && (
        <div
          role="status"
          className="absolute left-3 top-3 z-30 flex max-w-[calc(100%-1.5rem)] items-center gap-2 rounded-full border border-white/15 bg-black/75 py-1.5 pl-3 pr-1.5 text-[11px] font-semibold text-white shadow-lg shadow-black/40 backdrop-blur"
        >
          <History className="h-3.5 w-3.5 shrink-0 text-[#4ADE80]" />
          <span className="truncate">Resumed from {formatClock(resumeChip)}</span>
          <button
            onClick={startOver}
            className="shrink-0 rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold text-[#4ADE80] transition-colors hover:bg-[#22C55E] hover:text-[#04220f]"
          >
            Start over
          </button>
          <button
            onClick={() => setResumeChip(null)}
            aria-label="Dismiss resume hint"
            className="shrink-0 rounded-full p-1 text-slate-400 transition-colors hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* buffering / initial loading */}
      {(status === "loading" || (buffering && playing)) && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-[#4ADE80]" aria-label="Loading video" />
        </div>
      )}

      {/* error state */}
      {status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#0a0f24]/95 px-6 text-center" role="alert">
          <AlertTriangle className="h-10 w-10 text-amber-400" />
          <p className="max-w-md font-semibold text-slate-200">{errorMsg || "Playback error."}</p>
          <button
            onClick={() => {
              setStatus("loading");
              setErrorMsg("");
              if (src.kind === "signed") {
                resolveSigned(false).then((r) => {
                  if (r && videoRef.current) videoRef.current.src = r.url;
                });
              } else {
                const v = videoRef.current;
                if (v) {
                  v.load();
                  const hls = hlsRef.current;
                  if (hls) hls.startLoad();
                }
              }
            }}
            className="mt-1 inline-flex h-10 items-center gap-2 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] hover:bg-[#4ADE80]"
          >
            <RotateCcw className="h-4 w-4" /> Try again
          </button>
        </div>
      )}

      {/* center play button when paused */}
      {status === "ok" && !playing && (
        <button
          onClick={togglePlay}
          aria-label="Play"
          className="absolute left-1/2 top-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[#22C55E]/90 text-[#04220f] shadow-xl transition-transform hover:scale-105 hover:bg-[#4ADE80]"
        >
          <Play className="ml-1 h-7 w-7 fill-current" />
        </button>
      )}

      {/* control bar */}
      <div
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/85 via-black/50 to-transparent px-3 pb-2 pt-8 transition-opacity duration-200 ${
          controlsShown || !playing ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        {/* seek bar */}
        <div className="relative flex items-center">
          <div className="pointer-events-none absolute left-0 right-0 top-1/2 h-1.5 -translate-y-1/2 overflow-hidden rounded-full bg-white/20">
            <div
              className="absolute h-full rounded-full bg-white/25"
              style={{ width: duration ? `${(buffered / duration) * 100}%` : "0%" }}
            />
            <div
              className="absolute h-full rounded-full bg-gradient-to-r from-[#16A34A] to-[#4ADE80]"
              style={{ width: duration ? `${(current / duration) * 100}%` : "0%" }}
            />
          </div>
          <input
            type="range"
            min={0}
            max={duration || 0}
            step={0.1}
            value={current}
            aria-label="Seek"
            onChange={(e) => {
              const t = Number(e.target.value);
              setScrubbing(true);
              setCurrent(t);
              if (videoRef.current) videoRef.current.currentTime = t;
              setScrubbing(false);
            }}
            className="relative z-10 h-4 w-full cursor-pointer appearance-none bg-transparent [&::-webkit-slider-thumb]:h-3.5 [&::-webkit-slider-thumb]:w-3.5 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#4ADE80] [&::-moz-range-thumb]:h-3.5 [&::-moz-range-thumb]:w-3.5 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-[#4ADE80]"
          />
        </div>

        <div className="mt-1 flex items-center gap-1.5">
          <button onClick={togglePlay} aria-label={playing ? "Pause" : "Play"} className="rounded-lg p-2 text-white hover:bg-white/10">
            {playing ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 fill-current" />}
          </button>

          {/* volume */}
          <div className="group flex items-center">
            <button
              onClick={() => {
                if (videoRef.current) videoRef.current.muted = !videoRef.current.muted;
              }}
              aria-label={muted ? "Unmute" : "Mute"}
              className="rounded-lg p-2 text-white hover:bg-white/10"
            >
              {muted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              aria-label="Volume"
              onChange={(e) => {
                const v = videoRef.current;
                if (v) {
                  v.volume = Number(e.target.value);
                  v.muted = Number(e.target.value) === 0;
                }
              }}
              className="h-1.5 w-0 cursor-pointer appearance-none rounded-full bg-white/25 opacity-0 transition-all duration-200 group-hover:w-16 group-hover:opacity-100 sm:w-16 sm:opacity-100 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-moz-range-thumb]:h-3 [&::-moz-range-thumb]:w-3 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white"
            />
          </div>

          <span className="ml-1 select-none text-xs font-semibold tabular-nums text-slate-200">
            {fmt(current)} <span className="text-slate-400">/ {fmt(duration)}</span>
          </span>

          <div className="flex-1" />

          {/* speed */}
          <div className="relative">
            <button
              onClick={() => setMenu(menu === "speed" ? "none" : "speed")}
              aria-label="Playback speed"
              aria-expanded={menu === "speed"}
              className="flex items-center gap-1 rounded-lg px-2 py-2 text-xs font-bold text-white hover:bg-white/10"
            >
              <Gauge className="h-4 w-4" /> {speed}×
            </button>
            {menu === "speed" && (
              <div className="absolute bottom-11 right-0 w-28 rounded-xl border border-white/10 bg-[#0b1120] py-1 shadow-xl" role="menu">
                {SPEEDS.map((s) => (
                  <button
                    key={s}
                    role="menuitemradio"
                    aria-checked={speed === s}
                    onClick={() => applySpeed(s)}
                    className={`block w-full px-3 py-1.5 text-left text-xs font-semibold hover:bg-white/10 ${speed === s ? "text-[#4ADE80]" : "text-slate-200"}`}
                  >
                    {s}× {s === 1 ? "(normal)" : ""}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* quality: hls levels or separate files */}
          {hasQualityMenu && (
            <div className="relative">
              <button
                onClick={() => setMenu(menu === "quality" ? "none" : "quality")}
                aria-label="Video quality"
                aria-expanded={menu === "quality"}
                className="rounded-lg px-2 py-2 text-xs font-bold text-white hover:bg-white/10"
              >
                {showLevels
                  ? level === -1
                    ? "Auto"
                    : levels.find((l) => l.i === level)?.label || "Auto"
                  : qualityIdx < 0
                    ? "Auto"
                    : fileQualities[qualityIdx]?.label || "Auto"}
              </button>
              {menu === "quality" && (
                <div className="absolute bottom-11 right-0 w-32 rounded-xl border border-white/10 bg-[#0b1120] py-1 shadow-xl" role="menu">
                  <button
                    role="menuitemradio"
                    aria-checked={(showLevels ? level : qualityIdx) === -1}
                    onClick={() => (showLevels ? setHlsLevel(-1) : switchQualityFile(-1))}
                    className="block w-full px-3 py-1.5 text-left text-xs font-semibold text-slate-200 hover:bg-white/10"
                  >
                    Auto
                  </button>
                  {showLevels
                    ? levels.map((l) => (
                        <button
                          key={l.i}
                          role="menuitemradio"
                          aria-checked={level === l.i}
                          onClick={() => setHlsLevel(l.i)}
                          className={`block w-full px-3 py-1.5 text-left text-xs font-semibold hover:bg-white/10 ${level === l.i ? "text-[#4ADE80]" : "text-slate-200"}`}
                        >
                          {l.label}
                        </button>
                      ))
                    : fileQualities.map((q, i) => (
                        <button
                          key={`${q.label}-${i}`}
                          role="menuitemradio"
                          aria-checked={qualityIdx === i}
                          onClick={() => switchQualityFile(i)}
                          className={`block w-full px-3 py-1.5 text-left text-xs font-semibold hover:bg-white/10 ${qualityIdx === i ? "text-[#4ADE80]" : "text-slate-200"}`}
                        >
                          {q.label}
                        </button>
                      ))}
                </div>
              )}
            </div>
          )}

          {/* subtitles — dedicated CC toggle + settings menu */}
          <div className="relative">
            <div className="flex items-center overflow-hidden rounded-lg">
              <button
                onClick={toggleCc}
                aria-label={activeSub >= 0 ? "Turn subtitles off" : "Turn subtitles on"}
                aria-pressed={activeSub >= 0}
                data-testid="cc-button"
                title="Subtitles (C)"
                className={`px-2 py-2 text-[11px] font-black tracking-wide transition-colors ${
                  activeSub >= 0 ? "bg-[#22C55E] text-[#04220f]" : "text-white hover:bg-white/10"
                }`}
              >
                CC
              </button>
              <button
                onClick={() => setMenu(menu === "subs" ? "none" : "subs")}
                aria-label="Subtitle settings"
                aria-expanded={menu === "subs"}
                className={`px-1 py-2 transition-colors ${
                  activeSub >= 0 ? "bg-[#22C55E] text-[#04220f] hover:text-white" : "text-white hover:bg-white/10"
                }`}
              >
                <ChevronDown className="h-3.5 w-3.5" />
              </button>
            </div>
            {menu === "subs" && (
              <SubtitleMenu
                tracks={subtitles}
                localTracks={localTracks}
                activeSub={activeSub}
                onSelect={(idx) => loadSubTrack(allTracksRef.current[idx] ?? null, idx)}
                onLoadFile={handleLocalFile}
                onRemoveLocal={removeLocalTrack}
                style={subStyle}
                onStyle={updateSubStyle}
                note={null}
                error={subError}
                onClose={() => setMenu("none")}
              />
            )}
          </div>

          {/* next episode — only when the parent view provides one */}
          {onNext && (
            <button
              onClick={onNext}
              aria-label="Next episode"
              title="Next episode"
              className="rounded-lg p-2 text-white hover:bg-white/10"
            >
              <SkipForward className="h-5 w-5" />
            </button>
          )}

          <button onClick={toggleFullscreen} aria-label={fullscreen ? "Exit fullscreen" : "Fullscreen"} className="rounded-lg p-2 text-white hover:bg-white/10">
            {fullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </div>
  );
}
