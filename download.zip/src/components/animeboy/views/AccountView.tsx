"use client";

/**
 * Account Settings ("#/account") — every registered user's profile hub:
 * profile card, Profile Settings (change username), Security & Password
 * section and a Support ANIME BOY card.
 */
import { Heart, Mail, ShieldCheck, UserRound } from "lucide-react";
import { navigate, useAppStore } from "@/store/useAppStore";
import { ProfileSettingsForm } from "./../ProfileSettingsForm";
import { SecurityPasswordForm } from "./../SecurityPasswordForm";

export function AccountView() {
  const { user, userLoaded } = useAppStore();

  if (userLoaded && !user) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/10">
          <UserRound className="h-8 w-8 text-[#4ADE80]" />
        </span>
        <h1 className="mt-4 text-2xl font-black text-white">Account Settings</h1>
        <p className="mt-2 text-sm text-slate-400">Please sign in to manage your account.</p>
        <button
          onClick={() => navigate("/signin")}
          className="mt-6 h-11 rounded-full bg-[#22C55E] px-6 font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
        >
          Sign In
        </button>
      </div>
    );
  }

  if (!user) return <div className="py-24 text-center text-slate-400">Loading…</div>;

  return (
    <div className="fade-up mx-auto max-w-2xl px-4 pb-10 pt-8 sm:px-6">
      <h1 className="text-2xl font-black text-white sm:text-3xl">Account Settings</h1>
      <p className="mt-1 text-sm text-slate-400">Manage your profile and security.</p>

      {/* profile card */}
      <section className="mt-6 rounded-3xl border border-white/8 bg-white/[0.03] p-6" aria-label="Profile">
        <div className="flex items-center gap-4">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-[#22C55E] text-xl font-black text-[#052e16]">
            {(user.name || user.email).charAt(0).toUpperCase()}
          </span>
          <div className="min-w-0">
            <p className="truncate text-lg font-bold text-white">{user.name || "Viewer"}</p>
            <p className="flex items-center gap-1.5 truncate text-sm text-slate-400">
              <Mail className="h-3.5 w-3.5 shrink-0" /> {user.email}
            </p>
            {user.role === "ADMIN" && (
              <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-[#22C55E]/15 px-2 py-0.5 text-[10px] font-bold text-[#4ADE80]">
                <ShieldCheck className="h-3 w-3" /> ADMIN
              </span>
            )}
          </div>
        </div>
      </section>

      {/* profile settings — change username (independent of the password) */}
      <div className="mt-6">
        <ProfileSettingsForm isAdmin={user.role === "ADMIN"} />
      </div>

      {/* security & password */}
      <div className="mt-6">
        <SecurityPasswordForm isAdmin={user.role === "ADMIN"} />
      </div>

      {/* support ANIME BOY */}
      <section className="mt-6 overflow-hidden rounded-3xl border border-[#22C55E]/20 bg-gradient-to-br from-[#22C55E]/[0.08] to-transparent p-6">
        <div className="flex flex-wrap items-center gap-4">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#22C55E]/15">
            <Heart className="h-5.5 w-5.5 text-[#4ADE80]" />
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="text-base font-black text-white">Support ANIME BOY</h2>
            <p className="text-xs leading-relaxed text-slate-400">
              Love the site? A small donation keeps ANIME BOY running. 💚
            </p>
          </div>
          <button
            onClick={() => navigate("/support")}
            className="inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
          >
            <Heart className="h-4 w-4" /> Donate
          </button>
        </div>
      </section>
    </div>
  );
}
