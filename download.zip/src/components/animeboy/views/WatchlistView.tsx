"use client";

import { useQuery } from "@tanstack/react-query";
import { Bookmark, LogIn } from "lucide-react";
import { api } from "@/lib/client-api";
import { navigate, useAppStore, type AnimeType } from "@/store/useAppStore";
import { PosterGridSkeleton } from "./../Skeletons";
import { EmptyState, ErrorState } from "./../EmptyState";
import { PosterCard } from "./../PosterCard";

export function WatchlistView() {
  const { user, userLoaded } = useAppStore();

  const { data, isLoading, isError, refetch } = useQuery<{ items: AnimeType[] }>({
    queryKey: ["watchlist", user?.id],
    queryFn: () => api.get("/api/watchlist"),
    enabled: !!user,
  });

  if (userLoaded && !user) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20">
        <EmptyState
          icon={LogIn}
          title="Sign in to see your watchlist"
          description="ඔබගේ නැරඹුම් ලැයිස්තුව බලාගැනීමට පළමුව sign in වන්න. Your saved anime syncs with your account."
          action={
            <button
              onClick={() => navigate("/signin")}
              className="h-11 rounded-full bg-[#22C55E] px-6 font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
            >
              Sign In
            </button>
          }
        />
      </div>
    );
  }

  if (!user || isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 pt-8 sm:px-6">
        <h1 className="text-2xl font-black text-white">My Watchlist</h1>
        <div className="mt-6">
          <PosterGridSkeleton count={6} />
        </div>
      </div>
    );
  }

  return (
    <div className="fade-up mx-auto max-w-7xl px-4 pt-8 sm:px-6">
      <div className="flex items-center gap-3">
        <Bookmark className="h-7 w-7 text-[#4ADE80]" />
        <div>
          <h1 className="text-2xl font-black text-white sm:text-3xl">My Watchlist</h1>
          <p className="mt-0.5 text-sm text-slate-400">
            {data ? `${data.items.length} saved ${data.items.length === 1 ? "title" : "titles"}` : "…"}
          </p>
        </div>
      </div>

      <div className="mt-7 min-h-[300px]">
        {isError ? (
          <ErrorState message="Could not load your watchlist." onRetry={() => refetch()} />
        ) : !data || data.items.length === 0 ? (
          <EmptyState
            icon={Bookmark}
            title="Your watchlist is empty"
            description="Tap the bookmark icon on any anime to save it here. ඇනිමේ එකක් සුරැකීමට bookmark අයිකනය ඔබන්න."
            action={
              <button
                onClick={() => navigate("/")}
                className="h-10 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
              >
                Browse anime
              </button>
            }
          />
        ) : (
          <div className="grid grid-cols-2 gap-x-3.5 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {data.items.map((a) => (
              <div key={a.id} className="flex justify-center sm:justify-start">
                <PosterCard anime={a} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
