"use client";

/**
 * "Forgot Password?" — request an expiring, single-use email reset link.
 * The response is always generic (no account enumeration).
 */
import { useState } from "react";
import { KeyRound, Loader2, Mail } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { navigate } from "@/store/useAppStore";

export function ForgotPasswordView() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await api.post<{ message: string }>("/api/auth/forgot-password", { email: email.trim() });
      setSent(true);
      toast.success("Reset link sent", { description: res.message });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Request failed";
      // SMTP-not-configured is a real, actionable error worth showing inline.
      setError(msg);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fade-up mx-auto flex max-w-md flex-col px-4 pb-6 pt-12 sm:px-6">
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/12 glow-green">
          <KeyRound className="h-8 w-8 text-[#4ADE80]" />
        </span>
        <h1 className="mt-4 text-3xl font-black text-white">Forgot Password?</h1>
        <p className="mt-1.5 text-sm text-slate-400">
          Enter your account email and we&apos;ll send a secure reset link. It expires in 60 minutes and works only once.
        </p>
      </div>

      {sent ? (
        <div className="mt-8 rounded-3xl border border-[#22C55E]/25 bg-[#22C55E]/[0.06] p-6 text-center">
          <Mail className="mx-auto h-8 w-8 text-[#4ADE80]" />
          <p className="mt-3 text-sm leading-relaxed text-slate-200">
            If an account exists for <strong className="text-[#4ADE80]">{email}</strong>, a password reset link is on its way.
            Please check your inbox and spam folder.
          </p>
          <button
            onClick={() => navigate("/signin")}
            className="mt-5 h-11 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
          >
            Back to Sign In
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-8 space-y-4 rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-7" noValidate>
          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">Email</span>
            <span className="relative block">
              <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                required
                aria-label="Email address"
                className="h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] pl-11 pr-4 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25"
              />
            </span>
          </label>

          {error && (
            <p role="alert" className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="h-12 w-full rounded-xl bg-[#22C55E] font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:opacity-60"
          >
            {busy ? (
              <>
                <Loader2 className="mr-2 inline h-4 w-4 animate-spin" /> Sending…
              </>
            ) : (
              "Send Reset Link"
            )}
          </button>

          <p className="text-center text-sm text-slate-400">
            Remembered it?{" "}
            <button type="button" onClick={() => navigate("/signin")} className="font-bold text-[#4ADE80] hover:underline">
              Sign In
            </button>
          </p>
        </form>
      )}
    </div>
  );
}
