"use client";

import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Plus, Pencil, Trash2, Search, ArrowLeft, ListVideo, Film, MonitorPlay, Shapes,
  TvMinimalPlay, Loader2, Upload as UploadIcon, Layers, CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import type { AnimeType, EpisodeType, SeasonType } from "@/store/useAppStore";
import { VideoSourceEditor, type VideoSourceValue } from "./VideoSourceEditor";
import { AnimeEditor, SeriesManager, seedSource, inputCls, selectCls, AdminField } from "./AdminContent";

type Playlist = AnimeType & { seasonCount?: number };

/* Playlists are the series-shaped titles of the three playlist categories. */
const CATS = [
  { key: "", label: "All", icon: Layers },
  { key: "ANIME", label: "Anime Series", icon: MonitorPlay },
  { key: "DONGHUA", label: "Donghua Series", icon: TvMinimalPlay },
  { key: "OTHERS", label: "Others", icon: Shapes },
] as const;

const CAT_LABEL: Record<string, string> = {
  ANIME: "Anime Series",
  DONGHUA: "Donghua Series",
  OTHERS: "Others",
};

function playlistUrl(cat: string, q: string) {
  const p = new URLSearchParams({ type: "SERIES" });
  if (cat) p.set("category", cat);
  if (q.trim()) p.set("q", q.trim());
  return `/api/admin/anime?${p.toString()}`;
}

/** "Season 2" / custom name — mirrors the watch-page season labels. */
export function seasonName(s: { number: number; title: string | null }) {
  return s.title?.trim() || `Season ${s.number}`;
}

function episodeCount(a: Playlist) {
  return (a.seasons || []).reduce((n, s) => n + (s.episodes?.length || 0), 0);
}

/* ============================= playlist manager ============================ */

export function PlaylistManager() {
  const [view, setView] = useState<"list" | "upload" | "manage" | "edit">("list");
  const [cat, setCat] = useState<string>("");
  const [q, setQ] = useState("");
  const [active, setActive] = useState<Playlist | null>(null);
  const [prefill, setPrefill] = useState<{ cat: string; playlistId: string } | null>(null);

  const { data, isLoading, isError } = useQuery<{ items: Playlist[] }>({
    queryKey: ["admin-anime", "playlists", cat, q],
    queryFn: () => api.get(playlistUrl(cat, q)),
  });
  const items = data?.items || [];

  if (view === "manage" && active) {
    return (
      <SeriesManager
        anime={active}
        backLabel="Back to playlists"
        onBack={() => {
          setActive(null);
          setView("list");
        }}
      />
    );
  }

  if (view === "edit" && active) {
    return (
      <AnimeEditor
        existing={active}
        backLabel="Back to playlists"
        onBack={() => {
          setActive(null);
          setView("list");
        }}
      />
    );
  }

  if (view === "upload") {
    return (
      <PlaylistUpload
        prefill={prefill}
        onBack={() => {
          setPrefill(null);
          setView("list");
        }}
      />
    );
  }

  return (
    <div className="fade-up">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <h2 className="text-lg font-black text-white">Playlist Manager</h2>
          <p className="text-sm text-slate-400">
            Playlist uploads for Anime Series, Donghua Series and Others · {items.length} playlist{items.length === 1 ? "" : "s"}
          </p>
        </div>
        <div className="flex-1" />
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search playlists…"
            aria-label="Search playlists"
            className="h-10 w-48 rounded-full border border-white/10 bg-white/[0.04] pl-9 pr-3 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50"
          />
        </div>
        <button
          onClick={() => {
            setPrefill(null);
            setView("upload");
          }}
          className="inline-flex h-10 items-center gap-1.5 rounded-full bg-[#22C55E] px-4 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
        >
          <UploadIcon className="h-4 w-4" /> Upload Episode
        </button>
      </div>

      {/* category filter */}
      <div className="mt-4 flex flex-wrap gap-1.5" role="group" aria-label="Filter playlists by category">
        {CATS.map((c) => {
          const on = cat === c.key;
          return (
            <button
              key={c.key || "all"}
              onClick={() => setCat(c.key)}
              aria-pressed={on}
              className={`inline-flex h-9 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold transition-colors ${
                on
                  ? "bg-[#22C55E] text-[#04220f]"
                  : "border border-white/10 bg-white/[0.04] text-slate-300 hover:border-[#22C55E]/40 hover:text-white"
              }`}
            >
              <c.icon className="h-3.5 w-3.5" /> {c.label}
            </button>
          );
        })}
      </div>

      <div className="mt-5 overflow-hidden rounded-2xl border border-white/8">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-white/8 bg-white/[0.03] text-xs uppercase tracking-wider text-slate-400">
                <th className="px-4 py-3 font-bold">Playlist</th>
                <th className="px-4 py-3 font-bold">Category</th>
                <th className="px-4 py-3 font-bold">Seasons</th>
                <th className="px-4 py-3 font-bold">Episodes</th>
                <th className="px-4 py-3 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-400">Loading playlists…</td>
                </tr>
              ) : isError ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-red-300">
                    Failed to load — check that you are signed in as an admin.
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-slate-400">
                    No playlists here yet — click <strong className="text-[#4ADE80]">Upload Episode</strong> to create the first one.
                  </td>
                </tr>
              ) : (
                items.map((a) => (
                  <tr key={a.id} className="border-b border-white/5 transition-colors hover:bg-white/[0.02]">
                    <td className="max-w-72 px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        {a.posterUrl ? (
                          <img src={a.posterUrl} alt="" className="h-11 w-8 shrink-0 rounded object-cover" />
                        ) : (
                          <span className="h-11 w-8 shrink-0 rounded bg-white/8" />
                        )}
                        <span className="min-w-0">
                          <span className="block truncate font-semibold text-white">{a.titleEn}</span>
                          <span className="block truncate text-xs text-slate-500">/{a.slug}</span>
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 rounded bg-[#22C55E]/15 px-1.5 py-0.5 text-[10px] font-bold text-[#4ADE80]">
                        <Layers className="h-2.5 w-2.5" /> {CAT_LABEL[a.category] || a.category}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-300">{a.seasons?.length ?? a.seasonCount ?? 0}</td>
                    <td className="px-4 py-3 text-slate-300">{episodeCount(a)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setPrefill({ cat: a.category, playlistId: a.id });
                            setView("upload");
                          }}
                          aria-label={`Upload episode to ${a.titleEn}`}
                          title="Upload episode to this playlist"
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-[#4ADE80] hover:bg-[#22C55E]/10"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => {
                            setActive(a);
                            setView("manage");
                          }}
                          aria-label={`View episodes of ${a.titleEn}`}
                          title="Seasons & episodes — view, reorder, edit"
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
                        >
                          <ListVideo className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => {
                            setActive(a);
                            setView("edit");
                          }}
                          aria-label={`Edit ${a.titleEn}`}
                          title="Edit playlist details"
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => {
                            const eps = episodeCount(a);
                            if (
                              window.confirm(
                                `Delete playlist "${a.titleEn}"? This permanently removes its ${a.seasons?.length || 0} season(s), ${eps} episode(s) and every video & download link inside it.`
                              )
                            ) {
                              api
                                .delete(`/api/admin/anime/${a.id}`)
                                .then(() => {
                                  toast.success("Playlist deleted");
                                  return api.get(playlistUrl(cat, q));
                                })
                                .catch((e) => toast.error(e instanceof Error ? e.message : "Delete failed"));
                            }
                          }}
                          aria-label={`Delete ${a.titleEn}`}
                          title="Delete playlist"
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ========================== upload-episode workflow ======================== */

/**
 * The seven-step playlist upload workflow (Anime Series / Donghua Series /
 * Others): pick the category → create or choose a playlist → pick or create a
 * season → episode details + video source → save. After each save the form
 * stays on the same playlist & season with the next episode number suggested,
 * so many episodes can be added in a row without recreating anything.
 */
function PlaylistUpload({
  prefill,
  onBack,
}: {
  prefill: { cat: string; playlistId: string } | null;
  onBack: () => void;
}) {
  const qc = useQueryClient();
  const [cat, setCat] = useState(prefill?.cat || "");
  const [flow, setFlow] = useState<"create" | "existing">(prefill ? "existing" : "create");
  const [newName, setNewName] = useState("");
  const [playlistId, setPlaylistId] = useState(prefill?.playlistId || "");
  const [seasonChoice, setSeasonChoice] = useState<"new" | string>("new");
  const [newSeasonName, setNewSeasonName] = useState("");
  const [newSeasonNumber, setNewSeasonNumber] = useState("");
  const [epNumber, setEpNumber] = useState("1");
  const [epTitle, setEpTitle] = useState("");
  const [vs, setVs] = useState<VideoSourceValue>(seedSource(null));
  const [saving, setSaving] = useState(false);
  const [justSaved, setJustSaved] = useState<string | null>(null);

  // Playlists available for "Add to Existing" (+ the playlist being targeted).
  const { data: plData, isFetching: plFetching } = useQuery<{ items: Playlist[] }>({
    queryKey: ["admin-anime", "playlists-picker", cat],
    queryFn: () => api.get(playlistUrl(cat, "")),
    enabled: !!cat,
  });
  const playlists = useMemo(() => plData?.items || [], [plData]);

  const selected = playlists.find((p) => p.id === playlistId) || null;

  // Live season list of the targeted playlist (kept local so saves are
  // reflected instantly, even before the refetch lands). Reset ONLY when the
  // targeted playlist changes — a refetch of the same playlist must never
  // clobber the admin's season choice mid-workflow.
  const [seasons, setSeasons] = useState<SeasonType[]>([]);
  const selectedId = selected?.id ?? "";
  useEffect(() => {
    const list = [...(selected?.seasons || [])].sort((a, b) => a.number - b.number);
    setSeasons(list);
    setSeasonChoice(list.length ? list[0].id : "new");
    setEpNumber(String(Math.max(0, ...(list[0]?.episodes || []).map((e) => e.number)) + 1));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  const activeSeason =
    seasonChoice !== "new" ? seasons.find((s) => s.id === seasonChoice) || null : null;

  const switchCat = (key: string) => {
    setCat(key);
    setPlaylistId("");
    setSeasonChoice("new");
    setNewSeasonName("");
    setNewSeasonNumber("");
    setSeasons([]);
    setJustSaved(null);
  };

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-anime"] });
    qc.invalidateQueries({ queryKey: ["sections"] });
    qc.invalidateQueries({ queryKey: ["admin-stats"] });
  };

  const save = async () => {
    setJustSaved(null);
    if (!cat) {
      toast.error("Select a content category first (step 1)");
      return;
    }
    if (flow === "create" && !newName.trim()) {
      toast.error("Enter a playlist name (step 3)");
      return;
    }
    if (flow === "existing" && !playlistId) {
      toast.error("Choose an existing playlist (step 3)");
      return;
    }

    const numRaw = newSeasonNumber.trim();
    const wantsNewSeason = flow === "create" || seasonChoice === "new";
    if (wantsNewSeason && numRaw && (!/^\d+$/.test(numRaw) || Number(numRaw) < 1)) {
      toast.error("Season number must be a positive whole number (1, 2, 3 …) or left empty");
      return;
    }
    // Others playlists keep season fields OPTIONAL — videos without a season
    // name simply land in a clean auto-created "Season 1" (custom names still
    // work). Anime & Donghua series keep the season name required.
    const seasonOptional = cat === "OTHERS";
    const newSeasonTitle = newSeasonName.trim() || (numRaw ? `Season ${numRaw}` : "");
    if (wantsNewSeason && !newSeasonTitle && !seasonOptional) {
      toast.error("Enter a season name (e.g. Season 1, Final Season) — step 4");
      return;
    }
    const num = Math.floor(Number(epNumber));
    if (!/^\d+$/.test(epNumber.trim()) || num < 1) {
      toast.error("Episode number must be a positive whole number (1, 2, 3 …)");
      return;
    }

    setSaving(true);
    try {
      /* Step 3 — resolve or create the playlist (a series title in the
         chosen category; movie categories never enter this workflow). */
      let animeId = playlistId;
      let playlistTitle = selected?.titleEn || "";
      if (flow === "create") {
        const res = await api.post<{ anime: AnimeType }>("/api/admin/anime", {
          titleEn: newName.trim(),
          category: cat,
          type: "SERIES",
          published: true,
        });
        animeId = res.anime.id;
        playlistTitle = res.anime.titleEn;
      } else if (!playlistTitle) {
        const picked = playlists.find((p) => p.id === playlistId);
        if (!picked) {
          toast.error("Choose an existing playlist (step 3)");
          setSaving(false);
          return;
        }
        playlistTitle = picked.titleEn;
      }

      /* Step 4 — resolve or create the season. A season whose name already
         exists in the playlist is reused, so duplicates never pile up. */
      let targetSeasonId = seasonChoice;
      if (wantsNewSeason) {
        const dup = newSeasonTitle
          ? seasons.find((s) => (s.title || "").trim().toLowerCase() === newSeasonTitle.toLowerCase())
          : undefined;
        if (dup) {
          targetSeasonId = dup.id;
          toast.info(`Season “${newSeasonTitle}” already exists — adding the episode there`);
        } else {
          // Empty title (Others, optional season): send no title/number so the
          // API stores a clean season with the next free number — displayed as
          // "Season N" everywhere, exactly like a numbered season.
          const res = await api.post<{ season: SeasonType }>("/api/admin/seasons", {
            animeId,
            ...(newSeasonTitle ? { title: newSeasonTitle } : {}),
            ...(numRaw ? { number: Number(numRaw) } : {}),
          });
          setSeasons((prev) => [...prev, res.season].sort((a, b) => a.number - b.number));
          targetSeasonId = res.season.id;
        }
        // Continue in the season we just targeted (not back on “New season…”).
        setSeasonChoice(targetSeasonId);
        setNewSeasonName("");
        setNewSeasonNumber("");
      }

      /* Steps 5–7 — save the episode with its video source & download URL. */
      const payload = {
        seasonId: targetSeasonId,
        number: num,
        title: epTitle.trim() || null,
        ...vs,
        subtitleTracks: vs.subtitles,
        videoQualities: vs.qualities,
        thumbnailUrl: vs.videoThumb,
        subtitleUrl: "",
      };
      await api.post("/api/admin/episodes", payload);

      // Reflect the new episode locally so the next suggested number is right.
      setSeasons((prev) =>
        prev.map((s) =>
          s.id === targetSeasonId
            ? { ...s, episodes: [...s.episodes, { id: `tmp-${Date.now()}`, number: num } as EpisodeType] }
            : s
        )
      );
      setEpNumber(String(num + 1));
      setEpTitle("");
      setVs(seedSource(null));
      setJustSaved(`Episode ${num} saved to “${playlistTitle}” — add another episode, or press Done.`);

      // After a brand-new playlist the flow continues in "add to existing"
      // mode — more episodes never recreate the playlist.
      if (flow === "create") {
        setFlow("existing");
        setPlaylistId(animeId);
        setNewName("");
      }
      invalidate();
      toast.success(`Episode ${num} saved to “${playlistTitle}” ✓`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const stepHead = (n: number, title: string, done?: boolean) => (
    <h3 className="flex items-center gap-2.5 text-[13px] font-black uppercase tracking-wider text-white">
      <span
        className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-black ${
          done ? "bg-[#22C55E] text-[#04220f]" : "bg-[#22C55E]/15 text-[#4ADE80]"
        }`}
      >
        {done ? <CheckCircle2 className="h-3.5 w-3.5" /> : n}
      </span>
      {title}
    </h3>
  );

  return (
    <div className="fade-up">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-300 hover:text-[#4ADE80]">
        <ArrowLeft className="h-4 w-4" /> Back to playlists
      </button>
      <h2 className="mt-3 text-lg font-black text-white">Upload Episode to Playlist</h2>
      <p className="text-sm text-slate-400">
        Anime Series, Donghua Series and Others — create a new playlist or add to an existing one.
      </p>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        {/* step 1 — category */}
        <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          {stepHead(1, "Select Content Category", !!cat)}
          <div className="mt-4 grid gap-2 sm:grid-cols-3">
            {CATS.filter((c) => c.key).map((c) => {
              const on = cat === c.key;
              return (
                <button
                  key={c.key}
                  type="button"
                  onClick={() => switchCat(c.key)}
                  aria-pressed={on}
                  className={`flex flex-col items-center gap-1.5 rounded-xl border px-3 py-3.5 text-xs font-bold transition-colors ${
                    on
                      ? "border-[#22C55E] bg-[#22C55E]/12 text-[#4ADE80]"
                      : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-[#22C55E]/40 hover:text-white"
                  }`}
                >
                  <c.icon className="h-5 w-5" />
                  {c.label}
                </button>
              );
            })}
          </div>
          {!cat && <p className="mt-3 text-xs text-amber-300">Choose one of the three playlist categories to continue.</p>}
        </section>

        {/* step 2 — create vs existing */}
        <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          {stepHead(2, "Create New or Add to Existing", !!cat)}
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {(
              [
                { key: "create", title: "Create New Playlist", sub: "Start a fresh playlist with its first episode" },
                { key: "existing", title: "Add to Existing Playlist", sub: "Add more episodes to a playlist" },
              ] as const
            ).map((o) => {
              const on = flow === o.key;
              return (
                <button
                  key={o.key}
                  type="button"
                  disabled={!cat}
                  onClick={() => {
                    setFlow(o.key);
                    setSeasonChoice("new");
                    setSeasons([]);
                    setJustSaved(null);
                    if (o.key === "create") {
                      setPlaylistId("");
                    } else {
                      setNewSeasonName("");
                      setNewSeasonNumber("");
                    }
                  }}
                  aria-pressed={on}
                  className={`rounded-xl border px-3.5 py-3 text-left transition-colors disabled:opacity-40 ${
                    on
                      ? "border-[#22C55E] bg-[#22C55E]/12"
                      : "border-white/10 bg-white/[0.03] hover:border-[#22C55E]/40"
                  }`}
                >
                  <span className={`block text-[13px] font-bold ${on ? "text-[#4ADE80]" : "text-white"}`}>{o.title}</span>
                  <span className="mt-0.5 block text-[11px] leading-snug text-slate-400">{o.sub}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* step 3 — playlist name / picker */}
        <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          {stepHead(3, flow === "create" ? "New Playlist Name" : "Select Existing Playlist", flow === "create" ? !!newName.trim() : !!playlistId)}
          {flow === "create" ? (
            <div className="mt-4">
              <AdminField label="Playlist Name *">
                <input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Dragon Legacy"
                  className={inputCls}
                  aria-label="Playlist name"
                />
              </AdminField>
              <p className="mt-2 text-xs text-slate-500">
                The playlist is created in <strong className="text-slate-300">{cat ? CAT_LABEL[cat] : "the selected category"}</strong> and appears on the site immediately.
              </p>
            </div>
          ) : (
            <div className="mt-4">
              <AdminField label="Playlist *">
                <select
                  value={playlistId}
                  onChange={(e) => {
                    setPlaylistId(e.target.value);
                    setJustSaved(null);
                  }}
                  className={selectCls}
                  aria-label="Select existing playlist"
                  disabled={!cat || plFetching}
                >
                  <option value="" className="bg-[#0b1120]">
                    {!cat ? "Select a category first…" : plFetching ? "Loading playlists…" : "Select a playlist…"}
                  </option>
                  {playlists.map((p) => (
                    <option key={p.id} value={p.id} className="bg-[#0b1120]">
                      {p.titleEn} ({p.seasons?.length || 0} seasons · {episodeCount(p)} episodes)
                    </option>
                  ))}
                </select>
              </AdminField>
              {cat === "OTHERS" && (
                <p className="mt-2 text-xs text-slate-500">
                  Others single videos uploaded via <strong className="text-slate-300">Content → Add Content</strong> are not playlists and stay untouched.
                </p>
              )}
            </div>
          )}
        </section>

        {/* step 4 — season name (select or create); optional for Others */}
        <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          {stepHead(4, cat === "OTHERS" ? "Season Name (optional)" : "Season Name", seasonChoice !== "new" ? !!activeSeason : !!(newSeasonName.trim() || newSeasonNumber.trim()) || cat === "OTHERS")}
          <div className="mt-4">
            {flow === "existing" && !playlistId ? (
              <p className="text-xs text-slate-500">Choose a playlist in step 3 to pick or create its season.</p>
            ) : (
              <>
                {flow === "existing" && (
                  <AdminField label="Season">
                    <select
                      value={seasonChoice}
                      onChange={(e) => {
                        setSeasonChoice(e.target.value);
                        const s = seasons.find((x) => x.id === e.target.value);
                        setEpNumber(String(Math.max(0, ...(s?.episodes || []).map((x) => x.number)) + 1));
                        setJustSaved(null);
                      }}
                      className={selectCls}
                      aria-label="Select season"
                    >
                      <option value="new" className="bg-[#0b1120]">＋ New season…</option>
                      {seasons.map((s) => (
                        <option key={s.id} value={s.id} className="bg-[#0b1120]">
                          {seasonName(s)} ({s.episodes.length} episode{s.episodes.length === 1 ? "" : "s"})
                        </option>
                      ))}
                    </select>
                  </AdminField>
                )}
                {seasonChoice === "new" && (
                  <div className="mt-3 grid grid-cols-2 gap-3">
                    <AdminField label={cat === "OTHERS" ? "Season Name (optional)" : "Season Name *"}>
                      <input
                        value={newSeasonName}
                        onChange={(e) => setNewSeasonName(e.target.value)}
                        placeholder={cat === "OTHERS" ? "Optional — defaults to Season 1" : "Season 1, Final Season…"}
                        className={inputCls}
                        aria-label="Season name"
                      />
                    </AdminField>
                    <AdminField label="Season Number (optional)">
                      <input
                        value={newSeasonNumber}
                        onChange={(e) => setNewSeasonNumber(e.target.value.replace(/\D/g, "").slice(0, 3))}
                        placeholder="Auto"
                        inputMode="numeric"
                        className={inputCls}
                        aria-label="Season number (optional)"
                      />
                    </AdminField>
                    <p className="col-span-2 text-[11px] leading-relaxed text-slate-500">
                      Custom season names are allowed (Final Season, Special Season…). Leave the number empty and the
                      next free season number is assigned automatically.
                      {cat === "OTHERS" &&
                        " For Others playlists the season name is optional too — leave everything empty and the video is filed under a clean Season 1."}
                    </p>
                  </div>
                )}
              </>
            )}
          </div>
        </section>

        {/* step 5 — episode number & title */}
        <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          {stepHead(5, "Episode Number & Title", /^\d+$/.test(epNumber.trim()) && Number(epNumber) >= 1)}
          <div className="mt-4 grid grid-cols-[110px_1fr] gap-3">
            <AdminField label="Episode No. *">
              <input
                value={epNumber}
                onChange={(e) => setEpNumber(e.target.value.replace(/\D/g, "").slice(0, 3))}
                inputMode="numeric"
                className={inputCls}
                aria-label="Episode number"
              />
            </AdminField>
            <AdminField label="Episode Title (optional)">
              <input
                value={epTitle}
                onChange={(e) => setEpTitle(e.target.value)}
                placeholder="e.g. The Awakening"
                className={inputCls}
                aria-label="Episode title"
              />
            </AdminField>
          </div>
          {activeSeason && (
            <p className="mt-2 text-xs text-slate-500">
              Adding to <strong className="text-slate-300">{seasonName(activeSeason)}</strong> — next free number is pre-filled.
              A number that already exists there is rejected, so episodes are never duplicated.
            </p>
          )}
        </section>

        {/* step 6 — video source + download URL */}
        <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          {stepHead(6, "Video Source & Download URL", !!vs.videoUrl.trim() || !!vs.embedUrl.trim())}
          <div className="mt-4">
            <VideoSourceEditor value={vs} onChange={setVs} title={epTitle || `Episode ${epNumber || "1"}`} isEpisode />
          </div>
        </section>
      </div>

      {/* step 7 — save */}
      <div className="sticky bottom-4 z-10 mt-6 rounded-2xl border border-white/10 bg-[#0b1120]/95 p-3 backdrop-blur">
        <div className="flex flex-wrap items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 text-[13px] font-bold text-white">
              <Film className="h-3.5 w-3.5 text-[#4ADE80]" /> Step 7 — Save the episode to the playlist
            </p>
            {justSaved && (
              <p className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#4ADE80]">
                <CheckCircle2 className="h-3.5 w-3.5 shrink-0" /> {justSaved}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onBack}
            className="h-10 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white"
          >
            Done
          </button>
          <button
            type="button"
            onClick={save}
            disabled={saving}
            className="inline-flex h-10 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadIcon className="h-4 w-4" />}
            Save Episode
          </button>
        </div>
      </div>
    </div>
  );
}
