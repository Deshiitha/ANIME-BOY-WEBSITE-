"use client";

/**
 * Admin "Video Source" editor: lets admins attach a video to a movie or an
 * individual episode in three ways —
 *   1. Upload a file (existing pipeline, object storage when configured)
 *   2. External direct HTTPS URL (MP4 / WebM / HLS .m3u8) or s3://bucket/key
 *      for private-bucket signed playback
 *   3. A trusted provider embed (YouTube / Vimeo / Dailymotion / Drive / …)
 * with a live "Preview Video" player and a storage probe that reports
 * Content-Type + byte-range support before publishing.
 */
import { useId, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import {
  CheckCircle2,
  CircleAlert,
  Cloud,
  Download,
  ExternalLink,
  FileText as FileIcon,
  Link2,
  ListVideo,
  Loader2,
  MonitorPlay,
  PlayCircle,
  Plus,
  Trash2,
  TriangleAlert,
  Upload as UploadIcon,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { parseCuePreview, subtitleFormatFromUrl, validateSubtitleText, type ParsedCue } from "@/lib/subtitles";
import {
  detectSharePage,
  looksLikeHls,
  toEmbedUrl,
  validateDirectMediaUrl,
  validateDownloadUrl,
  validateSubtitleDownloadUrl,
  validateSubtitleUrl,
} from "@/lib/media-validate";
import type { AltSource, MediaProbeResult, QualityTrack, SubtitleTrack, VideoSourceKind } from "@/lib/media-types";
import { VideoPlayer } from "./../VideoPlayer";
import { UploadWidget } from "./UploadWidget";

const inputCls =
  "h-10 w-full rounded-lg border border-white/10 bg-[#0b1120] px-3 text-sm text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50";

export type VideoSourceValue = {
  videoSource: VideoSourceKind;
  videoUrl: string;
  embedUrl: string;
  qualities: QualityTrack[];
  subtitles: SubtitleTrack[];
  altSources: AltSource[];
  videoThumb: string;
  downloadEnabled: boolean;
  downloadUrl: string;
  downloadQualities: QualityTrack[];
  subtitleDownloadEnabled: boolean;
  subtitleDownloads: SubtitleTrack[];
};

const SOURCE_TABS: { id: VideoSourceKind; label: string; icon: typeof UploadIcon }[] = [
  { id: "upload", label: "Upload file", icon: UploadIcon },
  { id: "external", label: "External URL", icon: Cloud },
  { id: "embed", label: "Provider embed", icon: MonitorPlay },
];

/** Quick label picks for backup sources — matches the watch-page switcher. */
const ALT_LABEL_CHIPS = ["Server 1", "Server 2", "Google Drive", "TeraBox"];

function newAltId(): string {
  return `alt-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

function Lbl({ children }: { children: React.ReactNode }) {
  return <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-400">{children}</span>;
}

/* ------------------------------- URL status ------------------------------- */

function UrlStatus({ url }: { url: string }) {
  if (!url.trim()) return null;
  if (/^s3:\/\//i.test(url.trim())) {
    return (
      <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-sky-300">
        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        Private-bucket object — the server mints a short-lived signed URL for each viewer. Credentials stay on the server.
      </p>
    );
  }
  const problem = validateDirectMediaUrl(url);
  if (!problem) {
    return (
      <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-[#4ADE80]">
        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        {looksLikeHls(url)
          ? "HLS playlist detected (.m3u8) — plays with adaptive streaming. Playlists, segments and keys must be publicly reachable."
          : "Direct media URL looks good. Use Preview to verify Content-Type and byte-range (seeking) support."}
      </p>
    );
  }
  if (problem.startsWith("warn:")) {
    return (
      <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-amber-300">
        <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        {problem.slice(5)}
      </p>
    );
  }
  if (problem.startsWith("share:")) {
    return (
      <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-red-300">
        <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        {problem.slice(6)}
      </p>
    );
  }
  return (
    <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-red-300">
      <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
      {problem}
    </p>
  );
}

/* ---------------------------- subtitle track rows -------------------------- */

/** Common subtitle languages — admins may also type any other ISO code. */
const SUB_LANG_OPTIONS: { code: string; name: string }[] = [
  { code: "si", name: "Sinhala · සිංහල" },
  { code: "en", name: "English" },
  { code: "ta", name: "Tamil · தமிழ்" },
  { code: "hi", name: "Hindi" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese" },
  { code: "ms", name: "Malay" },
  { code: "bn", name: "Bengali" },
];

/**
 * One-click language presets for the spec's named fields (Sinhala / English /
 * Japanese / Other) — each sets the row's display label + ISO code at once.
 */
const SUB_LANG_PRESETS: { code: string; label: string; name: string }[] = [
  { code: "si", label: "Sinhala", name: "සිංහල" },
  { code: "en", label: "English", name: "English" },
  { code: "ja", label: "Japanese", name: "日本語" },
  { code: "ta", label: "Tamil", name: "தமிழ்" },
];

function fileNameFromUrl(url: string): string {
  const clean = url.split(/[?#]/)[0];
  const base = clean.slice(clean.lastIndexOf("/") + 1);
  return decodeURIComponent(base || clean);
}

function SubtitleRows({
  rows,
  onChange,
  validate = validateSubtitleUrl,
  placeholder = "https://cdn.example.com/subs/si.vtt — or upload",
  emptyHint,
  /** Download mode: show a per-file “Test Download” verification button. */
  showTest = false,
  /** Playback mode: per-row availability switch + format badge + cue preview. */
  showEnabled = false,
}: {
  rows: SubtitleTrack[];
  onChange: (rows: SubtitleTrack[]) => void;
  validate?: (url: string) => string | null;
  placeholder?: string;
  emptyHint?: string;
  showTest?: boolean;
  showEnabled?: boolean;
}) {
  const [uploading, setUploading] = useState<number | null>(null);
  // Rows whose stored file has been parsed and verified after upload: url → cue count.
  const [verified, setVerified] = useState<Record<string, number>>({});
  const listId = useId();

  const setRow = (idx: number, patch: Partial<SubtitleTrack>) =>
    onChange(rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)));

  const uploadRow = (idx: number, file: File) => {
    if (!/\.vtt$|\.srt$/i.test(file.name)) {
      toast.error("Subtitles must be .vtt or .srt files");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Subtitle file is too large. Maximum 2 MB.");
      return;
    }
    setUploading(idx);
    (async () => {
      // 1) Validate BEFORE uploading — an invalid file is never uploaded and
      //    never marked as attached to the video.
      const text = await file.text();
      const v = validateSubtitleText(text);
      if (!v.ok) {
        toast.error(`Invalid subtitle file — not uploaded. ${v.error || ""}`.trim());
        return;
      }
      // 2) Upload to storage (object storage when configured, else /api/files).
      const form = new FormData();
      form.append("file", file);
      form.append("kind", "subtitle");
      const res = await api.upload<{ url: string; name?: string }>("/api/admin/upload", form, (p) => p).promise;
      // 3) Verify the stored file round-trips and still parses — only then is
      //    it attached to the row (and counted as uploaded).
      const check = await fetch(res.url, { credentials: "omit" });
      if (!check.ok) throw new Error(`The stored file could not be read back (HTTP ${check.status}).`);
      const stored = validateSubtitleText(await check.text());
      if (!stored.ok) throw new Error(`The stored file is not a usable subtitle: ${stored.error || ""}`);
      setVerified((prev) => ({ ...prev, [res.url]: stored.cueCount }));
      onChange(
        rows.map((r, i) =>
          i === idx
            ? {
                ...r,
                url: res.url,
                // Auto-fill the display label from the file name when empty.
                label: r.label || file.name.replace(/\.(srt|vtt)$/i, ""),
              }
            : r
        )
      );
      toast.success(`Subtitle uploaded & verified ✓ (${stored.cueCount} cues)`);
    })()
      .catch((e) => toast.error(e instanceof Error ? e.message : "Upload failed"))
      .finally(() => setUploading(null));
  };

  return (
    <div className="space-y-2">
      <datalist id={listId}>
        {SUB_LANG_OPTIONS.map((l) => (
          <option key={l.code} value={l.code}>
            {l.name}
          </option>
        ))}
      </datalist>
      {rows.map((row, idx) => {
        const problem = row.url ? validate(row.url) : null;
        const disabled = row.enabled === false;
        const cueCount = row.url ? verified[row.url] : undefined;
        return (
          <div
            key={idx}
            className={`rounded-xl border bg-[#0b1120] p-2 ${
              disabled ? "border-white/5 opacity-70" : "border-white/8"
            }`}
          >
            <div className="grid grid-cols-[110px_74px_1fr_auto] items-center gap-2">
            <input
              value={row.label}
              onChange={(e) => setRow(idx, { label: e.target.value })}
              placeholder="සිංහල"
              aria-label="Subtitle label"
              className="h-8 rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
            />
            <input
              value={row.lang}
              list={listId}
              onChange={(e) => setRow(idx, { lang: e.target.value.toLowerCase().trim() })}
              placeholder="si"
              aria-label="Subtitle language code (si / en / ta — or any other)"
              title="Language code: si, en, ja, ta — or any other ISO code"
              className="h-8 rounded-lg border border-white/10 bg-[#050816] px-1.5 text-xs text-white outline-none focus:border-[#22C55E]/50"
            />
            <div className="min-w-0">
              <input
                value={row.url}
                onChange={(e) => setRow(idx, { url: e.target.value })}
                placeholder={placeholder}
                aria-label="Subtitle URL"
                className="h-8 w-full rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
              />
              {problem && !problem.startsWith("warn:") && <p className="mt-0.5 text-[10px] text-red-300">{problem}</p>}
            </div>
            <div className="flex items-center gap-1">
              <label
                className="flex h-8 cursor-pointer items-center gap-1 rounded-lg border border-white/10 px-2 text-[11px] font-semibold text-slate-300 hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
                aria-label={`Upload subtitle file for row ${idx + 1}`}
              >
                {uploading === idx ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <UploadIcon className="h-3.5 w-3.5" />}
                <input
                  type="file"
                  accept=".vtt,.srt,text/vtt,application/x-subrip"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) uploadRow(idx, f);
                    e.target.value = "";
                  }}
                />
              </label>
              <button
                type="button"
                onClick={() => onChange(rows.filter((_, i) => i !== idx))}
                aria-label={`Remove subtitle row ${idx + 1}`}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
            </div>
            {/* language presets (Sinhala / English / Japanese / Tamil / Other) + file name */}
            <div className="mt-1.5 flex flex-wrap items-center gap-1">
              <span className="mr-1 text-[9px] font-black uppercase tracking-wider text-slate-500">Language</span>
              {SUB_LANG_PRESETS.map((p) => (
                <button
                  key={p.code}
                  type="button"
                  onClick={() => setRow(idx, { lang: p.code, label: p.name })}
                  title={`Set this track to ${p.label} (${p.code})`}
                  className={`rounded-full border px-2 py-0.5 text-[10px] font-bold transition-colors ${
                    row.lang === p.code
                      ? "border-[#22C55E] bg-[#22C55E]/15 text-[#4ADE80]"
                      : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
                  }`}
                >
                  {p.label}
                </button>
              ))}
              <span
                className={`rounded-full border px-2 py-0.5 text-[10px] font-bold transition-colors ${
                  row.lang && !SUB_LANG_PRESETS.some((p) => p.code === row.lang)
                    ? "border-[#22C55E] bg-[#22C55E]/15 text-[#4ADE80]"
                    : "border-white/10 bg-white/[0.04] text-slate-400"
                }`}
                title="Any other language — type the ISO code in the language field"
              >
                Other
              </span>
              {row.url && (
                <span className="ml-auto flex items-center gap-1.5 text-[10px] text-slate-500">
                  <FileIcon className="h-3 w-3" />
                  <span className="max-w-45 truncate" title={fileNameFromUrl(row.url)}>
                    {fileNameFromUrl(row.url)}
                  </span>
                  {typeof cueCount === "number" && (
                    <span className="rounded bg-[#22C55E]/15 px-1 py-0.5 text-[9px] font-bold text-[#4ADE80]">✓ {cueCount} cues</span>
                  )}
                </span>
              )}
            </div>
            {(showEnabled || showTest) && row.url && (
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {showEnabled && (
                  <>
                    <label
                      className={`inline-flex h-7 cursor-pointer items-center gap-1.5 rounded-full border px-2.5 text-[10px] font-bold ${
                        disabled
                          ? "border-white/10 bg-white/[0.04] text-slate-400"
                          : "border-[#22C55E]/40 bg-[#22C55E]/10 text-[#4ADE80]"
                      }`}
                      title="Disabled rows are hidden from viewers (CC menu) until re-enabled"
                    >
                      <input
                        type="checkbox"
                        checked={!disabled}
                        onChange={(e) => setRow(idx, { enabled: e.target.checked })}
                        className="h-3 w-3 accent-[#22C55E]"
                        aria-label={`Subtitle availability for row ${idx + 1}`}
                      />
                      {disabled ? "Disabled" : "Enabled"}
                    </label>
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wide text-slate-400">
                      {subtitleFormatFromUrl(row.url)}
                    </span>
                  </>
                )}
                {showTest && <TestDownloadButton url={row.url} compact />}
                {showEnabled && <PreviewSubButton url={row.url} />}
              </div>
            )}
          </div>
        );
      })}
      <button
        type="button"
        onClick={() => onChange([...rows, { label: "", lang: "si", url: "", enabled: true }])}
        className="inline-flex h-8 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-3 text-[11px] font-bold text-[#4ADE80] hover:bg-[#22C55E]/20"
      >
        <Plus className="h-3.5 w-3.5" /> Add subtitle track
      </button>
      <p className="text-[10px] leading-relaxed text-slate-500">
        {emptyHint ||
          "Multiple languages per video are supported — upload .srt or .vtt files (stored in cloud/server storage, never in the frontend) or paste direct URLs. Files are validated before an upload is accepted; SRT is converted to WebVTT during playback automatically."}
      </p>
    </div>
  );
}

/* ------------------------------ quality rows ------------------------------ */

function QualityRows({
  rows,
  onChange,
}: {
  rows: QualityTrack[];
  onChange: (rows: QualityTrack[]) => void;
}) {
  return (
    <div className="space-y-2">
      {rows.map((row, idx) => (
        <div key={idx} className="grid grid-cols-[90px_1fr_auto] items-center gap-2 rounded-xl border border-white/8 bg-[#0b1120] p-2">
          <input
            value={row.label}
            onChange={(e) => onChange(rows.map((r, i) => (i === idx ? { ...r, label: e.target.value } : r)))}
            placeholder="1080p"
            aria-label="Quality label"
            className="h-8 rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
          />
          <input
            value={row.url}
            onChange={(e) => onChange(rows.map((r, i) => (i === idx ? { ...r, url: e.target.value } : r)))}
            placeholder="https://cdn.example.com/video-1080.mp4"
            aria-label="Quality URL"
            className="h-8 w-full rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
          />
          <button
            type="button"
            onClick={() => onChange(rows.filter((_, i) => i !== idx))}
            aria-label={`Remove quality row ${idx + 1}`}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
      <button
        type="button"
        onClick={() => onChange([...rows, { label: "", url: "" }])}
        className="inline-flex h-8 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-3 text-[11px] font-bold text-[#4ADE80] hover:bg-[#22C55E]/20"
      >
        <Plus className="h-3.5 w-3.5" /> Add quality variant
      </button>
      <p className="text-[10px] leading-relaxed text-slate-500">
        Optional. Use for separately encoded files (e.g. 480p / 720p / 1080p). HLS streams pick qualities automatically.
      </p>
    </div>
  );
}

/* ------------------------------ preview dialog ----------------------------- */

type PreviewState = {
  source: Parameters<typeof VideoPlayer>[0]["source"];
  probe?: (MediaProbeResult & { verdict?: string }) | null;
  label: string;
};

function PreviewDialog({ state, onClose }: { state: PreviewState; onClose: () => void }) {
  const probe = state.probe;
  // Portal to <body> so transformed page containers can't become the fixed
  // element's containing block (which would push the dialog off-screen).
  if (typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center overflow-y-auto bg-black/80 p-4" role="dialog" aria-modal="true" aria-label="Preview video">
      <div className="w-full max-w-3xl rounded-2xl border border-white/10 bg-[#0b1120] p-4 shadow-2xl">
        <div className="mb-3 flex items-center gap-2">
          <PlayCircle className="h-5 w-5 text-[#4ADE80]" />
          <h3 className="flex-1 truncate font-black text-white">Preview — {state.label}</h3>
          <button onClick={onClose} aria-label="Close preview" className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-300 hover:bg-white/10 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="relative overflow-hidden rounded-xl bg-black" style={{ aspectRatio: "16/9" }}>
          <div className="absolute inset-0">
            <VideoPlayer source={state.source} title={state.label} testId="preview-player" />
          </div>
        </div>

        {probe && (
          <div className="mt-3 space-y-1 rounded-xl border border-white/8 bg-white/[0.02] p-3 text-xs">
            <p className={`font-bold ${probe.ok && !probe.isHtml ? "text-[#4ADE80]" : "text-red-300"}`}>
              {probe.ok && !probe.isHtml ? "✓ URL reachable" : "✗ URL problem"} {probe.status ? `(HTTP ${probe.status})` : ""}
            </p>
            {probe.contentType && <p className="text-slate-400">Content-Type: <span className="font-mono text-slate-300">{probe.contentType}</span></p>}
            {probe.acceptRanges && <p className="text-slate-400">Byte-range: <span className="font-mono text-slate-300">{probe.acceptRanges}</span>{probe.acceptRanges === "bytes" ? " — seeking supported ✓" : " — seeking may be limited"}</p>}
            {probe.contentLength && <p className="text-slate-400">Size: <span className="font-mono text-slate-300">{(Number(probe.contentLength) / 1024 / 1024).toFixed(1)} MB</span></p>}
            {probe.verdict && <p className="text-slate-300">{probe.verdict}</p>}
            {probe.error && <p className="text-red-300">{probe.error}</p>}
          </div>
        )}
        <p className="mt-2 text-[11px] text-slate-500">
          Playback streams directly from the external host — nothing is copied to this website's storage.
        </p>
      </div>
    </div>,
    document.body
  );
}

/* ------------------------------ download rows ------------------------------ */

/** Per-quality downloadable files (MP4/WebM — HLS is rejected for downloads). */
function DownloadQualityRows({
  rows,
  onChange,
}: {
  rows: QualityTrack[];
  onChange: (rows: QualityTrack[]) => void;
}) {
  return (
    <div className="space-y-2">
      {rows.map((row, idx) => {
        const problem = row.url ? validateDownloadUrl(row.url) : null;
        return (
          <div key={idx} className="grid grid-cols-[90px_1fr_auto] items-start gap-2 rounded-xl border border-white/8 bg-[#0b1120] p-2">
            <input
              value={row.label}
              onChange={(e) => onChange(rows.map((r, i) => (i === idx ? { ...r, label: e.target.value } : r)))}
              placeholder="1080p"
              aria-label="Download quality label"
              className="h-8 rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
            />
            <div className="min-w-0">
              <input
                value={row.url}
                onChange={(e) => onChange(rows.map((r, i) => (i === idx ? { ...r, url: e.target.value } : r)))}
                placeholder="https://cdn.example.com/video-1080.mp4  ·  s3://bucket/video-1080.mp4"
                aria-label="Download quality URL"
                className="h-8 w-full rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
              />
              {problem && !problem.startsWith("warn:") && <p className="mt-0.5 text-[10px] text-red-300">{problem}</p>}
            </div>
            <button
              type="button"
              onClick={() => onChange(rows.filter((_, i) => i !== idx))}
              aria-label={`Remove download quality row ${idx + 1}`}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      })}
      <button
        type="button"
        onClick={() => onChange([...rows, { label: "", url: "" }])}
        className="inline-flex h-8 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-3 text-[11px] font-bold text-[#4ADE80] hover:bg-[#22C55E]/20"
      >
        <Plus className="h-3.5 w-3.5" /> Add quality download
      </button>
      <p className="text-[10px] leading-relaxed text-slate-500">
        Optional separate files per quality (480p / 720p / 1080p…). Each must be a single downloadable file —
        .m3u8 streams and provider embeds cannot be downloaded. Private buckets: use s3://bucket/key.
      </p>
    </div>
  );
}

/* ------------------------------ cue preview -------------------------------- */

/**
 * Admin "Preview" — fetches the subtitle file in the browser, converts SRT →
 * WebVTT exactly like the player does, and shows the first cues with timings.
 * Honest about failures (bad URL, CORS, unparseable file).
 */
function PreviewSubButton({ url }: { url: string }) {
  const [busy, setBusy] = useState(false);
  const [cues, setCues] = useState<ParsedCue[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const clean = url.trim();

  if (!clean) return null;

  const run = async () => {
    setBusy(true);
    setErr(null);
    setCues(null);
    try {
      const res = await fetch(clean, { credentials: "omit" });
      if (!res.ok) throw new Error(`The file could not be fetched (HTTP ${res.status}).`);
      const text = await res.text();
      const parsed = parseCuePreview(text, 3);
      if (!parsed.length) throw new Error("No cues could be parsed — is this a valid SRT or VTT file?");
      setCues(parsed);
    } catch (e) {
      setErr(
        e instanceof Error && /Failed to fetch|NetworkError/i.test(e.message)
          ? "The file could not be fetched from the browser (CORS or network). Uploaded /api/files/… URLs always work."
          : e instanceof Error
            ? e.message
            : "Preview failed"
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <button
        type="button"
        onClick={run}
        disabled={busy}
        className="inline-flex h-7 items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 text-[10px] font-bold text-slate-200 transition-colors hover:border-[#22C55E]/40 hover:text-[#4ADE80] disabled:opacity-50"
        aria-label={`Preview subtitle ${clean}`}
      >
        {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <PlayCircle className="h-3 w-3" />}
        Preview
      </button>
      {(cues || err) && (
        <div
          className={`mt-2 space-y-1.5 rounded-xl border p-3 text-[11px] leading-relaxed ${
            err ? "border-red-500/25 bg-red-500/[0.06] text-red-300" : "border-white/10 bg-white/[0.03]"
          }`}
          role="status"
        >
          {err ? (
            <p>{err}</p>
          ) : (
            cues?.map((c, i) => (
              <div key={i}>
                <span className="mr-2 font-bold tabular-nums text-[#4ADE80]">
                  {c.start} → {c.end}
                </span>
                <span className="text-slate-200">{c.lines.join(" / ")}</span>
              </div>
            ))
          )}
          {!err && <p className="text-[10px] text-slate-500">First {cues?.length} cue(s) — parsed exactly like the player parses them.</p>}
        </div>
      )}
    </div>
  );
}

/* ------------------------------ test download ------------------------------ */

type TestDownloadResult = {
  ok: boolean;
  kind?: string;
  status?: number;
  contentType?: string;
  sizeLabel?: string;
  contentDisposition?: string;
  provider?: string;
  downloadable?: "forced" | "fallback";
  verdict?: string;
  error?: string;
};

/**
 * Admin "Test Download" — server-verified proof that a configured download or
 * subtitle file is accessible and downloadable. Handles every storage kind the
 * download system accepts: site uploads (/api/files/…), private buckets
 * (s3://bucket/key) and external https links (with provider-aware verdicts for
 * Google Drive and TeraBox). Never claims success without a server check.
 */
function TestDownloadButton({ url, compact }: { url: string; compact?: boolean }) {
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<TestDownloadResult | null>(null);
  const clean = url.trim();

  if (!clean) return null;

  const run = async () => {
    setBusy(true);
    setResult(null);
    try {
      const res = await api.post<TestDownloadResult>("/api/admin/media/test-download", { url: clean });
      setResult(res);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Test failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={compact ? "" : "mt-2"}>
      <button
        type="button"
        onClick={run}
        disabled={busy}
        className={`inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] font-bold text-slate-200 transition-colors hover:border-[#22C55E]/40 hover:text-[#4ADE80] disabled:opacity-50 ${
          compact ? "h-7 px-2.5 text-[10px]" : "h-8 px-3 text-[11px]"
        }`}
        aria-label={`Test download for ${clean}`}
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Link2 className="h-3.5 w-3.5" />}
        Test Download
      </button>
      {result && (
        <div
          className={`mt-2 space-y-1 rounded-xl border p-3 text-[11px] leading-relaxed ${
            result.ok ? "border-[#22C55E]/25 bg-[#22C55E]/[0.06]" : "border-red-500/25 bg-red-500/[0.06]"
          }`}
          role="status"
        >
          <p className={`font-bold ${result.ok ? "text-[#4ADE80]" : "text-red-300"}`}>
            {result.ok ? "✓ Download verified" : "✗ Download problem"}
            {result.status ? ` (HTTP ${result.status})` : ""}
          </p>
          <p className={result.ok ? "text-slate-200" : "text-red-300"}>{result.ok ? result.verdict : result.error}</p>
          {result.ok && result.contentType && (
            <p className="text-slate-400">
              Content-Type: <span className="font-mono text-slate-300">{result.contentType}</span>
            </p>
          )}
          {result.ok && result.sizeLabel && (
            <p className="text-slate-400">
              Size: <span className="font-mono text-slate-300">{result.sizeLabel}</span>
              {result.downloadable === "forced" ? " · forced download ✓" : " · open-link fallback"}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------- test video -------------------------------- */

type TestSourceResult = {
  ok: boolean;
  playableInSite: boolean;
  provider: string;
  sourceType: string;
  compatibility: string;
  embedSupport: string;
  errorDetails: string | null;
  recommendedFix: string | null;
  embedUrl?: string | null;
  externalFallback?: string | null;
  fallbackAvailable?: boolean;
};

/**
 * Admin "Test Video Source" — server-verified playback report with six fields:
 * Video Provider · Source Type · Playback Compatibility · Embed Support ·
 * Error Details · Recommended Fix.
 *
 * A green "plays inside ANIME BOY" verdict is shown ONLY when the server
 * actually verified browser playback (official embed, probe-confirmed direct
 * stream, or signed private-bucket object). TeraBox share links are reported
 * honestly: valid link → honest fallback; in-site playback only via the
 * admin's separate authorized streaming URL (also verified here).
 */
function TestSourceButton({
  url,
  directUrl,
  provider,
}: {
  url: string;
  directUrl?: string;
  provider: string | null;
}) {
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<TestSourceResult | null>(null);

  const target = (url || directUrl || "").trim();
  if (!target) return null;

  const run = async () => {
    setBusy(true);
    setResult(null);
    try {
      const res = await api.post<TestSourceResult>("/api/admin/media/test-source", {
        url: url.trim(),
        directUrl: (directUrl || "").trim(),
      });
      setResult(res);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Test failed");
    } finally {
      setBusy(false);
    }
  };

  const verified = !!result?.playableInSite;

  return (
    <div>
      <button
        type="button"
        onClick={run}
        disabled={busy}
        className="inline-flex h-8 items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 text-[11px] font-bold text-slate-200 transition-colors hover:border-[#22C55E]/40 hover:text-[#4ADE80] disabled:opacity-50"
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
        Test Video Source
      </button>
      <p className="mt-1 text-[10px] text-slate-500">
        Server-verified check — a “plays inside the site” verdict is shown only after playback compatibility is confirmed.
      </p>
      {result && (
        <div
          className={`mt-2 space-y-1.5 rounded-xl border p-3 text-[11px] leading-relaxed ${
            verified
              ? "border-[#22C55E]/25 bg-[#22C55E]/[0.06]"
              : result.ok || result.fallbackAvailable
                ? "border-amber-400/25 bg-amber-400/[0.06]"
                : "border-red-500/25 bg-red-500/[0.06]"
          }`}
        >
          <p
            className={`font-bold ${
              verified ? "text-[#4ADE80]" : result.ok || result.fallbackAvailable ? "text-amber-300" : "text-red-300"
            }`}
          >
            {verified
              ? "✓ Plays inside ANIME BOY — verified"
              : result.fallbackAvailable
                ? "△ Valid source — falls back to “Watch on provider”"
                : result.ok
                  ? "△ Saved, but NOT playable inside the site"
                  : "✗ Playback problem"}
          </p>
          <dl className="grid gap-x-4 gap-y-1 sm:grid-cols-[130px_1fr]">
            <dt className="font-bold text-slate-400">Video Provider</dt>
            <dd className="text-slate-200">{result.provider}</dd>
            <dt className="font-bold text-slate-400">Source Type</dt>
            <dd className="text-slate-200">{result.sourceType}</dd>
            <dt className="font-bold text-slate-400">Playback Compatibility</dt>
            <dd className="text-slate-200">{result.compatibility}</dd>
            <dt className="font-bold text-slate-400">Embed Support</dt>
            <dd className="text-slate-200">{result.embedSupport}</dd>
            {result.errorDetails && (
              <>
                <dt className="font-bold text-slate-400">Error Details</dt>
                <dd className="text-red-300">{result.errorDetails}</dd>
              </>
            )}
            {result.recommendedFix && (
              <>
                <dt className="font-bold text-slate-400">Recommended Fix</dt>
                <dd className="text-sky-300">{result.recommendedFix}</dd>
              </>
            )}
          </dl>
          {result.embedUrl && (
            <p className="text-slate-500">
              Embed URL: <span className="break-all font-mono text-slate-400">{result.embedUrl}</span>
            </p>
          )}
        </div>
      )}
      {provider === null && target && !busy && (
        <p className="mt-1.5 text-[10px] text-amber-300">
          Provider not recognised yet — Test Video Source needs a valid YouTube / Vimeo / Dailymotion / Google Drive / Streamable / TeraBox link or a direct media URL.
        </p>
      )}
    </div>
  );
}

/* --------------------------- backup/alt sources ---------------------------- */

/**
 * Admin editor for additional/backup playback sources ("Server 2", Google
 * Drive, TeraBox share link, direct MP4/HLS backup…). Each row is one source
 * with its own Test button; every row is validated server-side on save.
 * A TeraBox row is stored as a provider entry and always resolves to the
 * honest "Watch on TeraBox" fallback — it is never treated as a stream.
 */
function AltSourcesSection({
  value,
  onChange,
}: {
  value: VideoSourceValue;
  onChange: (v: VideoSourceValue) => void;
}) {
  const rows = value.altSources;

  const update = (idx: number, patch: Partial<AltSource>) =>
    onChange({ ...value, altSources: rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)) });

  const addRow = () =>
    onChange({
      ...value,
      altSources: [
        ...rows,
        { id: newAltId(), label: `Server ${rows.length + 1}`, sourceType: "external", url: "", embedUrl: "", provider: null },
      ],
    });

  const removeRow = (idx: number) =>
    onChange({ ...value, altSources: rows.filter((_, i) => i !== idx) });

  return (
    <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5" aria-label="Backup video sources">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="flex items-center gap-2 font-black text-white">
          <ListVideo className="h-4 w-4 text-[#4ADE80]" /> Backup / additional sources
        </h3>
        <span className="text-[11px] text-slate-500">
          — visitors pick these under the player (Server 1 · Server 2 · Google Drive · TeraBox…)
        </span>
      </div>

      {rows.length === 0 && (
        <p className="mt-3 rounded-xl border border-white/8 bg-[#0b1120] p-3 text-[11px] leading-relaxed text-slate-400">
          The main source above is “Server 1”. Add backup sources so visitors can switch when one server is slow or
          blocked — a direct MP4/HLS URL, a Google Drive embed, or a TeraBox share link (TeraBox opens on terabox.com;
          pair it with a playable source to stream inside the site).
        </p>
      )}

      <div className="mt-3 space-y-3">
        {rows.map((row, idx) => {
          const isEmbed = row.sourceType === "embed";
          const embedCheck = isEmbed && row.embedUrl ? toEmbedUrl(row.embedUrl) : null;
          const embedOk = embedCheck && "embedUrl" in embedCheck ? embedCheck : null;
          const embedErr = embedCheck && "error" in embedCheck ? embedCheck.error : null;
          const directProblem = !isEmbed && row.url ? validateDirectMediaUrl(row.url) : null;

          return (
            <div key={row.id || idx} className="rounded-xl border border-white/8 bg-[#0b1120] p-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-md bg-white/8 px-2 py-1 text-[10px] font-black uppercase tracking-wide text-slate-300">
                  Backup {idx + 1}
                </span>
                <input
                  value={row.label}
                  onChange={(e) => update(idx, { label: e.target.value })}
                  placeholder="Server 2 / Google Drive / TeraBox"
                  aria-label={`Backup source ${idx + 1} label`}
                  className="h-8 w-44 rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
                />
                <div className="flex flex-wrap gap-1">
                  {ALT_LABEL_CHIPS.map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      onClick={() =>
                        update(idx, {
                          label: chip,
                          ...(chip === "Google Drive" ? { sourceType: "embed" as const } : {}),
                          ...(chip === "TeraBox" ? { sourceType: "embed" as const } : {}),
                        })
                      }
                      className={`rounded-full border px-2 py-0.5 text-[10px] font-bold transition-colors ${
                        row.label === chip
                          ? "border-[#22C55E]/60 bg-[#22C55E]/15 text-[#4ADE80]"
                          : "border-white/10 text-slate-400 hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
                      }`}
                    >
                      {chip}
                    </button>
                  ))}
                </div>
                <div className="flex-1" />
                <button
                  type="button"
                  onClick={() => removeRow(idx)}
                  aria-label={`Remove backup source ${idx + 1}`}
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="mt-2.5 grid gap-2 sm:grid-cols-[150px_1fr]">
                <select
                  value={row.sourceType}
                  onChange={(e) =>
                    update(idx, {
                      sourceType: e.target.value === "embed" ? "embed" : "external",
                      // keep both fields; the resolver picks per type
                    })
                  }
                  aria-label={`Backup source ${idx + 1} type`}
                  className="h-9 rounded-lg border border-white/10 bg-[#050816] px-2 text-xs text-white outline-none focus:border-[#22C55E]/50"
                >
                  <option value="external">Direct URL (MP4/HLS/DASH/s3)</option>
                  <option value="embed">Provider embed / share link</option>
                </select>
                <input
                  value={(isEmbed ? row.embedUrl : row.url) || ""}
                  onChange={(e) => update(idx, isEmbed ? { embedUrl: e.target.value } : { url: e.target.value })}
                  placeholder={
                    isEmbed
                      ? "https://drive.google.com/file/d/…/view · https://terabox.com/s/…"
                      : "https://cdn.example.com/backup.mp4 · https://cdn.example.com/stream.m3u8 · s3://bucket/video.mp4"
                  }
                  aria-label={`Backup source ${idx + 1} URL`}
                  spellCheck={false}
                  className="h-9 w-full rounded-lg border border-white/10 bg-[#050816] px-2.5 text-xs text-white outline-none focus:border-[#22C55E]/50"
                />
              </div>

              {isEmbed && (
                <>
                  {embedOk && (
                    <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[#4ADE80]">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      {embedOk.provider === "terabox"
                        ? "TeraBox link detected — visitors get a “Watch on TeraBox” button (pair it with a playable source above/below for in-site playback)."
                        : `${embedOk.provider} embed ready — plays inside the site player.`}
                    </p>
                  )}
                  {embedErr && <p className="mt-1.5 text-[11px] text-red-300">{embedErr}</p>}
                </>
              )}
              {!isEmbed && directProblem && !directProblem.startsWith("warn:") && (
                <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-red-300">
                  <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {directProblem}
                </p>
              )}
              {!isEmbed && directProblem?.startsWith("warn:") && (
                <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-amber-300">
                  <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {directProblem.slice(5)}
                </p>
              )}

              <div className="mt-2">
                <TestSourceButton
                  url={isEmbed ? row.embedUrl || "" : row.url || ""}
                  directUrl={!isEmbed ? undefined : value.videoUrl}
                  provider={embedOk ? embedOk.provider : isEmbed ? null : "direct"}
                />
              </div>
            </div>
          );
        })}
      </div>

      <button
        type="button"
        onClick={addRow}
        className="mt-3 inline-flex h-9 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-4 text-xs font-bold text-[#4ADE80] hover:bg-[#22C55E]/20"
      >
        <Plus className="h-3.5 w-3.5" /> Add backup source
      </button>
    </section>
  );
}

/* ----------------------------- downloads section --------------------------- */

function DownloadsSection({
  value,
  onChange,
  title,
}: {
  value: VideoSourceValue;
  onChange: (v: VideoSourceValue) => void;
  title: string;
}) {
  const set = (patch: Partial<VideoSourceValue>) => onChange({ ...value, ...patch });

  // "Reuse the playback URL" is only offered when the playback URL is itself a
  // downloadable file: direct MP4/WebM/MKV/MOV, a site upload, or an s3://
  // object — never an HLS playlist or a provider embed.
  const playbackReusable = useMemo(() => {
    if (value.videoSource === "embed") return false;
    const url = value.videoUrl.trim();
    if (!url) return false;
    if (/^s3:\/\//i.test(url)) return true;
    if (url.startsWith("/api/files/")) return !/\.m3u8(\?|$)/i.test(url);
    if (!/^https:\/\//i.test(url)) return false;
    return /\.(mp4|m4v|webm|mkv|mov|ogv|ogg)(\?|$)/i.test(url);
  }, [value.videoSource, value.videoUrl]);

  const reusePlayback = () => {
    set({ downloadEnabled: true, downloadUrl: value.videoUrl.trim() });
    toast.success("Playback URL copied to the download URL");
  };

  const mainProblem = value.downloadUrl ? validateDownloadUrl(value.downloadUrl) : null;

  return (
    <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5" aria-label="Downloads">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="flex items-center gap-2 font-black text-white">
          <Download className="h-4 w-4 text-[#4ADE80]" /> Downloads
        </h3>
        <span className="text-[11px] text-slate-500">— separate from playback; visitors see download buttons below the player</span>
      </div>

      {/* video downloads */}
      <label className="mt-4 flex items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
        <input
          type="checkbox"
          checked={value.downloadEnabled}
          onChange={(e) => set({ downloadEnabled: e.target.checked })}
          className="h-4 w-4 accent-[#22C55E]"
        />
        <span className="text-sm font-semibold text-slate-200">
          Enable Video Download <span className="block text-[11px] font-normal text-slate-500">පිටපත් බාගැනීම — “වීඩියෝව බාගන්න” button on the watch page</span>
        </span>
      </label>

      {value.downloadEnabled && (
        <div className="mt-3 space-y-3">
          <div>
            <Lbl>Video download URL (MP4 / WebM file, s3://bucket/key or site upload)</Lbl>
            <input
              value={value.downloadUrl}
              onChange={(e) => set({ downloadUrl: e.target.value })}
              placeholder="https://cdn.example.com/movie.mp4  ·  s3://bucket/movie.mp4"
              className={inputCls}
              aria-label="Video download URL"
              spellCheck={false}
            />
            {mainProblem && !mainProblem.startsWith("warn:") && (
              <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-red-300">
                <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {mainProblem}
              </p>
            )}
            {mainProblem?.startsWith("warn:") && (
              <p className="mt-1.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-amber-300">
                <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {mainProblem.slice(5)}
              </p>
            )}
            {!mainProblem && !value.downloadUrl && (
              <p className="mt-1.5 text-[11px] leading-relaxed text-slate-500">
                A single downloadable file (MP4 / WebM). HLS playlists, DASH manifests and provider embeds are not
                downloadable files — upload or link a separate MP4 for the download button. Google Drive’s official
                “export=download” link is accepted, and a TeraBox share page may be saved (the download then
                continues on TeraBox’s official page).
              </p>
            )}
            <TestDownloadButton url={value.downloadUrl} />
          </div>

          {playbackReusable && (
            <div className="rounded-xl border border-white/8 bg-[#0b1120] p-3">
              <button
                type="button"
                onClick={reusePlayback}
                className="inline-flex h-8 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-3 text-[11px] font-bold text-[#4ADE80] hover:bg-[#22C55E]/20"
              >
                <Link2 className="h-3.5 w-3.5" /> Reuse playback URL as download URL
              </button>
              <p className="mt-1.5 text-[10px] leading-relaxed text-slate-500">
                The playback source is a direct file, so it can double as the download. Hosts that send
                Content-Disposition: attachment save the file instantly — use “Test Download” to confirm yours does;
                otherwise visitors get the “Open Download Link” fallback.
              </p>
            </div>
          )}

          <div>
            <Lbl>Per-quality download files (optional)</Lbl>
            <DownloadQualityRows rows={value.downloadQualities} onChange={(downloadQualities) => set({ downloadQualities })} />
          </div>
        </div>
      )}

      {/* subtitle downloads */}
      <label className="mt-4 flex items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
        <input
          type="checkbox"
          checked={value.subtitleDownloadEnabled}
          onChange={(e) => set({ subtitleDownloadEnabled: e.target.checked })}
          className="h-4 w-4 accent-[#22C55E]"
        />
        <span className="text-sm font-semibold text-slate-200">
          Enable Subtitle Download <span className="block text-[11px] font-normal text-slate-500">“උපසිරැසි බාගන්න” button — SRT / VTT files with language labels</span>
        </span>
      </label>

      {value.subtitleDownloadEnabled && (
        <div className="mt-3">
          <Lbl>Subtitle download files (SRT / VTT)</Lbl>
          <SubtitleRows
            rows={value.subtitleDownloads}
            onChange={(subtitleDownloads) => set({ subtitleDownloads })}
            validate={validateSubtitleDownloadUrl}
            placeholder="https://cdn.example.com/subs/si.srt — or upload"
            emptyHint="Add one row per language — Sinhala (si) and English (en) at minimum. SRT and VTT are both supported; upload a file or paste an external URL, then use Test Download to verify it."
            showTest
          />
          {!value.subtitleDownloads.length && (
            <p className="mt-1.5 rounded-lg border border-[#22C55E]/25 bg-[#22C55E]/[0.06] px-2.5 py-1.5 text-[10px] leading-relaxed text-[#4ADE80]">
              No separate files here — the subtitle tracks configured for playback are offered for download automatically, so
              visitors always download the exact same file that plays over the video.
            </p>
          )}
        </div>
      )}

      <div className="mt-4 rounded-xl border border-white/8 bg-[#0b1120] p-3 text-[11px] leading-relaxed text-slate-400">
        <p className="font-bold text-slate-300">How downloads work:</p>
        <ul className="mt-1 list-disc space-y-0.5 pl-4">
          <li>Files download straight from your storage host / CDN — nothing is copied to or proxied by this website.</li>
          <li>Private buckets (s3://): the server checks access, then signs a short-lived download URL — credentials never leave the server.</li>
          <li>Playback and download URLs are fully independent — editing one never changes the other.</li>
          <li>These settings apply to “{title}” only.</li>
        </ul>
      </div>
    </section>
  );
}

/* ------------------------------ main editor -------------------------------- */

export function VideoSourceEditor({
  value,
  onChange,
  title,
  isEpisode = false,
}: {
  value: VideoSourceValue;
  onChange: (v: VideoSourceValue) => void;
  title: string;
  isEpisode?: boolean;
}) {
  const [preview, setPreview] = useState<PreviewState | null>(null);
  const [probing, setProbing] = useState(false);
  const set = (patch: Partial<VideoSourceValue>) => onChange({ ...value, ...patch });

  const embedDetected = useMemo(() => {
    if (value.videoSource !== "embed" || !value.embedUrl.trim()) return null;
    const res = toEmbedUrl(value.embedUrl);
    return "embedUrl" in res ? res : null;
  }, [value.videoSource, value.embedUrl]);

  const canPreview = useMemo(() => {
    if (value.videoSource === "upload") return !!value.videoUrl.trim();
    if (value.videoSource === "external") return !!value.videoUrl.trim();
    return !!embedDetected;
  }, [value, embedDetected]);

  const openPreview = async () => {
    if (!canPreview) {
      toast.error("Add a video source first");
      return;
    }
    if (value.videoSource === "embed" && embedDetected) {
      // No-iframe providers (TeraBox) preview as the external-page card,
      // never as a broken iframe.
      if (embedDetected.provider === "terabox") {
        setPreview({
          source: {
            kind: "external_page",
            provider: "terabox",
            providerLabel: "TeraBox",
            pageUrl: embedDetected.embedUrl,
            note: "Visitors see this card on the watch page and continue on TeraBox — playback and downloads follow TeraBox's own player and permissions.",
          },
          label: title,
        });
        return;
      }
      setPreview({
        source: { kind: "embed", provider: embedDetected.provider, providerLabel: embedDetected.provider, embedUrl: embedDetected.embedUrl },
        label: title,
      });
      return;
    }
    const url = value.videoUrl.trim();
    setProbing(true);
    let probe: PreviewState["probe"] = null;
    if (/^https?:\/\//i.test(url)) {
      try {
        probe = await api.post<MediaProbeResult & { verdict?: string }>("/api/admin/media/probe", { url });
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "URL check failed");
        setProbing(false);
        return;
      }
    }
    setProbing(false);
    if (/^s3:\/\//i.test(url)) {
      // Private bucket: mint a one-off signed URL for the preview player.
      try {
        const signed = await api.post<{ url: string; kind: "mp4" | "hls" }>("/api/admin/media/sign", { url });
        setPreview({
          source: { kind: signed.kind, url: signed.url },
          label: title,
          probe: { ok: true, verdict: `Signed preview URL generated (valid for a limited time). Kind: ${signed.kind}.` },
        });
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Could not sign the object for preview");
      }
      return;
    }
    setPreview({
      source: { kind: looksLikeHls(url) ? "hls" : "mp4", url, poster: value.videoThumb || undefined },
      label: title,
      probe,
    });
  };

  const switchToEmbed = () => {
    const res = toEmbedUrl(value.videoUrl);
    if ("embedUrl" in res) {
      onChange({ ...value, videoSource: "embed", embedUrl: res.embedUrl });
      toast.success(`Converted to ${res.provider} embed`);
    } else {
      toast.error(res.error);
    }
  };

  const isShareLink =
    value.videoSource === "external" &&
    !!value.videoUrl.trim() &&
    detectSharePage(value.videoUrl.trim())?.startsWith("share:") === true &&
    /^s3:\/\//i.test(value.videoUrl) === false;

  return (
    <>
      <section className="rounded-2xl border border-white/8 bg-white/[0.02] p-5" aria-label="Video source">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="flex items-center gap-2 font-black text-white">
          <MonitorPlay className="h-4 w-4 text-[#4ADE80]" /> Video Source
        </h3>
        <span className="text-[11px] text-slate-500">— where the video streams from</span>
        <div className="flex-1" />
        <button
          type="button"
          onClick={openPreview}
          disabled={!canPreview || probing}
          className="inline-flex h-9 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-4 text-xs font-bold text-[#4ADE80] transition-colors hover:bg-[#22C55E]/20 disabled:opacity-40"
        >
          {probing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
          Preview Video
        </button>
      </div>

      {/* source type selector */}
      <div className="mt-4 grid grid-cols-3 gap-2" role="tablist" aria-label="Video source type">
        {SOURCE_TABS.map((t) => {
          const active = value.videoSource === t.id;
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => set({ videoSource: t.id })}
              className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-bold transition-colors ${
                active
                  ? "border-[#22C55E] bg-[#22C55E]/15 text-[#4ADE80]"
                  : "border-white/10 bg-[#0b1120] text-slate-300 hover:border-[#22C55E]/40"
              }`}
            >
              <Icon className="h-4 w-4" /> {t.label}
            </button>
          );
        })}
      </div>

      {/* upload */}
      {value.videoSource === "upload" && (
        <div className="mt-4 space-y-4">
          <UploadWidget
            kind="video"
            label="Video file"
            accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-matroska"
            value={value.videoUrl}
            onChange={(url) => set({ videoUrl: url })}
            hint="MP4 / WebM / MOV / MKV — streamed with range support"
          />
          <div>
            <Lbl>Subtitle tracks (optional)</Lbl>
            <SubtitleRows rows={value.subtitles} onChange={(subtitles) => set({ subtitles })} showEnabled showTest />
          </div>
        </div>
      )}

      {/* external URL */}
      {value.videoSource === "external" && (
        <div className="mt-4 space-y-4">
          <div>
            <Lbl>Direct video URL (HTTPS MP4 / WebM or HLS .m3u8)</Lbl>
            <input
              value={value.videoUrl}
              onChange={(e) => set({ videoUrl: e.target.value })}
              placeholder="https://cdn.example.com/movie.mp4  ·  https://cdn.example.com/stream.m3u8  ·  s3://bucket/video.mp4"
              className={inputCls}
              aria-label="External video URL"
              spellCheck={false}
            />
            <UrlStatus url={value.videoUrl} />
            {isShareLink && (
              <button
                type="button"
                onClick={switchToEmbed}
                className="mt-2 inline-flex h-8 items-center gap-1.5 rounded-full bg-[#F59E0B] px-3 text-[11px] font-bold text-black hover:bg-[#fbbf24]"
              >
                <ExternalLink className="h-3.5 w-3.5" /> Convert to provider embed
              </button>
            )}
            {!isShareLink && !!value.videoUrl.trim() && (
              <div className="mt-2">
                <TestSourceButton url={value.videoUrl} provider="direct" />
              </div>
            )}
          </div>

          <div>
            <Lbl>Quality variants (optional)</Lbl>
            <QualityRows rows={value.qualities} onChange={(qualities) => set({ qualities })} />
          </div>
          <div>
            <Lbl>Subtitle tracks (optional)</Lbl>
            <SubtitleRows rows={value.subtitles} onChange={(subtitles) => set({ subtitles })} showEnabled showTest />
          </div>

          <div className="rounded-xl border border-white/8 bg-[#0b1120] p-3 text-[11px] leading-relaxed text-slate-400">
            <p className="font-bold text-slate-300">Cloud storage requirements for direct playback:</p>
            <ul className="mt-1 list-disc space-y-0.5 pl-4">
              <li>HTTPS URL with the correct Content-Type (video/mp4, application/vnd.apple.mpegurl…)</li>
              <li>Byte-range request support so seeking works (S3 / R2 / CDN: on by default)</li>
              <li>CORS enabled for HLS playback and cross-origin subtitles</li>
              <li>For HLS: playlist, segments and encryption keys all publicly reachable</li>
              <li>Private bucket? Use <span className="font-mono text-sky-300">s3://bucket/key</span> — the server signs playback URLs after an access check</li>
            </ul>
          </div>
        </div>
      )}

      {/* provider embed */}
      {value.videoSource === "embed" && (
        <div className="mt-4 space-y-3">
          <div>
            <Lbl>Provider video URL (watch link or embed URL)</Lbl>
            <input
              value={value.embedUrl}
              onChange={(e) => set({ embedUrl: e.target.value })}
              placeholder="https://www.youtube.com/watch?v=…  ·  https://vimeo.com/…  ·  https://drive.google.com/file/d/…/view  ·  https://terabox.com/s/…"
              className={inputCls}
              aria-label="Provider embed URL"
              spellCheck={false}
            />
            {value.embedUrl.trim() && embedDetected && (
              <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[#4ADE80]">
                <CheckCircle2 className="h-3.5 w-3.5" /> {embedDetected.provider === "terabox"
                  ? "TeraBox link detected — visitors get a “Watch on TeraBox” button (or play your authorized streaming URL below)."
                  : `${embedDetected.provider} embed ready — plays inside the site player.`}
              </p>
            )}
            {value.embedUrl.trim() &&
              (() => {
                const res = toEmbedUrl(value.embedUrl);
                return "error" in res ? (
                  <p className="mt-1.5 text-[11px] text-red-300">{res.error}</p>
                ) : null;
              })()}
          </div>

          {/* Test Video Source — server-verified playback report (6 fields) */}
          <TestSourceButton
            url={value.embedUrl}
            directUrl={embedDetected?.provider === "terabox" ? value.videoUrl : undefined}
            provider={embedDetected?.provider || null}
          />

          {/* TeraBox: optional authorized direct streaming URL */}
          {embedDetected?.provider === "terabox" && (
            <div className="rounded-xl border border-sky-400/20 bg-sky-400/[0.06] p-3">
              <Lbl>Authorized streaming URL (optional)</Lbl>
              <input
                value={value.videoUrl}
                onChange={(e) => set({ videoUrl: e.target.value })}
                placeholder="https://cdn.example.com/movie.mp4 or s3://bucket/movie.mp4 — only if you have the right to stream it"
                className={inputCls}
                aria-label="Authorized streaming URL for TeraBox entry"
                spellCheck={false}
              />
              <p className="mt-1.5 text-[11px] leading-relaxed text-sky-200">
                If you also hold a direct HTTPS stream for this video (your own CDN, object storage or a licensed URL), paste it
                here and ANIME BOY will play it in the built-in player with a “Watch on TeraBox” button underneath. Never paste
                third-party extracted stream URLs — only sources you are authorized to use. Leave empty to keep the
                “Watch on TeraBox” card only.
              </p>
            </div>
          )}

          <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.06] p-3 text-[11px] leading-relaxed text-amber-200">
            Playback controls, ads and quality options are provided by the provider and vary by service. Only trusted providers are
            accepted — YouTube, Vimeo, Dailymotion, Google Drive, Streamable and TeraBox. Arbitrary iframe HTML is never allowed.
            The video always stays on the provider; nothing is downloaded to this website. Google Drive files must be shared as
            “Anyone with the link → Viewer” to embed.
          </div>
        </div>
      )}

      {/* optional poster/thumbnail */}
      <div className="mt-4">
        <UploadWidget
          kind="thumbnail"
          label={isEpisode ? "Episode thumbnail / player poster (optional)" : "Video poster / thumbnail (optional)"}
          accept="image/jpeg,image/png,image/webp,image/avif"
          value={value.videoThumb}
          onChange={(url) => set({ videoThumb: url })}
          hint="Shown in the player before playback starts"
        />
      </div>

      {preview && <PreviewDialog state={preview} onClose={() => setPreview(null)} />}
      </section>

      {/* backup/alternative sources — Server 2, Google Drive, TeraBox… */}
      <AltSourcesSection value={value} onChange={onChange} />

      {/* downloads — independent playback/editing, per movie and per episode */}
      <DownloadsSection value={value} onChange={onChange} title={title} />
    </>
  );
}
