"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, ExternalLink, ListVideo, Play } from "lucide-react";
import { api, fmtDuration } from "@/lib/client-api";
import { getLastWatched, saveLastWatched } from "@/lib/watch-progress";
import type { PlayableSource } from "@/lib/media-types";
import { navigate, useAppStore, type AnimeType, type EpisodeType, type SeasonType } from "@/store/useAppStore";
import { Spinner } from "./../Skeletons";
import { ErrorState } from "./../EmptyState";
import { VideoPlayer } from "./../VideoPlayer";
import { DownloadBar } from "./../DownloadBar";

/** Client-side fallback when the API has not produced a `video` object. */
function legacySource(a: AnimeType, ep: EpisodeType | null): PlayableSource {
  const url = a.type === "MOVIE" ? a.videoUrl : ep?.videoUrl;
  if (!url) return { kind: "none" };
  const subtitles = ((a.type === "MOVIE" ? a.subtitleTracks : ep?.subtitleTracks) || []).filter(
    (t) => t && t.url && t.enabled !== false
  );
  const subs = subtitles.length
    ? subtitles
    : (a.type === "MOVIE" ? a.subtitleUrl : ep?.subtitleUrl)
      ? [{ label: "සිංහල", lang: "si", url: (a.type === "MOVIE" ? a.subtitleUrl : ep?.subtitleUrl)! }]
      : [];
  const poster = a.type === "MOVIE" ? a.videoThumb || a.backdropUrl || a.posterUrl : ep?.thumbnailUrl || a.backdropUrl || a.posterUrl;
  const kind = /\.m3u8(\?|$)/i.test(url) ? "hls" : "mp4";
  return { kind, url, subtitles: subs, poster } as PlayableSource;
}

export function hasVideo(ep: EpisodeType): boolean {
  if (ep.video) return ep.video.kind !== "none";
  return !!ep.videoUrl || !!ep.embedUrl;
}

/**
 * Every selectable playback source for the current movie/episode: the primary
 * video first, then the admin-configured backup sources ("Server 2", Google
 * Drive, TeraBox share link…). Sources that resolve to nothing are dropped so
 * every button the visitor sees is a real option.
 */
function buildSourceList(anime: AnimeType, episode: EpisodeType | null): PlayableSource[] {
  if (!anime.id) return [];
  const apiSources = anime.type === "MOVIE" ? anime.sources : episode?.sources;
  if (apiSources?.length) return apiSources.filter((s) => s.kind !== "none");
  const primary = anime.type === "MOVIE" ? anime.video : episode?.video;
  if (primary && primary.kind !== "none") return [primary];
  // Client-side fallback when the API has not produced a `video` object.
  const legacy = legacySource(anime, episode);
  return legacy.kind !== "none" ? [legacy] : [];
}

/** Button label for a source entry ("Server 1", "Server 2", "Google Drive"…). */
function sourceButtonLabel(source: PlayableSource, index: number): string {
  if (source.sourceLabel) return source.sourceLabel;
  return index === 0 ? "Server 1" : `Server ${index + 1}`;
}

/** True when this source plays OUTSIDE the site (TeraBox share page fallback). */
function isExternalOnly(source: PlayableSource): boolean {
  return source.kind === "external_page";
}

/** Provider display name for an external-only source ("TeraBox"). */
function externalProviderLabel(source: PlayableSource): string {
  return source.kind === "external_page" ? source.providerLabel : "provider";
}

export function WatchView({ slug }: { slug: string }) {
  const { route } = useAppStore();

  const qSeason = Number(route.query.get("s")) || null;
  const qEpisode = Number(route.query.get("e")) || null;

  // Auto-start playback request: set to the target season/episode whenever the
  // visitor acts inside the watch page (picks a playlist episode, presses
  // Prev/Next, auto-advance). A plain deep link / page load — or switching
  // seasons — never starts playback by itself.
  const [autoPlayFor, setAutoPlayFor] = useState<{ s: number; e: number } | null>(null);

  const { data, isLoading, isError, error, refetch } = useQuery<{ anime: AnimeType }>({
    queryKey: ["anime", slug],
    queryFn: () => api.get(`/api/anime/${slug}`),
  });

  const anime = data?.anime;

  const { season, episode, prev, next } = useMemo(() => {
    if (!anime) return { season: null, episode: null, prev: null, next: null };
    if (anime.type === "MOVIE") return { season: null, episode: null, prev: null, next: null };
    const seasons = [...(anime.seasons || [])].sort((a, b) => a.number - b.number);
    // Remember-last-watched: without explicit ?s/?e params, reopen the last
    // season + episode this visitor watched for THIS series.
    const last = qSeason == null && qEpisode == null ? getLastWatched(anime.slug) : null;
    const s =
      seasons.find((x) => x.number === qSeason) ||
      (last ? seasons.find((x) => x.number === last.s) : null) ||
      seasons[0] ||
      null;
    if (!s) return { season: null, episode: null, prev: null, next: null };
    const epNum = qEpisode ?? (last && last.s === s.number ? last.e : null);
    const idx = s.episodes.findIndex((e) => e.number === epNum);
    const current = idx >= 0 ? s.episodes[idx] : s.episodes[0] || null;
    const flat = seasons.flatMap((ss) => ss.episodes.map((e) => ({ s: ss.number, e: e.number })));
    const fi = flat.findIndex((f) => f.s === s.number && f.e === current?.number);
    const p = fi > 0 ? flat[fi - 1] : null;
    const n = fi >= 0 && fi < flat.length - 1 ? flat[fi + 1] : null;
    return { season: s, episode: current, prev: p, next: n };
  }, [anime, qSeason, qEpisode]);

  // Persist the visitor's place in this series (season + episode) so the watch
  // page reopens exactly there next time.
  useEffect(() => {
    if (anime?.type === "SERIES" && season && episode) {
      saveLastWatched(anime.slug, season.number, episode.number);
    }
  }, [anime?.slug, anime?.type, season?.id, season?.number, episode?.id, episode?.number]);

  const sourceList = useMemo(() => buildSourceList(anime || ({} as AnimeType), episode), [anime, episode]);

  // Selected playback source, scoped to the current title+episode. A manual
  // pick from a previous episode is simply ignored (key mismatch) instead of
  // being reset by an effect — switching to a new episode always starts on
  // Server 1 until the visitor picks another source for THAT episode.
  const listKey = `${slug}-${episode?.id ?? "movie"}-${sourceList.length}`;
  const [picked, setPicked] = useState<{ key: string; id: string | null }>({ key: "", id: null });
  const pickedSourceId = picked.key === listKey ? picked.id : null;

  const activeIndex = useMemo(() => {
    if (pickedSourceId) {
      const i = sourceList.findIndex((s) => (s.sourceId || "primary") === pickedSourceId);
      if (i >= 0) return i;
    }
    return 0;
  }, [sourceList, pickedSourceId]);
  const source: PlayableSource = sourceList[activeIndex] ?? { kind: "none" };

  const scrollToPlayer = () =>
    document.querySelector("[data-video-player]")?.scrollIntoView({ behavior: "smooth", block: "start" });

  // Episode navigation — every in-page action plays the target immediately.
  const goEp = (target: { s: number; e: number } | null) => {
    if (!target) return;
    setAutoPlayFor(target);
    navigate(`/watch/${slug}?s=${target.s}&e=${target.e}`);
    scrollToPlayer();
  };

  // Season switch — load that season's episode list; start paused on its
  // first episode (the visitor picks what to play).
  const goSeason = (seasonNumber: number) => {
    if (!anime) return;
    const s = (anime.seasons || []).find((x) => x.number === seasonNumber);
    if (!s || s.number === season?.number) return;
    setAutoPlayFor(null);
    const first = s.episodes[0];
    navigate(first ? `/watch/${slug}?s=${s.number}&e=${first.number}` : `/watch/${slug}?s=${s.number}`);
    scrollToPlayer();
  };

  // keyboard navigation for prev/next — never hijack keys typed inside the player
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if ((e.target as HTMLElement | null)?.closest?.("[data-video-player]")) return;
      if (e.key === "ArrowLeft" && prev) goEp(prev);
      if (e.key === "ArrowRight" && next) goEp(next);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [prev, next]);

  if (isLoading) return <Spinner label="Loading player…" />;

  if (isError || !anime) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20">
        <ErrorState message={error instanceof Error ? error.message : "Not found"} onRetry={() => refetch()} />
      </div>
    );
  }

  if (anime.status === "UPCOMING") {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#F59E0B]/12">
          <span className="text-3xl">⏳</span>
        </span>
        <h1 className="mt-4 text-2xl font-black text-white">{anime.titleEn}</h1>
        <p className="mt-2 font-semibold text-[#F59E0B]">
          This title has not been released yet{anime.releaseYear ? ` — expected ${anime.releaseYear}` : ""}.
        </p>
        <p className="mt-1 text-sm text-slate-400">මෙය තවම නිකුත් වී නොමැත. නිකුත් වූ පසු නරඹිය හැක.</p>
        <button
          onClick={() => navigate(`/anime/${anime.slug}`)}
          className="mt-6 h-11 rounded-full bg-[#22C55E] px-6 font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
        >
          View details instead
        </button>
      </div>
    );
  }

  const unavailable = source.kind === "none";

  // Auto-play applies to the episode the visitor explicitly chose (playlist
  // pick, Prev/Next, auto-advance) — never to a plain page load.
  const wantsAutoPlay =
    !!autoPlayFor && autoPlayFor.s === (season?.number ?? -1) && autoPlayFor.e === (episode?.number ?? -1);

  const watchTitle =
    anime.type === "MOVIE"
      ? anime.titleEn
      : `${anime.titleEn} — S${season?.number ?? 1} E${episode?.number ?? 1}${episode?.title ? ` · ${episode.title}` : ""}`;

  return (
    <div className="fade-up mx-auto max-w-7xl px-4 pb-10 pt-6 sm:px-6">
      <button
        onClick={() => navigate(`/anime/${anime.slug}`)}
        className="mb-4 inline-flex h-10 items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-4 text-sm font-semibold text-slate-200 transition-colors hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
        aria-label="Back to details"
      >
        <ChevronLeft className="h-4 w-4" /> {anime.titleEn}
      </button>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        {/* player column — min-w-0 keeps long "Series — S1 E1 · title" nowrap
            titles from forcing the auto grid track wider than the viewport
            (mobile horizontal-scroll bug) */}
        <div className="min-w-0">
          <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black shadow-2xl shadow-black/60" style={{ aspectRatio: "16/9" }}>
            <div className="absolute inset-0">
              {unavailable ? (
                <div className="flex h-full flex-col items-center justify-center gap-3 bg-[#0a0f24] text-center">
                  <ListVideo className="h-10 w-10 text-slate-600" />
                  <p className="text-lg font-bold text-slate-200">Video Source Not Available</p>
                  <p className="max-w-sm px-4 text-sm text-slate-500">
                    No video has been added for this {anime.type === "MOVIE" ? "movie" : "episode"} yet — admins can
                    attach a video file, cloud URL or provider embed in the dashboard.
                  </p>
                  <p className="text-xs text-slate-600">වීඩියෝ මූලාවේල්ල තවමත් එකතු කර නොමැත.</p>
                </div>
              ) : (
                <VideoPlayer
                  key={source.sourceId || "primary"}
                  source={source}
                  title={watchTitle}
                  testId="watch-player"
                  autoPlay={wantsAutoPlay}
                  onNext={anime.type === "SERIES" && next ? () => goEp(next) : undefined}
                  progressKey={anime.type === "MOVIE" ? `movie:${anime.id}` : `ep:${episode?.id ?? ""}`}
                  progressMeta={{
                    slug: anime.slug,
                    title: watchTitle,
                    poster:
                      (anime.type === "MOVIE" ? anime.videoThumb || anime.backdropUrl : episode?.thumbnailUrl || anime.backdropUrl) ||
                      anime.posterUrl,
                    label: anime.type === "MOVIE" ? "Movie" : `Season ${season?.number ?? 1} · Episode ${episode?.number ?? 1}`,
                    s: season?.number,
                    e: episode?.number,
                  }}
                />
              )}
            </div>
          </div>

          {/* playback-source switcher — only rendered when more than one real
              source exists. Sources marked external (TeraBox share pages) say
              so honestly instead of pretending to play in-site. */}
          {sourceList.length > 1 && (
            <div className="mt-3" role="tablist" aria-label="Playback sources">
              <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">Playback source</p>
              <div className="flex flex-wrap gap-2">
                {sourceList.map((s, i) => {
                  const active = i === activeIndex;
                  const external = isExternalOnly(s);
                  return (
                    <button
                      key={s.sourceId || `src-${i}`}
                      role="tab"
                      aria-selected={active}
                      onClick={() => setPicked({ key: listKey, id: s.sourceId || "primary" })}
                      title={
                        external
                          ? `${sourceButtonLabel(s, i)} — plays on ${externalProviderLabel(s)} (opens in a new tab, not inside the site)`
                          : sourceButtonLabel(s, i)
                      }
                      className={`inline-flex h-9 items-center gap-1.5 rounded-full border px-3.5 text-xs font-bold transition-colors ${
                        active
                          ? "border-[#22C55E] bg-[#22C55E]/15 text-[#4ADE80]"
                          : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
                      }`}
                    >
                      {external && <ExternalLink className="h-3 w-3 shrink-0" />}
                      {sourceButtonLabel(s, i)}
                      {external && <span className="text-[10px] font-semibold text-slate-500">({externalProviderLabel(s)})</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* download buttons — always describe the currently selected movie/episode */}
          <DownloadBar key={`${anime.id}-${episode?.id ?? "movie"}`} anime={anime} episode={episode} />

          {source.kind === "embed" && (
            <p className="mt-2 text-xs text-slate-500">
              මෙම video එක {source.providerLabel} වෙතින් stream වේ · playback & controls {source.providerLabel} සතු වේ.
            </p>
          )}

          {/* No-iframe providers (e.g. TeraBox) with an authorized direct
              stream: the player works AND the official page stays one click away. */}
          {(source.kind === "mp4" || source.kind === "hls" || source.kind === "dash") && source.externalPage && (
            <a
              href={source.externalPage.pageUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-[#4ADE80] transition-colors hover:text-white"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Watch on {source.externalPage.providerLabel} — official page (new tab)
            </a>
          )}

          {/* title + controls */}
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-lg font-extrabold text-white sm:text-xl">{watchTitle}</h1>
              {episode?.description && <p className="mt-0.5 truncate text-sm text-slate-400">{episode.description}</p>}
            </div>
            {anime.type === "SERIES" && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => goEp(prev)}
                  disabled={!prev}
                  aria-label="Previous episode"
                  className="inline-flex h-11 items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-4 text-sm font-semibold text-slate-200 transition-colors enabled:hover:border-[#22C55E]/40 enabled:hover:text-[#4ADE80] disabled:opacity-40"
                >
                  <ChevronLeft className="h-4 w-4" /> Prev
                </button>
                <button
                  onClick={() => goEp(next)}
                  disabled={!next}
                  aria-label="Next episode"
                  className="inline-flex h-11 items-center gap-1.5 rounded-full bg-[#22C55E] px-4 text-sm font-bold text-[#04220f] transition-colors enabled:hover:bg-[#4ADE80] disabled:opacity-40"
                >
                  Next <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>

          {anime.type === "MOVIE" && anime.descriptionSi && (
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-400">{anime.descriptionSi}</p>
          )}
        </div>

        {/* playlist column */}
        {anime.type === "SERIES" && season && (
          <PlaylistPanel
            anime={anime}
            season={season}
            currentEpisode={episode}
            onSelectSeason={goSeason}
            onSelectEpisode={(ep) => goEp({ s: season.number, e: ep.number })}
          />
        )}
      </div>
    </div>
  );
}

/* ------------------------------ playlist panel ----------------------------- */

/**
 * Season selector + playlist for the selected season. The currently playing
 * episode is highlighted, auto-scrolled into view, and every listed episode
 * starts playing the moment it is clicked.
 */
function PlaylistPanel({
  anime,
  season,
  currentEpisode,
  onSelectSeason,
  onSelectEpisode,
}: {
  anime: AnimeType;
  season: SeasonType;
  currentEpisode: EpisodeType | null;
  onSelectSeason: (seasonNumber: number) => void;
  onSelectEpisode: (ep: EpisodeType) => void;
}) {
  const seasons = useMemo(() => [...(anime.seasons || [])].sort((a, b) => a.number - b.number), [anime.seasons]);
  const activeItemRef = useRef<HTMLLIElement | null>(null);

  // Keep the playing episode visible in the playlist (episode change,
  // season change and auto-advance all land here).
  useEffect(() => {
    activeItemRef.current?.scrollIntoView({ block: "nearest" });
  }, [currentEpisode?.id, season.id]);

  return (
    <aside
      className="flex flex-col overflow-hidden rounded-2xl border border-white/8 bg-white/[0.02] lg:sticky lg:top-20 lg:max-h-[calc(100vh-6rem)]"
      aria-label="Episode playlist"
    >
      <div className="border-b border-white/8 p-4 pb-3">
        <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-[#4ADE80]">
          <ListVideo className="h-4 w-4" /> Playlist
        </h2>
        {/* the playlist name — the series/playlists title this episode belongs to */}
        <p className="mt-1.5 truncate text-sm font-bold text-white" title={anime.titleEn}>
          {anime.titleEn}
        </p>
        {/* Season selector — shown when the playlist has multiple seasons. */}
        {seasons.length > 1 && (
          <label className="mt-3 block">
            <span className="sr-only">Select season</span>
            <select
              value={season.number}
              onChange={(e) => onSelectSeason(Number(e.target.value))}
              aria-label="Select season"
              className="h-10 w-full appearance-none rounded-xl border border-white/10 bg-[#0b1120] bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2212%22%20height%3D%2212%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222.5%22%3E%3Cpath%20d%3D%22m6%209%206%206%206-6%22%2F%3E%3C%2Fsvg%3E')] bg-[position:right_0.75rem_center] bg-no-repeat px-3 pr-9 text-sm font-semibold text-white outline-none transition-colors focus:border-[#22C55E]/50"
            >
              {seasons.map((s) => (
                <option key={s.id} value={s.number} className="bg-[#0b1120]">
                  Season {s.number}
                  {s.title ? ` — ${s.title}` : ""} ({s.episodes.length} ep)
                </option>
              ))}
            </select>
          </label>
        )}
        <p className="mt-2.5 text-[11px] font-black uppercase tracking-widest text-slate-500">
          Playlist — Season {season.number}
          {season.title ? ` · ${season.title}` : ""} · {season.episodes.length} episode{season.episodes.length === 1 ? "" : "s"}
        </p>
      </div>

      <ol className="flex-1 space-y-1.5 overflow-y-auto p-3" aria-label={`Season ${season.number} episodes`}>
        {season.episodes.map((ep) => {
          const active = currentEpisode?.id === ep.id;
          return (
            <PlaylistItem
              key={ep.id}
              ep={ep}
              anime={anime}
              active={active}
              innerRef={active ? activeItemRef : undefined}
              onSelect={() => onSelectEpisode(ep)}
            />
          );
        })}
        {season.episodes.length === 0 && (
          <li className="rounded-xl border border-dashed border-white/10 px-4 py-8 text-center text-sm text-slate-500">
            No episodes in this season yet.
          </li>
        )}
      </ol>
    </aside>
  );
}

function PlaylistItem({
  ep,
  anime,
  active,
  innerRef,
  onSelect,
}: {
  ep: EpisodeType;
  anime: AnimeType;
  active: boolean;
  innerRef?: React.Ref<HTMLLIElement>;
  onSelect: () => void;
}) {
  const [thumbBroken, setThumbBroken] = useState(false);
  const playable = hasVideo(ep);
  const thumb = ep.thumbnailUrl || anime.backdropUrl || anime.posterUrl || "";

  return (
    <li ref={innerRef}>
      <button
        onClick={() => playable && onSelect()}
        disabled={!playable}
        aria-current={active ? "true" : undefined}
        title={playable ? `Play Episode ${ep.number}` : "This episode has no video yet"}
        className={`flex w-full items-center gap-3 rounded-xl border p-2 text-left transition-colors ${
          active
            ? "border-[#22C55E]/60 bg-[#22C55E]/10"
            : playable
              ? "border-transparent hover:bg-white/[0.05]"
              : "border-transparent opacity-50"
        }`}
      >
        <span className="relative h-12 w-20 shrink-0 overflow-hidden rounded-lg bg-gradient-to-br from-[#16233a] to-[#0b1120]">
          {thumb && !thumbBroken ? (
            <img
              src={thumb}
              alt=""
              loading="lazy"
              onError={() => setThumbBroken(true)}
              className="h-full w-full object-cover"
            />
          ) : null}
          <span
            className={`absolute inset-0 flex items-center justify-center ${
              active ? "bg-black/45" : "bg-black/25"
            }`}
          >
            {active ? (
              <Play className="h-5 w-5 fill-[#4ADE80] text-[#4ADE80]" />
            ) : (
              <span className="text-xs font-black text-white/90">{ep.number}</span>
            )}
          </span>
        </span>
        <span className="min-w-0 flex-1">
          <span className={`block text-[10px] font-black uppercase tracking-widest ${active ? "text-[#4ADE80]" : "text-slate-500"}`}>
            Episode {ep.number}
          </span>
          <span className={`block truncate text-sm font-semibold ${active ? "text-[#4ADE80]" : "text-slate-200"}`}>
            {ep.title || `Episode ${ep.number}`}
          </span>
          {fmtDuration(ep.durationSec) && (
            <span className="text-[11px] text-slate-500">{fmtDuration(ep.durationSec)}</span>
          )}
        </span>
      </button>
    </li>
  );
}
