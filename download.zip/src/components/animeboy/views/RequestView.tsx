"use client";

import { useState } from "react";
import { MailPlus, Clapperboard, MonitorPlay, Send, PartyPopper } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { useAppStore } from "@/store/useAppStore";

export function RequestView() {
  const { user } = useAppStore();
  const [title, setTitle] = useState("");
  const [type, setType] = useState<"MOVIE" | "SERIES">("MOVIE");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (title.trim().length < 2) {
      setError("Please enter the anime title. / කරුණාකර ඇනිමේ නම ලියන්න.");
      return;
    }
    setSending(true);
    try {
      await api.post("/api/requests", { title: title.trim(), type, message: message.trim() });
      setDone(true);
      setTitle("");
      setMessage("");
      toast.success("Request sent! We'll review it soon.");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not send request";
      setError(msg);
      toast.error(msg);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fade-up mx-auto max-w-2xl px-4 pb-6 pt-10 sm:px-6">
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/12 glow-green">
          <MailPlus className="h-8 w-8 text-[#4ADE80]" />
        </span>
        <h1 className="mt-4 text-3xl font-black text-white">Request Anime</h1>
        <p className="mt-2 text-slate-400">
          ඔබට අවශ්‍ය ඇනිමේ චිත්‍රපටය හෝ කතා මාලාව ඉල්ලන්න — අපි ඉක්මනින් සිංහල පිටපත එකතු කිරීමට උත්සාහ කරන්නෙමු.
        </p>
        {!user && (
          <p className="mt-1 text-xs text-slate-500">
            You can request without signing in — sign in to track responses from your account.
          </p>
        )}
      </div>

      {done ? (
        <div className="mt-10 rounded-3xl border border-[#22C55E]/30 bg-[#22C55E]/8 p-8 text-center fade-up">
          <PartyPopper className="mx-auto h-10 w-10 text-[#4ADE80]" />
          <h2 className="mt-3 text-xl font-bold text-white">Request received! 🎉</h2>
          <p className="mt-2 text-sm text-slate-300">
            ඔබගේ ඉල්ලීම ලැබී ඇත. ANIME BOY කණ්ඩායම ඉක්මනින් සමාලෝචනය කරයි.
          </p>
          <button
            onClick={() => setDone(false)}
            className="mt-5 h-11 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
          >
            Send another request
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-9 space-y-5 rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-8" noValidate>
          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">
              Anime Title <span className="text-[#4ADE80]">*</span>
            </span>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Demon Slayer: Infinity Castle"
              aria-label="Anime title"
              aria-required="true"
              maxLength={200}
              className="h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25"
            />
          </label>

          <div>
            <span className="mb-1.5 block text-sm font-bold text-slate-200">
              Type <span className="text-[#4ADE80]">*</span>
            </span>
            <div className="grid grid-cols-2 gap-2.5" role="radiogroup" aria-label="Request type">
              {[
                { v: "MOVIE" as const, label: "Anime Movie", icon: Clapperboard },
                { v: "SERIES" as const, label: "Anime Series", icon: MonitorPlay },
              ].map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  role="radio"
                  aria-checked={type === opt.v}
                  onClick={() => setType(opt.v)}
                  className={`flex h-14 items-center justify-center gap-2 rounded-xl border text-sm font-bold transition-all ${
                    type === opt.v
                      ? "border-[#22C55E]/60 bg-[#22C55E]/12 text-[#4ADE80] glow-green"
                      : "border-white/10 bg-[#0b1120] text-slate-300 hover:border-white/25"
                  }`}
                >
                  <opt.icon className="h-5 w-5" /> {opt.label}
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">
              Message <span className="text-xs font-medium text-slate-500">(optional)</span>
            </span>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              maxLength={2000}
              placeholder="සිංහල හඬ හෝ උපසිරැසි අවශ්‍යද? වෙනත් විස්තර…"
              aria-label="Optional message"
              className="w-full resize-none rounded-xl border border-white/10 bg-[#0b1120] px-4 py-3 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25"
            />
          </label>

          {error && (
            <p role="alert" className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={sending}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#22C55E] py-3.5 font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:opacity-60"
          >
            {sending ? (
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-[#04220f]/30 border-t-[#04220f]" aria-hidden="true" />
            ) : (
              <Send className="h-4.5 w-4.5" />
            )}
            {sending ? "Sending…" : "Send Request"}
          </button>
        </form>
      )}
    </div>
  );
}
