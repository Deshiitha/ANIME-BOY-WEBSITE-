"use client";

/**
 * Password reset ("#/reset-password?token=…") — consumes a single-use,
 * expiring emailed token. Token validity is checked before showing the form.
 */
import { useEffect, useState } from "react";
import { KeyRound, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { navigate, parseHash, useAppStore } from "@/store/useAppStore";
import { passwordStrength, validatePassword } from "@/lib/password-policy";

const STRENGTH_LABELS = ["", "Weak", "Fair", "Good", "Strong"];

export function ResetPasswordView() {
  const { route } = useAppStore();
  const [token, setToken] = useState("");
  const [checking, setChecking] = useState(true);
  const [tokenValid, setTokenValid] = useState(false);

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  // Pull the token from the hash query (also survives refresh).
  useEffect(() => {
    const t = parseHash(window.location.hash || "#/reset-password").query.get("token") || route.query.get("token") || "";
    setToken(t);
    (async () => {
      if (!t) {
        setChecking(false);
        return;
      }
      try {
        const res = await api.post<{ valid: boolean }>("/api/auth/validate-reset-token", { token: t });
        setTokenValid(res.valid);
      } catch {
        setTokenValid(false);
      } finally {
        setChecking(false);
      }
    })();
  }, []);

  const strength = passwordStrength(password);
  const check = password ? validatePassword(password) : { ok: true, message: "" };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!check.ok) return setError(check.message);
    if (password !== confirm) return setError("The passwords do not match.");
    setBusy(true);
    try {
      await api.post("/api/auth/reset-password", { token, newPassword: password });
      toast.success("Password updated ✓", { description: "You can now sign in with your new password." });
      navigate("/signin");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Reset failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fade-up mx-auto flex max-w-md flex-col px-4 pb-6 pt-12 sm:px-6">
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/12 glow-green">
          <KeyRound className="h-8 w-8 text-[#4ADE80]" />
        </span>
        <h1 className="mt-4 text-3xl font-black text-white">Choose a New Password</h1>
      </div>

      {checking ? (
        <p className="mt-10 flex items-center justify-center gap-2 text-sm text-slate-400">
          <Loader2 className="h-4 w-4 animate-spin" /> Checking your reset link…
        </p>
      ) : !token || !tokenValid ? (
        <div className="mt-8 rounded-3xl border border-red-500/25 bg-red-500/[0.06] p-6 text-center">
          <p className="text-sm leading-relaxed text-red-200">
            This password reset link is invalid, already used, or expired. Request a fresh one — links stay valid for 60 minutes.
          </p>
          <button
            onClick={() => navigate("/forgot-password")}
            className="mt-5 h-11 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
          >
            Request New Link
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-8 space-y-4 rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-7" noValidate>
          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">New Password</span>
            <span className="relative block">
              <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
              <input
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 8 characters with a letter and a number"
                autoComplete="new-password"
                required
                aria-label="New password"
                className="h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] pl-11 pr-20 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25"
              />
              <button
                type="button"
                onClick={() => setShow((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg px-2.5 py-1.5 text-[11px] font-bold text-slate-400 transition-colors hover:bg-white/5 hover:text-[#4ADE80]"
              >
                {show ? "Hide" : "Show"}
              </button>
            </span>
          </label>
          {password && (
            <div className="flex items-center gap-2" aria-live="polite">
              <div className="flex h-1.5 flex-1 gap-1" aria-hidden="true">
                {[1, 2, 3, 4].map((i) => (
                  <span key={i} className={`h-full flex-1 rounded-full ${i <= strength ? (strength >= 3 ? "bg-[#22C55E]" : "bg-amber-500") : "bg-white/10"}`} />
                ))}
              </div>
              <span className={`text-[11px] font-bold ${strength >= 3 ? "text-[#4ADE80]" : "text-amber-400"}`}>{STRENGTH_LABELS[strength]}</span>
            </div>
          )}
          {!check.ok && password && <p className="text-[11px] text-amber-300">{check.message}</p>}

          <label className="block">
            <span className="mb-1.5 block text-sm font-bold text-slate-200">Confirm New Password</span>
            <span className="relative block">
              <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
              <input
                type={show ? "text" : "password"}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="Type the new password again"
                autoComplete="new-password"
                required
                aria-label="Confirm new password"
                className="h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] pl-11 pr-4 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25"
              />
            </span>
          </label>
          {confirm && password !== confirm && <p className="text-[11px] text-red-300">Passwords do not match</p>}

          {error && (
            <p role="alert" className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="h-12 w-full rounded-xl bg-[#22C55E] font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:opacity-60"
          >
            {busy ? (
              <>
                <Loader2 className="mr-2 inline h-4 w-4 animate-spin" /> Updating…
              </>
            ) : (
              "Update Password"
            )}
          </button>
        </form>
      )}
    </div>
  );
}
