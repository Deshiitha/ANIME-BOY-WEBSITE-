"use client";

import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Clapperboard, History, Hourglass, MonitorPlay, Play, Zap, Tv, Star, Brush, TvMinimalPlay, Shapes, X } from "lucide-react";
import { api } from "@/lib/client-api";
import type { AnimeType, EpisodeCardType } from "@/store/useAppStore";
import { navigate } from "@/store/useAppStore";
import {
  formatClock,
  getWatchProgressList,
  onWatchProgressChange,
  removeWatchProgress,
  type WatchProgressEntry,
} from "@/lib/watch-progress";
import { HeroCarousel } from "./../HeroCarousel";
import { SectionRow } from "./../SectionRow";
import { HeroSkeleton, PosterSkeleton } from "./../Skeletons";
import { ErrorState } from "./../EmptyState";

type SectionsResponse = {
  featured: AnimeType[];
  recentMovies: { items: AnimeType[]; total: number };
  comingSoonMovies: { items: AnimeType[]; total: number };
  recentSeries: { items: AnimeType[]; total: number };
  latestEpisodes: { items: EpisodeCardType[]; total: number };
  comingSoonSeries: { items: AnimeType[]; total: number };
  topRated: { items: AnimeType[]; total: number };
  recentDonghua: { items: AnimeType[]; total: number };
  recentDonghuaSeries: { items: AnimeType[]; total: number };
  recentOthers: { items: AnimeType[]; total: number };
};

export function HomeView() {
  const { data, isLoading, isError, refetch } = useQuery<SectionsResponse>({
    queryKey: ["sections"],
    queryFn: () => api.get("/api/sections"),
    staleTime: 30_000,
  });

  if (isLoading) {
    return (
      <div>
        <HeroSkeleton />
        <div className="mx-auto mt-10 max-w-7xl space-y-10 px-4 sm:px-6">
          {[0, 1].map((i) => (
            <div key={i} className="flex gap-3.5 overflow-hidden">
              {Array.from({ length: 6 }).map((_, j) => (
                <PosterSkeleton key={j} />
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20">
        <ErrorState message="We couldn't load the homepage content. Check your connection and try again." onRetry={() => refetch()} />
      </div>
    );
  }

  return (
    <div className="fade-up">
      <HeroCarousel items={data.featured} />

      <div className="relative z-10 mx-auto mt-10 max-w-7xl space-y-12 pb-6 sm:space-y-14">
        <ContinueWatchingRow />
        <SectionRow
          icon={<Clapperboard className="h-5 w-5 text-slate-200" />}
          title="Recently Added Anime Movies"
          count={data.recentMovies.total}
          items={data.recentMovies.items}
          viewAllHash="/movies?status=RELEASED"
        />
        <SectionRow
          icon={<Hourglass className="h-5 w-5 text-[#F59E0B]" />}
          title="Coming Soon Anime Movies"
          tone="amber"
          upcomingBadge
          count={data.comingSoonMovies.total}
          items={data.comingSoonMovies.items}
          viewAllHash="/movies?status=UPCOMING"
        />
        <SectionRow
          icon={<MonitorPlay className="h-5 w-5 text-slate-200" />}
          title="Recently Added Anime Series"
          count={data.recentSeries.total}
          items={data.recentSeries.items}
          viewAllHash="/series?status=RELEASED"
        />
        <SectionRow
          icon={<Brush className="h-5 w-5 text-[#4ADE80]" />}
          title="Recently Added Donghua Movie"
          count={data.recentDonghua.total}
          items={data.recentDonghua.items}
          viewAllHash="/donghua?status=RELEASED"
        />
        <SectionRow
          icon={<TvMinimalPlay className="h-5 w-5 text-[#4ADE80]" />}
          title="Recently Added Donghua Series"
          count={data.recentDonghuaSeries.total}
          items={data.recentDonghuaSeries.items}
          viewAllHash="/donghua-series?status=RELEASED"
        />
        <SectionRow
          icon={<Shapes className="h-5 w-5 text-[#4ADE80]" />}
          title="Recently Added Others"
          count={data.recentOthers.total}
          items={data.recentOthers.items}
          viewAllHash="/others?status=RELEASED"
        />
        <SectionRow
          icon={<Zap className="h-5 w-5 text-[#4ADE80]" />}
          title="Latest Episodes"
          count={data.latestEpisodes.total}
          episodeItems={data.latestEpisodes.items}
          viewAllHash="/series?status=RELEASED"
        />
        <SectionRow
          icon={<Tv className="h-5 w-5 text-[#F59E0B]" />}
          title="Coming Soon Anime Series"
          tone="amber"
          upcomingBadge
          count={data.comingSoonSeries.total}
          items={data.comingSoonSeries.items}
          viewAllHash="/series?status=UPCOMING"
        />
        <SectionRow
          icon={<Star className="h-5 w-5 fill-[#FACC15] text-[#FACC15]" />}
          title="Top Rated Anime"
          tone="gold"
          count={data.topRated.total}
          items={data.topRated.items}
          viewAllHash="/search?sort=rating"
        />
      </div>
    </div>
  );
}

/* ---------------------------- continue watching ---------------------------- */

const CW_GRADIENTS = [
  "from-emerald-900/70 via-[#101827] to-[#050816]",
  "from-teal-900/60 via-[#101827] to-[#050816]",
  "from-green-900/60 via-[#0b1120] to-[#050816]",
];

/** Home row of partially-watched movies/episodes with resume + remove actions. */
function ContinueWatchingRow() {
  const [items, setItems] = useState<WatchProgressEntry[]>([]);

  useEffect(() => {
    const sync = () => setItems(getWatchProgressList());
    sync();
    return onWatchProgressChange(sync);
  }, []);

  if (items.length === 0) return null;

  return (
    <section aria-label="Continue watching" className="fade-up">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 sm:px-6">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#22C55E]/12">
          <History className="h-5 w-5 text-[#4ADE80]" />
        </span>
        <h2 className="whitespace-nowrap text-lg font-extrabold text-white sm:text-xl">Continue Watching</h2>
        <span className="hidden h-[3px] min-w-10 flex-1 rounded-full bg-gradient-to-r from-[#22C55E] to-transparent sm:block" />
        <span className="hidden shrink-0 text-[13px] font-medium text-slate-400 sm:block">
          {items.length} {items.length === 1 ? "title" : "titles"}
        </span>
        <button
          onClick={() => {
            removeWatchProgress();
            setItems([]);
          }}
          className="ml-auto inline-flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[13px] font-bold text-slate-400 transition-colors hover:bg-white/5 hover:text-white"
        >
          Clear all
        </button>
      </div>

      <div className="relative mt-4">
        <div
          className="no-scrollbar flex snap-x snap-mandatory gap-3.5 overflow-x-auto scroll-smooth px-4 pb-2 sm:px-6"
          role="list"
        >
          {items.map((entry, i) => {
            const pct = entry.duration > 0 ? Math.min(100, Math.round((entry.seconds / entry.duration) * 100)) : 0;
            const left = entry.duration > 0 ? Math.max(0, entry.duration - entry.seconds) : 0;
            const href = `/watch/${entry.slug}${entry.s ? `?s=${entry.s}${entry.e ? `&e=${entry.e}` : ""}` : ""}`;
            return (
              <div role="listitem" key={entry.key} className="group/cw w-[150px] shrink-0 snap-start sm:w-[168px] lg:w-[176px]">
                <div className="relative overflow-hidden rounded-xl border border-white/8 bg-[#101827] shadow-lg shadow-black/40 transition-all duration-300 hover:border-[#22C55E]/45 hover:shadow-[0_0_28px_rgba(34,197,94,0.18)]">
                  <button
                    onClick={() => navigate(href)}
                    aria-label={`Resume ${entry.title}`}
                    className="relative block aspect-[2/3] w-full text-left"
                  >
                    {entry.poster ? (
                      <img
                        src={entry.poster}
                        alt=""
                        loading="lazy"
                        decoding="async"
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover/cw:scale-[1.06]"
                      />
                    ) : (
                      <span
                        className={`absolute inset-0 flex items-center justify-center bg-gradient-to-br ${CW_GRADIENTS[i % CW_GRADIENTS.length]} p-4`}
                      >
                        <span className="line-clamp-3 text-center text-sm font-bold text-[#4ADE80]/90">{entry.title}</span>
                      </span>
                    )}
                    <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

                    <span className="absolute left-2 top-2 rounded-md bg-[#22C55E]/85 px-1.5 py-0.5 text-[9.5px] font-black uppercase tracking-wide text-[#04220f]">
                      {entry.label || "Resume"}
                    </span>

                    <span className="absolute right-2 top-2 rounded-md bg-black/65 px-1.5 py-0.5 text-[10.5px] font-bold text-white backdrop-blur-sm">
                      {pct}%
                    </span>

                    {/* hover play */}
                    <span className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover/cw:opacity-100">
                      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#22C55E] text-[#04220f] shadow-xl shadow-[#22C55E]/40">
                        <Play className="h-5 w-5 fill-current" />
                      </span>
                    </span>

                    {/* progress bar */}
                    <span className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/15">
                      <span className="block h-full bg-[#22C55E]" style={{ width: `${pct}%` }} />
                    </span>
                  </button>

                  <button
                    onClick={() => removeWatchProgress(entry.key)}
                    aria-label={`Remove ${entry.title} from Continue Watching`}
                    className="absolute right-1.5 top-1.5 flex h-7 w-7 items-center justify-center rounded-full bg-black/70 text-slate-300 opacity-0 backdrop-blur transition-all hover:text-white focus:opacity-100 group-hover/cw:opacity-100"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>

                <button onClick={() => navigate(href)} className="mt-2 block w-full text-left">
                  <h3 className="line-clamp-2 text-[13.5px] font-semibold leading-snug text-slate-100 transition-colors group-hover/cw:text-[#4ADE80]">
                    {entry.title}
                  </h3>
                  <p className="mt-0.5 text-[12px] font-semibold text-[#4ADE80]">
                    {left > 0 ? `${formatClock(left)} left` : `${pct}% watched`}
                  </p>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
