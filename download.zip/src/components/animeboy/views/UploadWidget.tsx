"use client";

import { useRef, useState } from "react";
import { UploadCloud, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";

type UploadResult = { url: string; storage: string; fileName: string; size: number };

/**
 * Admin upload widget with real progress bar, client-side validation
 * and clear failure handling. Uploads go to object storage when S3 is
 * configured, otherwise to local server storage.
 */
export function UploadWidget({
  kind,
  label,
  accept,
  value,
  onChange,
  hint,
}: {
  kind: "video" | "poster" | "backdrop" | "subtitle" | "thumbnail";
  label: string;
  accept: string;
  value: string;
  onChange: (url: string) => void;
  hint?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const isVideo = kind === "video";

  const startUpload = (file: File) => {
    // client-side validation (server re-validates)
    const maxMB = isVideo ? Number(process.env.NEXT_PUBLIC_MAX_VIDEO_MB) || 512 : 10;
    if (file.size > maxMB * 1024 * 1024) {
      toast.error(`File too large — maximum ${maxMB} MB`);
      return;
    }
    const okTypes = accept.split(",").map((t) => t.trim());
    if (okTypes.length && !okTypes.some((t) => file.type.startsWith(t.replace("/*", "")))) {
      toast.error(`Unsupported file type: ${file.type || "unknown"}`);
      return;
    }

    const form = new FormData();
    form.append("file", file);
    form.append("kind", kind);

    setProgress(0);
    const { promise, abort } = api.upload<UploadResult>("/api/admin/upload", form, setProgress);
    (window as unknown as { __abUploadAbort?: () => void }).__abUploadAbort = abort;

    promise
      .then((res) => {
        onChange(res.url);
        toast.success(`Uploaded via ${res.storage === "s3" ? "object storage" : "server storage"}`);
      })
      .catch((err) => {
        toast.error(err instanceof Error ? err.message : "Upload failed");
      })
      .finally(() => {
        setProgress(null);
        if (inputRef.current) inputRef.current.value = "";
      });
  };

  return (
    <div>
      <span className="mb-1.5 block text-sm font-bold text-slate-200">{label}</span>

      {value ? (
        <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-[#0b1120] p-3">
          {isVideo ? (
            <video src={value} className="h-14 w-24 rounded-lg bg-black object-cover" muted />
          ) : (
            <img src={value} alt="" className="h-14 w-10 rounded-lg bg-black object-cover" />
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-semibold text-slate-300">{value}</p>
            <p className="text-[11px] text-slate-500">Attached — replace or remove</p>
          </div>
          <button
            type="button"
            onClick={() => onChange("")}
            aria-label="Remove attachment"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const file = e.dataTransfer.files?.[0];
            if (file) startUpload(file);
          }}
          className={`flex w-full flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed px-4 py-6 text-center transition-colors ${
            dragOver
              ? "border-[#4ADE80] bg-[#22C55E]/10"
              : "border-white/15 bg-[#0b1120] hover:border-[#22C55E]/50"
          }`}
        >
          <UploadCloud className="h-6 w-6 text-[#4ADE80]" />
          <span className="text-sm font-semibold text-slate-200">
            Click to upload or drag & drop
          </span>
          {hint && <span className="text-[11px] text-slate-500">{hint}</span>}
        </button>
      )}

      {/* progress */}
      {progress !== null && (
        <div className="mt-2" role="status">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
            <span className="flex items-center gap-1.5">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-[#4ADE80]" /> Uploading…
            </span>
            <span>{progress}%</span>
          </div>
          <div className="mt-1 h-2 overflow-hidden rounded-full bg-white/8">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#16A34A] to-[#4ADE80] transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <button
            type="button"
            onClick={() => (window as unknown as { __abUploadAbort?: () => void }).__abUploadAbort?.()}
            className="mt-1.5 text-[11px] font-semibold text-red-300 hover:underline"
          >
            Cancel upload
          </button>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        aria-label={`Upload ${label}`}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) startUpload(file);
        }}
      />

      <UrlOr value={value} onChange={onChange} />
    </div>
  );
}

/** Also allow pasting a hosted URL directly. */
function UrlOr({ value, onChange }: { value: string; onChange: (url: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  return editing ? (
    <div className="mt-2 flex gap-2">
      <input
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder="https://example.com/file.mp4"
        className="h-9 flex-1 rounded-lg border border-white/10 bg-[#0b1120] px-3 text-xs text-white outline-none focus:border-[#22C55E]/50"
        aria-label="External file URL"
      />
      <button
        type="button"
        onClick={() => {
          onChange(draft.trim());
          setEditing(false);
        }}
        className="h-9 rounded-lg bg-[#22C55E] px-3 text-xs font-bold text-[#04220f]"
      >
        Use URL
      </button>
    </div>
  ) : (
    <button
      type="button"
      onClick={() => setEditing(true)}
      className="mt-1.5 text-[11px] font-semibold text-slate-400 hover:text-[#4ADE80]"
    >
      …or paste a hosted file URL instead
    </button>
  );
}
