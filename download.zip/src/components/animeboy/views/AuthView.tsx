"use client";

import { useState } from "react";
import { LogIn, UserPlus, Mail, Lock, UserRound } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { navigate, useAppStore, type SessionUser } from "@/store/useAppStore";

export function AuthView({ mode }: { mode: "signin" | "signup" }) {
  const { setUser } = useAppStore();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await api.post<{ user: SessionUser }>(
        mode === "signin" ? "/api/auth/login" : "/api/auth/register",
        mode === "signin" ? { email, password } : { name, email, password }
      );
      setUser(res.user);
      toast.success(mode === "signin" ? `Welcome back, ${res.user.name || res.user.email}!` : "Account created — welcome to ANIME BOY! 🎉");
      navigate("/");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Authentication failed";
      setError(msg);
    } finally {
      setBusy(false);
    }
  };

  const isSignup = mode === "signup";

  return (
    <div className="fade-up mx-auto flex max-w-md flex-col px-4 pb-6 pt-12 sm:px-6">
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/12 glow-green">
          {isSignup ? <UserPlus className="h-8 w-8 text-[#4ADE80]" /> : <LogIn className="h-8 w-8 text-[#4ADE80]" />}
        </span>
        <h1 className="mt-4 text-3xl font-black text-white">
          {isSignup ? "Create Account" : "Welcome Back"}
        </h1>
        <p className="mt-1.5 text-sm text-slate-400">
          {isSignup
            ? "Sign up to save your watchlist and request anime."
            : "Sign in to sync your watchlist across devices."}
        </p>
      </div>

      <form onSubmit={submit} className="mt-8 space-y-4 rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-7" noValidate>
        {isSignup && (
          <IconField icon={UserRound} label="Username (optional)">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="3–20 letters, numbers or underscores"
              aria-label="Username"
              autoComplete="username"
              spellCheck={false}
              maxLength={20}
              className={inputCls}
            />
          </IconField>
        )}

        <IconField icon={Mail} label="Email">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            aria-label="Email address"
            aria-required="true"
            autoComplete="email"
            required
            className={inputCls}
          />
        </IconField>

        <IconField icon={Lock} label="Password">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={isSignup ? "At least 6 characters" : "Your password"}
            aria-label="Password"
            aria-required="true"
            autoComplete={isSignup ? "new-password" : "current-password"}
            required
            minLength={6}
            className={inputCls}
          />
        </IconField>

        {error && (
          <p role="alert" className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="h-12 w-full rounded-xl bg-[#22C55E] font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:opacity-60"
        >
          {busy ? "Please wait…" : isSignup ? "Create Account" : "Sign In"}
        </button>

        <p className="text-center text-sm text-slate-400">
          {isSignup ? "Already have an account?" : "New to ANIME BOY?"}{" "}
          <button
            type="button"
            onClick={() => navigate(isSignup ? "/signin" : "/signup")}
            className="font-bold text-[#4ADE80] hover:underline"
          >
            {isSignup ? "Sign In" : "Create one free"}
          </button>
        </p>

        {!isSignup && (
          <p className="text-center">
            <button
              type="button"
              onClick={() => navigate("/forgot-password")}
              className="text-sm font-semibold text-[#4ADE80]/90 hover:text-[#4ADE80] hover:underline"
            >
              Forgot password?
            </button>
          </p>
        )}
      </form>
    </div>
  );
}

const inputCls =
  "h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] pl-11 pr-4 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25";

function IconField({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-bold text-slate-200">{label}</span>
      <span className="relative block">
        <Icon className="pointer-events-none absolute left-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-slate-500" />
        {children}
      </span>
    </label>
  );
}
