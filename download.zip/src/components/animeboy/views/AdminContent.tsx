"use client";

import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Plus, Pencil, Trash2, Eye, EyeOff, Star, Search, ArrowLeft, ArrowUp, ArrowDown,
  ListVideo, Film, MonitorPlay, Brush, TvMinimalPlay, Save, Loader2, Upload as UploadIcon,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import type { AnimeType, EpisodeType, SeasonType } from "@/store/useAppStore";
import { UploadWidget } from "./UploadWidget";
import { VideoSourceEditor, type VideoSourceValue } from "./VideoSourceEditor";

type AdminAnime = AnimeType & { seasonCount?: number };

/* Library filter tabs — the five independent content types. */
const LIB_FILTERS = [
  { key: "all", label: "All", category: "", type: "" },
  { key: "anime-movies", label: "Anime Movies", category: "ANIME", type: "MOVIE" },
  { key: "anime-series", label: "Anime Series", category: "ANIME", type: "SERIES" },
  { key: "donghua", label: "Donghua Movie", category: "DONGHUA", type: "MOVIE" },
  { key: "donghua-series", label: "Donghua Series", category: "DONGHUA", type: "SERIES" },
  { key: "others", label: "Others", category: "OTHERS", type: "" },
] as const;

/* ----------------------------- content list ----------------------------- */

export function AdminContent() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [filterKey, setFilterKey] = useState<string>("all");
  const [editing, setEditing] = useState<AdminAnime | "new" | null>(null);
  const [managingSeries, setManagingSeries] = useState<AdminAnime | null>(null);

  const filter = LIB_FILTERS.find((f) => f.key === filterKey) || LIB_FILTERS[0];
  const filterQs = new URLSearchParams();
  if (q.trim()) filterQs.set("q", q.trim());
  if (filter.category) filterQs.set("category", filter.category);
  if (filter.type) filterQs.set("type", filter.type);

  const { data, isLoading, isError, refetch } = useQuery<{ items: AdminAnime[] }>({
    queryKey: ["admin-anime", filterQs.toString()],
    queryFn: () => api.get(`/api/admin/anime?${filterQs.toString()}`),
  });

  const mutate = async (fn: () => Promise<unknown>, okMsg: string) => {
    try {
      await fn();
      toast.success(okMsg);
      qc.invalidateQueries({ queryKey: ["admin-anime"] });
      qc.invalidateQueries({ queryKey: ["sections"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Action failed");
    }
  };

  if (managingSeries) {
    return <SeriesManager anime={managingSeries} onBack={() => setManagingSeries(null)} />;
  }

  if (editing) {
    return (
      <AnimeEditor
        existing={editing === "new" ? null : editing}
        onBack={() => setEditing(null)}
      />
    );
  }

  return (
    <div>
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <h2 className="text-lg font-black text-white">Content Library</h2>
          <p className="text-sm text-slate-400">{data?.items.length ?? 0} titles in this view</p>
        </div>
        <div className="flex-1" />
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search titles…"
            aria-label="Search content"
            className="h-10 w-48 rounded-full border border-white/10 bg-white/[0.04] pl-9 pr-3 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50"
          />
        </div>
        <button
          onClick={() => setEditing("new")}
          className="inline-flex h-10 items-center gap-1.5 rounded-full bg-[#22C55E] px-4 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
        >
          <Plus className="h-4 w-4" /> Add Content
        </button>
      </div>

      {/* content type filter — five independent categories */}
      <div className="mt-4 flex flex-wrap gap-1.5" role="group" aria-label="Filter content by category">
        {LIB_FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilterKey(f.key)}
            aria-pressed={filterKey === f.key}
            className={`h-9 rounded-full px-4 text-[13px] font-semibold transition-colors ${
              filterKey === f.key
                ? "bg-[#22C55E] text-[#04220f]"
                : "border border-white/10 bg-white/[0.04] text-slate-300 hover:border-[#22C55E]/40 hover:text-white"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="mt-5 overflow-hidden rounded-2xl border border-white/8">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead>
              <tr className="border-b border-white/8 bg-white/[0.03] text-xs uppercase tracking-wider text-slate-400">
                <th className="px-4 py-3 font-bold">Title</th>
                <th className="px-4 py-3 font-bold">Type</th>
                <th className="px-4 py-3 font-bold">Year</th>
                <th className="px-4 py-3 font-bold">Rating</th>
                <th className="px-4 py-3 font-bold">Status</th>
                <th className="px-4 py-3 font-bold">Live</th>
                <th className="px-4 py-3 font-bold">Featured</th>
                <th className="px-4 py-3 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-slate-400">Loading…</td>
                </tr>
              ) : isError ? (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-red-300">
                    Failed to load — check that you are signed in as an admin.
                  </td>
                </tr>
              ) : (
                data?.items.map((a) => (
                  <tr key={a.id} className="border-b border-white/5 transition-colors hover:bg-white/[0.02]">
                    <td className="max-w-56 px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        {a.posterUrl ? (
                          <img src={a.posterUrl} alt="" className="h-11 w-8 shrink-0 rounded object-cover" />
                        ) : (
                          <span className="h-11 w-8 shrink-0 rounded bg-white/8" />
                        )}
                        <span className="min-w-0">
                          <span className="block truncate font-semibold text-white">{a.titleEn}</span>
                          <span className="block truncate text-xs text-slate-500">/{a.slug}</span>
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 text-slate-300">
                        {a.type === "MOVIE" ? <Film className="h-3.5 w-3.5" /> : <MonitorPlay className="h-3.5 w-3.5" />}
                        {a.type}
                      </span>
                      {a.category === "DONGHUA" && (
                        <span className="mt-1 inline-flex items-center gap-1 rounded bg-[#22C55E]/15 px-1.5 py-0.5 text-[10px] font-bold text-[#4ADE80]">
                          <Brush className="h-2.5 w-2.5" /> DONGHUA
                        </span>
                      )}
                      {a.category === "OTHERS" && (
                        <span className="mt-1 inline-flex items-center gap-1 rounded bg-[#22C55E]/15 px-1.5 py-0.5 text-[10px] font-bold text-[#4ADE80]">
                          <Brush className="h-2.5 w-2.5" /> OTHERS
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-300">{a.releaseYear || "—"}</td>
                    <td className="px-4 py-3">
                      {typeof a.rating === "number" ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-[#FACC15]">
                          <Star className="h-3.5 w-3.5 fill-[#FACC15]" /> {a.rating.toFixed(1)}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="px-4 py-3">
                      {a.status === "UPCOMING" ? (
                        <span className="rounded bg-[#F59E0B]/15 px-2 py-0.5 text-xs font-bold text-[#F59E0B]">UPCOMING</span>
                      ) : (
                        <span className="rounded bg-[#22C55E]/15 px-2 py-0.5 text-xs font-bold text-[#4ADE80]">RELEASED</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => mutate(() => api.patch(`/api/admin/anime/${a.id}`, { published: !a.published }), a.published ? "Unpublished" : "Published ✓")}
                        aria-label={a.published ? "Unpublish" : "Publish"}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg ${a.published ? "text-[#4ADE80]" : "text-slate-500"}`}
                        title={a.published ? "Live — click to unpublish" : "Draft — click to publish"}
                      >
                        {a.published ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => mutate(() => api.patch(`/api/admin/anime/${a.id}`, { featured: !a.featured }), a.featured ? "Removed from hero carousel" : "Added to hero carousel ✓")}
                        aria-label="Toggle featured"
                        className={`flex h-8 w-8 items-center justify-center rounded-lg ${a.featured ? "text-[#FACC15]" : "text-slate-600"}`}
                        title="Toggle hero carousel"
                      >
                        <Star className={`h-4 w-4 ${a.featured ? "fill-[#FACC15]" : ""}`} />
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        {a.type === "SERIES" && (
                          <button
                            onClick={() => setManagingSeries(a)}
                            aria-label="Manage seasons and episodes"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
                            title="Seasons & episodes"
                          >
                            <ListVideo className="h-4 w-4" />
                          </button>
                        )}
                        <button
                          onClick={() => setEditing(a)}
                          aria-label="Edit"
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete "${a.titleEn}"? This also removes its seasons, episodes and watchlist entries.`)) {
                              mutate(() => api.delete(`/api/admin/anime/${a.id}`), "Deleted");
                            }
                          }}
                          aria-label="Delete"
                          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- anime editor ----------------------------- */

const GENRES = ["Action", "Adventure", "Comedy", "Drama", "Fantasy", "Mystery", "Romance", "School", "Sci-Fi", "Slice of Life", "Supernatural"];

/**
 * True when the admin actually attached a playable video source (upload with a
 * file URL, external URL, or a provider embed). Used to decide whether creating
 * a series should also seed Season 1 · Episode 1 with that source.
 */
export function sourceAttached(vs: VideoSourceValue): boolean {
  if (vs.videoSource === "embed") return !!vs.embedUrl.trim();
  return !!vs.videoUrl.trim();
}

export function seedSource(existing: {
  videoSource?: string;
  videoUrl?: string | null;
  embedUrl?: string | null;
  videoQualities?: unknown;
  subtitleTracks?: unknown;
  altSources?: unknown;
  subtitleUrl?: string | null;
  videoThumb?: string | null;
  thumbnailUrl?: string | null;
  downloadEnabled?: boolean;
  downloadUrl?: string | null;
  downloadQualities?: unknown;
  subtitleDownloadEnabled?: boolean;
  subtitleDownloads?: unknown;
} | null): VideoSourceValue {
  const tracks = (existing?.subtitleTracks as VideoSourceValue["subtitles"]) || [];
  const legacySub = existing?.subtitleUrl;
  return {
    videoSource: (existing?.videoSource as VideoSourceValue["videoSource"]) || "upload",
    videoUrl: existing?.videoUrl || "",
    embedUrl: existing?.embedUrl || "",
    qualities: (existing?.videoQualities as VideoSourceValue["qualities"]) || [],
    subtitles: tracks.length
      ? tracks
      : legacySub
        ? [{ label: "සිංහල", lang: "si", url: legacySub }]
        : [],
    altSources: (existing?.altSources as VideoSourceValue["altSources"]) || [],
    videoThumb: existing?.videoThumb || existing?.thumbnailUrl || "",
    downloadEnabled: !!existing?.downloadEnabled,
    downloadUrl: existing?.downloadUrl || "",
    downloadQualities: (existing?.downloadQualities as VideoSourceValue["downloadQualities"]) || [],
    subtitleDownloadEnabled: !!existing?.subtitleDownloadEnabled,
    subtitleDownloads: (existing?.subtitleDownloads as VideoSourceValue["subtitleDownloads"]) || [],
  };
}

export function AnimeEditor({ existing, onBack, backLabel = "Back to library" }: { existing: AdminAnime | null; onBack: () => void; backLabel?: string }) {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [vs, setVs] = useState<VideoSourceValue>(seedSource(existing));
  const initialKind =
    existing?.category === "OTHERS"
      ? "others"
      : existing?.category === "DONGHUA"
        ? existing?.type === "SERIES"
          ? "donghua-series"
          : "donghua"
        : existing?.type === "SERIES"
          ? "anime-series"
          : "anime-movie";
  const [form, setForm] = useState({
    titleEn: existing?.titleEn || "",
    titleSi: existing?.titleSi || "",
    contentKind: initialKind as "anime-movie" | "anime-series" | "donghua" | "donghua-series" | "others",
    status: existing?.status || "RELEASED",
    descriptionSi: existing?.descriptionSi || "",
    descriptionEn: existing?.descriptionEn || "",
    genres: existing?.genres || [],
    releaseYear: existing?.releaseYear?.toString() || "",
    rating: existing?.rating?.toString() || "",
    languageLabel: (existing?.languageLabel as string) || "SINHALA_DUBBED",
    availability: existing?.availability || "",
    // Optional season/episode labels — only editable for the Others category.
    seasonNumber: existing?.seasonNumber?.toString() || "",
    episodeNumber: existing?.episodeNumber?.toString() || "",
    posterUrl: existing?.posterUrl || "",
    backdropUrl: existing?.backdropUrl || "",
    featured: existing?.featured || false,
    featuredOrder: existing?.featuredOrder?.toString() || "0",
    homeRank: existing?.homeRank?.toString() || "0",
    published: existing?.published ?? true,
  });
  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }));
  const startedRef = useRef(false);

  // content category selector → category + type pair stored in the database
  const KIND_MAP = {
    "anime-movie": { category: "ANIME", type: "MOVIE" },
    "anime-series": { category: "ANIME", type: "SERIES" },
    donghua: { category: "DONGHUA", type: "MOVIE" },
    "donghua-series": { category: "DONGHUA", type: "SERIES" },
    // Others is the flexible bucket: any video with poster/description/download;
    // stored as a movie-style title so playback & downloads work unchanged.
    others: { category: "OTHERS", type: "MOVIE" },
  } as const;
  const kind = KIND_MAP[form.contentKind];

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    startedRef.current = true;
    if (!form.titleEn.trim()) {
      toast.error("English title is required");
      return;
    }
    // Optional Others season/episode labels must be positive integers when filled.
    for (const [label, value] of [
      ["Season number", form.seasonNumber],
      ["Episode number", form.episodeNumber],
    ] as const) {
      const v = value.trim();
      if (v && (!/^\d+$/.test(v) || Number(v) < 1)) {
        toast.error(`${label} must be a positive whole number (1, 2, 3, 4, 5 …) or left empty`);
        return;
      }
    }
    setSaving(true);
    try {
      const payload = {
        ...form,
        ...kind,
        ...vs,
        // The API reads playback subtitle tracks as `subtitleTracks` and quality
        // variants as `videoQualities`; the editor state calls them `subtitles`
        // and `qualities`. Send both spellings so saving never wipes tracks.
        subtitleTracks: vs.subtitles,
        videoQualities: vs.qualities,
        subtitleUrl: "",
      };
      delete (payload as Record<string, unknown>).contentKind;
      let created: AnimeType | null = null;
      if (existing) {
        await api.patch(`/api/admin/anime/${existing.id}`, payload);
        toast.success("Saved ✓");
      } else {
        const res = await api.post<{ anime: AnimeType }>("/api/admin/anime", payload);
        created = res.anime;
        toast.success("Anime created ✓");
      }
      // Series + a video source → seed "Season 1 · Episode 1" with that exact
      // source so the cloud video link saved on this form actually plays.
      // Only on CREATION — editing never touches existing seasons/episodes.
      if (created && kind.type === "SERIES" && sourceAttached(vs)) {
        try {
          const { season } = await api.post<{ season: SeasonType }>("/api/admin/seasons", {
            animeId: created.id,
            number: 1,
          });
          await api.post("/api/admin/episodes", {
            seasonId: season.id,
            number: 1,
            title: "Episode 1",
            ...vs,
            subtitleTracks: vs.subtitles,
            videoQualities: vs.qualities,
            thumbnailUrl: vs.videoThumb,
            subtitleUrl: "",
          });
          toast.success("Season 1 · Episode 1 created with this video source ✓");
        } catch (epErr) {
          toast.warning(
            epErr instanceof Error
              ? `Series created, but Season 1 · Episode 1 could not be created: ${epErr.message}`
              : "Series created, but Season 1 · Episode 1 could not be created"
          );
        }
      }
      qc.invalidateQueries({ queryKey: ["admin-anime"] });
      qc.invalidateQueries({ queryKey: ["sections"] });
      onBack();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={save} className="fade-up">
      <button type="button" onClick={onBack} className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-300 hover:text-[#4ADE80]">
        <ArrowLeft className="h-4 w-4" /> {backLabel}
      </button>
      <h2 className="mt-3 text-lg font-black text-white">{existing ? `Edit — ${existing.titleEn}` : "Add New Content"}</h2>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        {/* left column: text fields */}
        <div className="space-y-4 rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          <Field label="English title *">
            <input value={form.titleEn} onChange={(e) => set({ titleEn: e.target.value })} className={inputCls} required />
          </Field>
          <Field label="සිංහල නම (Sinhala title)">
            <input value={form.titleSi} onChange={(e) => set({ titleSi: e.target.value })} className={inputCls} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="SELECT CONTENT CATEGORY">
              <select
                value={form.contentKind}
                onChange={(e) => set({ contentKind: e.target.value as typeof form.contentKind })}
                className={selectCls}
                aria-label="Select content category"
              >
                <option value="anime-movie" className="bg-[#0b1120]">Anime Movie</option>
                <option value="anime-series" className="bg-[#0b1120]">Anime Series</option>
                <option value="donghua" className="bg-[#0b1120]">Donghua Movie</option>
                <option value="donghua-series" className="bg-[#0b1120]">Donghua Series</option>
                <option value="others" className="bg-[#0b1120]">Others</option>
              </select>
            </Field>
            <Field label="Status">
              <select value={form.status} onChange={(e) => set({ status: e.target.value as "RELEASED" | "UPCOMING" })} className={selectCls}>
                <option value="RELEASED" className="bg-[#0b1120]">Released</option>
                <option value="UPCOMING" className="bg-[#0b1120]">Coming soon (upcoming)</option>
              </select>
            </Field>
          </div>
          {form.contentKind === "others" && (
            <div className="grid grid-cols-2 gap-3">
              <Field label="Season number (optional)">
                <input
                  value={form.seasonNumber}
                  onChange={(e) => set({ seasonNumber: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                  placeholder="e.g. 1"
                  inputMode="numeric"
                  className={inputCls}
                  aria-label="Season number (optional)"
                />
              </Field>
              <Field label="Episode number (optional)">
                <input
                  value={form.episodeNumber}
                  onChange={(e) => set({ episodeNumber: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                  placeholder="e.g. 1"
                  inputMode="numeric"
                  className={inputCls}
                  aria-label="Episode number (optional)"
                />
              </Field>
            </div>
          )}
          <Field label="සිංහල විස්තරය (Sinhala description)">
            <textarea value={form.descriptionSi} onChange={(e) => set({ descriptionSi: e.target.value })} rows={4} className={areaCls} />
          </Field>
          <Field label="English description">
            <textarea value={form.descriptionEn} onChange={(e) => set({ descriptionEn: e.target.value })} rows={3} className={areaCls} />
          </Field>
          <Field label="Genres">
            <div className="flex flex-wrap gap-1.5">
              {GENRES.map((g) => {
                const on = form.genres.includes(g);
                return (
                  <button
                    key={g}
                    type="button"
                    aria-pressed={on}
                    onClick={() => set({ genres: on ? form.genres.filter((x) => x !== g) : [...form.genres, g] })}
                    className={`rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                      on ? "bg-[#22C55E] text-[#04220f]" : "border border-white/10 text-slate-300 hover:border-[#22C55E]/40"
                    }`}
                  >
                    {g}
                  </button>
                );
              })}
            </div>
          </Field>
        </div>

        {/* right column: meta + media + placement */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 rounded-2xl border border-white/8 bg-white/[0.02] p-5">
            <Field label="Release year">
              <input value={form.releaseYear} onChange={(e) => set({ releaseYear: e.target.value.replace(/\D/g, "").slice(0, 4) })} placeholder="2024" inputMode="numeric" className={inputCls} />
            </Field>
            <Field label="Rating (0–10)">
              <input value={form.rating} onChange={(e) => set({ rating: e.target.value })} placeholder="8.5" inputMode="decimal" className={inputCls} />
            </Field>
            <Field label="Language label">
              <select value={form.languageLabel} onChange={(e) => set({ languageLabel: e.target.value })} className={selectCls}>
                <option value="SINHALA_DUBBED" className="bg-[#0b1120]">Sinhala Dubbed</option>
                <option value="SINHALA_SUB" className="bg-[#0b1120]">Sinhala Sub</option>
                <option value="ANIME_REVIEW" className="bg-[#0b1120]">Anime Review</option>
              </select>
            </Field>
            <Field label="Availability note">
              <input value={form.availability} onChange={(e) => set({ availability: e.target.value })} placeholder="සිංහල හඬ කැවූ" className={inputCls} />
            </Field>
            <Field label="Hero carousel order">
              <input value={form.featuredOrder} onChange={(e) => set({ featuredOrder: e.target.value.replace(/\D/g, "") })} placeholder="0" inputMode="numeric" className={inputCls} />
            </Field>
            <Field label="Home row rank (lower first)">
              <input value={form.homeRank} onChange={(e) => set({ homeRank: e.target.value.replace(/\D/g, "") })} placeholder="0" inputMode="numeric" className={inputCls} />
            </Field>
            <label className="col-span-2 flex items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
              <input type="checkbox" checked={form.featured} onChange={(e) => set({ featured: e.target.checked })} className="h-4 w-4 accent-[#22C55E]" />
              <span className="text-sm font-semibold text-slate-200">Show in hero carousel (featured)</span>
            </label>
            <label className="col-span-2 flex items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
              <input type="checkbox" checked={form.published} onChange={(e) => set({ published: e.target.checked })} className="h-4 w-4 accent-[#22C55E]" />
              <span className="text-sm font-semibold text-slate-200">Published (visible to everyone)</span>
            </label>
          </div>

          <div className="space-y-4 rounded-2xl border border-white/8 bg-white/[0.02] p-5">
            <UploadWidget kind="poster" label="Poster (portrait 2:3)" accept="image/jpeg,image/png,image/webp,image/avif" value={form.posterUrl} onChange={(url) => set({ posterUrl: url })} hint="JPG / PNG / WebP up to 10 MB" />
            <UploadWidget kind="backdrop" label="Backdrop (wide)" accept="image/jpeg,image/png,image/webp,image/avif" value={form.backdropUrl} onChange={(url) => set({ backdropUrl: url })} hint="Used in hero carousel & detail page" />
            {/* Video Source is shown for EVERY category — the exact same editor
                movies use (Upload file / External URL / Provider embed + Preview
                Video). For series it is the series' cloud video source: creating
                the series seeds Season 1 · Episode 1 with it, and episodes
                without their own source fall back to it at playback time. */}
            <VideoSourceEditor
              value={vs}
              onChange={setVs}
              title={form.titleEn || (kind.type === "SERIES" ? "Series video" : "Movie video")}
            />
            {form.contentKind === "others" && (
              <p className="rounded-xl border border-[#22C55E]/25 bg-[#22C55E]/[0.05] p-3 text-xs text-slate-300">
                <strong className="text-[#4ADE80]">Others</strong> accepts any type of video — title, description, poster,
                video source and download URL all work exactly like a movie. Season and episode numbers are optional
                labels shown on the details page; leave them empty for standalone videos. For multi-episode
                <strong className="text-[#4ADE80]"> Others playlists</strong>, use the <strong className="text-[#4ADE80]">Playlists</strong> tab instead.
              </p>
            )}
            {form.contentKind === "anime-series" && (
              <p className="rounded-xl border border-white/8 bg-[#0b1120] p-3 text-xs text-slate-400">
                <strong className="text-[#4ADE80]">Anime Series</strong> — the Video Source above is this series' cloud
                video: creating the series with a source attached seeds <strong className="text-[#4ADE80]">Season 1 ·
                Episode 1</strong> automatically, and any episode without its own source plays it. Attach a different
                video to each episode later via the <strong className="text-[#4ADE80]">Playlists</strong> tab
                (Upload Episode) or the <strong className="text-[#4ADE80]">Seasons &amp; Episodes</strong> manager in the
                library — every episode keeps its own independent source &amp; download URL.
              </p>
            )}
            {form.contentKind === "donghua-series" && (
              <p className="rounded-xl border border-[#22C55E]/25 bg-[#22C55E]/[0.05] p-3 text-xs text-slate-300">
                <strong className="text-[#4ADE80]">Donghua Series</strong> works exactly like Anime Series — the Video
                Source above is saved with the series (creating it seeds <strong className="text-[#4ADE80]">Season 1 ·
                Episode 1</strong>; episodes without their own source play it), and season name &amp; number, episode
                number, episode title, per-episode video URL, thumbnail and subtitles are managed under the
                <strong className="text-[#4ADE80]"> Playlists</strong> tab or <strong className="text-[#4ADE80]">Seasons
                &amp; Episodes</strong> in the library.
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="sticky bottom-4 z-10 mt-6 flex items-center justify-end gap-3 rounded-2xl border border-white/10 bg-[#0b1120]/95 p-3 backdrop-blur">
        <button type="button" onClick={onBack} className="h-10 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white">
          Cancel
        </button>
        <button
          type="submit"
          disabled={saving}
          className="inline-flex h-10 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {existing ? "Save Changes" : "Create Content"}
        </button>
      </div>
    </form>
  );
}

/* ---------------------------- series manager ---------------------------- */

export function SeriesManager({ anime, onBack, backLabel = "Back to library" }: { anime: AdminAnime; onBack: () => void; backLabel?: string }) {
  const qc = useQueryClient();
  const [openSeason, setOpenSeason] = useState<number | null>(anime.seasons?.[0]?.number ?? 1);

  const { data, isLoading } = useQuery<{ anime: AnimeType }>({
    queryKey: ["anime", anime.slug],
    queryFn: () => api.get(`/api/anime/${anime.slug}`),
  });

  // Seasons are always shown in ascending order (Season 1 → N), matching the
  // watch page and the public API.
  const seasons = [...(data?.anime.seasons || [])].sort((a, b) => a.number - b.number);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["anime", anime.slug] });
    qc.invalidateQueries({ queryKey: ["admin-anime"] });
    qc.invalidateQueries({ queryKey: ["sections"] });
  };

  /** Move a season up/down by swapping its number with the neighbouring season. */
  const moveSeason = async (season: SeasonType, dir: -1 | 1) => {
    const idx = seasons.findIndex((s) => s.id === season.id);
    const neighbor = seasons[idx + dir];
    if (!neighbor) return;
    try {
      await api.patch(`/api/admin/seasons/${season.id}`, { number: neighbor.number });
      toast.success(`Season order updated ✓`);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not reorder seasons");
    }
  };

  const addSeason = async () => {
    const nextNumber = seasons.length ? Math.max(...seasons.map((s) => s.number)) + 1 : 1;
    try {
      await api.post("/api/admin/seasons", { animeId: anime.id, number: nextNumber });
      toast.success(`Season ${nextNumber} added`);
      setOpenSeason(nextNumber);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not add season");
    }
  };

  return (
    <div className="fade-up">
      <button onClick={onBack} className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-300 hover:text-[#4ADE80]">
        <ArrowLeft className="h-4 w-4" /> {backLabel}
      </button>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        {anime.posterUrl && <img src={anime.posterUrl} alt="" className="h-14 w-10 rounded-lg object-cover" />}
        <div>
          <h2 className="text-lg font-black text-white">{anime.titleEn}</h2>
          <p className="text-sm text-slate-400">Seasons & episodes management</p>
        </div>
        <div className="flex-1" />
        <button
          onClick={addSeason}
          className="inline-flex h-10 items-center gap-1.5 rounded-full bg-[#22C55E] px-4 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
        >
          <Plus className="h-4 w-4" /> Add Season
        </button>
      </div>

      {isLoading ? (
        <p className="mt-8 text-slate-400">Loading seasons…</p>
      ) : seasons.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-white/10 px-6 py-12 text-center text-slate-400">
          No seasons yet. Click <strong className="text-[#4ADE80]">Add Season</strong> to create Season 1.
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          {seasons.map((s, i) => (
            <SeasonBlock
              key={s.id}
              season={s}
              animeId={anime.id}
              open={openSeason === s.number}
              onToggle={() => setOpenSeason(openSeason === s.number ? null : s.number)}
              onChanged={invalidate}
              onMove={(dir) => moveSeason(s, dir)}
              isFirst={i === 0}
              isLast={i === seasons.length - 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function SeasonBlock({
  season,
  animeId,
  open,
  onToggle,
  onChanged,
  onMove,
  isFirst,
  isLast,
}: {
  season: SeasonType;
  animeId: string;
  open: boolean;
  onToggle: () => void;
  onChanged: () => void;
  onMove: (dir: -1 | 1) => void;
  isFirst: boolean;
  isLast: boolean;
}) {
  const [newEp, setNewEp] = useState(false);
  const [editingSeason, setEditingSeason] = useState(false);

  const deleteSeason = async () => {
    if (!window.confirm(`Delete Season ${season.number} and all its episodes?`)) return;
    try {
      await api.delete(`/api/admin/seasons/${season.id}`);
      toast.success("Season deleted");
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  };

  /** Move an episode up/down by swapping numbers with the neighbouring episode. */
  const moveEpisode = async (ep: EpisodeType, dir: -1 | 1) => {
    const idx = season.episodes.findIndex((e) => e.id === ep.id);
    const neighbor = season.episodes[idx + dir];
    if (!neighbor) return;
    try {
      await api.patch(`/api/admin/episodes/${ep.id}`, { number: neighbor.number });
      toast.success("Episode order updated ✓");
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not reorder episodes");
    }
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-white/8 bg-white/[0.02]">
      <div className="flex items-center gap-3 px-4 py-3.5">
        <button onClick={onToggle} className="flex flex-1 items-center gap-3 text-left" aria-expanded={open}>
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#22C55E]/12 font-black text-[#4ADE80]">
            {season.number}
          </span>
          <span>
            {/* Custom season names lead ("Final Season"); numbered-only seasons fall back to "Season N". */}
            <span className="block font-bold text-white">{season.title?.trim() || `Season ${season.number}`}</span>
            <span className="block text-xs text-slate-400">
              Season {season.number} · {season.episodes.length} episode{season.episodes.length === 1 ? "" : "s"}
            </span>
          </span>
        </button>
        <div className="flex items-center gap-0.5" role="group" aria-label={`Season ${season.number} actions`}>
          <button
            onClick={() => onMove(-1)}
            disabled={isFirst}
            aria-label={`Move season ${season.number} up`}
            title="Move season up"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80] disabled:opacity-25 disabled:hover:bg-transparent"
          >
            <ArrowUp className="h-4 w-4" />
          </button>
          <button
            onClick={() => onMove(1)}
            disabled={isLast}
            aria-label={`Move season ${season.number} down`}
            title="Move season down"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80] disabled:opacity-25 disabled:hover:bg-transparent"
          >
            <ArrowDown className="h-4 w-4" />
          </button>
          <button
            onClick={() => setEditingSeason(true)}
            aria-label={`Edit season ${season.number}`}
            title="Edit season number & name"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            onClick={deleteSeason}
            aria-label={`Delete season ${season.number}`}
            title="Delete season"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
          >
            <Trash2 className="h-4 w-4" />
          </button>
          <button onClick={onToggle} aria-label="Toggle season" className="px-2 text-slate-400 hover:text-white">
            {open ? "▾" : "▸"}
          </button>
        </div>
      </div>

      {editingSeason && (
        <div className="border-t border-white/8">
          <SeasonEditForm
            season={season}
            onDone={() => {
              setEditingSeason(false);
              onChanged();
            }}
            onCancel={() => setEditingSeason(false)}
          />
        </div>
      )}

      {open && (
        <div className="border-t border-white/8 p-4">
          <ol className="space-y-2">
            {season.episodes.map((ep, i) => (
              <EpisodeRow
                key={ep.id}
                episode={ep}
                onChanged={onChanged}
                onMove={(dir) => moveEpisode(ep, dir)}
                isFirst={i === 0}
                isLast={i === season.episodes.length - 1}
              />
            ))}
            {season.episodes.length === 0 && (
              <li className="rounded-xl border border-dashed border-white/10 px-4 py-6 text-center text-sm text-slate-500">
                No episodes in this season yet.
              </li>
            )}
          </ol>

          {newEp ? (
            <EpisodeForm
              seasonId={season.id}
              // Suggest the next FREE number (highest existing + 1) — length+1
              // would collide when earlier episodes were deleted (e.g. 1,3 → 3).
              nextNumber={Math.max(0, ...season.episodes.map((e) => e.number)) + 1}
              onDone={() => {
                setNewEp(false);
                onChanged();
              }}
              onCancel={() => setNewEp(false)}
            />
          ) : (
            <button
              onClick={() => setNewEp(true)}
              className="mt-3 inline-flex h-9 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-4 text-xs font-bold text-[#4ADE80] transition-colors hover:bg-[#22C55E]/20"
            >
              <Plus className="h-3.5 w-3.5" /> Add Episode
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function EpisodeRow({
  episode,
  onChanged,
  onMove,
  isFirst,
  isLast,
}: {
  episode: EpisodeType;
  onChanged: () => void;
  onMove: (dir: -1 | 1) => void;
  isFirst: boolean;
  isLast: boolean;
}) {
  const [editing, setEditing] = useState(false);

  const remove = async () => {
    if (!window.confirm(`Delete Episode ${episode.number}?`)) return;
    try {
      await api.delete(`/api/admin/episodes/${episode.id}`);
      toast.success("Episode deleted");
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  };

  if (editing) {
    return (
      <li>
        <EpisodeForm
          seasonId=""
          episode={episode}
          onDone={() => {
            setEditing(false);
            onChanged();
          }}
          onCancel={() => setEditing(false)}
        />
      </li>
    );
  }

  return (
    <li className="flex items-center gap-2 rounded-xl border border-white/8 bg-[#0b1120] px-3.5 py-2.5">
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/8 text-xs font-black text-slate-200">
        {episode.number}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-semibold text-white">{episode.title || `Episode ${episode.number}`}</span>
        <span className="block truncate text-[11px] text-slate-500">
          <EpisodeSourceBadge episode={episode} />
          {episode.subtitleTracks?.length || episode.subtitleUrl ? " · subtitles ✓" : ""}
        </span>
      </span>
      <div className="flex shrink-0 items-center gap-0.5" role="group" aria-label={`Episode ${episode.number} actions`}>
        <button
          onClick={() => onMove(-1)}
          disabled={isFirst}
          aria-label={`Move episode ${episode.number} up`}
          title="Move episode up"
          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-[#4ADE80] disabled:opacity-25 disabled:hover:bg-transparent"
        >
          <ArrowUp className="h-4 w-4" />
        </button>
        <button
          onClick={() => onMove(1)}
          disabled={isLast}
          aria-label={`Move episode ${episode.number} down`}
          title="Move episode down"
          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-[#4ADE80] disabled:opacity-25 disabled:hover:bg-transparent"
        >
          <ArrowDown className="h-4 w-4" />
        </button>
        <button
          onClick={() => setEditing(true)}
          aria-label={`Edit episode ${episode.number}`}
          title="Edit episode"
          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
        >
          <Pencil className="h-4 w-4" />
        </button>
        <button
          onClick={remove}
          aria-label={`Delete episode ${episode.number}`}
          title="Delete episode"
          className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </li>
  );
}

/* --------------------------- season edit form --------------------------- */

function SeasonEditForm({
  season,
  onDone,
  onCancel,
}: {
  season: SeasonType;
  onDone: () => void;
  onCancel: () => void;
}) {
  const [saving, setSaving] = useState(false);
  const [number, setNumber] = useState(String(season.number));
  const [name, setName] = useState(season.title || "");

  const save = async () => {
    const n = Number(number);
    if (!n || n < 1) {
      toast.error("Season number must be 1 or higher");
      return;
    }
    setSaving(true);
    try {
      await api.patch(`/api/admin/seasons/${season.id}`, { number: n, title: name });
      toast.success(`Season ${n} updated ✓`);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-3 bg-[#22C55E]/[0.04] p-4">
      <div className="grid grid-cols-[110px_1fr] gap-2.5">
        <Field label="Season #">
          <input
            value={number}
            onChange={(e) => setNumber(e.target.value.replace(/\D/g, "").slice(0, 3))}
            inputMode="numeric"
            className={inputCls}
            aria-label="Season number"
          />
        </Field>
        <Field label="Season name (optional)">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. The Final Arc"
            className={inputCls}
            aria-label="Season name"
          />
        </Field>
      </div>
      <p className="text-[11px] text-slate-500">
        Changing the season number reorders the season — if another season already uses that number, the two seasons swap positions.
      </p>
      <div className="flex justify-end gap-2">
        <button onClick={onCancel} className="h-9 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white">
          Cancel
        </button>
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex h-9 items-center gap-1.5 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save Season
        </button>
      </div>
    </div>
  );
}

function EpisodeSourceBadge({ episode }: { episode: EpisodeType }) {
  const has = episode.video ? episode.video.kind !== "none" : !!episode.videoUrl || !!episode.embedUrl;
  if (!has) return <span className="text-amber-400">● no video yet</span>;
  const kind = episode.video?.kind;
  if (kind === "embed") return <span className="text-[#4ADE80]">● {episode.video?.providerLabel || "embed"} embed</span>;
  if (kind === "signed") return <span className="text-sky-300">● private bucket (signed)</span>;
  if (kind === "hls") return <span className="text-[#4ADE80]">● HLS stream</span>;
  if (episode.videoSource === "external") return <span className="text-[#4ADE80]">● external URL</span>;
  return <span className="text-[#4ADE80]">● video attached</span>;
}

function EpisodeForm({
  seasonId,
  episode,
  nextNumber,
  onDone,
  onCancel,
}: {
  seasonId: string;
  episode?: EpisodeType;
  nextNumber?: number;
  onDone: () => void;
  onCancel: () => void;
}) {
  const [saving, setSaving] = useState(false);
  const [vs, setVs] = useState<VideoSourceValue>(
    seedSource({
      videoSource: episode?.videoSource,
      videoUrl: episode?.videoUrl,
      embedUrl: episode?.embedUrl,
      videoQualities: episode?.videoQualities,
      subtitleTracks: episode?.subtitleTracks,
      altSources: episode?.altSources,
      subtitleUrl: episode?.subtitleUrl,
      thumbnailUrl: episode?.thumbnailUrl,
      // Download settings must round-trip too — otherwise saving an episode
      // would silently disable its download buttons and wipe the URLs.
      downloadEnabled: episode?.downloadEnabled,
      downloadUrl: episode?.downloadUrl,
      downloadQualities: episode?.downloadQualities,
      subtitleDownloadEnabled: episode?.subtitleDownloadEnabled,
      subtitleDownloads: episode?.subtitleDownloads,
    })
  );
  const [form, setForm] = useState({
    number: episode?.number?.toString() || nextNumber?.toString() || "1",
    title: episode?.title || "",
    durationSec: episode?.durationSec?.toString() || "",
    description: episode?.description || "",
  });
  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }));

  const save = async () => {
    // Season and episode numbers must be positive integers — validate before
    // hitting the API so the admin gets a precise message, not a generic error.
    const number = Math.floor(Number(form.number));
    if (!/^\d+$/.test((form.number || "").trim()) || number < 1) {
      toast.error("Episode number must be a positive integer (1, 2, 3, 4, 5 …)");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...form,
        number,
        ...vs,
        // Same key-mapping as the anime editor — see note above.
        subtitleTracks: vs.subtitles,
        videoQualities: vs.qualities,
        thumbnailUrl: vs.videoThumb,
        subtitleUrl: "",
      };
      if (episode) {
        await api.patch(`/api/admin/episodes/${episode.id}`, payload);
        toast.success("Episode updated ✓");
      } else {
        await api.post("/api/admin/episodes", { ...payload, seasonId });
        toast.success("Episode added ✓");
      }
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-3 rounded-xl border border-[#22C55E]/30 bg-[#22C55E]/[0.04] p-4">
      <div className="grid grid-cols-[80px_1fr_110px] gap-2.5">
        <Field label="EP #">
          <input
            value={form.number}
            onChange={(e) => set({ number: e.target.value.replace(/\D/g, "").slice(0, 3) })}
            inputMode="numeric"
            className={inputCls}
            aria-label="Episode number"
          />
        </Field>
        <Field label="Episode title">
          <input value={form.title} onChange={(e) => set({ title: e.target.value })} className={inputCls} aria-label="Episode title" />
        </Field>
        <Field label="Duration (sec)">
          <input
            value={form.durationSec}
            onChange={(e) => set({ durationSec: e.target.value.replace(/\D/g, "").slice(0, 5) })}
            inputMode="numeric"
            className={inputCls}
            aria-label="Duration in seconds"
          />
        </Field>
      </div>
      <Field label="Episode description (optional)">
        <input value={form.description} onChange={(e) => set({ description: e.target.value })} className={inputCls} aria-label="Episode description" />
      </Field>

      <VideoSourceEditor value={vs} onChange={setVs} title={episode ? `Episode ${episode.number}` : `Episode ${form.number}`} isEpisode />

      <div className="flex justify-end gap-2">
        <button onClick={onCancel} className="h-9 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white">
          Cancel
        </button>
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex h-9 items-center gap-1.5 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadIcon className="h-4 w-4" />}
          {episode ? "Save Episode" : "Add Episode"}
        </button>
      </div>
    </div>
  );
}

/* ------------------------------- shared ------------------------------- */

const inputCls =
  "h-10 w-full rounded-lg border border-white/10 bg-[#0b1120] px-3 text-sm text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50";
const selectCls = inputCls;
const areaCls =
  "w-full resize-none rounded-lg border border-white/10 bg-[#0b1120] px-3 py-2.5 text-sm text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-400">{label}</span>
      {children}
    </label>
  );
}

export { inputCls, selectCls, areaCls, Field as AdminField };
