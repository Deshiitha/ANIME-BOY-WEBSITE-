"use client";

/**
 * "Support ANIME BOY" ("#/support") — the public donation page.
 *
 *  - Preset + custom amounts in Sri Lankan Rupees, optional donor name,
 *    optional message, anonymous option.
 *  - PayHere hosted checkout (Sri Lankan payment gateway): the browser only
 *    ever receives a pre-signed parameter set — no card data ever touches
 *    this site, and the donation is verified exclusively by PayHere's signed
 *    server callback.
 *  - Optional bank-transfer donations (details configured by the admin),
 *    recorded as PENDING until the site owner verifies the credit.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Banknote,
  CheckCircle2,
  Clock3,
  CreditCard,
  Hash,
  Heart,
  HeartHandshake,
  Loader2,
  PartyPopper,
  PencilLine,
  Phone,
  ShieldCheck,
  TriangleAlert,
  MapPin,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { parseHash, useAppStore } from "@/store/useAppStore";
import { MethodChips } from "./../PaymentMethodBadges";

type DonationConfigResponse = {
  config: {
    donationEnabled: boolean;
    heading: string;
    description: string;
    thankYouNote: string;
    presets: number[];
    publicRecognition: boolean;
    provider: "PAYHERE" | "WEBXPAY" | "NONE";
    gatewayReady: boolean;
    gatewayMode: string;
    gatewayCurrency: string;
    supportedCurrencies: string[];
    supportedMethods: string[];
    bankEnabled: boolean;
    bank: {
      name: string;
      accountName: string;
      accountNumber: string;
      branch: string;
      instructions: string;
    };
  };
};

type DonorWall = {
  enabled: boolean;
  items: { name: string; amountCents: number; message: string | null; createdAt: string }[];
  totalVerifiedCents: number;
  countVerified: number;
};

const inputCls =
  "h-12 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25";

export function SupportView() {
  const { user, route } = useAppStore();
  const [amount, setAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState("");
  const [donorName, setDonorName] = useState("");
  const [donorEmail, setDonorEmail] = useState("");
  const [message, setMessage] = useState("");
  const [anonymous, setAnonymous] = useState(false);
  const [method, setMethod] = useState<"GATEWAY" | "BANK_TRANSFER">("GATEWAY");
  const [bankRef, setBankRef] = useState("");
  const [phone, setPhone] = useState("");
  const [addressLine1, setAddressLine1] = useState("");
  const [city, setCity] = useState("");
  const [busy, setBusy] = useState(false);
  const submittedRef = useRef(false);

  const { data: cfg } = useQuery({
    queryKey: ["donation-config"],
    queryFn: () => api.get<DonationConfigResponse>("/api/donations/config"),
    staleTime: 30_000,
  });
  const wall = useQuery({
    queryKey: ["donor-wall"],
    queryFn: () => api.get<DonorWall>("/api/donations/public"),
    staleTime: 30_000,
  });

  const config = cfg?.config;
  const providerName = config?.provider === "WEBXPAY" ? "WebXPay" : "PayHere";
  const currency = config?.gatewayCurrency || "LKR";
  const amountPrefix = currency === "LKR" ? "Rs." : currency;
  const needsWebxpayDetails = config?.provider === "WEBXPAY" && config?.gatewayReady;
  const effectiveMethod = method === "GATEWAY" && !config?.gatewayReady ? "BANK_TRANSFER" : method;

  // Pre-fill from the signed-in account.
  useEffect(() => {
    if (user) {
      setDonorName((n) => n || user.name || "");
      setDonorEmail((e) => e || user.email);
    }
  }, [user]);

  /* ------------------- post-payment return banner + polling ------------------- */
  const returnOrderId = route.query.get("donation") || parseHash(typeof window !== "undefined" ? window.location.hash : "").query.get("donation") || "";
  const returnResult = route.query.get("result");
  const status = useQuery({
    queryKey: ["donation-status", returnOrderId],
    queryFn: () => api.get<{ donation: { orderId: string; status: string; method: string; amountCents: number; donorLabel: string } }>(`/api/donations/status?orderId=${encodeURIComponent(returnOrderId)}`),
    enabled: !!returnOrderId,
    refetchInterval: (q) => (q.state.data?.donation.status === "PENDING" ? 5000 : false),
    refetchIntervalInBackground: false,
    retry: 1,
  });

  /* ------------------------------- submit -------------------------------- */
  const finalAmount = useMemo(() => {
    if (amount !== null) return amount;
    const n = Number(customAmount);
    return Number.isFinite(n) && n > 0 ? Math.round(n) : null;
  }, [amount, customAmount]);

  const donateNow = async () => {
    if (!config?.donationEnabled) return;
    if (finalAmount === null) {
      toast.error("Please choose or enter a donation amount");
      return;
    }
    if (effectiveMethod === "GATEWAY" && !donorEmail.trim()) {
      toast.error("An email address is required for online payments (for the receipt)");
      return;
    }
    if (needsWebxpayDetails && effectiveMethod === "GATEWAY") {
      if (!phone.trim()) {
        toast.error("A contact number is required by the payment gateway");
        return;
      }
      if (!addressLine1.trim()) {
        toast.error("An address line is required by the payment gateway");
        return;
      }
    }

    setBusy(true);
    try {
      const res = await api.post<{
        donation: { orderId: string };
        next: string;
        payhere?: { action: string; params: Record<string, string> };
        webxpay?: { action: string; params: Record<string, string> };
      }>("/api/donations", {
        method: effectiveMethod,
        amount: finalAmount,
        currency,
        donorName: donorName.trim() || undefined,
        donorEmail: donorEmail.trim() || undefined,
        message: message.trim() || undefined,
        anonymous,
        reference: effectiveMethod === "BANK_TRANSFER" && bankRef.trim() ? bankRef.trim() : undefined,
        phone: phone.trim() || undefined,
        addressLine1: addressLine1.trim() || undefined,
        city: city.trim() || undefined,
      });

      const checkout =
        res.next === "PAYHERE_CHECKOUT" && res.payhere
          ? res.payhere
          : res.next === "WEBXPAY_CHECKOUT" && res.webxpay
            ? res.webxpay
            : null;
      if (checkout) {
        // Native form POST to the provider's hosted checkout — card details are
        // entered on the provider's PCI-compliant page, never on this website.
        if (submittedRef.current) return;
        submittedRef.current = true;
        const form = document.createElement("form");
        form.method = "POST";
        form.action = checkout.action;
        form.style.display = "none";
        for (const [key, value] of Object.entries(checkout.params)) {
          const input = document.createElement("input");
          input.type = "hidden";
          input.name = key;
          input.value = value;
          form.appendChild(input);
        }
        document.body.appendChild(form);
        form.submit();
        return;
      }

      // Bank transfer recorded — pending manual verification.
      toast.success("Thank you! Your donation is recorded 💚", {
        description: "The site owner will verify the bank credit shortly — thank you for supporting ANIME BOY!",
        duration: 8000,
      });
      setBankRef("");
      setMessage("");
      wall.refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not start the donation");
    } finally {
      setBusy(false);
      setTimeout(() => (submittedRef.current = false), 1500);
    }
  };

  /* ------------------------------- states -------------------------------- */
  if (!cfg) {
    return (
      <div className="flex items-center justify-center gap-3 py-28 text-slate-400">
        <Loader2 className="h-5 w-5 animate-spin" /> Loading…
      </div>
    );
  }

  if (!config?.donationEnabled) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#22C55E]/10">
          <Heart className="h-8 w-8 text-[#4ADE80]" />
        </span>
        <h1 className="mt-4 text-2xl font-black text-white">Support ANIME BOY 💚</h1>
        <p className="mt-2 text-sm text-slate-400">
          Donations are temporarily paused. Please check back soon — thank you for wanting to support the community!
        </p>
      </div>
    );
  }

  const presets = config.presets.length ? config.presets : [100, 250, 500, 1000, 2000, 5000];
  const gatewayUsable = config.gatewayReady;
  const bankUsable = config.bankEnabled;
  const noMethod = !gatewayUsable && !bankUsable;

  return (
    <div className="fade-up mx-auto max-w-3xl px-4 pb-12 pt-8 sm:px-6">
      {/* hero */}
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-[#22C55E]/12 glow-green">
          <Heart className="h-8 w-8 text-[#4ADE80]" fill="currentColor" />
        </span>
        <h1 className="mt-4 text-3xl font-black text-white sm:text-4xl">{config.heading}</h1>
        <p className="mx-auto mt-2 max-w-xl text-sm leading-relaxed text-slate-400 sm:text-base">{config.description}</p>
        <p className="mx-auto mt-3 max-w-xl text-xs leading-relaxed text-slate-500">{config.thankYouNote}</p>
      </div>

      {/* post-payment confirmation */}
      {returnOrderId && status.data?.donation && (
        <div
          role="status"
          aria-live="polite"
          className={`mt-6 overflow-hidden rounded-3xl border p-5 sm:p-6 ${
            status.data.donation.status === "VERIFIED"
              ? "border-[#22C55E]/35 bg-[#22C55E]/[0.07]"
              : status.data.donation.status === "PENDING"
                ? "border-amber-400/30 bg-amber-400/[0.06]"
                : "border-red-500/25 bg-red-500/[0.06]"
          }`}
        >
          <div className="flex flex-wrap items-center gap-4">
            <span
              className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
                status.data.donation.status === "VERIFIED"
                  ? "bg-[#22C55E]/15 text-[#4ADE80]"
                  : status.data.donation.status === "PENDING"
                    ? "bg-amber-400/15 text-amber-300"
                    : "bg-red-500/15 text-red-300"
              }`}
            >
              {status.data.donation.status === "VERIFIED" ? (
                <CheckCircle2 className="h-7 w-7" />
              ) : status.data.donation.status === "PENDING" ? (
                <Clock3 className="h-7 w-7" />
              ) : (
                <TriangleAlert className="h-7 w-7" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <p className={`text-lg font-black ${status.data.donation.status === "VERIFIED" ? "text-[#4ADE80]" : status.data.donation.status === "PENDING" ? "text-amber-200" : "text-red-200"}`}>
                {status.data.donation.status === "VERIFIED"
                  ? `Thank you ${status.data.donation.donorLabel}! 💚`
                  : status.data.donation.status === "PENDING"
                    ? returnResult === "cancelled"
                      ? "Payment cancelled — no charge was made."
                      : "Payment received — verifying…"
                    : "This payment did not complete."}
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-slate-400">
                {status.data.donation.status === "PENDING" && returnResult !== "cancelled"
                  ? "We're confirming it with the payment gateway using its secure server callback. This page updates automatically — you can safely close it."
                  : status.data.donation.status === "VERIFIED"
                    ? `Your donation of ${amountPrefix} ${(status.data.donation.amountCents / 100).toLocaleString("en-LK")} was verified and goes towards keeping ANIME BOY running. A confirmation has been recorded for your receipt.`
                    : "You can try again any time — no charge was made."}
              </p>
            </div>
            {status.data.donation.status === "VERIFIED" && (
              <span className="flex items-center gap-1.5 rounded-full bg-[#22C55E]/15 px-3 py-1.5 text-[11px] font-bold text-[#4ADE80]">
                <Hash className="h-3 w-3" /> {status.data.donation.orderId}
              </span>
            )}
          </div>
        </div>
      )}

      {noMethod ? (
        <div className="mt-8 rounded-3xl border border-amber-400/25 bg-amber-400/[0.06] p-6 text-center">
          <TriangleAlert className="mx-auto h-7 w-7 text-amber-300" />
          <p className="mt-3 text-sm leading-relaxed text-amber-100">
            Donations are enabled, but no payment method is configured yet. The site owner can add the PayHere gateway
            (Admin Dashboard → Donations) or bank-transfer details to start accepting support.
          </p>
        </div>
      ) : (
        <div className="mt-8 rounded-3xl border border-white/8 bg-white/[0.03] p-6 sm:p-8" aria-label="Donation form">
          {/* amount picker */}
          <h2 className="flex items-center gap-2 text-base font-black text-white">
            <HeartHandshake className="h-4.5 w-4.5 text-[#4ADE80]" /> Choose an amount ({currency})
          </h2>
          <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4 lg:grid-cols-7">
            {presets.map((p) => {
              const active = amount === p && !customAmount;
              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    setAmount(p);
                    setCustomAmount("");
                  }}
                  aria-pressed={active}
                  className={`flex h-14 items-center justify-center rounded-2xl border text-sm font-black transition-all ${
                    active
                      ? "border-[#22C55E] bg-[#22C55E]/15 text-[#4ADE80] shadow-lg shadow-[#22C55E]/10"
                      : "border-white/10 bg-[#0b1120] text-slate-200 hover:border-[#22C55E]/40"
                  }`}
                >
                  {amountPrefix} {p.toLocaleString("en-LK")}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => {
                setAmount(null);
                document.getElementById("custom-amount-input")?.focus();
              }}
              aria-pressed={!!customAmount}
              className={`flex h-14 items-center justify-center gap-1.5 rounded-2xl border text-sm font-black transition-all ${
                customAmount
                  ? "border-[#22C55E] bg-[#22C55E]/15 text-[#4ADE80]"
                  : "border-white/10 bg-[#0b1120] text-slate-200 hover:border-[#22C55E]/40"
              }`}
            >
              <PencilLine className="h-3.5 w-3.5" /> Custom
            </button>
          </div>
          <div className="mt-3">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Custom amount ({amountPrefix})</span>
              <input
                id="custom-amount-input"
                type="number"
                inputMode="numeric"
                min={10}
                step={1}
                value={customAmount}
                onChange={(e) => {
                  setCustomAmount(e.target.value);
                  setAmount(null);
                }}
                placeholder="e.g. 750"
                aria-label={`Custom donation amount in ${currency}`}
                className={inputCls}
              />
            </label>
          </div>

          {/* donor details */}
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Your name (optional)</span>
              <input
                value={donorName}
                onChange={(e) => setDonorName(e.target.value)}
                placeholder="Name to display"
                maxLength={60}
                aria-label="Donor name (optional)"
                className={inputCls}
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">
                Email {effectiveMethod === "GATEWAY" ? "(required — for your receipt)" : "(optional)"}
              </span>
              <input
                type="email"
                value={donorEmail}
                onChange={(e) => setDonorEmail(e.target.value)}
                placeholder="you@example.com"
                aria-label="Donor email"
                className={inputCls}
              />
            </label>
          </div>

          {/* payment provider contact fields (WebXPay hosted checkout requires them) */}
          {needsWebxpayDetails && effectiveMethod === "GATEWAY" && (
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <label className="block">
                <span className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">
                  <Phone className="h-3 w-3" /> Contact number <span className="normal-case text-[#F59E0B]">(required)</span>
                </span>
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="07X XXX XXXX"
                  inputMode="tel"
                  maxLength={30}
                  aria-label="Contact number"
                  className={inputCls}
                />
              </label>
              <label className="block">
                <span className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">
                  <MapPin className="h-3 w-3" /> Address <span className="normal-case text-[#F59E0B]">(required)</span>
                </span>
                <input
                  value={addressLine1}
                  onChange={(e) => setAddressLine1(e.target.value)}
                  placeholder="Street / city line"
                  maxLength={120}
                  aria-label="Address line"
                  className={inputCls}
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">City (optional)</span>
                <input
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Colombo"
                  maxLength={60}
                  aria-label="City"
                  className={inputCls}
                />
              </label>
            </div>
          )}
          <label className="mt-4 block">
            <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Support message (optional)</span>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Say something nice to the community…"
              maxLength={280}
              rows={2}
              aria-label="Support message (optional)"
              className={`${inputCls} h-auto py-3`}
            />
          </label>
          <label className="mt-4 flex cursor-pointer items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
            <input
              type="checkbox"
              checked={anonymous}
              onChange={(e) => setAnonymous(e.target.checked)}
              className="h-4 w-4 accent-[#22C55E]"
            />
            <span className="text-sm text-slate-200">
              Donate anonymously <span className="text-[11px] text-slate-500">— your name stays private everywhere</span>
            </span>
          </label>

          {/* payment method */}
          <h2 className="mt-7 flex items-center gap-2 text-base font-black text-white">
            <ShieldCheck className="h-4.5 w-4.5 text-[#4ADE80]" /> Payment method
          </h2>
          <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
            {gatewayUsable && (
              <button
                type="button"
                onClick={() => setMethod("GATEWAY")}
                aria-pressed={effectiveMethod === "GATEWAY"}
                className={`flex items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                  effectiveMethod === "GATEWAY" ? "border-[#22C55E] bg-[#22C55E]/10" : "border-white/10 bg-[#0b1120] hover:border-[#22C55E]/40"
                }`}
              >
                <CreditCard className={`mt-0.5 h-5 w-5 shrink-0 ${effectiveMethod === "GATEWAY" ? "text-[#4ADE80]" : "text-slate-400"}`} />
                <span className="min-w-0">
                  <span className="block text-sm font-bold text-white">
                    Card / Wallet / Banking ({providerName})
                    {config.gatewayMode !== "live" && <span className="ml-1.5 rounded bg-[#F59E0B]/15 px-1.5 py-0.5 text-[9.5px] font-black uppercase text-[#F59E0B]">{config.gatewayMode}</span>}
                  </span>
                  <MethodChips methods={config.supportedMethods} className="mt-1.5" />
                  <span className="mt-1.5 block text-[11px] leading-relaxed text-slate-400">
                    Secure hosted checkout — you'll pick the exact method on {providerName}&apos;s page. Card details never touch this site.
                  </span>
                </span>
              </button>
            )}
            {bankUsable && (
              <button
                type="button"
                onClick={() => setMethod("BANK_TRANSFER")}
                aria-pressed={effectiveMethod === "BANK_TRANSFER"}
                className={`flex items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                  effectiveMethod === "BANK_TRANSFER" ? "border-[#22C55E] bg-[#22C55E]/10" : "border-white/10 bg-[#0b1120] hover:border-[#22C55E]/40"
                }`}
              >
                <Banknote className={`mt-0.5 h-5 w-5 shrink-0 ${effectiveMethod === "BANK_TRANSFER" ? "text-[#4ADE80]" : "text-slate-400"}`} />
                <span>
                  <span className="block text-sm font-bold text-white">Bank transfer</span>
                  <span className="mt-0.5 block text-[11px] leading-relaxed text-slate-400">
                    Deposit to our bank account and record your donation for verification.
                  </span>
                </span>
              </button>
            )}
          </div>

          {/* bank details + reference */}
          {effectiveMethod === "BANK_TRANSFER" && (
            <div className="mt-4 rounded-2xl border border-sky-400/20 bg-sky-400/[0.05] p-4">
              <h3 className="text-sm font-bold text-sky-100">Bank account details</h3>
              <dl className="mt-2 space-y-1 text-[13px] leading-relaxed text-slate-300">
                {config.bank.name && (
                  <div className="flex gap-2">
                    <dt className="w-32 shrink-0 text-slate-400">Bank</dt>
                    <dd className="font-semibold text-white">{config.bank.name}</dd>
                  </div>
                )}
                {config.bank.branch && (
                  <div className="flex gap-2">
                    <dt className="w-32 shrink-0 text-slate-400">Branch</dt>
                    <dd className="font-semibold text-white">{config.bank.branch}</dd>
                  </div>
                )}
                {config.bank.accountName && (
                  <div className="flex gap-2">
                    <dt className="w-32 shrink-0 text-slate-400">Account name</dt>
                    <dd className="font-semibold text-white">{config.bank.accountName}</dd>
                  </div>
                )}
                {config.bank.accountNumber && (
                  <div className="flex gap-2">
                    <dt className="w-32 shrink-0 text-slate-400">Account no.</dt>
                    <dd className="font-mono font-bold text-[#4ADE80]">{config.bank.accountNumber}</dd>
                  </div>
                )}
              </dl>
              {config.bank.instructions && <p className="mt-2 text-[11px] leading-relaxed text-slate-400">{config.bank.instructions}</p>}
              <label className="mt-3 block">
                <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Transfer reference / slip no. (optional)</span>
                <input
                  value={bankRef}
                  onChange={(e) => setBankRef(e.target.value)}
                  placeholder="e.g. slip number or transaction reference"
                  maxLength={80}
                  aria-label="Bank transfer reference"
                  className={inputCls}
                />
              </label>
              <p className="mt-2 text-[11px] leading-relaxed text-slate-400">
                After transferring, press “Donate Now” below so we can record your gift — it will be verified and listed once
                the credit is confirmed.
              </p>
            </div>
          )}

          {/* secure donate button */}
          <button
            type="button"
            onClick={donateNow}
            disabled={busy || finalAmount === null}
            className="mt-7 flex h-14 w-full items-center justify-center gap-2.5 rounded-full bg-[#22C55E] text-base font-black text-[#04220f] shadow-xl shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] disabled:opacity-50"
          >
            {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Heart className="h-5 w-5" fill="currentColor" />}
            {effectiveMethod === "GATEWAY" ? `Donate Now — Secure Payment via ${providerName}` : "Donate Now"}
          </button>
          <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[11px] text-slate-500">
            <ShieldCheck className="h-3.5 w-3.5" />
            {effectiveMethod === "GATEWAY"
              ? `You'll continue to ${providerName}'s secure page. We never see or store card numbers or CVV codes.`
              : "Your donation is recorded and verified by the site owner before being listed."}
          </p>
        </div>
      )}

      {/* donor recognition wall */}
      {wall.data?.enabled && wall.data.items.length > 0 && (
        <section className="mt-10" aria-label="Recent supporters">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 text-lg font-black text-white">
              <PartyPopper className="h-5 w-5 text-[#4ADE80]" /> Recent supporters
            </h2>
            {wall.data.totalVerifiedCents > 0 && (
              <p className="text-xs text-slate-400">
                Rs. {(wall.data.totalVerifiedCents / 100).toLocaleString("en-LK")} raised · {wall.data.countVerified} donation
                {wall.data.countVerified === 1 ? "" : "s"} 💚
              </p>
            )}
          </div>
          <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
            {wall.data.items.map((d, i) => (
              <li key={i} className="rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <div className="flex items-center justify-between gap-3">
                  <p className="flex min-w-0 items-center gap-2 text-sm font-bold text-white">
                    <Heart className="h-3.5 w-3.5 shrink-0 text-[#4ADE80]" fill="currentColor" />
                    <span className="truncate">{d.name}</span>
                  </p>
                  <span className="shrink-0 rounded-full bg-[#22C55E]/12 px-2.5 py-0.5 text-xs font-black text-[#4ADE80]">
                    Rs. {(d.amountCents / 100).toLocaleString("en-LK")}
                  </span>
                </div>
                {d.message && <p className="mt-1.5 truncate text-xs italic text-slate-400">“{d.message}”</p>}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
