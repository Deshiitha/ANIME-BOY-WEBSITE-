"use client";

import { useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SlidersHorizontal, SearchX, Clapperboard, MonitorPlay, Brush, TvMinimalPlay, Shapes, Search as SearchIcon } from "lucide-react";
import { api } from "@/lib/client-api";
import { navigate, useAppStore, type AnimeType } from "@/store/useAppStore";
import { PosterCard } from "./../PosterCard";
import { PosterGridSkeleton } from "./../Skeletons";
import { EmptyState, ErrorState } from "./../EmptyState";

type BrowseResponse = { items: AnimeType[]; total: number; page: number; pages: number };
export type BrowseMode = "movies" | "series" | "donghua" | "donghua-series" | "others" | "search";

const GENRES = ["Action", "Adventure", "Comedy", "Drama", "Fantasy", "Mystery", "Romance", "School", "Sci-Fi", "Slice of Life", "Supernatural"];
const SORTS = [
  { value: "recent", label: "Recently Added" },
  { value: "rating", label: "Top Rated" },
  { value: "year", label: "Newest Release" },
  { value: "title", label: "A → Z" },
];
const LANGS = [
  { value: "SINHALA_DUBBED", label: "සිංහල Dubbed" },
  { value: "SINHALA_SUB", label: "සිංහල Sub" },
  { value: "ANIME_REVIEW", label: "Anime Review" },
];

export function BrowseView({ mode }: { mode: BrowseMode }) {
  const { route } = useAppStore();
  const routeQ = route.query.get("q") || "";

  // Fixed content type/category per mode — the five categories are independent.
  const fixed =
    mode === "movies"
      ? { type: "MOVIE", category: "ANIME" }
      : mode === "series"
        ? { type: "SERIES", category: "ANIME" }
        : mode === "donghua"
          ? { type: "MOVIE", category: "DONGHUA" }
          : mode === "donghua-series"
            ? { type: "SERIES", category: "DONGHUA" }
            : mode === "others"
              ? // Others is the flexible category — any video type, category filter only.
                { type: "", category: "OTHERS" }
              : { type: "", category: "" }; // search — user-filterable

  const [q, setQ] = useState(routeQ);
  const [type, setType] = useState<string>(fixed.type);
  const [category, setCategory] = useState<string>(fixed.category);
  const [genre, setGenre] = useState("");
  const [year, setYear] = useState("");
  const [language, setLanguage] = useState("");
  const [status, setStatus] = useState(route.query.get("status") || "");
  const [sort, setSort] = useState(route.query.get("sort") || "recent");
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const gridTop = useRef<HTMLDivElement>(null);

  // Note: route query values are read at mount; AppShell remounts this view
  // (via key) whenever the hash query changes, e.g. header search navigation.

  const title =
    mode === "movies"
      ? "Anime Movies"
      : mode === "series"
        ? "Anime Series"
        : mode === "donghua"
          ? "Donghua Movie"
          : mode === "donghua-series"
            ? "Donghua Series"
            : mode === "others"
              ? "Others"
              : "Search";
  const subtitle =
    mode === "movies"
      ? "සිංහල හඬ කැවූ සහ උපසිරැසි සහිත ඇනිමේ චිත්‍රපට"
      : mode === "series"
        ? "සිංහල ඇනිමේ කතා මාලා සහ නවතම කථාංග"
        : mode === "donghua"
          ? "චීන ඩොන්ගුවා චිත්‍රපට — සිංහල හඬ කැවූ සහ උපසිරැසි සහිත"
          : mode === "donghua-series"
            ? "චීන ඩොන්ගුවා කතා මාලා සහ නවතම කථාංග"
            : mode === "others"
              ? "වෙනත් වීඩියෝ අන්තර්ගතය — විවිධාකාර ඇනිමේ වීඩියෝ"
              : "Search by title, then filter by category, type, genre, year and language";

  const params = useMemo(() => {
    const p = new URLSearchParams();
    if (q.trim()) p.set("q", q.trim());
    if (type) p.set("type", type);
    if (category) p.set("category", category);
    if (genre) p.set("genre", genre);
    if (year) p.set("year", year);
    if (language) p.set("language", language);
    if (status) p.set("status", status);
    if (sort) p.set("sort", sort);
    p.set("page", String(page));
    p.set("limit", "24");
    return p.toString();
  }, [q, type, category, genre, year, language, status, sort, page]);

  const { data, isLoading, isError, refetch, isFetching } = useQuery<BrowseResponse>({
    queryKey: ["browse", params],
    queryFn: () => api.get(`/api/anime?${params}`),
    placeholderData: (prev) => prev,
  });

  const years = useMemo(() => {
    const now = new Date().getFullYear() + 1;
    return Array.from({ length: now - 2009 }, (_, i) => String(now - i));
  }, []);

  const changeFilter = (fn: () => void) => {
    fn();
    setPage(1);
  };

  const gotoPage = (p: number) => {
    setPage(p);
    gridTop.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="fade-up mx-auto max-w-7xl px-4 pb-4 pt-8 sm:px-6">
      <div ref={gridTop} className="scroll-mt-20" />
      {/* heading */}
      <div className="flex flex-wrap items-center gap-3">
        {mode === "movies" ? (
          <Clapperboard className="h-7 w-7 text-[#4ADE80]" />
        ) : mode === "series" ? (
          <MonitorPlay className="h-7 w-7 text-[#4ADE80]" />
        ) : mode === "donghua" ? (
          <Brush className="h-7 w-7 text-[#4ADE80]" />
        ) : mode === "donghua-series" ? (
          <TvMinimalPlay className="h-7 w-7 text-[#4ADE80]" />
        ) : mode === "others" ? (
          <Shapes className="h-7 w-7 text-[#4ADE80]" />
        ) : (
          <SearchIcon className="h-7 w-7 text-[#4ADE80]" />
        )}
        <div>
          <h1 className="text-2xl font-black text-white sm:text-3xl">{title}</h1>
          <p className="mt-0.5 text-sm text-slate-400">{subtitle}</p>
        </div>
        <div className="flex-1" />
        {data && (
          <span className="text-sm text-slate-400">
            {data.total} {data.total === 1 ? "result" : "results"}
          </span>
        )}
      </div>

      {/* search input (search page) */}
      {mode === "search" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setPage(1);
          }}
          role="search"
          className="mt-5"
        >
          <div className="relative">
            <SearchIcon className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
            <input
              value={q}
              onChange={(e) => changeFilter(() => setQ(e.target.value))}
              placeholder="Type an anime title…  /  ඇනිමේ නම ටයිප් කරන්න…"
              aria-label="Search anime by title"
              className="h-12 w-full rounded-2xl border border-white/10 bg-white/[0.04] pl-11 pr-4 text-[15px] text-white placeholder:text-slate-500 outline-none transition-all focus:border-[#22C55E]/50 focus:ring-2 focus:ring-[#22C55E]/25"
            />
          </div>
        </form>
      )}

      {/* filter bar */}
      <div className="mt-5 flex flex-wrap items-center gap-2">
        <button
          onClick={() => setShowFilters((v) => !v)}
          aria-expanded={showFilters}
          className={`inline-flex h-10 items-center gap-2 rounded-full border px-4 text-sm font-semibold transition-colors ${
            showFilters || genre || year || language || status
              ? "border-[#22C55E]/50 bg-[#22C55E]/10 text-[#4ADE80]"
              : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-white/20"
          }`}
        >
          <SlidersHorizontal className="h-4 w-4" /> Filters
          {(genre || year || language || status) && (
            <span className="h-2 w-2 rounded-full bg-[#4ADE80]" aria-hidden="true" />
          )}
        </button>

        <label className="sr-only" htmlFor="sort-select">Sort results</label>
        <select
          id="sort-select"
          value={sort}
          onChange={(e) => changeFilter(() => setSort(e.target.value))}
          className="h-10 rounded-full border border-white/10 bg-white/[0.04] px-3.5 text-sm font-semibold text-slate-200 outline-none transition-colors focus:border-[#22C55E]/50"
        >
          {SORTS.map((s) => (
            <option key={s.value} value={s.value} className="bg-[#0b1120]">
              Sort: {s.label}
            </option>
          ))}
        </select>

        {mode === "search" && (
          <>
            <div className="flex rounded-full border border-white/10 bg-white/[0.04] p-1" role="group" aria-label="Filter by category">
              {[
                { v: "", label: "All" },
                { v: "ANIME", label: "Anime" },
                { v: "DONGHUA", label: "Donghua" },
                { v: "OTHERS", label: "Others" },
              ].map((c) => (
                <button
                  key={c.v}
                  onClick={() => changeFilter(() => setCategory(c.v))}
                  aria-pressed={category === c.v}
                  className={`h-8 rounded-full px-3.5 text-[13px] font-semibold transition-colors ${
                    category === c.v ? "bg-[#22C55E] text-[#04220f]" : "text-slate-300 hover:text-white"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
            <div className="flex rounded-full border border-white/10 bg-white/[0.04] p-1" role="group" aria-label="Filter by type">
              {[
                { v: "", label: "All" },
                { v: "MOVIE", label: "Movies" },
                { v: "SERIES", label: "Series" },
              ].map((t) => (
                <button
                  key={t.v}
                  onClick={() => changeFilter(() => setType(t.v))}
                  aria-pressed={type === t.v}
                  className={`h-8 rounded-full px-3.5 text-[13px] font-semibold transition-colors ${
                    type === t.v ? "bg-[#22C55E] text-[#04220f]" : "text-slate-300 hover:text-white"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* expandable filters */}
      {showFilters && (
        <div className="mt-3 grid gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Genre">
            <select value={genre} onChange={(e) => changeFilter(() => setGenre(e.target.value))} className={selectCls}>
              <option value="" className="bg-[#0b1120]">All genres</option>
              {GENRES.map((g) => (
                <option key={g} value={g} className="bg-[#0b1120]">{g}</option>
              ))}
            </select>
          </Field>
          <Field label="Release year">
            <select value={year} onChange={(e) => changeFilter(() => setYear(e.target.value))} className={selectCls}>
              <option value="" className="bg-[#0b1120]">Any year</option>
              {years.map((y) => (
                <option key={y} value={y} className="bg-[#0b1120]">{y}</option>
              ))}
            </select>
          </Field>
          <Field label="Language">
            <select value={language} onChange={(e) => changeFilter(() => setLanguage(e.target.value))} className={selectCls}>
              <option value="" className="bg-[#0b1120]">All languages</option>
              {LANGS.map((l) => (
                <option key={l.value} value={l.value} className="bg-[#0b1120]">{l.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Status">
            <select value={status} onChange={(e) => changeFilter(() => setStatus(e.target.value))} className={selectCls}>
              <option value="" className="bg-[#0b1120]">All</option>
              <option value="RELEASED" className="bg-[#0b1120]">Released</option>
              <option value="UPCOMING" className="bg-[#0b1120]">Coming Soon</option>
            </select>
          </Field>
          {(genre || year || language || status || type || category) && (
            <button
              onClick={() => changeFilter(() => { setGenre(""); setYear(""); setLanguage(""); setStatus(""); if (mode === "search") { setType(""); setCategory(""); } })}
              className="h-10 rounded-lg border border-white/10 px-4 text-sm font-semibold text-slate-300 transition-colors hover:border-red-400/40 hover:text-red-300"
            >
              Clear all filters
            </button>
          )}
        </div>
      )}

      {/* results */}
      <div className="mt-7 min-h-[300px]">
        {isLoading ? (
          <PosterGridSkeleton />
        ) : isError ? (
          <ErrorState message="Failed to load results." onRetry={() => refetch()} />
        ) : !data || data.items.length === 0 ? (
          <EmptyState
            icon={SearchX}
            title="No anime found"
            description="Try a different title, or remove some filters. වෙනත් නමකින් සොයන්න නැතහොත් ෆිල්ටර් ඉවත් කරන්න."
            action={
              <button
                onClick={() => navigate("/request")}
                className="h-10 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
              >
                Request this anime
              </button>
            }
          />
        ) : (
          <>
            <div className={`grid grid-cols-2 gap-x-3.5 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 ${isFetching ? "opacity-60 transition-opacity" : ""}`}>
              {data.items.map((a) => (
                <div key={a.id} className="flex justify-center sm:justify-start">
                  <PosterCard anime={a} />
                </div>
              ))}
            </div>
            {data.pages > 1 && (
              <nav aria-label="Pagination" className="mt-10 flex items-center justify-center gap-1.5">
                <PageBtn disabled={page <= 1} onClick={() => gotoPage(page - 1)} label="Previous page">‹ Prev</PageBtn>
                {Array.from({ length: data.pages }).map((_, i) => (
                  <PageBtn key={i} active={page === i + 1} onClick={() => gotoPage(i + 1)} label={`Page ${i + 1}`}>
                    {i + 1}
                  </PageBtn>
                ))}
                <PageBtn disabled={page >= data.pages} onClick={() => gotoPage(page + 1)} label="Next page">Next ›</PageBtn>
              </nav>
            )}
          </>
        )}
      </div>
    </div>
  );
}

const selectCls =
  "h-10 w-full rounded-lg border border-white/10 bg-[#0b1120] px-3 text-sm text-slate-200 outline-none focus:border-[#22C55E]/50";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-400">{label}</span>
      {children}
    </label>
  );
}

function PageBtn({
  active,
  disabled,
  onClick,
  children,
  label,
}: {
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      aria-current={active ? "page" : undefined}
      className={`flex h-9 min-w-9 items-center justify-center rounded-lg px-2 text-sm font-semibold transition-colors ${
        active
          ? "bg-[#22C55E] text-[#04220f]"
          : disabled
            ? "text-slate-600"
            : "border border-white/10 text-slate-300 hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
      }`}
    >
      {children}
    </button>
  );
}
