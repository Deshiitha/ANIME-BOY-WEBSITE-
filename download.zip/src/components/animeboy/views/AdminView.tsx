"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard, Film, ListVideo, MailPlus, Users, Settings, ShieldAlert,
  Eye, EyeOff, Check, X as XIcon, Trash2, Youtube, Loader2, Database, HardDrive,
  Cloud, Heart, Brush, Shapes,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { navigate, useAppStore } from "@/store/useAppStore";
import { AdminContent } from "./AdminContent";
import { PlaylistManager } from "./PlaylistManager";
import { CloudVideoManager } from "./CloudVideoManager";
import { DonationManagement } from "./../DonationManagement";
import { SmtpSettings } from "./../SmtpSettings";
import { ProfileSettingsForm } from "./../ProfileSettingsForm";
import { SecurityPasswordForm } from "./../SecurityPasswordForm";

type Stats = {
  stats: { animeTotal: number; movies: number; series: number; upcoming: number; episodes: number; users: number; pendingRequests: number; published: number; donghuaMovies: number; donghuaSeries: number; others: number };
  storage: "s3" | "local";
};

type RequestRow = {
  id: string;
  title: string;
  type: string;
  message: string | null;
  status: string;
  createdAt: string;
  user?: { email: string; name: string | null } | null;
};

type UserRow = {
  id: string;
  email: string;
  name: string | null;
  role: string;
  createdAt: string;
  _count: { watchlist: number; requests: number };
};

const TABS = [
  { key: "overview", label: "Overview", icon: LayoutDashboard },
  { key: "cloud", label: "Cloud Video Manager", icon: Cloud },
  { key: "content", label: "Content", icon: Film },
  { key: "playlists", label: "Playlists", icon: ListVideo },
  { key: "requests", label: "Requests", icon: MailPlus },
  { key: "users", label: "Users", icon: Users },
  { key: "donations", label: "Donations", icon: Heart },
  { key: "settings", label: "Settings", icon: Settings },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export function AdminView() {
  const { user, userLoaded } = useAppStore();
  const [tab, setTab] = useState<TabKey>("overview");

  const { data: stats } = useQuery<Stats>({
    queryKey: ["admin-stats"],
    queryFn: () => api.get("/api/admin/stats"),
    enabled: user?.role === "ADMIN",
  });

  if (userLoaded && (!user || user.role !== "ADMIN")) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-red-500/10">
          <ShieldAlert className="h-8 w-8 text-red-400" />
        </span>
        <h1 className="mt-4 text-2xl font-black text-white">Admin access only</h1>
        <p className="mt-2 text-sm text-slate-400">
          This dashboard requires an administrator account. All admin API actions are
          authorised on the server.
        </p>
        {!user && (
          <button
            onClick={() => navigate("/signin")}
            className="mt-6 h-11 rounded-full bg-[#22C55E] px-6 font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
          >
            Sign In
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="fade-up mx-auto max-w-7xl px-4 pb-6 pt-8 sm:px-6">
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#22C55E]/12 glow-green">
          <LayoutDashboard className="h-6 w-6 text-[#4ADE80]" />
        </span>
        <div>
          <h1 className="text-2xl font-black text-white sm:text-3xl">Admin Dashboard</h1>
          <p className="text-sm text-slate-400">ANIME BOY content management</p>
        </div>
      </div>

      {/* tabs */}
      <div className="mt-6 flex gap-1 overflow-x-auto rounded-2xl border border-white/8 bg-white/[0.02] p-1.5" role="tablist" aria-label="Admin sections">
        {TABS.map((t) => {
          const active = tab === t.key;
          const badge = t.key === "requests" ? stats?.stats.pendingRequests : undefined;
          return (
            <button
              key={t.key}
              role="tab"
              aria-selected={active}
              onClick={() => setTab(t.key)}
              className={`relative flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-colors ${
                active ? "bg-[#22C55E] text-[#04220f] shadow-lg shadow-[#22C55E]/20" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              <t.icon className="h-4 w-4" /> {t.label}
              {typeof badge === "number" && badge > 0 && (
                <span className={`ml-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-black ${active ? "bg-[#04220f] text-[#4ADE80]" : "bg-[#F59E0B] text-[#1c1002]"}`}>
                  {badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="mt-6">
        {tab === "overview" && <Overview stats={stats} />}
        {tab === "cloud" && <CloudVideoManager />}
        {tab === "content" && <AdminContent />}
        {tab === "playlists" && <PlaylistManager />}
        {tab === "requests" && <RequestsTab />}
        {tab === "users" && <UsersTab />}
        {tab === "donations" && <DonationManagement />}
        {tab === "settings" && <SettingsTab />}
      </div>
    </div>
  );
}

/* ------------------------------ overview ------------------------------ */

function Overview({ stats }: { stats?: Stats }) {
  if (!stats) {
    return (
      <div className="flex items-center gap-3 py-14 text-slate-400">
        <Loader2 className="h-5 w-5 animate-spin" /> Loading stats…
      </div>
    );
  }
  const s = stats.stats;
  const cards = [
    { label: "Total titles", value: s.animeTotal, icon: Film, tone: "text-[#4ADE80]" },
    { label: "Anime movies", value: s.movies, icon: Film, tone: "text-white" },
    { label: "Anime series", value: s.series, icon: ListVideo, tone: "text-white" },
    { label: "Donghua Movie", value: s.donghuaMovies, icon: Brush, tone: "text-[#4ADE80]" },
    { label: "Donghua series", value: s.donghuaSeries, icon: Brush, tone: "text-[#4ADE80]" },
    { label: "Others", value: s.others, icon: Shapes, tone: "text-[#4ADE80]" },
    { label: "Episodes", value: s.episodes, icon: ListVideo, tone: "text-white" },
    { label: "Upcoming", value: s.upcoming, icon: Film, tone: "text-[#F59E0B]" },
    { label: "Published", value: s.published, icon: Eye, tone: "text-[#4ADE80]" },
    { label: "Users", value: s.users, icon: Users, tone: "text-white" },
    { label: "Pending requests", value: s.pendingRequests, icon: MailPlus, tone: "text-[#FACC15]" },
  ];

  return (
    <div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
            <div className="flex items-center justify-between">
              <c.icon className={`h-5 w-5 ${c.tone}`} />
              <span className={`text-2xl font-black ${c.tone}`}>{c.value}</span>
            </div>
            <p className="mt-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-5">
          <h3 className="flex items-center gap-2 font-bold text-white">
            {stats.storage === "s3" ? <Database className="h-4.5 w-4.5 text-[#4ADE80]" /> : <HardDrive className="h-4.5 w-4.5 text-[#4ADE80]" />}
            File storage
          </h3>
          <p className="mt-2 text-sm leading-relaxed text-slate-400">
            {stats.storage === "s3"
              ? "Uploads are stored in your configured S3-compatible object storage."
              : "Uploads are stored on the server's local disk (db/uploads) and streamed through /api/files with range support. To use object storage instead, set the S3_* environment variables — see the setup notes."}
          </p>
        </div>
        <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-5">
          <h3 className="font-bold text-white">Getting started</h3>
          <ul className="mt-2 space-y-1.5 text-sm text-slate-400">
            <li>• Five content categories: <strong className="text-slate-200">Anime Movies, Anime Series, Donghua Movie, Donghua Series, Others</strong></li>
            <li>• Use <strong className="text-slate-200">Cloud Video Manager → Add Cloud Video</strong> to publish a cloud-hosted video</li>
            <li>• Use <strong className="text-slate-200">Content → Add Content</strong> for full metadata control and to pick one of the five categories</li>
            <li>• Use <strong className="text-slate-200">Playlists → Upload Episode</strong> for playlist uploads (Anime Series, Donghua Series &amp; Others) — create a playlist, pick or name a season, add episode after episode</li>
            <li>• Toggle the star to place titles in the hero carousel</li>
            <li>• Manage seasons/episodes via the list icon on any series row (anime &amp; donghua) or the <strong className="text-slate-200">Playlists</strong> tab</li>
            <li>• Set your YouTube channel link in <strong className="text-slate-200">Settings</strong></li>
          </ul>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ requests ------------------------------ */

function RequestsTab() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery<{ items: RequestRow[] }>({
    queryKey: ["admin-requests"],
    queryFn: () => api.get("/api/admin/requests"),
  });

  const setStatus = async (id: string, status: string) => {
    try {
      await api.patch(`/api/admin/requests/${id}`, { status });
      toast.success(`Marked ${status.toLowerCase()}`);
      qc.invalidateQueries({ queryKey: ["admin-requests"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    }
  };

  const remove = async (id: string) => {
    if (!window.confirm("Delete this request?")) return;
    try {
      await api.delete(`/api/admin/requests/${id}`);
      toast.success("Request deleted");
      qc.invalidateQueries({ queryKey: ["admin-requests"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  };

  return (
    <div>
      <h2 className="text-lg font-black text-white">Anime Requests</h2>
      {isLoading ? (
        <p className="mt-4 text-slate-400">Loading…</p>
      ) : !data || data.items.length === 0 ? (
        <p className="mt-6 rounded-2xl border border-dashed border-white/10 px-6 py-10 text-center text-slate-400">
          No requests yet.
        </p>
      ) : (
        <ul className="mt-4 space-y-2.5">
          {data.items.map((r) => (
            <li key={r.id} className="rounded-2xl border border-white/8 bg-white/[0.02] p-4">
              <div className="flex flex-wrap items-start gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-bold text-white">{r.title}</h3>
                    <span className="rounded bg-white/8 px-1.5 py-0.5 text-[10px] font-bold text-slate-300">{r.type}</span>
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                        r.status === "APPROVED"
                          ? "bg-[#22C55E]/15 text-[#4ADE80]"
                          : r.status === "REJECTED"
                            ? "bg-red-500/15 text-red-300"
                            : "bg-[#F59E0B]/15 text-[#F59E0B]"
                      }`}
                    >
                      {r.status}
                    </span>
                  </div>
                  {r.message && <p className="mt-1 text-sm text-slate-400">“{r.message}”</p>}
                  <p className="mt-1 text-xs text-slate-500">
                    {r.user ? `${r.user.name || r.user.email} · ` : "Guest · "}
                    {new Date(r.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  {r.status !== "APPROVED" && (
                    <button onClick={() => setStatus(r.id, "APPROVED")} aria-label="Approve" className="flex h-8 w-8 items-center justify-center rounded-lg text-[#4ADE80] hover:bg-[#22C55E]/10" title="Approve">
                      <Check className="h-4 w-4" />
                    </button>
                  )}
                  {r.status !== "REJECTED" && (
                    <button onClick={() => setStatus(r.id, "REJECTED")} aria-label="Reject" className="flex h-8 w-8 items-center justify-center rounded-lg text-amber-300 hover:bg-amber-500/10" title="Reject">
                      <XIcon className="h-4 w-4" />
                    </button>
                  )}
                  {r.status !== "PENDING" && (
                    <button onClick={() => setStatus(r.id, "PENDING")} aria-label="Reset to pending" className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5" title="Reset to pending">
                      <EyeOff className="h-4 w-4" />
                    </button>
                  )}
                  <button onClick={() => remove(r.id)} aria-label="Delete request" className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300" title="Delete">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* -------------------------------- users -------------------------------- */

function UsersTab() {
  const { data, isLoading } = useQuery<{ users: UserRow[] }>({
    queryKey: ["admin-users"],
    queryFn: () => api.get("/api/admin/users"),
  });

  return (
    <div>
      <h2 className="text-lg font-black text-white">Users</h2>
      {isLoading ? (
        <p className="mt-4 text-slate-400">Loading…</p>
      ) : (
        <div className="mt-4 overflow-hidden rounded-2xl border border-white/8">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead>
              <tr className="border-b border-white/8 bg-white/[0.03] text-xs uppercase tracking-wider text-slate-400">
                <th className="px-4 py-3 font-bold">User</th>
                <th className="px-4 py-3 font-bold">Role</th>
                <th className="px-4 py-3 font-bold">Watchlist</th>
                <th className="px-4 py-3 font-bold">Requests</th>
                <th className="px-4 py-3 font-bold">Joined</th>
              </tr>
            </thead>
            <tbody>
              {data?.users.map((u) => (
                <tr key={u.id} className="border-b border-white/5">
                  <td className="px-4 py-3">
                    <span className="block font-semibold text-white">{u.name || "—"}</span>
                    <span className="block text-xs text-slate-500">{u.email}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`rounded px-2 py-0.5 text-xs font-bold ${u.role === "ADMIN" ? "bg-[#22C55E]/15 text-[#4ADE80]" : "bg-white/8 text-slate-300"}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-300">{u._count.watchlist}</td>
                  <td className="px-4 py-3 text-slate-300">{u._count.requests}</td>
                  <td className="px-4 py-3 text-slate-400">{new Date(u.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ------------------------------- settings ------------------------------ */

function SettingsTab() {
  const qc = useQueryClient();
  const { config } = useAppStore();
  // null = untouched (follow config), string = user edited
  const [urlDraft, setUrlDraft] = useState<string | null>(null);
  const [handleDraft, setHandleDraft] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const url = urlDraft ?? config.youtubeChannelUrl ?? "";
  const handle = handleDraft ?? config.channelHandle ?? "";

  const save = async () => {
    setSaving(true);
    try {
      await api.put("/api/admin/config", { youtubeChannelUrl: url.trim(), channelHandle: handle.trim() });
      qc.invalidateQueries({ queryKey: ["config"] });
      setUrlDraft(null);
      setHandleDraft(null);
      toast.success("Settings saved ✓");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-xl">
      <h2 className="text-lg font-black text-white">Site Settings</h2>

      <div className="mt-4 space-y-4 rounded-2xl border border-white/8 bg-white/[0.02] p-5">
        <label className="block">
          <span className="mb-1.5 flex items-center gap-2 text-sm font-bold text-slate-200">
            <Youtube className="h-4 w-4 text-[#4ADE80]" /> YouTube channel URL
          </span>
          <input
            value={url}
            onChange={(e) => setUrlDraft(e.target.value)}
            placeholder="https://www.youtube.com/@YourChannel"
            className="h-11 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50"
            aria-label="YouTube channel URL"
          />
          <span className="mt-1.5 block text-xs text-slate-500">
            Shown in the footer as a Subscribe button. Leave empty to hide the button.
          </span>
        </label>

        <label className="block">
          <span className="mb-1.5 block text-sm font-bold text-slate-200">Channel handle (display)</span>
          <input
            value={handle}
            onChange={(e) => setHandleDraft(e.target.value)}
            placeholder="@AnimeBoyLK"
            className="h-11 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50"
            aria-label="Channel handle"
          />
        </label>

        <button
          onClick={save}
          disabled={saving}
          className="inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save Settings
        </button>
      </div>

      {/* email (SMTP) — powers password-reset emails */}
      <SmtpSettings />

      {/* admin profile settings — change own username (password reauthentication) */}
      <div className="mt-6">
        <ProfileSettingsForm isAdmin />
      </div>

      {/* admin account security — changes only this admin's own password */}
      <div className="mt-6">
        <SecurityPasswordForm isAdmin />
      </div>
    </div>
  );
}
