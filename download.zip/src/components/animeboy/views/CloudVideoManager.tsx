"use client";

/**
 * Admin "Cloud Video Manager" — the dedicated section for every cloud-hosted
 * video on ANIME BOY (movies and series episodes in one place).
 *
 *  - "Add Cloud Video" → paste a cloud URL (direct MP4/HLS or a provider
 *    embed), fill in the anime details, preview, publish.
 *  - Inventory of all video entries with source badges (direct / HLS / embed /
 *    signed private bucket / local upload), quality + subtitle counts.
 *  - Publish / unpublish / edit the video / delete, without leaving the page.
 *
 * Video files are never stored on this server — only URLs, titles, thumbnails,
 * subtitles and metadata live in the database.
 */
import { useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2,
  Cloud,
  ExternalLink,
  Eye,
  EyeOff,
  Film,
  Loader2,
  MonitorPlay,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Trash2,
  TriangleAlert,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import type { AltSource, QualityTrack, SubtitleTrack, VideoSourceKind } from "@/lib/media-types";
import { isS3ObjectUrl, looksLikeHls, toEmbedUrl } from "@/lib/media-validate";
import { navigate, type AnimeType, type EpisodeType } from "@/store/useAppStore";
import { VideoSourceEditor, type VideoSourceValue } from "./VideoSourceEditor";
import { UploadWidget } from "./UploadWidget";
import { AdminField, areaCls, inputCls, selectCls } from "./AdminContent";

type AdminAnime = AnimeType;

type CloudEntry = {
  kind: "movie" | "episode";
  entryId: string;
  animeId: string;
  animeSlug: string;
  animeTitle: string;
  published: boolean;
  title: string;
  label: string;
  poster: string | null;
  videoSource: VideoSourceKind;
  videoUrl: string | null;
  embedUrl: string | null;
  videoProvider: string | null;
  qualities: QualityTrack[];
  subtitles: SubtitleTrack[];
  altSources: AltSource[];
};

const EMPTY_VS: VideoSourceValue = {
  videoSource: "external",
  videoUrl: "",
  embedUrl: "",
  qualities: [],
  subtitles: [],
  altSources: [],
  videoThumb: "",
  downloadEnabled: false,
  downloadUrl: "",
  downloadQualities: [],
  subtitleDownloadEnabled: false,
  subtitleDownloads: [],
};

const PROVIDER_LABELS: Record<string, string> = {
  youtube: "YouTube",
  vimeo: "Vimeo",
  dailymotion: "Dailymotion",
  gdrive: "Google Drive",
  streamable: "Streamable",
  terabox: "TeraBox",
};

/** Friendly cloud-provider name for the URL the admin just pasted. */
function providerHintFromUrl(raw: string): string | null {
  const url = raw.trim();
  if (!url) return null;
  if (/^s3:\/\//i.test(url)) return "Private S3 bucket (signed playback)";
  let host = "";
  try {
    host = new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
  const rules: [RegExp, string][] = [
    [/^drive\.google\.com$|^docs\.google\.com$/, "Google Drive"],
    [/^(m\.)?youtube\.com$|^youtu\.be$/, "YouTube"],
    [/^vimeo\.com$|^player\.vimeo\.com$/, "Vimeo"],
    [/^dailymotion\.com$|^dai\.ly$/, "Dailymotion"],
    [/^streamable\.com$/, "Streamable"],
    [/^(www\.)?terabox\.com$|^teraboxapp\.com$|^1024tera\.com$|^1024terabox\.com$|^teraboxlink\.com$|^terasharelink\.com$|^teraboxshare\.com$|^freeterabox\.com$|^4funbox\.com$|^mirrobox\.com$|^nephobox\.com$|^momerybox\.com$|^tibibox\.com$/, "TeraBox"],
    [/^dropbox\.com$|^dl\.dropboxusercontent\.com$/, "Dropbox"],
    [/\.r2\.dev$|^.*\.cloudflarestorage\.com$/, "Cloudflare R2"],
    [/\.bunnycdn\.com$|\.bunny\.net$|^.+\.mediastore\.$/, "Bunny Stream / CDN"],
    [/\.amazonaws\.com$/, "AWS S3"],
    [/\.wasabisys\.com$/, "Wasabi"],
    [/\.backblazeb2\.com$/, "Backblaze B2"],
    [/\.googleapis\.com$/, "Google Cloud Storage"],
    [/\.azureedge\.net$|\.blob\.core\.windows\.net$/, "Azure Storage / CDN"],
    [/\.cloudfront\.net$/, "AWS CloudFront CDN"],
  ];
  for (const [re, name] of rules) if (re.test(host)) return name;
  if (/\.mp4$|\.webm$|\.m3u8$/i.test(url.split("?")[0])) return `Direct file · ${host}`;
  return host || null;
}

function entrySourceBadge(e: CloudEntry): { text: string; cls: string } {
  if (e.videoSource === "embed" && e.embedUrl) {
    const label = PROVIDER_LABELS[e.videoProvider || ""] || "Provider";
    // No-iframe providers (TeraBox) use the official page fallback, not an iframe.
    if (e.videoProvider === "terabox")
      return {
        text: e.videoUrl ? "TeraBox + authorized stream" : "TeraBox · watch on provider",
        cls: "bg-violet-500/15 text-violet-300",
      };
    return { text: `${label} embed`, cls: "bg-violet-500/15 text-violet-300" };
  }
  if (e.videoSource === "external" && e.videoUrl) {
    if (isS3ObjectUrl(e.videoUrl))
      return { text: "Private bucket · signed", cls: "bg-sky-500/15 text-sky-300" };
    if (looksLikeHls(e.videoUrl))
      return { text: "HLS stream", cls: "bg-[#22C55E]/15 text-[#4ADE80]" };
    return { text: "Direct cloud URL", cls: "bg-[#22C55E]/15 text-[#4ADE80]" };
  }
  if (e.videoSource === "upload" && e.videoUrl)
    return { text: "Local upload", cls: "bg-white/10 text-slate-300" };
  return { text: "No video yet", cls: "bg-amber-400/15 text-amber-300" };
}

function hasCloudVideo(e: CloudEntry): boolean {
  if (e.videoSource === "embed") return !!e.embedUrl;
  return !!e.videoUrl;
}

function flatten(items: AdminAnime[]): CloudEntry[] {
  const entries: CloudEntry[] = [];
  for (const a of items) {
    if (a.type === "MOVIE") {
      entries.push({
        kind: "movie",
        entryId: a.id,
        animeId: a.id,
        animeSlug: a.slug,
        animeTitle: a.titleEn,
        published: a.published,
        title: a.titleEn,
        label: "Movie",
        poster: a.posterUrl,
        videoSource: a.videoSource,
        videoUrl: a.videoUrl,
        embedUrl: a.embedUrl,
        videoProvider: a.videoProvider,
        qualities: a.videoQualities || [],
        subtitles: a.subtitleTracks || [],
        altSources: a.altSources || [],
      });
    } else {
      for (const s of a.seasons || []) {
        for (const ep of s.episodes) {
          entries.push({
            kind: "episode",
            entryId: ep.id,
            animeId: a.id,
            animeSlug: a.slug,
            animeTitle: a.titleEn,
            published: a.published,
            title: ep.title ? `${a.titleEn} — ${ep.title}` : a.titleEn,
            label: `S${s.number} · E${ep.number}`,
            poster: ep.thumbnailUrl || a.posterUrl,
            videoSource: ep.videoSource,
            videoUrl: ep.videoUrl,
            embedUrl: ep.embedUrl,
            videoProvider: ep.videoProvider,
            qualities: ep.videoQualities || [],
            subtitles: ep.subtitleTracks || [],
            altSources: ep.altSources || [],
          });
        }
      }
    }
  }
  return entries;
}

function seedVs(e: CloudEntry): VideoSourceValue {
  return {
    ...EMPTY_VS,
    videoSource: e.videoSource || "external",
    videoUrl: e.videoUrl || "",
    embedUrl: e.embedUrl || "",
    qualities: e.qualities || [],
    subtitles: e.subtitles || [],
    altSources: e.altSources || [],
  };
}

type FilterKey = "all" | "movies" | "episodes" | "missing";

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "movies", label: "Movies" },
  { key: "episodes", label: "Episodes" },
  { key: "missing", label: "Missing video" },
];

export function CloudVideoManager() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<FilterKey>("all");
  const [q, setQ] = useState("");
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<CloudEntry | null>(null);

  const { data, isLoading } = useQuery<{ items: AdminAnime[] }>({
    queryKey: ["admin-anime", ""],
    queryFn: () => api.get("/api/admin/anime"),
  });

  const entries = useMemo(() => flatten(data?.items || []), [data]);

  const visible = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return entries.filter((e) => {
      if (filter === "movies" && e.kind !== "movie") return false;
      if (filter === "episodes" && e.kind !== "episode") return false;
      if (filter === "missing" && hasCloudVideo(e)) return false;
      if (needle && !`${e.title} ${e.animeTitle} ${e.embedUrl || ""} ${e.videoUrl || ""}`.toLowerCase().includes(needle))
        return false;
      return true;
    });
  }, [entries, filter, q]);

  const counts = useMemo(
    () => ({
      total: entries.length,
      withVideo: entries.filter(hasCloudVideo).length,
      missing: entries.filter((e) => !hasCloudVideo(e)).length,
    }),
    [entries]
  );

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-anime"] });
    qc.invalidateQueries({ queryKey: ["sections"] });
    qc.invalidateQueries({ queryKey: ["anime"] });
    qc.invalidateQueries({ queryKey: ["admin-stats"] });
  };

  const togglePublished = async (e: CloudEntry) => {
    try {
      await api.patch(`/api/admin/anime/${e.animeId}`, { published: !e.published });
      toast.success(!e.published ? "Published ✓" : "Unpublished");
      invalidate();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Update failed");
    }
  };

  const removeEntry = async (e: CloudEntry) => {
    const what = e.kind === "movie" ? `"${e.animeTitle}" (and all its seasons/episodes)` : `Episode ${e.label}`;
    if (!window.confirm(`Delete ${what}? This cannot be undone.`)) return;
    try {
      if (e.kind === "movie") await api.delete(`/api/admin/anime/${e.entryId}`);
      else await api.delete(`/api/admin/episodes/${e.entryId}`);
      toast.success("Deleted");
      invalidate();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    }
  };

  return (
    <div>
      {/* header */}
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#22C55E]/12 glow-green">
          <Cloud className="h-5.5 w-5.5 text-[#4ADE80]" />
        </span>
        <div>
          <h2 className="text-lg font-black text-white">Cloud Video Manager</h2>
          <p className="text-sm text-slate-400">
            Videos stream from your cloud storage — only URLs &amp; metadata are stored here.
          </p>
        </div>
        <div className="flex-1" />
        <button
          onClick={() => setAdding(true)}
          className="inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
        >
          <Plus className="h-4 w-4" /> Add Cloud Video
        </button>
      </div>

      {/* summary + search + filters */}
      <div className="mt-5 flex flex-wrap items-center gap-2.5">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-[#22C55E]/30 bg-[#22C55E]/10 px-3 py-1.5 text-xs font-bold text-[#4ADE80]">
          <CheckCircle2 className="h-3.5 w-3.5" /> {counts.withVideo}/{counts.total} entries have a video
        </span>
        {counts.missing > 0 && (
          <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1.5 text-xs font-bold text-amber-300">
            <TriangleAlert className="h-3.5 w-3.5" /> {counts.missing} waiting for a video
          </span>
        )}
        <span className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs font-semibold text-slate-400 sm:inline-flex">
          <ShieldCheck className="h-3.5 w-3.5 text-[#4ADE80]" /> Server-side only: private keys &amp; signing
        </span>
        <div className="flex-1" />
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search videos…"
            aria-label="Search cloud videos"
            className="h-10 w-48 rounded-full border border-white/10 bg-white/[0.04] pl-9 pr-3 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50"
          />
        </div>
      </div>

      <div className="mt-3 flex gap-1 overflow-x-auto rounded-2xl border border-white/8 bg-white/[0.02] p-1.5" role="tablist" aria-label="Cloud video filters">
        {FILTERS.map((f) => {
          const active = filter === f.key;
          return (
            <button
              key={f.key}
              role="tab"
              aria-selected={active}
              onClick={() => setFilter(f.key)}
              className={`relative shrink-0 rounded-xl px-4 py-2 text-sm font-bold transition-colors ${
                active ? "bg-[#22C55E] text-[#04220f]" : "text-slate-300 hover:bg-white/5"
              }`}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      {/* inventory */}
      <div className="mt-4 overflow-hidden rounded-2xl border border-white/8">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead>
              <tr className="border-b border-white/8 bg-white/[0.03] text-xs uppercase tracking-wider text-slate-400">
                <th className="px-4 py-3 font-bold">Video</th>
                <th className="px-4 py-3 font-bold">Where it streams from</th>
                <th className="px-4 py-3 font-bold">Quality</th>
                <th className="px-4 py-3 font-bold">Subtitles</th>
                <th className="px-4 py-3 font-bold">Live</th>
                <th className="px-4 py-3 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-slate-400">Loading…</td>
                </tr>
              ) : visible.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-slate-400">
                    No entries here yet — click <strong className="text-[#4ADE80]">Add Cloud Video</strong> to publish one.
                  </td>
                </tr>
              ) : (
                visible.map((e) => {
                  const badge = entrySourceBadge(e);
                  const missing = !hasCloudVideo(e);
                  return (
                    <tr key={`${e.kind}-${e.entryId}`} className="border-b border-white/5 transition-colors hover:bg-white/[0.02]">
                      <td className="max-w-72 px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          {e.poster ? (
                            <img src={e.poster} alt="" loading="lazy" className="h-11 w-8 shrink-0 rounded object-cover" />
                          ) : (
                            <span className="flex h-11 w-8 shrink-0 items-center justify-center rounded bg-white/8">
                              {e.kind === "movie" ? <Film className="h-3.5 w-3.5 text-slate-500" /> : <MonitorPlay className="h-3.5 w-3.5 text-slate-500" />}
                            </span>
                          )}
                          <span className="min-w-0">
                            <span className="block truncate font-semibold text-white">{e.title}</span>
                            <span className="block truncate text-xs text-slate-500">
                              {e.label} · {e.animeTitle}
                            </span>
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-block rounded px-2 py-0.5 text-xs font-bold ${badge.cls}`}>{badge.text}</span>
                        {missing && (
                          <button
                            onClick={() => setEditing(e)}
                            className="ml-2 text-xs font-bold text-[#4ADE80] underline-offset-2 hover:underline"
                          >
                            attach now
                          </button>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-300">{e.qualities.length || "—"}</td>
                      <td className="px-4 py-3 text-slate-300">{e.subtitles.length || "—"}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => togglePublished(e)}
                          aria-label={e.published ? "Unpublish" : "Publish"}
                          title={
                            e.published
                              ? "Live — click to unpublish (affects the whole title)"
                              : "Hidden — click to publish"
                          }
                          className={`flex h-8 w-8 items-center justify-center rounded-lg ${e.published ? "text-[#4ADE80]" : "text-slate-500"}`}
                        >
                          {e.published ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => navigate(`/watch/${e.animeSlug}${e.kind === "episode" ? "" : ""}`)}
                            aria-label="Open watch page"
                            title="Open watch page"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => setEditing(e)}
                            aria-label="Edit video source"
                            title="Edit video source"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-[#4ADE80]"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => removeEntry(e)}
                            aria-label="Delete"
                            title="Delete"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-300"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {adding && <CloudVideoForm onClose={() => setAdding(false)} onSaved={invalidate} items={data?.items || []} />}
      {editing && <EditVideoDialog entry={editing} onClose={() => setEditing(null)} onSaved={invalidate} />}
    </div>
  );
}

/* ------------------------------ add-cloud form ----------------------------- */

type Target = "new-movie" | "new-series" | "existing-movie" | "existing-episode" | "existing-series";

const TARGETS: { key: Target; label: string; hint: string }[] = [
  { key: "new-movie", label: "New movie", hint: "Anime Movie" },
  { key: "new-series", label: "New series", hint: "Anime Series + S/E" },
  { key: "existing-movie", label: "Existing movie", hint: "Attach / replace" },
  { key: "existing-episode", label: "Existing episode", hint: "Attach / replace" },
  { key: "existing-series", label: "Existing series", hint: "Add new episode" },
];

function CloudVideoForm({
  onClose,
  onSaved,
  items,
}: {
  onClose: () => void;
  onSaved: () => void;
  items: AdminAnime[];
}) {
  const [saving, setSaving] = useState(false);
  const [target, setTarget] = useState<Target>("new-movie");
  const [vs, setVs] = useState<VideoSourceValue>(EMPTY_VS);
  const [publish, setPublish] = useState(true);
  const [meta, setMeta] = useState({
    titleEn: "",
    titleSi: "",
    descriptionSi: "",
    descriptionEn: "",
    releaseYear: "",
    languageLabel: "SINHALA_DUBBED",
    posterUrl: "",
    seasonNumber: "1",
    episodeNumber: "1",
  });
  const [movieId, setMovieId] = useState("");
  const [seriesId, setSeriesId] = useState("");
  const [seasonId, setSeasonId] = useState("");
  const [episodeId, setEpisodeId] = useState("");
  // Saved Season # / Episode # of the episode picked under "Existing episode",
  // loaded into editable inputs so the admin can renumber or move it.
  const [epEdit, setEpEdit] = useState({ seasonNumber: "", episodeNumber: "" });

  const set = (patch: Partial<typeof meta>) => setMeta((m) => ({ ...m, ...patch }));

  const movies = items.filter((a) => a.type === "MOVIE");
  const series = items.filter((a) => a.type === "SERIES");
  const selectedSeries = series.find((s) => s.id === seriesId);
  const seasons = selectedSeries?.seasons || [];
  const selectedSeason = seasons.find((s) => s.id === seasonId);
  const episodes: EpisodeType[] = selectedSeason?.episodes || [];

  /* ------------------- season / episode number helpers ------------------- */

  /** Parse a Season/Episode number input; null when it is not a positive integer. */
  const parsePositiveInt = (raw: string): number | null => {
    if (!/^\d+$/.test(raw.trim())) return null;
    const n = Math.floor(Number(raw));
    return n >= 1 ? n : null;
  };

  /** Next free episode number inside a season of a series (max existing + 1). */
  const nextEpisodeNumberIn = (seriesRow: AdminAnime | undefined, seasonNum: number): number => {
    const season = seriesRow?.seasons?.find((s) => s.number === seasonNum);
    const nums = (season?.episodes || []).map((e) => e.number);
    return nums.length ? Math.max(...nums) + 1 : 1;
  };

  /** Season row with the given number, if it already exists in the series. */
  const seasonByNumber = (seriesRow: AdminAnime | undefined, seasonNum: number) =>
    seriesRow?.seasons?.find((s) => s.number === seasonNum);

  /** Highest existing season of a series (where new episodes usually go). */
  const latestSeasonNumber = (seriesRow: AdminAnime | undefined): number => {
    const nums = (seriesRow?.seasons || []).map((s) => s.number);
    return nums.length ? Math.max(...nums) : 1;
  };

  /**
   * "Existing series": pick a series → the season number defaults to its latest
   * season and the episode number auto-suggests the next free slot. Both inputs
   * stay fully editable afterwards.
   */
  const pickSeriesForNewEpisode = (id: string) => {
    setSeriesId(id);
    const row = series.find((s) => s.id === id);
    const seasonNum = latestSeasonNumber(row);
    set({ seasonNumber: String(seasonNum), episodeNumber: String(nextEpisodeNumberIn(row, seasonNum)) });
  };

  const changeSeasonNumberForNewEpisode = (raw: string) => {
    const digits = raw.replace(/\D/g, "").slice(0, 3);
    const num = parsePositiveInt(digits);
    set({
      seasonNumber: digits,
      // Re-suggest the next free episode slot whenever the season changes —
      // the admin can still overwrite it manually right after.
      episodeNumber: num ? String(nextEpisodeNumberIn(selectedSeries, num)) : "",
    });
  };

  // Context line under the season input ("Existing series" target).
  const seasonContext = (() => {
    if (!selectedSeries) return "Pick a series first.";
    const num = parsePositiveInt(meta.seasonNumber);
    if (!num) return "Season number must be 1, 2, 3, 4 …";
    const match = seasonByNumber(selectedSeries, num);
    if (match)
      return `Season ${num} exists — ${match.episodes.length} episode${match.episodes.length === 1 ? "" : "s"}${match.title ? ` · ${match.title}` : ""}.`;
    return `Season ${num} does not exist yet — it will be created automatically.`;
  })();

  const providerHint = providerHintFromUrl(vs.videoSource === "embed" ? vs.embedUrl : vs.videoUrl);

  const sourceReady =
    vs.videoSource === "embed"
      ? !("error" in toEmbedUrl(vs.embedUrl))
      : !!vs.videoUrl.trim();

  /** Validate the two number inputs once, shared by every series target. */
  const readSeriesNumbers = (): { season: number; episode: number } | null => {
    const season = parsePositiveInt(meta.seasonNumber);
    const episode = parsePositiveInt(meta.episodeNumber);
    if (!season) {
      toast.error("Season number must be a positive integer (1, 2, 3, 4 …)");
      return null;
    }
    if (!episode) {
      toast.error("Episode number must be a positive integer (1, 2, 3, 4, 5 …)");
      return null;
    }
    return { season, episode };
  };

  /**
   * Find a season by number inside a series, creating it when missing.
   * `/api/anime/[slug]` looks up by SLUG — pass the slug, never the id, for
   * the existence check; the id is only used to create the season.
   */
  const findOrCreateSeason = async (animeId: string, animeSlug: string, seasonNum: number): Promise<string> => {
    const detail = await api.get<{ anime: AnimeType }>(`/api/anime/${animeSlug}`);
    const match = detail.anime.seasons?.find((s) => s.number === seasonNum);
    if (match) return match.id;
    const created = await api.post<{ season: { id: string } }>("/api/admin/seasons", {
      animeId,
      number: seasonNum,
    });
    return created.season.id;
  };

  const submit = async () => {
    const sourcePayload = {
      videoSource: vs.videoSource,
      videoUrl: vs.videoUrl.trim(),
      embedUrl: vs.embedUrl.trim(),
      videoQualities: vs.qualities,
      subtitleTracks: vs.subtitles,
      altSources: vs.altSources,
      videoThumb: vs.videoThumb.trim(),
      subtitleUrl: "",
      downloadEnabled: vs.downloadEnabled,
      downloadUrl: vs.downloadUrl.trim(),
      downloadQualities: vs.downloadQualities,
      subtitleDownloadEnabled: vs.subtitleDownloadEnabled,
      subtitleDownloads: vs.subtitleDownloads,
    };

    setSaving(true);
    try {
      if (target === "new-movie") {
        if (!meta.titleEn.trim()) {
          toast.error("Anime title is required");
          setSaving(false);
          return;
        }
        await api.post("/api/admin/anime", {
          titleEn: meta.titleEn.trim(),
          titleSi: meta.titleSi.trim(),
          descriptionSi: meta.descriptionSi.trim(),
          descriptionEn: meta.descriptionEn.trim(),
          releaseYear: meta.releaseYear,
          languageLabel: meta.languageLabel,
          posterUrl: meta.posterUrl.trim(),
          type: "MOVIE",
          published: publish,
          ...sourcePayload,
        });
        toast.success(publish ? "Movie published ✓" : "Movie saved as draft");
      } else if (target === "new-series") {
        if (!meta.titleEn.trim()) {
          toast.error("Anime title is required");
          setSaving(false);
          return;
        }
        const nums = readSeriesNumbers();
        if (!nums) {
          setSaving(false);
          return;
        }
        const created = await api.post<{ anime: { id: string; slug: string } }>("/api/admin/anime", {
          titleEn: meta.titleEn.trim(),
          titleSi: meta.titleSi.trim(),
          descriptionSi: meta.descriptionSi.trim(),
          descriptionEn: meta.descriptionEn.trim(),
          releaseYear: meta.releaseYear,
          languageLabel: meta.languageLabel,
          posterUrl: meta.posterUrl.trim(),
          type: "SERIES",
          published: publish,
        });
        const seasonId2 = await findOrCreateSeason(created.anime.id, created.anime.slug, nums.season);
        await api.post("/api/admin/episodes", {
          seasonId: seasonId2,
          number: nums.episode,
          ...sourcePayload,
        });
        toast.success(publish ? "Series + episode published ✓" : "Saved as draft");
      } else if (target === "existing-series") {
        // Upload a NEW episode into an existing series, in the season the admin
        // chose (the season itself is created automatically when it is new).
        if (!seriesId) {
          toast.error("Pick a series first");
          setSaving(false);
          return;
        }
        const nums = readSeriesNumbers();
        if (!nums) {
          setSaving(false);
          return;
        }
        const existingSeason = seasonByNumber(selectedSeries, nums.season);
        if (
          existingSeason &&
          existingSeason.episodes.some((e) => e.number === nums.episode)
        ) {
          toast.error(
            `Episode ${nums.episode} already exists in Season ${nums.season} of "${selectedSeries.titleEn}" — pick another number, or edit that episode instead.`
          );
          setSaving(false);
          return;
        }
        const seasonId2 = await findOrCreateSeason(seriesId, selectedSeries.slug, nums.season);
        await api.post("/api/admin/episodes", {
          seasonId: seasonId2,
          number: nums.episode,
          ...sourcePayload,
        });
        toast.success(`Episode ${nums.episode} added to Season ${nums.season} ✓`);
      } else if (target === "existing-movie") {
        if (!movieId) {
          toast.error("Pick a movie first");
          setSaving(false);
          return;
        }
        await api.patch(`/api/admin/anime/${movieId}`, sourcePayload);
        toast.success("Movie video updated ✓");
      } else {
        if (!episodeId) {
          toast.error("Pick an episode first");
          setSaving(false);
          return;
        }
        // Season # / Episode # inputs are loaded from the picked episode — the
        // admin may renumber it and/or move it to another season of the series.
        const seasonNum = parsePositiveInt(epEdit.seasonNumber);
        const episodeNum = parsePositiveInt(epEdit.episodeNumber);
        if (selectedSeason && !seasonNum) {
          toast.error("Season number must be a positive integer (1, 2, 3, 4 …)");
          setSaving(false);
          return;
        }
        if (!episodeNum) {
          toast.error("Episode number must be a positive integer (1, 2, 3, 4, 5 …)");
          setSaving(false);
          return;
        }
        const patch: Record<string, unknown> = {
          ...sourcePayload,
          thumbnailUrl: vs.videoThumb.trim(),
          number: episodeNum,
        };
        if (selectedSeason && seasonNum !== selectedSeason.number) {
          const targetSeason = seasonByNumber(selectedSeries, seasonNum);
          if (targetSeason?.episodes.some((e) => e.id !== episodeId && e.number === episodeNum)) {
            toast.error(
              `Episode ${episodeNum} already exists in Season ${seasonNum} of "${selectedSeries.titleEn}".`
            );
            setSaving(false);
            return;
          }
          patch.seasonId = await findOrCreateSeason(seriesId, selectedSeries.slug, seasonNum);
        }
        await api.patch(`/api/admin/episodes/${episodeId}`, patch);
        toast.success("Episode video updated ✓");
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[80] overflow-y-auto bg-black/80 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Add Cloud Video">
      <div className="fade-up mx-auto my-4 max-w-3xl rounded-3xl border border-white/10 bg-[#0b1120] shadow-2xl shadow-black/60">
        {/* header */}
        <div className="flex items-center gap-3 border-b border-white/8 px-6 py-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#22C55E]/12">
            <Cloud className="h-5 w-5 text-[#4ADE80]" />
          </span>
          <div className="flex-1">
            <h3 className="text-base font-black text-white">Add Cloud Video</h3>
            <p className="text-xs text-slate-400">Paste a cloud video URL — nothing is uploaded to this server.</p>
          </div>
          <button onClick={onClose} aria-label="Close" className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-white">
            ✕
          </button>
        </div>

        <div className="space-y-5 px-6 py-5">
          {/* step 1 — target */}
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-400">1 · What are we publishing?</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
              {TARGETS.map((t) => {
                const active = target === t.key;
                return (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => setTarget(t.key)}
                    aria-pressed={active}
                    className={`rounded-xl border px-3 py-2.5 text-left transition-colors ${
                      active ? "border-[#22C55E] bg-[#22C55E]/15" : "border-white/10 bg-[#0b1120] hover:border-[#22C55E]/40"
                    }`}
                  >
                    <span className={`block text-sm font-bold ${active ? "text-[#4ADE80]" : "text-white"}`}>{t.label}</span>
                    <span className="block text-[10.5px] text-slate-400">{t.hint}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* step 2 — details */}
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-400">2 · Anime details</p>
            {(target === "new-movie" || target === "new-series") && (
              <div className="space-y-3 rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  <AdminField label="Anime title (English) *">
                    <input
                      value={meta.titleEn}
                      onChange={(e) => set({ titleEn: e.target.value })}
                      className={inputCls}
                      placeholder="Dragon Legacy"
                    />
                  </AdminField>
                  <AdminField label="සිංහල නම (Sinhala title)">
                    <input
                      value={meta.titleSi}
                      onChange={(e) => set({ titleSi: e.target.value })}
                      className={inputCls}
                      placeholder="ඩ්‍රැගන් ලෙගසි"
                    />
                  </AdminField>
                </div>
                <AdminField label="සිංහල විස්තරය (description)">
                  <textarea
                    value={meta.descriptionSi}
                    onChange={(e) => set({ descriptionSi: e.target.value })}
                    rows={3}
                    className={areaCls}
                  />
                </AdminField>
                <AdminField label="English description">
                  <textarea
                    value={meta.descriptionEn}
                    onChange={(e) => set({ descriptionEn: e.target.value })}
                    rows={2}
                    className={areaCls}
                  />
                </AdminField>
                <div className="grid gap-3 sm:grid-cols-3">
                  <AdminField label="Release year">
                    <input
                      value={meta.releaseYear}
                      onChange={(e) => set({ releaseYear: e.target.value.replace(/\D/g, "").slice(0, 4) })}
                      placeholder="2025"
                      inputMode="numeric"
                      className={inputCls}
                    />
                  </AdminField>
                  <AdminField label="Language label">
                    <select value={meta.languageLabel} onChange={(e) => set({ languageLabel: e.target.value })} className={selectCls}>
                      <option value="SINHALA_DUBBED" className="bg-[#0b1120]">Sinhala Dubbed</option>
                      <option value="SINHALA_SUB" className="bg-[#0b1120]">Sinhala Sub</option>
                      <option value="ANIME_REVIEW" className="bg-[#0b1120]">Anime Review</option>
                    </select>
                  </AdminField>
                  {target === "new-series" && (
                    <AdminField label="Season number">
                      <input
                        value={meta.seasonNumber}
                        onChange={(e) => set({ seasonNumber: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                        placeholder="1"
                        inputMode="numeric"
                        autoComplete="off"
                        className={inputCls}
                        aria-label="Season number"
                      />
                    </AdminField>
                  )}
                </div>
                {target === "new-series" && (
                  <AdminField label="Episode number">
                    <input
                      value={meta.episodeNumber}
                      onChange={(e) => set({ episodeNumber: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                      placeholder="1"
                      inputMode="numeric"
                      autoComplete="off"
                      className={inputCls}
                      aria-label="Episode number"
                    />
                  </AdminField>
                )}
                <UploadWidget
                  kind="poster"
                  label="Poster (portrait 2:3)"
                  accept="image/jpeg,image/png,image/webp,image/avif"
                  value={meta.posterUrl}
                  onChange={(url) => set({ posterUrl: url })}
                  hint="Shown in browse lists & the hero carousel"
                />
              </div>
            )}

            {target === "existing-movie" && (
              <div className="rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <AdminField label="Pick the movie">
                  <select value={movieId} onChange={(e) => setMovieId(e.target.value)} className={selectCls}>
                    <option value="" className="bg-[#0b1120]">— select a movie —</option>
                    {movies.map((m) => (
                      <option key={m.id} value={m.id} className="bg-[#0b1120]">
                        {m.titleEn} {m.videoSource !== "upload" || m.videoUrl ? "(has video)" : "(no video)"}
                      </option>
                    ))}
                  </select>
                </AdminField>
                {movies.length === 0 && (
                  <p className="mt-2 text-xs text-amber-300">No movies yet — use “New movie” instead.</p>
                )}
              </div>
            )}

            {target === "existing-series" && (
              <div className="space-y-3 rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <AdminField label="Series">
                  <select value={seriesId} onChange={(e) => pickSeriesForNewEpisode(e.target.value)} className={selectCls}>
                    <option value="" className="bg-[#0b1120]">— select a series —</option>
                    {series.map((s) => (
                      <option key={s.id} value={s.id} className="bg-[#0b1120]">
                        {s.titleEn} ({s.seasons?.length || 0} season{(s.seasons?.length || 0) === 1 ? "" : "s"})
                      </option>
                    ))}
                  </select>
                </AdminField>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <AdminField label="Season number">
                      <input
                        value={meta.seasonNumber}
                        onChange={(e) => changeSeasonNumberForNewEpisode(e.target.value)}
                        placeholder="1"
                        inputMode="numeric"
                        autoComplete="off"
                        className={inputCls}
                        aria-label="Season number for the new episode"
                      />
                    </AdminField>
                    <p className="mt-1.5 text-[11px] leading-snug text-slate-400">{seasonContext}</p>
                  </div>
                  <div>
                    <AdminField label="Episode number (next free suggested)">
                      <input
                        value={meta.episodeNumber}
                        onChange={(e) => set({ episodeNumber: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                        placeholder="1"
                        inputMode="numeric"
                        autoComplete="off"
                        className={inputCls}
                        aria-label="Episode number for the new episode"
                      />
                    </AdminField>
                    <p className="mt-1.5 text-[11px] leading-snug text-slate-400">
                      Auto-filled from the chosen season — change it to any free number.
                    </p>
                  </div>
                </div>
                {!series.length && (
                  <p className="text-xs text-amber-300">No series yet — use “New series” instead.</p>
                )}
              </div>
            )}

            {target === "existing-episode" && (
              <div className="space-y-3 rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                <div className="grid gap-3 sm:grid-cols-3">
                  <AdminField label="Series">
                    <select value={seriesId} onChange={(e) => { setSeriesId(e.target.value); setSeasonId(""); setEpisodeId(""); setEpEdit({ seasonNumber: "", episodeNumber: "" }); }} className={selectCls}>
                      <option value="" className="bg-[#0b1120]">— series —</option>
                      {series.map((s) => (
                        <option key={s.id} value={s.id} className="bg-[#0b1120]">{s.titleEn}</option>
                      ))}
                    </select>
                  </AdminField>
                  <AdminField label="Season">
                    <select value={seasonId} onChange={(e) => { setSeasonId(e.target.value); setEpisodeId(""); setEpEdit({ seasonNumber: "", episodeNumber: "" }); }} disabled={!selectedSeries} className={selectCls}>
                      <option value="" className="bg-[#0b1120]">— season —</option>
                      {seasons.map((s) => (
                        <option key={s.id} value={s.id} className="bg-[#0b1120]">Season {s.number}</option>
                      ))}
                    </select>
                  </AdminField>
                  <AdminField label="Episode">
                    <select
                      value={episodeId}
                      onChange={(e) => {
                        const id = e.target.value;
                        setEpisodeId(id);
                        // Load the episode's saved Season # / Episode # into the
                        // editable inputs below so they can be changed on save.
                        const ep = episodes.find((x) => x.id === id);
                        setEpEdit({
                          seasonNumber: selectedSeason && ep ? String(selectedSeason.number) : "",
                          episodeNumber: ep ? String(ep.number) : "",
                        });
                      }}
                      disabled={!selectedSeason}
                      className={selectCls}
                    >
                      <option value="" className="bg-[#0b1120]">— episode —</option>
                      {episodes.map((ep) => (
                        <option key={ep.id} value={ep.id} className="bg-[#0b1120]">
                          EP {ep.number}{ep.title ? ` · ${ep.title}` : ""}
                        </option>
                      ))}
                    </select>
                  </AdminField>
                </div>
                {episodeId && (
                  <div className="grid gap-3 rounded-xl border border-[#22C55E]/25 bg-[#22C55E]/[0.04] p-3 sm:grid-cols-2">
                    <AdminField label="Season # (saved)">
                      <input
                        value={epEdit.seasonNumber}
                        onChange={(e) => setEpEdit((s) => ({ ...s, seasonNumber: e.target.value.replace(/\D/g, "").slice(0, 3) }))}
                        placeholder="1"
                        inputMode="numeric"
                        autoComplete="off"
                        className={inputCls}
                        aria-label="Saved season number"
                      />
                    </AdminField>
                    <AdminField label="Episode # (saved)">
                      <input
                        value={epEdit.episodeNumber}
                        onChange={(e) => setEpEdit((s) => ({ ...s, episodeNumber: e.target.value.replace(/\D/g, "").slice(0, 3) }))}
                        placeholder="1"
                        inputMode="numeric"
                        autoComplete="off"
                        className={inputCls}
                        aria-label="Saved episode number"
                      />
                    </AdminField>
                    <p className="text-[11px] leading-snug text-slate-400 sm:col-span-2">
                      Loaded from the selected episode — change the numbers to renumber it or move it to another season of this series when saving.
                    </p>
                  </div>
                )}
                {!series.length && <p className="text-xs text-amber-300">No series yet — use “New series” instead.</p>}
              </div>
            )}
          </div>

          {/* step 3 — cloud video source (full editor: validation, quality, subs, preview, downloads) */}
          <div>
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-400">3 · Cloud video source</p>
            {providerHint && (
              <p className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-sky-400/30 bg-sky-400/10 px-3 py-1 text-[11px] font-bold text-sky-300">
                <Cloud className="h-3 w-3" /> Provider detected: {providerHint}
              </p>
            )}
            <VideoSourceEditor value={vs} onChange={setVs} title={meta.titleEn || "New cloud video"} isEpisode={target.includes("episode")} />
          </div>

          {/* publish row */}
          <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/8 bg-white/[0.02] p-4">
            <label className="flex items-center gap-2.5 text-sm font-semibold text-slate-200">
              <input type="checkbox" checked={publish} onChange={(e) => setPublish(e.target.checked)} className="h-4 w-4 accent-[#22C55E]" />
              Publish immediately (visible to everyone)
            </label>
            <span className="text-xs text-slate-500">Uncheck to save as a hidden draft.</span>
            <div className="flex-1" />
            <button onClick={onClose} className="h-10 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white">
              Cancel
            </button>
            <button
              onClick={submit}
              disabled={saving}
              className="inline-flex h-10 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Cloud className="h-4 w-4" />}
              {publish ? "Publish Cloud Video" : "Save Draft"}
            </button>
          </div>
          {!sourceReady && (
            <p className="-mt-2 text-center text-[11px] text-slate-500">
              Tip: paste a direct HTTPS media URL (MP4 / WebM / .m3u8) or a provider link in the “Provider embed” tab above.
            </p>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

/* ------------------------------ edit dialog -------------------------------- */

function EditVideoDialog({
  entry,
  onClose,
  onSaved,
}: {
  entry: CloudEntry;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [saving, setSaving] = useState(false);
  const [vs, setVs] = useState<VideoSourceValue>(() => seedVs(entry));

  const save = async () => {
    const payload = {
      videoSource: vs.videoSource,
      videoUrl: vs.videoUrl.trim(),
      embedUrl: vs.embedUrl.trim(),
      videoQualities: vs.qualities,
      subtitleTracks: vs.subtitles,
      altSources: vs.altSources,
      videoThumb: vs.videoThumb.trim(),
      subtitleUrl: "",
      downloadEnabled: vs.downloadEnabled,
      downloadUrl: vs.downloadUrl.trim(),
      downloadQualities: vs.downloadQualities,
      subtitleDownloadEnabled: vs.subtitleDownloadEnabled,
      subtitleDownloads: vs.subtitleDownloads,
    };
    setSaving(true);
    try {
      if (entry.kind === "movie") {
        await api.patch(`/api/admin/anime/${entry.entryId}`, payload);
      } else {
        await api.patch(`/api/admin/episodes/${entry.entryId}`, { ...payload, thumbnailUrl: vs.videoThumb.trim() });
      }
      toast.success("Video source updated ✓");
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[80] overflow-y-auto bg-black/80 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={`Edit video — ${entry.title}`}>
      <div className="fade-up mx-auto my-4 max-w-2xl rounded-3xl border border-white/10 bg-[#0b1120] shadow-2xl shadow-black/60">
        <div className="flex items-center gap-3 border-b border-white/8 px-6 py-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#22C55E]/12">
            <MonitorPlay className="h-5 w-5 text-[#4ADE80]" />
          </span>
          <div className="flex-1 min-w-0">
            <h3 className="truncate text-base font-black text-white">Edit video — {entry.title}</h3>
            <p className="text-xs text-slate-400">{entry.label} · streams from the cloud, nothing stored here.</p>
          </div>
          <button onClick={onClose} aria-label="Close" className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-white">
            ✕
          </button>
        </div>

        <div className="space-y-4 px-6 py-5">
          <VideoSourceEditor value={vs} onChange={setVs} title={entry.title} isEpisode={entry.kind === "episode"} />

          <div className="flex justify-end gap-2">
            <button onClick={onClose} className="h-10 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white">
              Cancel
            </button>
            <button
              onClick={save}
              disabled={saving}
              className="inline-flex h-10 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
              Save Video Source
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}
