"use client";

import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Star, Play, CalendarDays, Languages, Tv, Clapperboard, Bookmark, BookmarkCheck,
  Hourglass, ChevronLeft, ListVideo, BadgeCheck,
} from "lucide-react";
import { toast } from "sonner";
import { api, fmtDuration, LANGUAGE_LABELS } from "@/lib/client-api";
import { navigate, useAppStore, type AnimeType } from "@/store/useAppStore";
import { Spinner, PosterSkeleton } from "./../Skeletons";
import { ErrorState } from "./../EmptyState";

export function DetailView({ slug }: { slug: string }) {
  const { user } = useAppStore();
  const qc = useQueryClient();
  const [seasonNumber, setSeasonNumber] = useState<number | null>(null);
  const [inList, setInList] = useState<boolean | null>(null);

  const { data, isLoading, isError, error, refetch } = useQuery<{ anime: AnimeType }>({
    queryKey: ["anime", slug],
    queryFn: () => api.get(`/api/anime/${slug}`),
  });

  const anime = data?.anime;

  // initial season selection
  const activeSeason = useMemo(() => {
    if (!anime?.seasons?.length) return null;
    const found = anime.seasons.find((s) => s.number === seasonNumber);
    return found || anime.seasons[0];
  }, [anime, seasonNumber]);

  // watchlist state for this title
  const { data: wl } = useQuery<{ items: AnimeType[] }>({
    queryKey: ["watchlist", user?.id],
    queryFn: () => api.get("/api/watchlist"),
    enabled: !!user,
  });
  const watchlisted = inList ?? !!wl?.items.some((i) => i.id === anime?.id);

  const toggleWatchlist = async () => {
    if (!user) {
      toast("Sign in to build your watchlist", { description: "ඔබගේ නැරඹුම් ලැයිස්තුවට එකතු කිරීමට sign in වන්න." });
      navigate("/signin");
      return;
    }
    if (!anime) return;
    try {
      const res = await api.post<{ inWatchlist: boolean }>("/api/watchlist", { animeId: anime.id, action: "toggle" });
      setInList(res.inWatchlist);
      qc.invalidateQueries({ queryKey: ["watchlist"] });
      toast(res.inWatchlist ? "Added to your watchlist ✓" : "Removed from watchlist");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not update watchlist");
    }
  };

  if (isLoading) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <div className="h-[300px] w-full animate-pulse rounded-3xl bg-white/[0.04]" />
        <div className="mt-6 flex gap-6">
          <PosterSkeleton />
          <div className="flex-1 space-y-3 py-2">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-5 w-2/3 animate-pulse rounded bg-white/[0.06]" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (isError || !anime) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20">
        <ErrorState
          message={error instanceof Error ? error.message : "Anime not found. It may have been removed."}
          onRetry={() => refetch()}
        />
        <div className="mt-6 text-center">
          <button onClick={() => navigate("/")} className="text-sm font-semibold text-[#4ADE80] hover:underline">
            ← Back to home
          </button>
        </div>
      </div>
    );
  }

  const upcoming = anime.status === "UPCOMING";
  const firstEp = activeSeason?.episodes?.[0];
  const moviePlayable = anime.type === "MOVIE" ? (anime.video ? anime.video.kind !== "none" : !!anime.videoUrl) : false;
  const canWatch = !upcoming && (anime.type === "MOVIE" ? moviePlayable : !!firstEp);
  const movieVideoUrl = anime.type === "MOVIE" ? `/watch/${anime.slug}` : "";

  return (
    <article className="fade-up pb-10">
      {/* backdrop */}
      <div className="relative h-[42vh] min-h-[260px] w-full overflow-hidden sm:h-[48vh]">
        {anime.backdropUrl || anime.posterUrl ? (
          <img
            src={anime.backdropUrl || anime.posterUrl || ""}
            alt={`${anime.titleEn} backdrop`}
            className="absolute inset-0 h-full w-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-[#0d3b1e] via-[#101827] to-[#050816]" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050816] via-[#050816]/55 to-[#050816]/20" />
        <button
          onClick={() => history.back()}
          className="absolute left-4 top-4 z-10 inline-flex h-10 items-center gap-1.5 rounded-full border border-white/15 bg-black/40 px-4 text-sm font-semibold text-white backdrop-blur transition-colors hover:border-[#4ADE80]/50 sm:left-6"
          aria-label="Go back"
        >
          <ChevronLeft className="h-4 w-4" /> Back
        </button>
      </div>

      <div className="mx-auto -mt-28 max-w-6xl px-4 sm:px-6">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end">
          {/* poster */}
          <div className="w-36 shrink-0 sm:w-48">
            <div className="overflow-hidden rounded-2xl border border-white/10 shadow-2xl shadow-black/60 glow-green-lg">
              {anime.posterUrl ? (
                <img src={anime.posterUrl} alt={`${anime.titleEn} poster`} className="aspect-[2/3] w-full object-cover" />
              ) : (
                <div className="flex aspect-[2/3] w-full items-center justify-center bg-[#101827] p-4 text-center text-sm font-bold text-[#4ADE80]">
                  {anime.titleEn}
                </div>
              )}
            </div>
          </div>

          {/* titles + meta */}
          <div className="min-w-0 flex-1 pb-1">
            <span
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11.5px] font-bold ${
                upcoming
                  ? "border-[#F59E0B]/50 bg-[#F59E0B]/10 text-[#F59E0B]"
                  : "border-[#22C55E]/50 bg-[#22C55E]/12 text-[#4ADE80]"
              }`}
            >
              {upcoming ? <Hourglass className="h-3.5 w-3.5" /> : anime.type === "MOVIE" ? <Clapperboard className="h-3.5 w-3.5" /> : <Tv className="h-3.5 w-3.5" />}
              {upcoming ? "COMING SOON" : anime.category === "OTHERS" ? "OTHERS" : anime.type === "MOVIE" ? "ANIME MOVIE" : "ANIME SERIES"}
            </span>
            <h1 className="mt-2 text-3xl font-black leading-tight text-white sm:text-4xl">{anime.titleEn}</h1>
            {anime.titleSi && <p className="mt-1 text-lg font-semibold text-[#4ADE80]">{anime.titleSi}</p>}

            <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
              {typeof anime.rating === "number" && (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-[#FACC15]/30 bg-black/40 px-2.5 py-1 font-bold text-white">
                  <Star className="h-4 w-4 fill-[#FACC15] text-[#FACC15]" /> {anime.rating.toFixed(1)}
                </span>
              )}
              {anime.releaseYear && (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-2.5 py-1 font-semibold text-slate-200">
                  <CalendarDays className="h-4 w-4 text-slate-400" /> {anime.releaseYear}
                </span>
              )}
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-2.5 py-1 font-semibold text-slate-200">
                <Languages className="h-4 w-4 text-slate-400" /> {LANGUAGE_LABELS[anime.languageLabel] || anime.languageLabel}
              </span>
              {anime.type === "SERIES" && anime.seasons && (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.05] px-2.5 py-1 font-semibold text-slate-200">
                  <ListVideo className="h-4 w-4 text-slate-400" /> {anime.seasons.length} season{anime.seasons.length > 1 ? "s" : ""}
                </span>
              )}
            </div>

            {/* genres */}
            {anime.genres.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {anime.genres.map((g) => (
                  <span key={g} className="rounded-full bg-white/[0.06] px-2.5 py-1 text-xs font-medium text-slate-300">
                    {g}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* actions */}
        <div className="mt-6 flex flex-wrap items-center gap-3">
          {upcoming ? (
            <span className="inline-flex h-12 items-center gap-2 rounded-full bg-[#F59E0B] px-6 font-bold text-[#1c1002]">
              <Hourglass className="h-5 w-5" /> Releasing {anime.releaseYear || "soon"} — not available yet
            </span>
          ) : canWatch ? (
            <button
              onClick={() => navigate(movieVideoUrl || `/watch/${anime.slug}`)}
              className="inline-flex h-12 items-center gap-2 rounded-full bg-[#22C55E] px-7 font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/30 transition-all hover:bg-[#4ADE80] hover:glow-green"
            >
              <Play className="h-5 w-5 fill-current" />
              {anime.type === "MOVIE" ? "Watch Now" : `Play S${activeSeason?.number} E1`}
            </button>
          ) : (
            <span className="inline-flex h-12 items-center gap-2 rounded-full border border-white/15 px-6 font-semibold text-slate-400">
              Episodes coming soon
            </span>
          )}

          <button
            onClick={toggleWatchlist}
            aria-pressed={watchlisted}
            className={`inline-flex h-12 items-center gap-2 rounded-full border px-5 font-semibold transition-all ${
              watchlisted
                ? "border-[#22C55E]/60 bg-[#22C55E]/12 text-[#4ADE80]"
                : "border-white/20 bg-white/5 text-white hover:border-[#22C55E]/40 hover:text-[#4ADE80]"
            }`}
          >
            {watchlisted ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
            {watchlisted ? "In Watchlist" : "Add to Watchlist"}
          </button>
        </div>

        {/* synopsis + availability */}
        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="text-lg font-extrabold text-white">කථා සාරාංශය — Synopsis</h2>
            <p className="mt-2.5 leading-relaxed text-slate-300">
              {anime.descriptionSi || anime.descriptionEn || "විස්තරයක් තවම එකතු කර නොමැත."}
            </p>
            {anime.descriptionEn && anime.descriptionSi && (
              <p className="mt-3 text-sm leading-relaxed text-slate-400">{anime.descriptionEn}</p>
            )}
          </div>
          <aside className="rounded-2xl border border-white/8 bg-white/[0.03] p-5">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#4ADE80]">Details</h2>
            <dl className="mt-3 space-y-2.5 text-sm">
              <Row
                label="Type"
                value={
                  anime.category === "OTHERS"
                    ? "Others"
                    : anime.type === "MOVIE"
                      ? "Anime Movie"
                      : "Anime Series"
                }
              />
              {anime.category === "OTHERS" && anime.seasonNumber != null && (
                <Row label="Season" value={String(anime.seasonNumber)} />
              )}
              {anime.category === "OTHERS" && anime.episodeNumber != null && (
                <Row label="Episode" value={String(anime.episodeNumber)} />
              )}
              <Row label="Year" value={anime.releaseYear ? String(anime.releaseYear) : "TBA"} />
              <Row label="Language" value={LANGUAGE_LABELS[anime.languageLabel] || anime.languageLabel} />
              <Row
                label="Availability"
                value={anime.availability || (upcoming ? "ඉක්මනින් — coming soon" : "සිංහල උපසිරැසි / හඬ")}
              />
              <Row label="Status" value={upcoming ? "Upcoming" : "Released"} />
              {typeof anime.rating === "number" && <Row label="Rating" value={`★ ${anime.rating.toFixed(1)} / 10`} />}
            </dl>
            {anime.published === false && user?.role === "ADMIN" && (
              <p className="mt-3 rounded-lg bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-300">
                Draft — only visible to admins
              </p>
            )}
          </aside>
        </div>

        {/* seasons + episodes */}
        {anime.type === "SERIES" && anime.seasons && anime.seasons.length > 0 && (
          <section className="mt-10" aria-label="Episodes">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-xl font-extrabold text-white">Episodes</h2>
              {anime.seasons.length > 1 && (
                <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Select season">
                  {anime.seasons.map((s) => (
                    <button
                      key={s.id}
                      role="tab"
                      aria-selected={activeSeason?.id === s.id}
                      onClick={() => setSeasonNumber(s.number)}
                      className={`h-10 rounded-xl px-4 text-sm font-bold transition-colors ${
                        activeSeason?.id === s.id
                          ? "bg-[#22C55E] text-[#04220f] shadow-lg shadow-[#22C55E]/25"
                          : "border border-white/10 bg-white/[0.04] text-slate-300 hover:border-[#22C55E]/40"
                      }`}
                    >
                      Season {s.number}
                      {s.title ? ` — ${s.title}` : ""}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {upcoming ? (
              <div className="mt-5 rounded-2xl border border-[#F59E0B]/25 bg-[#F59E0B]/5 px-5 py-6 text-center">
                <Hourglass className="mx-auto h-8 w-8 text-[#F59E0B]" />
                <p className="mt-2 font-bold text-[#F59E0B]">මෙම කතා මාලාව තවම නිකුත් වී නොමැත</p>
                <p className="mt-1 text-sm text-slate-400">
                  Episode list will unlock when the season releases{anime.releaseYear ? ` in ${anime.releaseYear}` : ""}.
                </p>
              </div>
            ) : (
              <ol className="mt-5 space-y-2.5">
                {activeSeason?.episodes?.length ? (
                  activeSeason.episodes.map((ep) => {
                    const playable = ep.video ? ep.video.kind !== "none" : !!ep.videoUrl || !!ep.embedUrl;
                    return (
                      <li key={ep.id}>
                        <button
                          onClick={() =>
                            playable
                              ? navigate(`/watch/${anime.slug}?s=${activeSeason.number}&e=${ep.number}`)
                              : toast("This episode is not available yet")
                          }
                          className={`group flex w-full items-center gap-4 rounded-2xl border p-3.5 text-left transition-all ${
                            playable
                              ? "border-white/8 bg-white/[0.03] hover:border-[#22C55E]/45 hover:bg-[#22C55E]/[0.06]"
                              : "border-white/5 bg-white/[0.015] opacity-70"
                          }`}
                          aria-label={`Episode ${ep.number}: ${ep.title || ""}${playable ? "" : " (unavailable)"}`}
                        >
                          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#22C55E]/12 text-sm font-black text-[#4ADE80] transition-colors group-hover:bg-[#22C55E] group-hover:text-[#04220f]">
                            {ep.number}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-semibold text-white">
                              {ep.title || `Episode ${ep.number}`}
                            </span>
                            {ep.description && (
                              <span className="mt-0.5 block truncate text-[13px] text-slate-400">{ep.description}</span>
                            )}
                          </span>
                          <span className="hidden shrink-0 items-center gap-2 text-xs text-slate-500 sm:flex">
                            {fmtDuration(ep.durationSec) && <span>{fmtDuration(ep.durationSec)}</span>}
                            {(ep.subtitleTracks?.length || ep.subtitleUrl) && (
                              <span className="rounded bg-white/8 px-1.5 py-0.5 font-semibold text-slate-300">CC සිං</span>
                            )}
                          </span>
                          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/8 text-white transition-colors group-hover:bg-[#22C55E] group-hover:text-[#04220f]">
                            {playable ? <Play className="h-4 w-4 fill-current" /> : <BadgeCheck className="h-4 w-4" />}
                          </span>
                        </button>
                      </li>
                    );
                  })
                ) : (
                  <li className="rounded-2xl border border-dashed border-white/10 px-5 py-8 text-center text-sm text-slate-400">
                    No episodes added for this season yet — check back soon.
                  </li>
                )}
              </ol>
            )}
          </section>
        )}
      </div>
    </article>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="shrink-0 text-slate-400">{label}</dt>
      <dd className="text-right font-semibold text-slate-200">{value}</dd>
    </div>
  );
}
