"use client";

/**
 * Download bar shown directly below the watch-page player: "Download Video" /
 * "Download Subtitles" with per-quality / per-language selection menus. Files
 * always come straight from the storage provider (or a signed private-bucket
 * URL minted on demand) — never proxied through this site. When the URL
 * cannot start a download on its own, a provider-aware download dialog takes
 * over cleanly: the branded "Download Your Video" dialog for Google Drive
 * (whose primary button saves the file directly in the browser via Drive's
 * official direct-download endpoint), a TeraBox-specific explanation for
 * TeraBox, and a neutral hand-off for any other storage host — never a scary
 * technical error.
 *
 * Both buttons are ALWAYS rendered on every watch page: when no authorized
 * file is configured they switch to a disabled state that says why
 * ("Subtitles Not Available" / "Video Download Not Available") instead of
 * disappearing — a fake-looking download must never be shown, but the
 * buttons themselves must never be missing either.
 */
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  Check,
  Cloud,
  Copy,
  Download,
  ExternalLink,
  Info,
  Loader2,
  ShieldCheck,
  Subtitles,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import type { ResolvedDownload } from "@/lib/media-types";
import type { AnimeType, EpisodeType } from "@/store/useAppStore";
import { Popover, PopoverContent, PopoverTrigger } from "./../ui/popover";

const BTN_PRIMARY =
  "bg-[#22C55E] text-[#04220f] hover:bg-[#4ADE80] shadow-lg shadow-[#22C55E]/20";
// Spec design: dark #101827 background + emerald border + smooth hover.
const BTN_OUTLINE =
  "border border-[#22C55E]/50 bg-[#101827] text-[#4ADE80] hover:border-[#22C55E] hover:bg-[#22C55E]/10";

function triggerDownload(url: string, filename: string) {
  const a = document.createElement("a");
  a.href = url;
  a.download = filename; // honoured same-origin; cross-origin relies on the provider's Content-Disposition
  // noreferrer strips the Referer header — Google Drive serves its virus-scan
  // interstitial (instead of the file) to download navigations that carry a
  // third-party Referer. Without it the file streams straight into the
  // browser download.
  a.rel = "noopener noreferrer";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

type DownloadOption = { index: number; label: string; format: string; lang?: string };

function DownloadButton({
  variant,
  label,
  sinhala,
  icon,
  options,
  busy,
  onPick,
  unavailableNote,
}: {
  variant: "primary" | "outline";
  label: string;
  sinhala: string;
  icon: React.ReactNode;
  options: DownloadOption[];
  busy: { index: number | null } | null;
  onPick: (index: number) => void;
  /** Set when the button must stay visible but disabled — explains why. */
  unavailableNote?: string;
}) {
  const unavailable = options.length === 0;
  const hasMenu = options.length > 1;

  const buttonEl = (
    <button
      type="button"
      disabled={unavailable || !!busy}
      title={unavailable ? unavailableNote : undefined}
      onClick={unavailable ? undefined : hasMenu ? undefined : () => onPick(options[0].index)}
      aria-label={`${label} (${sinhala})${hasMenu ? " — choose a file" : ""}`}
      aria-haspopup={hasMenu ? "menu" : undefined}
      aria-disabled={unavailable || undefined}
      className={`inline-flex min-h-12 items-center justify-center gap-2.5 rounded-full px-5 py-3 text-sm font-bold transition-colors sm:min-w-56 ${
        unavailable ? "cursor-not-allowed opacity-55" : "disabled:opacity-60"
      } ${variant === "primary" ? BTN_PRIMARY : BTN_OUTLINE}`}
    >
      {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : icon}
      <span className="text-left leading-tight">
        {label}
        <span className={`block text-[11px] font-semibold ${unavailable ? "text-slate-400" : "opacity-80"}`}>
          {sinhala}
        </span>
      </span>
      {hasMenu && !busy && (
        <span aria-hidden className="ml-1 text-xs opacity-70">
          ▾
        </span>
      )}
    </button>
  );

  // Unavailable (disabled state) or single option → a plain button; no empty menu.
  if (unavailable || !hasMenu) return buttonEl;

  return (
    <Popover>
      <PopoverTrigger asChild>
        {buttonEl}
      </PopoverTrigger>
      <PopoverContent
        align="start"
        sideOffset={8}
        className="w-72 rounded-2xl border-white/10 bg-[#0b1120] p-2 shadow-2xl shadow-black/60"
      >
          <p className="px-3 pb-1.5 pt-2 text-[11px] font-bold uppercase tracking-wider text-slate-500">
            {label} — choose a file
          </p>
          <div role="menu" aria-label={`${label} options`}>
            {options.map((opt) => (
              <button
                key={opt.index}
                type="button"
                role="menuitem"
                onClick={() => onPick(opt.index)}
                disabled={!!busy}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-[#22C55E]/10 disabled:opacity-50"
              >
                <span className="flex h-8 w-10 shrink-0 items-center justify-center rounded-lg bg-white/8 text-[10px] font-black text-slate-200">
                  {busy && busy.index === opt.index ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    opt.format
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold text-white">{opt.label}</span>
                  <span className="block text-[11px] text-slate-500">
                    {opt.lang ? `language: ${opt.lang} · ` : ""}
                    {opt.format}
                  </span>
                </span>
                <Download className="h-4 w-4 shrink-0 text-[#4ADE80]" />
              </button>
            ))}
          </div>
        </PopoverContent>
    </Popover>
  );
}

/** Official Google Drive triangle logo (Google brand geometry, 4 colours). */
function GoogleDriveIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 87.3 78" className={className} aria-hidden="true" focusable="false">
      <path d="m6.6 66.85 3.85 6.65c.8 1.4 1.95 2.5 3.3 3.3l13.75-23.8h-27.5c0 1.55.4 3.1 1.2 4.5z" fill="#0066da" />
      <path d="m43.65 25-13.75-23.8c-1.35.8-2.5 1.9-3.3 3.3l-25.4 44a9.06 9.06 0 0 0-1.2 4.5h27.5z" fill="#00ac47" />
      <path d="m73.55 76.8c1.35-.8 2.5-1.9 3.3-3.3l1.6-2.75 7.65-13.25c.8-1.4 1.2-2.95 1.2-4.5h-27.5l5.85 11.5z" fill="#ea4335" />
      <path d="m43.65 25 13.75-23.8c-1.35-.8-2.9-1.2-4.5-1.2h-18.5c-1.6 0-3.15.45-4.5 1.2z" fill="#00832d" />
      <path d="m59.8 53h-32.3l-13.75 23.8c1.35.8 2.9 1.2 4.5 1.2h50.8c1.6 0 3.15-.45 4.5-1.2z" fill="#2684fc" />
      <path d="m73.4 26.5-12.7-22c-.8-1.4-1.95-2.5-3.3-3.3l-13.75 23.8 13.75 23.8h27.45c0-1.55-.4-3.1-1.2-4.5z" fill="#ffba00" />
    </svg>
  );
}

/**
 * Provider-aware download dialog for hosts that cannot force a download.
 * Google Drive gets the branded "Download Your Video" dialog (emerald primary
 * button, Drive indicator, friendly tip, secure footer); TeraBox and every
 * other storage host get the same clean shell with their own honest
 * explanation — never a scary technical error.
 */
function DownloadDialog({
  res,
  kind,
  onClose,
}: {
  res: ResolvedDownload;
  kind: "video" | "subtitle";
  onClose: () => void;
}) {
  const [closing, setClosing] = useState(false);
  const [copied, setCopied] = useState(false);
  const primaryRef = useRef<HTMLButtonElement>(null);

  const isDrive = res.provider === "googledrive";
  const isTeraBox = res.provider === "terabox";
  const noun = kind === "video" ? "video" : "subtitle file";

  // Hostname behind the file, for the storage-provider indicator.
  let hostLabel = "";
  try {
    hostLabel = new URL(res.url).hostname.replace(/^www\./, "");
  } catch {}

  const requestClose = () => setClosing(true);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setClosing(true);
    };
    document.addEventListener("keydown", onKey);
    // Keep the page behind the dialog still while it is open (mobile scroll).
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    primaryRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  const copy = async () => {
    try {
      // Always copy the ORIGINAL download URL the admin stored for this title
      // — never the derived direct-download URL.
      await navigator.clipboard.writeText(res.copyUrl ?? res.url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 4000);
    } catch {
      toast.error("Could not copy the link");
    }
  };
  const open = () => {
    // Google Drive: res.url is Drive's official direct-download endpoint
    // (Content-Disposition: attachment), so this navigation makes the browser
    // save the file immediately — the page never leaves the site, and no
    // Drive app, preview page or intermediate redirect page is involved.
    if (isDrive) {
      triggerDownload(res.url, res.filename);
      return;
    }
    window.open(res.url, "_blank", "noopener,noreferrer");
  };

  if (typeof document === "undefined") return null;

  return createPortal(
    <div
      className={`fixed inset-0 z-[80] flex overflow-y-auto bg-black/80 p-4 backdrop-blur-[2px] ${
        closing ? "animate-out fade-out duration-150" : "animate-in fade-in duration-200"
      }`}
      role="dialog"
      aria-modal="true"
      aria-label={isDrive ? "Download your video" : "Open download link"}
      onClick={requestClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        onAnimationEnd={(e) => {
          if (closing && e.target === e.currentTarget) onClose();
        }}
        className={`m-auto w-full max-w-md rounded-3xl border border-white/10 bg-[#0B1224] p-5 shadow-2xl shadow-black/60 sm:p-6 ${
          closing ? "animate-out fade-out zoom-out-95 duration-150" : "animate-in fade-in zoom-in-95 duration-200"
        }`}
      >
        {/* Header: provider icon, title, description, close button */}
        <div className="flex items-start gap-3.5">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#22C55E]/25 bg-[#22C55E]/10">
            {isDrive ? (
              <GoogleDriveIcon className="h-6 w-6" />
            ) : (
              <Cloud className="h-6 w-6 text-[#4ADE80]" />
            )}
          </span>
          <div className="min-w-0 flex-1 pt-0.5">
            <h3 className="text-lg font-black leading-tight text-white">
              {isDrive ? (kind === "video" ? "Download Your Video" : "Download Your Subtitle") : "Open Download Link"}
            </h3>
            <p className="mt-1 text-sm leading-relaxed text-slate-300">
              {isDrive
                ? `Your ${noun} is ready! The download starts directly in your browser.`
                : "Your file is ready on the storage host. Continue there to download it."}
            </p>
          </div>
          <button
            type="button"
            onClick={requestClose}
            aria-label="Close"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* File information card: filename, size, type, provider indicator */}
        <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-11 shrink-0 items-center justify-center rounded-lg bg-white/10 text-[10px] font-black tracking-wide text-slate-100">
              {res.format}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold text-white" title={res.filename}>
                {res.filename}
              </p>
              <p className="mt-0.5 truncate text-xs text-slate-400">
                {res.format}
                {res.sizeLabel ? ` · ${res.sizeLabel}` : ""}
              </p>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2 border-t border-white/10 pt-3">
            {isDrive ? (
              <>
                <GoogleDriveIcon className="h-4 w-4 shrink-0" />
                <span className="text-xs font-bold text-slate-100">Google Drive</span>
                <span className="truncate text-[11px] text-slate-500">· hosted by Google</span>
              </>
            ) : (
              <>
                <Cloud className="h-4 w-4 shrink-0 text-[#4ADE80]" />
                <span className="text-xs font-bold text-slate-100">{isTeraBox ? "TeraBox" : "External storage host"}</span>
                {hostLabel && !isTeraBox ? <span className="truncate text-[11px] text-slate-500">· {hostLabel}</span> : null}
              </>
            )}
          </div>
        </div>

        {/* Primary action: hand off to the provider's own download page */}
        <button
          ref={primaryRef}
          type="button"
          onClick={open}
          className="mt-4 flex min-h-12 w-full items-center justify-center gap-2.5 rounded-full bg-[#22C55E] px-6 py-3.5 text-base font-black text-[#04220f] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] hover:shadow-[#22C55E]/40 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#22C55E]/60"
        >
          {isDrive ? (
            <Download className="h-5 w-5" strokeWidth={2.5} />
          ) : (
            <ExternalLink className="h-5 w-5" strokeWidth={2.5} />
          )}
          {isDrive ? "Download from Google Drive" : "Open Download Link"}
        </button>

        {/* Secondary action: copy the provider download link */}
        <button
          type="button"
          onClick={copy}
          className="mt-2.5 flex min-h-12 w-full items-center justify-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-6 py-3 text-sm font-bold text-slate-100 transition-colors hover:border-[#22C55E]/50 hover:bg-[#22C55E]/10 hover:text-[#4ADE80] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#22C55E]/50"
        >
          {copied ? <Check className="h-4 w-4 text-[#4ADE80]" /> : <Copy className="h-4 w-4" />}
          Copy Download Link
        </button>
        <div aria-live="polite">
          {copied && (
            <p className="mt-2 flex items-center justify-center gap-1.5 text-xs font-semibold text-[#4ADE80]">
              <Check className="h-3.5 w-3.5" /> Download link copied successfully!
            </p>
          )}
        </div>

        {/* Friendly, helpful tip — replaces the old technical warning */}
        <div className="mt-4 flex items-start gap-3 rounded-2xl border border-[#22C55E]/20 bg-[#22C55E]/[0.07] p-3.5">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#4ADE80]" />
          <p className="text-[13px] leading-relaxed text-slate-200">
            {isDrive ? (
              <>
                Your browser downloads the file straight from Google Drive — no Drive app, no preview page. If
                Google Drive asks to confirm a large file, tap{" "}
                <span className="font-bold text-[#4ADE80]">Download</span> to continue.
              </>
            ) : (
              res.note || "Continue to the storage host to download your file."
            )}
          </p>
        </div>

        {/* Footer note */}
        <div className="mt-5 flex items-center justify-center gap-1.5 border-t border-white/10 pt-3.5">
          <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[#4ADE80]" />
          <p className="text-center text-[11px] font-medium text-slate-400">
            {isDrive
              ? `Your ${noun} will be downloaded securely through Google Drive.`
              : "The file comes straight from its original storage host — this site never re-hosts your download."}
          </p>
        </div>
      </div>
    </div>,
    document.body
  );
}

export function DownloadBar({ anime, episode }: { anime: AnimeType; episode: EpisodeType | null }) {
  const [busy, setBusy] = useState<{ kind: "video" | "subtitle"; index: number | null } | null>(null);
  const [fallback, setFallback] = useState<{ res: ResolvedDownload; kind: "video" | "subtitle" } | null>(null);

  // Series → the buttons always describe the currently selected episode; the
  // component is re-keyed by WatchView on episode change, so menus and state
  // reset together with the player.
  const info = anime.type === "MOVIE" ? anime.downloads : episode?.downloads;
  const video = info?.video?.enabled ? info.video.options || [] : [];
  const subs = info?.subtitles?.enabled ? info.subtitles.options || [] : [];

  const resolve = async (kind: "video" | "subtitle", index: number) => {
    const scope = anime.type === "MOVIE" ? "anime" : "episode";
    const id = anime.type === "MOVIE" ? anime.id : episode?.id;
    if (!id) return;
    setBusy({ kind, index });
    try {
      const res = await api.get<ResolvedDownload>(
        `/api/media/download/${scope}/${id}?kind=${kind}&index=${index}`
      );
      if (res.mode === "direct") {
        triggerDownload(res.url, res.filename);
        toast.success(`Download started — ${res.filename}${res.sizeLabel ? ` (${res.sizeLabel})` : ""}`);
      } else {
        setFallback({ res, kind });
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Download failed");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="mt-3 flex flex-wrap items-center gap-2.5" data-download-bar aria-label="Downloads">
      <DownloadButton
        variant="primary"
        label="Download Video"
        sinhala={video.length ? "වීඩියෝව බාගන්න" : "Video Download Not Available"}
        icon={<Download className="h-5 w-5" />}
        options={video}
        busy={busy?.kind === "video" ? busy : null}
        onPick={(i) => resolve("video", i)}
        unavailableNote="Video downloads are not available for this title. The admin can enable them and add a downloadable file in the dashboard."
      />
      <DownloadButton
        variant="outline"
        label="Download Subtitles"
        sinhala={subs.length ? "උපසිරැසි බාගන්න" : "Subtitles Not Available"}
        icon={<Subtitles className="h-5 w-5" />}
        options={subs}
        busy={busy?.kind === "subtitle" ? busy : null}
        onPick={(i) => resolve("subtitle", i)}
        unavailableNote="No subtitle file (SRT / VTT) has been added for this title. The admin can upload one in the dashboard."
      />
      {fallback && <DownloadDialog res={fallback.res} kind={fallback.kind} onClose={() => setFallback(null)} />}
    </div>
  );
}
