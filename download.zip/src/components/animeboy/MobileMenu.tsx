"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Home, Clapperboard, MonitorPlay, Brush, TvMinimalPlay, Shapes, MailPlus, Bookmark, LogIn, LogOut, LayoutDashboard, Search, Heart } from "lucide-react";
import { navigate, isRouteActive, useAppStore } from "@/store/useAppStore";
import { api } from "@/lib/client-api";
import { useToast } from "@/hooks/use-toast";

const ITEMS = [
  { label: "Home", si: "මුල් පිටුව", hash: "/", icon: Home },
  { label: "Anime Movies", si: "චිත්‍රපට", hash: "/movies", icon: Clapperboard },
  { label: "Anime Series", si: "කතා මාලා", hash: "/series", icon: MonitorPlay },
  { label: "Donghua Movie", si: "චීන ඇනිමේ චිත්‍රපට", hash: "/donghua", icon: Brush },
  { label: "Donghua Series", si: "චීන ඇනිමේ කතා මාලා", hash: "/donghua-series", icon: TvMinimalPlay },
  { label: "Others", si: "වෙනත් වීඩියෝ", hash: "/others", icon: Shapes },
  { label: "Request Anime", si: "ඉල්ලීම්", hash: "/request", icon: MailPlus },
  { label: "My Watchlist", si: "මගේ නැරඹුම් ලැයිස්තුව", hash: "/watchlist", icon: Bookmark },
];
export function MobileMenu() {
  const { mobileMenuOpen: open, setMobileMenuOpen, user, route, setUser } = useAppStore();
  const { toast } = useToast();

  const go = (hash: string) => {
    setMobileMenuOpen(false);
    navigate(hash);
  };

  const signOut = async () => {
    try {
      await api.post("/api/auth/logout");
      setUser(null);
      setMobileMenuOpen(false);
      toast({ title: "Signed out" });
      navigate("/");
    } catch {
      toast({ title: "Sign out failed", variant: "destructive" });
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <motion.nav
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 260 }}
            aria-label="Mobile navigation"
            className="fixed left-0 top-0 z-50 flex h-full w-[82%] max-w-xs flex-col border-r border-white/10 bg-gradient-to-b from-[#0b1120] via-[#070b1a] to-[#050816] lg:hidden"
          >
            <div className="flex items-center justify-between border-b border-white/8 px-5 py-4">
              <LogoCompact />
              <button
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close menu"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-300 hover:bg-white/5"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-3 py-4">
              {ITEMS.map((item) => {
                const active = isRouteActive(route.path, item.hash);
                return (
                  <button
                    key={item.hash}
                    onClick={() => go(item.hash)}
                    aria-current={active ? "page" : undefined}
                    className={`mb-1.5 flex w-full items-center gap-3.5 rounded-xl px-4 py-3.5 text-left transition-colors ${
                      active
                        ? "bg-[#22C55E]/12 text-[#4ADE80] border border-[#22C55E]/30"
                        : "text-slate-200 hover:bg-white/5 border border-transparent"
                    }`}
                  >
                    <item.icon className={`h-5 w-5 shrink-0 ${active ? "text-[#4ADE80]" : "text-slate-400"}`} />
                    <span className="flex flex-col">
                      <span className="text-[15px] font-semibold">{item.label}</span>
                      <span className="text-[11px] text-slate-500">{item.si}</span>
                    </span>
                  </button>
                );
              })}

              {user?.role === "ADMIN" && (
                <button
                  onClick={() => go("/admin")}
                  className={`mb-1.5 flex w-full items-center gap-3.5 rounded-xl px-4 py-3.5 text-left ${
                    route.path.startsWith("/admin")
                      ? "bg-[#22C55E]/12 text-[#4ADE80] border border-[#22C55E]/30"
                      : "text-slate-200 hover:bg-white/5 border border-transparent"
                  }`}
                >
                  <LayoutDashboard className="h-5 w-5 shrink-0 text-slate-400" />
                  <span className="flex flex-col">
                    <span className="text-[15px] font-semibold">Admin Dashboard</span>
                    <span className="text-[11px] text-slate-500">කළමනාකරණය</span>
                  </span>
                </button>
              )}

              {/* Support ANIME BOY — donate entry with heart icon */}
              <button
                onClick={() => go("/support")}
                className={`flex w-full items-center gap-3.5 rounded-xl px-4 py-3.5 text-left transition-colors ${
                  route.path.startsWith("/support")
                    ? "bg-[#22C55E]/12 text-[#4ADE80] border border-[#22C55E]/30"
                    : "text-slate-200 hover:bg-white/5 border border-transparent"
                }`}
                aria-label="Support ANIME BOY with a donation"
              >
                <Heart className={`h-5 w-5 shrink-0 ${route.path.startsWith("/support") ? "text-[#4ADE80]" : "text-[#F472B6]"}`} fill="currentColor" />
                <span className="flex flex-col">
                  <span className="text-[15px] font-semibold">Support ANIME BOY</span>
                  <span className="text-[11px] text-slate-500">දායක වන්න · Donate</span>
                </span>
              </button>
            </div>

            <div className="border-t border-white/8 p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
              {user ? (
                <div className="flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#22C55E] text-sm font-bold text-[#052e16]">
                      {(user.name || user.email).charAt(0).toUpperCase()}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-white">{user.name || "Viewer"}</p>
                      <p className="truncate text-xs text-slate-500">{user.email}</p>
                    </div>
                  </div>
                  <button
                    onClick={signOut}
                    aria-label="Sign out"
                    className="flex h-9 w-9 items-center justify-center rounded-lg text-red-300 hover:bg-red-500/10"
                  >
                    <LogOut className="h-4.5 w-4.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => go("/signin")}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#22C55E] font-bold text-[#052e16] shadow-lg shadow-[#22C55E]/25 transition-colors hover:bg-[#4ADE80]"
                >
                  <LogIn className="h-4.5 w-4.5" /> Sign In
                </button>
              )}
            </div>
          </motion.nav>
        </>
      )}
    </AnimatePresence>
  );
}

function LogoCompact() {
  return (
    <button onClick={() => navigate("/")} className="flex items-center gap-2" aria-label="ANIME BOY home">
      <span className="text-lg font-black tracking-wide text-white">
        ANIME <span className="text-[#4ADE80]">BOY</span>
      </span>
    </button>
  );
}
