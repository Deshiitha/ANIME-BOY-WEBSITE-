"use client";

/**
 * Admin "Donation Management" — master switches, PayHere gateway credentials
 * (write-only secret), bank transfer details, page text, preset amounts,
 * donation history with filters, manual bank-transfer verification and CSV
 * export.
 *
 * Security notes surfaced in the UI:
 *  - The merchant secret is WRITE-ONLY: it is displayed as a masked hint and
 *    can be replaced or cleared, never read back.
 *  - PayHere donations become VERIFIED only through the signed server
 *    callback — never from a browser response.
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Banknote,
  Check,
  CircleDollarSign,
  Clock3,
  Download,
  Heart,
  Landmark,
  Loader2,
  RotateCcw,
  Settings2,
  ShieldCheck,
  Users,
  X,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { DonationPaymentSettings } from "./DonationPaymentSettings";
import { methodLabel } from "./PaymentMethodBadges";

type DonationConfig = {
  donationEnabled: boolean;
  donationHeading: string;
  donationDescription: string;
  donationThankYouNote: string;
  donationPresets: number[];
  donationPublicRecognition: boolean;
  provider: string;
  gatewayEnabled: boolean;
  gatewayMode: string;
  payhereMerchantId: string;
  payhereMerchantSecretSet: boolean;
  payhereMerchantSecretHint: string;
  bankEnabled: boolean;
  bankName: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankBranch: string;
  bankInstructions: string;
};

type DonationRow = {
  id: string;
  orderId: string;
  method: string;
  amountCents: number;
  currency: string;
  donorName: string | null;
  donorEmail: string | null;
  message: string | null;
  anonymous: boolean;
  status: string;
  providerRef: string | null;
  paymentMethod: string | null;
  reference: string | null;
  statusMessage: string | null;
  createdAt: string;
  user?: { email: string; name: string | null } | null;
};

type Summary = {
  verifiedTotalCents: number;
  verifiedCount: number;
  todayTotalCents: number;
  todayCount: number;
  monthTotalCents: number;
  monthCount: number;
  pendingCount: number;
  failedCount: number;
  canceledCount: number;
  rejectedCount: number;
  refundedCount: number;
  refundedTotalCents: number;
};

type ListResponse = {
  items: DonationRow[];
  total: number;
  page: number;
  pageSize: number;
  summary: Summary;
};

const inputCls =
  "h-11 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50";
const cardCls = "rounded-2xl border border-white/8 bg-white/[0.02] p-5";
const saveBtn =
  "inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60";

export function DonationManagement() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery<{ config: DonationConfig }>({
    queryKey: ["admin-donation-config"],
    queryFn: () => api.get("/api/admin/donations/config"),
  });
  const cfg = data?.config;

  if (isLoading || !cfg) {
    return (
      <p className="flex items-center gap-2 py-12 text-slate-400">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading donation settings…
      </p>
    );
  }

  return (
    <div className="space-y-6">
      {/* donation dashboard — accurate totals from verified payments */}
      <SummaryCards />
      {/* payment receiving settings (provider, credentials, payout) */}
      <DonationPaymentSettings />
      <GeneralSettings cfg={cfg} onSaved={() => qc.invalidateQueries({ queryKey: ["admin-donation-config"] })} />
      <BankSettings cfg={cfg} onSaved={() => qc.invalidateQueries({ queryKey: ["admin-donation-config"] })} />
      <HistoryTable />
    </div>
  );
}

/* -------------------------------- summary --------------------------------- */

function SummaryCards() {
  const { data } = useQuery<ListResponse>({
    queryKey: ["admin-donations", "summary"],
    queryFn: () => api.get("/api/admin/donations?page=1"),
    staleTime: 10_000,
  });
  const s = data?.summary;
  const fmt = (cents: number | undefined) =>
    `Rs. ${((cents || 0) / 100).toLocaleString("en-LK")}`;
  const cards = [
    { label: "Total received (verified)", value: fmt(s?.verifiedTotalCents), sub: `${s?.verifiedCount ?? 0} donations`, icon: Heart, tone: "text-[#4ADE80]" },
    { label: "Today's donations", value: fmt(s?.todayTotalCents), sub: `${s?.todayCount ?? 0} today`, icon: CircleDollarSign, tone: "text-[#4ADE80]" },
    { label: "This month", value: fmt(s?.monthTotalCents), sub: `${s?.monthCount ?? 0} this month`, icon: CircleDollarSign, tone: "text-[#4ADE80]" },
    { label: "Successful payments", value: s?.verifiedCount ?? 0, sub: "verified by gateway callback", icon: ShieldCheck, tone: "text-[#4ADE80]" },
    { label: "Pending payments", value: s?.pendingCount ?? 0, sub: "awaiting verification", icon: Clock3, tone: "text-[#F59E0B]" },
    { label: "Failed payments", value: (s?.failedCount ?? 0) + (s?.rejectedCount ?? 0), sub: `${s?.canceledCount ?? 0} canceled`, icon: XCircle, tone: "text-red-300" },
    { label: "Refunds", value: s?.refundedCount ?? 0, sub: fmt(s?.refundedTotalCents), icon: RotateCcw, tone: "text-slate-300" },
    { label: "Records", value: data?.total ?? 0, sub: "all donation records", icon: Users, tone: "text-white" },
  ];
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {cards.map((c) => (
        <div key={c.label} className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
          <div className="flex items-center justify-between">
            <c.icon className={`h-5 w-5 ${c.tone}`} />
            <span className={`text-xl font-black ${c.tone}`}>{c.value}</span>
          </div>
          <p className="mt-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-400">{c.label}</p>
          {c.sub && <p className="mt-0.5 text-[10.5px] text-slate-500">{c.sub}</p>}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------ general + text ----------------------------- */

function GeneralSettings({ cfg, onSaved }: { cfg: DonationConfig; onSaved: () => void }) {
  const [enabled, setEnabled] = useState(cfg.donationEnabled);
  const [recognition, setRecognition] = useState(cfg.donationPublicRecognition);
  const [heading, setHeading] = useState(cfg.donationHeading);
  const [description, setDescription] = useState(cfg.donationDescription);
  const [thankYou, setThankYou] = useState(cfg.donationThankYouNote);
  const [presets, setPresets] = useState(cfg.donationPresets.join(", "));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setEnabled(cfg.donationEnabled);
    setRecognition(cfg.donationPublicRecognition);
    setHeading(cfg.donationHeading);
    setDescription(cfg.donationDescription);
    setThankYou(cfg.donationThankYouNote);
    setPresets(cfg.donationPresets.join(", "));
  }, [cfg]);

  const save = async () => {
    setSaving(true);
    try {
      await api.put("/api/admin/donations/config", {
        donationEnabled: enabled,
        donationPublicRecognition: recognition,
        donationHeading: heading,
        donationDescription: description,
        donationThankYouNote: thankYou,
        donationPresets: presets,
      });
      toast.success("Donation settings saved ✓");
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className={cardCls} aria-label="Donation settings">
      <h3 className="flex items-center gap-2 font-black text-white">
        <Settings2 className="h-4.5 w-4.5 text-[#4ADE80]" /> Donation settings
      </h3>

      <div className="mt-4 space-y-2.5">
        <ToggleRow
          checked={enabled}
          onChange={setEnabled}
          title="Enable donations"
          subtitle="Shows the Support ANIME BOY page and Donate buttons"
        />
        <ToggleRow
          checked={recognition}
          onChange={setRecognition}
          title="Public donor recognition"
          subtitle="List verified supporters on the donation page (anonymous stays hidden)"
        />
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Page heading</span>
          <input value={heading} onChange={(e) => setHeading(e.target.value)} className={inputCls} aria-label="Donation page heading" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Preset amounts (Rs., comma separated)</span>
          <input value={presets} onChange={(e) => setPresets(e.target.value)} placeholder="100, 250, 500, 1000, 2000" className={inputCls} aria-label="Preset donation amounts" />
        </label>
        <label className="block sm:col-span-2">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Description</span>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} className={`${inputCls} h-auto py-2.5`} aria-label="Donation page description" />
        </label>
        <label className="block sm:col-span-2">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Thank-you note</span>
          <textarea value={thankYou} onChange={(e) => setThankYou(e.target.value)} rows={2} className={`${inputCls} h-auto py-2.5`} aria-label="Thank you note" />
        </label>
      </div>

      <button onClick={save} disabled={saving} className={`mt-4 ${saveBtn}`}>
        {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save settings
      </button>
    </section>
  );
}

/* ------------------------------ bank transfer ------------------------------ */

function BankSettings({ cfg, onSaved }: { cfg: DonationConfig; onSaved: () => void }) {
  const [enabled, setEnabled] = useState(cfg.bankEnabled);
  const [bankName, setBankName] = useState(cfg.bankName);
  const [branch, setBranch] = useState(cfg.bankBranch);
  const [accountName, setAccountName] = useState(cfg.bankAccountName);
  const [accountNumber, setAccountNumber] = useState(cfg.bankAccountNumber);
  const [instructions, setInstructions] = useState(cfg.bankInstructions);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setEnabled(cfg.bankEnabled);
    setBankName(cfg.bankName);
    setBranch(cfg.bankBranch);
    setAccountName(cfg.bankAccountName);
    setAccountNumber(cfg.bankAccountNumber);
    setInstructions(cfg.bankInstructions);
  }, [cfg]);

  const save = async () => {
    setSaving(true);
    try {
      await api.put("/api/admin/donations/config", {
        bankEnabled: enabled,
        bankName,
        bankBranch: branch,
        bankAccountName: accountName,
        bankAccountNumber: accountNumber,
        bankInstructions: instructions,
      });
      toast.success("Bank transfer settings saved ✓");
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className={cardCls} aria-label="Bank transfer settings">
      <h3 className="flex items-center gap-2 font-black text-white">
        <Landmark className="h-4.5 w-4.5 text-[#4ADE80]" /> Manual bank transfer
      </h3>
      <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
        Optional alternative for donors without cards. Details are shown publicly on the donation page; submitted transfers
        stay <strong className="text-slate-300">PENDING</strong> until you verify the credit below.
      </p>

      <div className="mt-4">
        <ToggleRow checked={enabled} onChange={setEnabled} title="Enable bank transfer donations" subtitle="Shows bank details and a record-donation form" />
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Bank</span>
          <input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="Bank of Ceylon" className={inputCls} aria-label="Bank name" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Branch</span>
          <input value={branch} onChange={(e) => setBranch(e.target.value)} placeholder="Colombo 07" className={inputCls} aria-label="Bank branch" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Account name</span>
          <input value={accountName} onChange={(e) => setAccountName(e.target.value)} placeholder="A. B. Perera" className={inputCls} aria-label="Account name" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Account number</span>
          <input value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} placeholder="8001234567" className={inputCls} aria-label="Account number" />
        </label>
        <label className="block sm:col-span-2">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Instructions for donors</span>
          <textarea value={instructions} onChange={(e) => setInstructions(e.target.value)} rows={2} placeholder="e.g. Please use 'ANIMEBOY' as the reference…" className={`${inputCls} h-auto py-2.5`} aria-label="Bank transfer instructions" />
        </label>
      </div>

      <button onClick={save} disabled={saving} className={`mt-4 ${saveBtn}`}>
        {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save bank details
      </button>
    </section>
  );
}

/* --------------------------------- history --------------------------------- */

const STATUS_BADGE: Record<string, string> = {
  VERIFIED: "bg-[#22C55E]/15 text-[#4ADE80]",
  PENDING: "bg-[#F59E0B]/15 text-[#F59E0B]",
  FAILED: "bg-red-500/15 text-red-300",
  CANCELED: "bg-white/10 text-slate-400",
  REJECTED: "bg-red-500/15 text-red-300",
  REFUNDED: "bg-sky-500/15 text-sky-300",
};

function HistoryTable() {
  const qc = useQueryClient();
  const [status, setStatus] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);
  const [acting, setActing] = useState<string | null>(null);

  const params = useMemo(() => {
    const p = new URLSearchParams({ page: String(page) });
    if (status) p.set("status", status);
    if (from) p.set("from", from);
    if (to) p.set("to", to);
    return p.toString();
  }, [status, from, to, page]);

  const { data, isLoading } = useQuery<ListResponse>({
    queryKey: ["admin-donations", params],
    queryFn: () => api.get(`/api/admin/donations?${params}`),
  });

  const act = async (id: string, action: "verify" | "reject" | "refund") => {
    if (action === "verify" && !window.confirm("Confirm the money arrived in your bank account? This marks the donation as VERIFIED and shows it publicly (if recognition is on).")) return;
    if (action === "refund" && !window.confirm("Mark this donation as REFUNDED? Record the refund in your provider dashboard first — this only updates your bookkeeping totals.")) return;
    setActing(id);
    try {
      await api.patch(`/api/admin/donations/${id}`, { action });
      toast.success(action === "verify" ? "Donation verified ✓" : action === "refund" ? "Marked as refunded" : "Donation rejected");
      qc.invalidateQueries({ queryKey: ["admin-donations"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Action failed");
    } finally {
      setActing(null);
    }
  };

  const exportCsv = async () => {
    try {
      const q = new URLSearchParams();
      if (status) q.set("status", status);
      if (from) q.set("from", from);
      if (to) q.set("to", to);
      const res = await fetch(`/api/admin/donations/export?${q.toString()}`, { credentials: "same-origin" });
      if (!res.ok) throw new Error(`Export failed (${res.status})`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `anime-boy-donations-${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success("CSV exported ✓");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Export failed");
    }
  };

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <section className={cardCls} aria-label="Donation history">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="flex items-center gap-2 font-black text-white">
          <Banknote className="h-4.5 w-4.5 text-[#4ADE80]" /> Donation history
        </h3>
        <div className="flex-1" />
        <button
          onClick={exportCsv}
          className="inline-flex h-9 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-3.5 text-xs font-bold text-[#4ADE80] hover:bg-[#22C55E]/20"
        >
          <Download className="h-3.5 w-3.5" /> Export CSV
        </button>
      </div>

      {/* filters */}
      <div className="mt-4 grid gap-2.5 sm:grid-cols-3">
        <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className={inputCls} aria-label="Filter by status">
          <option value="">All statuses</option>
          <option value="VERIFIED">Verified</option>
          <option value="PENDING">Pending</option>
          <option value="FAILED">Failed</option>
          <option value="CANCELED">Canceled</option>
          <option value="REJECTED">Rejected</option>
          <option value="REFUNDED">Refunded</option>
        </select>
        <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#0b1120] px-3">
          <span className="shrink-0 text-[11px] font-bold text-slate-500">FROM</span>
          <input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1); }} className="h-11 w-full bg-transparent text-sm text-white outline-none" aria-label="From date" />
        </label>
        <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#0b1120] px-3">
          <span className="shrink-0 text-[11px] font-bold text-slate-500">TO</span>
          <input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(1); }} className="h-11 w-full bg-transparent text-sm text-white outline-none" aria-label="To date" />
        </label>
      </div>

      {isLoading ? (
        <p className="flex items-center gap-2 py-8 text-slate-400">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </p>
      ) : !data || data.items.length === 0 ? (
        <p className="mt-6 rounded-2xl border border-dashed border-white/10 px-6 py-10 text-center text-slate-400">
          No donations {status || from || to ? "match these filters" : "yet"}.
        </p>
      ) : (
        <>
          <div className="mt-4 overflow-x-auto rounded-2xl border border-white/8">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead>
                <tr className="border-b border-white/8 bg-white/[0.03] text-xs uppercase tracking-wider text-slate-400">
                  <th className="px-4 py-3 font-bold">Date</th>
                  <th className="px-4 py-3 font-bold">Donor</th>
                  <th className="px-4 py-3 font-bold">Amount</th>
                  <th className="px-4 py-3 font-bold">Payment method</th>
                  <th className="px-4 py-3 font-bold">Transaction ID</th>
                  <th className="px-4 py-3 font-bold">Status</th>
                  <th className="px-4 py-3 font-bold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((d) => (
                  <tr key={d.id} className="border-b border-white/5 align-top">
                    <td className="px-4 py-3 text-slate-400">
                      {new Date(d.createdAt).toLocaleDateString("en-LK", { year: "numeric", month: "short", day: "numeric" })}
                    </td>
                    <td className="px-4 py-3">
                      <span className="block font-semibold text-white">{d.anonymous ? "Anonymous" : d.donorName || "—"}</span>
                      <span className="block text-xs text-slate-500">{d.donorEmail || d.user?.email || ""}</span>
                      {d.message && <span className="mt-0.5 block max-w-xs truncate text-xs italic text-slate-400">“{d.message}”</span>}
                    </td>
                    <td className="px-4 py-3 font-black text-[#4ADE80]">
                      {d.currency === "LKR" ? "Rs. " : `${d.currency} `}
                      {(d.amountCents / 100).toLocaleString("en-LK")}
                    </td>
                    <td className="px-4 py-3 text-slate-300">
                      <span className="block">{d.method === "PAYHERE" ? "PayHere" : d.method === "WEBXPAY" ? "WebXPay" : "Bank transfer"}</span>
                      {d.paymentMethod && <span className="block text-xs font-semibold text-[#4ADE80]">{methodLabel(d.paymentMethod)}</span>}
                      {d.reference && <span className="block text-xs text-slate-500">ref: {d.reference}</span>}
                    </td>
                    <td className="px-4 py-3">
                      <span className="block break-all font-mono text-xs text-slate-300">{d.providerRef || d.orderId}</span>
                      <span className="block text-[10.5px] text-slate-500">order: {d.orderId}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`rounded px-2 py-0.5 text-[11px] font-bold ${STATUS_BADGE[d.status] || "bg-white/10 text-slate-300"}`}>{d.status}</span>
                      {d.statusMessage && <span className="mt-1 block max-w-[180px] text-[11px] leading-snug text-slate-500">{d.statusMessage}</span>}
                    </td>
                    <td className="px-4 py-3">
                      {d.method === "BANK_TRANSFER" && d.status === "PENDING" ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => act(d.id, "verify")}
                            disabled={acting === d.id}
                            title="Verify — money arrived in the bank"
                            aria-label="Verify donation"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-[#4ADE80] hover:bg-[#22C55E]/10 disabled:opacity-40"
                          >
                            {acting === d.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                          </button>
                          <button
                            onClick={() => act(d.id, "reject")}
                            disabled={acting === d.id}
                            title="Reject"
                            aria-label="Reject donation"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-amber-300 hover:bg-amber-500/10 disabled:opacity-40"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ) : d.status === "VERIFIED" ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => act(d.id, "refund")}
                            disabled={acting === d.id}
                            title="Mark refunded — record a refund you processed in the provider dashboard"
                            aria-label="Mark donation refunded"
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-sky-300 hover:bg-sky-500/10 disabled:opacity-40"
                          >
                            {acting === d.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-slate-600">
                          {d.method !== "BANK_TRANSFER" ? "auto-verified via callback" : "—"}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {totalPages > 1 && (
            <div className="mt-3 flex items-center justify-center gap-2">
              <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1} className="h-9 rounded-full border border-white/10 px-4 text-xs font-bold text-slate-300 disabled:opacity-40 hover:border-[#22C55E]/40">
                Prev
              </button>
              <span className="text-xs text-slate-400">
                Page {page} / {totalPages}
              </span>
              <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="h-9 rounded-full border border-white/10 px-4 text-xs font-bold text-slate-300 disabled:opacity-40 hover:border-[#22C55E]/40">
                Next
              </button>
            </div>
          )}
        </>
      )}
    </section>
  );
}

/* --------------------------------- shared ---------------------------------- */

function ToggleRow({
  checked,
  onChange,
  title,
  subtitle,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  title: string;
  subtitle: string;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4 accent-[#22C55E]" />
      <span className="text-sm font-semibold text-slate-200">
        {title} <span className="block text-[11px] font-normal text-slate-500">{subtitle}</span>
      </span>
    </label>
  );
}
