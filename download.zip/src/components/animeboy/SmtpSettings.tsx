"use client";

/**
 * Admin "Email (SMTP)" settings — credentials used for password-reset emails.
 * The SMTP password is write-only (masked hint, replace or clear). Env vars
 * SMTP_* act as a fallback when nothing is configured here.
 */
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Eye, EyeOff, Loader2, Mail, ShieldCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";

type SmtpConfig = {
  smtpHost: string;
  smtpPort: string;
  smtpUser: string;
  smtpPassSet: boolean;
  smtpPassHint: string;
  smtpFrom: string;
  smtpSecure: boolean;
  envConfigured: boolean;
};

const inputCls =
  "h-11 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50";

export function SmtpSettings() {
  const { data, refetch } = useQuery({
    queryKey: ["admin-smtp"],
    queryFn: () => api.get<{ config: SmtpConfig }>("/api/admin/smtp"),
  });
  const cfg = data?.config;

  const [host, setHost] = useState("");
  const [port, setPort] = useState("587");
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [from, setFrom] = useState("");
  const [secure, setSecure] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (cfg) {
      setHost(cfg.smtpHost);
      setPort(cfg.smtpPort || "587");
      setUser(cfg.smtpUser);
      setFrom(cfg.smtpFrom);
      setSecure(cfg.smtpSecure);
    }
  }, [cfg]);

  if (!cfg) {
    return (
      <p className="flex items-center gap-2 py-8 text-slate-400">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading email settings…
      </p>
    );
  }

  const save = async (clearPass = false) => {
    setSaving(true);
    try {
      await api.put("/api/admin/smtp", {
        smtpHost: host,
        smtpPort: port,
        smtpUser: user,
        smtpFrom: from,
        smtpSecure: secure,
        ...(clearPass ? { smtpPass: "CLEAR" } : pass.trim() ? { smtpPass: pass.trim() } : {}),
      });
      setPass("");
      toast.success(clearPass ? "SMTP password removed" : "Email settings saved ✓");
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-6 rounded-2xl border border-white/8 bg-white/[0.02] p-5" aria-label="Email settings">
      <h3 className="flex items-center gap-2 font-black text-white">
        <Mail className="h-4.5 w-4.5 text-[#4ADE80]" /> Email (SMTP)
      </h3>
      <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
        Used to deliver password-reset emails. Example: Gmail with an app password — host smtp.gmail.com, port 587.
        {cfg.envConfigured && " (SMTP_* environment variables are configured and act as fallback.)"}
      </p>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">SMTP host</span>
          <input value={host} onChange={(e) => setHost(e.target.value)} placeholder="smtp.gmail.com" className={inputCls} aria-label="SMTP host" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Port (587 TLS / 465 SSL)</span>
          <input value={port} onChange={(e) => setPort(e.target.value)} placeholder="587" inputMode="numeric" className={inputCls} aria-label="SMTP port" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Username</span>
          <input value={user} onChange={(e) => setUser(e.target.value)} placeholder="you@gmail.com" className={inputCls} aria-label="SMTP username" autoComplete="off" />
        </label>
        <label className="block">
          <span className="mb-1.5 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
            <span>Password (write-only)</span>
            {cfg.smtpPassSet && (
              <span className="flex items-center gap-1.5 normal-case text-[#4ADE80]">
                <ShieldCheck className="h-3.5 w-3.5" /> configured {cfg.smtpPassHint && <span className="font-mono text-slate-500">{cfg.smtpPassHint}</span>}
              </span>
            )}
          </span>
          <span className="relative block">
            <input
              type={showPass ? "text" : "password"}
              value={pass}
              onChange={(e) => setPass(e.target.value)}
              placeholder={cfg.smtpPassSet ? "Type a new password to replace it" : "SMTP password / app password"}
              className={`${inputCls} pr-11`}
              aria-label="SMTP password"
              autoComplete="off"
            />
            <button
              type="button"
              onClick={() => setShowPass((v) => !v)}
              aria-label={showPass ? "Hide password" : "Show password"}
              className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-[#4ADE80]"
            >
              {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </span>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">From address</span>
          <input value={from} onChange={(e) => setFrom(e.target.value)} placeholder="no-reply@yourdomain.com" className={inputCls} aria-label="From address" />
        </label>
        <label className="flex items-center gap-3 self-end rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3">
          <input type="checkbox" checked={secure} onChange={(e) => setSecure(e.target.checked)} className="h-4 w-4 accent-[#22C55E]" />
          <span className="text-sm font-semibold text-slate-200">
            Use SSL/TLS from the start <span className="block text-[11px] font-normal text-slate-500">(usually for port 465)</span>
          </span>
        </label>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <button
          onClick={() => save(false)}
          disabled={saving}
          className="inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save email settings
        </button>
        {cfg.smtpPassSet && (
          <button
            onClick={() => {
              if (window.confirm("Remove the stored SMTP password? Password-reset emails will stop until a new one is saved.")) save(true);
            }}
            disabled={saving}
            className="inline-flex h-11 items-center gap-2 rounded-full border border-red-500/30 px-5 text-sm font-bold text-red-300 transition-colors hover:bg-red-500/10"
          >
            <Trash2 className="h-4 w-4" /> Remove password
          </button>
        )}
      </div>
    </div>
  );
}
