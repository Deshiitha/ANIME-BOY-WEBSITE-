"use client";

import { useQuery } from "@tanstack/react-query";
import { Youtube, Mail, Heart } from "lucide-react";
import { Logo } from "./Logo";
import { navigate, useAppStore } from "@/store/useAppStore";
import { api } from "@/lib/client-api";

export function Footer() {
  const { config: bootConfig } = useAppStore();
  // Live config so admin changes reflect immediately (same cache key as settings).
  const { data: cfgData } = useQuery({
    queryKey: ["config"],
    queryFn: () => api.get<{ config: { youtubeChannelUrl?: string; channelHandle?: string } }>("/api/config"),
    staleTime: 10_000,
  });
  const config = cfgData?.config ?? bootConfig;
  const channelUrl = config.youtubeChannelUrl?.trim();

  const links = [
    { label: "Home", hash: "/" },
    { label: "Anime Movies", hash: "/movies" },
    { label: "Anime Series", hash: "/series" },
    { label: "Donghua Movie", hash: "/donghua" },
    { label: "Donghua Series", hash: "/donghua-series" },
    { label: "Others", hash: "/others" },
    { label: "Request Anime", hash: "/request" },
    { label: "My Watchlist", hash: "/watchlist" },
    { label: "Support ANIME BOY", hash: "/support" },
  ];

  return (
    <footer className="mt-auto border-t border-white/8 bg-[#040611]">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-400">
            ANIME BOY — සිංහල හඬ කැවූ සහ උපසිරැසි සහිත ඇනිමේ චිත්‍රපට සහ කතා මාලා නරඹන්න.
            Sinhala anime streaming for the community.
          </p>
          {channelUrl ? (
            <a
              href={channelUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#052e16] transition-all hover:bg-[#4ADE80] hover:glow-green"
            >
              <Youtube className="h-5 w-5" /> Subscribe on YouTube
            </a>
          ) : (
            <p className="mt-5 inline-flex h-11 items-center gap-2 rounded-full border border-dashed border-white/15 px-5 text-xs text-slate-500">
              <Youtube className="h-4 w-4" /> YouTube link not set — admins can add it in the dashboard
            </p>
          )}
        </div>

        <div>
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#4ADE80]">Browse</h3>
          <ul className="mt-4 space-y-2.5">
            {links.map((l) => (
              <li key={l.hash}>
                <button
                  onClick={() => navigate(l.hash)}
                  className={`text-sm transition-colors hover:text-[#4ADE80] ${
                    l.hash === "/support" ? "flex items-center gap-1.5 font-bold text-[#4ADE80]" : "text-slate-300"
                  }`}
                >
                  {l.hash === "/support" && <Heart className="h-3.5 w-3.5" fill="currentColor" />}
                  {l.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#4ADE80]">About</h3>
          <p className="mt-4 text-sm leading-relaxed text-slate-400">
            ANIME BOY is a fan streaming portal for Sinhala anime dubs, subs and reviews.
            All series and movie artwork shown here is original placeholder art for demonstration.
          </p>
          <p className="mt-4 flex items-center gap-2 text-xs text-slate-500">
            <Mail className="h-3.5 w-3.5" /> Contact via the Request Anime page
          </p>
        </div>
      </div>

      <div className="border-t border-white/5 py-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] text-center md:pb-5">
        <p className="text-xs text-slate-500">
          © {new Date().getFullYear()} ANIME BOY · Built for the Sinhala anime community · Demo content only
        </p>
      </div>
    </footer>
  );
}
