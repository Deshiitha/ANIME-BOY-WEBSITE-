"use client";

import { useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/sonner";
import { api } from "@/lib/client-api";
import { parseHash, useAppStore, type SessionUser, type EpisodeCardType } from "@/store/useAppStore";
import { Header } from "./Header";
import { MobileMenu } from "./MobileMenu";
import { BottomNav } from "./BottomNav";
import { Footer } from "./Footer";
import { HomeView } from "./views/HomeView";
import { BrowseView } from "./views/BrowseView";
import { DetailView } from "./views/DetailView";
import { WatchView } from "./views/WatchView";
import { RequestView } from "./views/RequestView";
import { WatchlistView } from "./views/WatchlistView";
import { AuthView } from "./views/AuthView";
import { AdminView } from "./views/AdminView";
import { SupportView } from "./views/SupportView";
import { AccountView } from "./views/AccountView";
import { ForgotPasswordView } from "./views/ForgotPasswordView";
import { ResetPasswordView } from "./views/ResetPasswordView";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 15_000 },
  },
});

function Shell() {
  const { route, setRoute, setUser, setUserLoaded, setConfig, user, setWatchlistIds } = useAppStore();

  // hash routing
  useEffect(() => {
    const onHash = () => {
      setRoute(parseHash(window.location.hash || "#/"));
      window.scrollTo({ top: 0 });
    };
    // Sync the deep-linked hash into the store on first mount (the store
    // starts at "#/" so server and client HTML match during hydration).
    onHash();
    if (!window.location.hash) window.location.replace("#/");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [setRoute]);

  // bootstrap: session + public config
  useEffect(() => {
    (async () => {
      try {
        const me = await api.get<{ user: SessionUser | null }>("/api/auth/me");
        setUser(me.user);
        if (me.user) {
          try {
            const wl = await api.get<{ items: { id: string }[] }>("/api/watchlist");
            setWatchlistIds(wl.items.map((i) => i.id));
          } catch {
            /* not signed in or failure — ignore */
          }
        }
      } catch {
        /* offline — ignore */
      } finally {
        setUserLoaded(true);
      }
      try {
        const cfg = await api.get<{ config: { youtubeChannelUrl?: string; channelHandle?: string } }>("/api/config");
        setConfig(cfg.config || {});
      } catch {
        /* ignore */
      }
    })();
  }, [setUser, setUserLoaded, setConfig, setWatchlistIds]);

  const root = route.segments[0] || "";
  let view: React.ReactNode;

  switch (root) {
    case "":
      view = <HomeView />;
      break;
    case "movies":
      view = <BrowseView key={`m${route.raw}`} mode="movies" />;
      break;
    case "series":
      view = <BrowseView key={`s${route.raw}`} mode="series" />;
      break;
    case "donghua":
      view = <BrowseView key={`d${route.raw}`} mode="donghua" />;
      break;
    case "donghua-series":
      view = <BrowseView key={`ds${route.raw}`} mode="donghua-series" />;
      break;
    case "others":
      view = <BrowseView key={`o${route.raw}`} mode="others" />;
      break;
    case "search":
      view = <BrowseView key={`q${route.raw}`} mode="search" />;
      break;
    case "anime":
      view = <DetailView slug={route.segments[1] || ""} />;
      break;
    case "watch":
      view = <WatchView slug={route.segments[1] || ""} />;
      break;
    case "request":
      view = <RequestView />;
      break;
    case "watchlist":
      view = <WatchlistView />;
      break;
    case "signin":
      view = <AuthView mode="signin" />;
      break;
    case "signup":
      view = <AuthView mode="signup" />;
      break;
    case "support":
      view = <SupportView />;
      break;
    case "account":
      view = <AccountView />;
      break;
    case "forgot-password":
      view = <ForgotPasswordView />;
      break;
    case "reset-password":
      view = <ResetPasswordView key={route.raw} />;
      break;
    case "admin":
      view = <AdminView />;
      break;
    default:
      view = (
        <div className="mx-auto max-w-md px-4 py-28 text-center">
          <p className="text-6xl">🥷</p>
          <h1 className="mt-4 text-2xl font-black text-white">Page not found</h1>
          <p className="mt-2 text-sm text-slate-400">මෙම පිටුව හමු නොවිය.</p>
          <button
            onClick={() => (window.location.hash = "#/")}
            className="mt-6 h-11 rounded-full bg-[#22C55E] px-6 font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80]"
          >
            Back to Home
          </button>
        </div>
      );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <MobileMenu />
      <main className="flex-1 pb-24 md:pb-0">{view}</main>
      <Footer />
      <BottomNav />
    </div>
  );
}

export function AppShell() {
  return (
    <QueryClientProvider client={queryClient}>
      <Shell />
      <Toaster position="top-center" richColors theme="dark" />
    </QueryClientProvider>
  );
}

export type { EpisodeCardType };
