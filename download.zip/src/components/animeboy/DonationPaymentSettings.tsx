"use client";

/**
 * Admin "Donation Payment Settings" — how donation funds are received.
 *
 * Security model surfaced in this UI:
 *  - Provider credentials (PayHere merchant secret, WebXPay secret/public
 *    keys) are WRITE-ONLY: stored server-side, shown as masked hints,
 *    replaceable or clearable, never readable back.
 *  - The payout (receiving) account number is only ever displayed masked
 *    (last 4 digits).
 *  - Saving payment/payout settings requires admin re-authentication with
 *    the current password (verified server-side).
 *  - This website never collects or stores full card numbers, CVVs, PINs or
 *    OTPs. Card data is entered exclusively on the provider's hosted
 *    checkout, and payouts settle to the linked bank account per provider
 *    rules.
 */
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle2,
  CreditCard,
  Eye,
  EyeOff,
  KeyRound,
  Landmark,
  Loader2,
  RefreshCcw,
  ShieldCheck,
  Trash2,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client-api";
import { MethodChips } from "./PaymentMethodBadges";

type PaymentSettingsConfig = {
  donationEnabled: boolean;
  provider: "PAYHERE" | "WEBXPAY" | "NONE";
  gatewayEnabled: boolean;
  gatewayMode: string;
  gatewayCurrency: string;
  payhereMerchantId: string;
  payhereMerchantSecretSet: boolean;
  payhereMerchantSecretHint: string;
  webxpayMerchantId: string;
  webxpayGatewayId: string;
  webxpaySecretKeySet: boolean;
  webxpaySecretKeyHint: string;
  webxpayPublicKeySet: boolean;
  webxpayPublicKeyHint: string;
  payoutBankName: string;
  payoutAccountHolder: string;
  payoutAccountNumber: string;
  payoutAccountNumberMasked: string;
  payoutCurrency: string;
  connectionReady: boolean;
  connectionMissing: string[];
  bankEnabled: boolean;
  bankName: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankBranch: string;
  bankInstructions: string;
};

type GetResponse = {
  config: PaymentSettingsConfig;
  notifyPaths: { payhere: string; webxpay: string };
};

const inputCls =
  "h-11 w-full rounded-xl border border-white/10 bg-[#0b1120] px-4 text-sm text-white placeholder:text-slate-500 outline-none focus:border-[#22C55E]/50";
const cardCls = "rounded-2xl border border-white/8 bg-white/[0.02] p-5";
const saveBtn =
  "inline-flex h-11 items-center gap-2 rounded-full bg-[#22C55E] px-6 text-sm font-bold text-[#04220f] transition-colors hover:bg-[#4ADE80] disabled:opacity-60";

export function DonationPaymentSettings() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery<GetResponse>({
    queryKey: ["admin-donation-config"],
    queryFn: () => api.get<GetResponse>("/api/admin/donations/config"),
  });
  const origin = typeof window !== "undefined" ? window.location.origin : "";

  if (isLoading || !data) {
    return (
      <p className="flex items-center gap-2 py-12 text-slate-400">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading payment settings…
      </p>
    );
  }

  const cfg = data.config;

  return (
    <div className="space-y-5">
      <ConnectionStatus cfg={cfg} />
      <ProviderCard cfg={cfg} origin={origin} notifyPaths={data.notifyPaths} onSaved={() => qc.invalidateQueries({ queryKey: ["admin-donation-config"] })} />
      <PayoutCard cfg={cfg} onSaved={() => qc.invalidateQueries({ queryKey: ["admin-donation-config"] })} />
    </div>
  );
}

/* --------------------------- connection status --------------------------- */

function ConnectionStatus({ cfg }: { cfg: PaymentSettingsConfig }) {
  const providerName = cfg.provider === "PAYHERE" ? "PayHere" : cfg.provider === "WEBXPAY" ? "WebXPay" : "None";
  return (
    <div
      className={`rounded-2xl border p-5 ${
        cfg.connectionReady ? "border-[#22C55E]/30 bg-[#22C55E]/[0.06]" : "border-amber-400/30 bg-amber-400/[0.05]"
      }`}
      aria-live="polite"
    >
      <div className="flex flex-wrap items-center gap-3">
        {cfg.connectionReady ? (
          <CheckCircle2 className="h-6 w-6 shrink-0 text-[#4ADE80]" />
        ) : (
          <AlertTriangle className="h-6 w-6 shrink-0 text-amber-300" />
        )}
        <div className="min-w-0">
          <p className={`text-sm font-black ${cfg.connectionReady ? "text-[#4ADE80]" : "text-amber-200"}`}>
            {cfg.connectionReady
              ? `Gateway connection ready — ${providerName} (${cfg.gatewayMode === "live" ? "live" : cfg.gatewayMode === "sandbox" ? "sandbox" : "staging"})`
              : "Connection incomplete"}
          </p>
          <p className="mt-0.5 text-xs text-slate-400">
            {cfg.connectionReady
              ? "Donors can pay through the provider's secure hosted checkout. Donations become VERIFIED only after the provider's signed server callback."
              : `Missing: ${cfg.connectionMissing.join(", ") || "configuration"}.`}
          </p>
        </div>
        <span className="ml-auto rounded-full border border-white/10 bg-[#0b1120] px-3 py-1 text-[11px] font-bold text-slate-300">
          Provider: {providerName}
        </span>
      </div>
    </div>
  );
}

/* ------------------------------- provider -------------------------------- */

function ProviderCard({
  cfg,
  origin,
  notifyPaths,
  onSaved,
}: {
  cfg: PaymentSettingsConfig;
  origin: string;
  notifyPaths: { payhere: string; webxpay: string };
  onSaved: () => void;
}) {
  const [provider, setProvider] = useState<string>(cfg.provider);
  const [gatewayEnabled, setGatewayEnabled] = useState(cfg.gatewayEnabled);
  const [mode, setMode] = useState(cfg.gatewayMode);
  const [gatewayCurrency, setGatewayCurrency] = useState(cfg.gatewayCurrency);

  const [payhereMerchantId, setPayhereMerchantId] = useState(cfg.payhereMerchantId);
  const [payhereSecret, setPayhereSecret] = useState("");
  const [showPayhereSecret, setShowPayhereSecret] = useState(false);

  const [webxpayMerchantId, setWebxpayMerchantId] = useState(cfg.webxpayMerchantId);
  const [webxpayGatewayId, setWebxpayGatewayId] = useState(cfg.webxpayGatewayId);
  const [webxpaySecretKey, setWebxpaySecretKey] = useState("");
  const [showWebxpaySecret, setShowWebxpaySecret] = useState(false);
  const [webxpayPublicKey, setWebxpayPublicKey] = useState("");

  const [reauthOpen, setReauthOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setProvider(cfg.provider);
    setGatewayEnabled(cfg.gatewayEnabled);
    setMode(cfg.gatewayMode);
    setGatewayCurrency(cfg.gatewayCurrency);
    setPayhereMerchantId(cfg.payhereMerchantId);
    setWebxpayMerchantId(cfg.webxpayMerchantId);
    setWebxpayGatewayId(cfg.webxpayGatewayId);
  }, [cfg]);

  const dirty = () => true; // payment settings always ask for re-auth on save
  void dirty;

  const save = async (payloadExtra: Record<string, unknown> = {}) => {
    setSaving(true);
    try {
      await api.put("/api/admin/donations/config", {
        currentPassword: password,
        provider: provider as string,
        gatewayEnabled,
        gatewayMode: mode,
        gatewayCurrency,
        payhereMerchantId,
        webxpayMerchantId,
        webxpayGatewayId,
        ...(payhereSecret.trim() ? { payhereMerchantSecret: payhereSecret.trim() } : {}),
        ...(webxpaySecretKey.trim() ? { webxpaySecretKey: webxpaySecretKey.trim() } : {}),
        ...(webxpayPublicKey.trim() ? { webxpayPublicKey: webxpayPublicKey } : {}),
        ...payloadExtra,
      });
      setPayhereSecret("");
      setWebxpaySecretKey("");
      setWebxpayPublicKey("");
      setPassword("");
      setReauthOpen(false);
      toast.success("Payment settings saved ✓");
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const clearSecret = async (field: "payhereMerchantSecret" | "webxpaySecretKey" | "webxpayPublicKey", label: string) => {
    if (!window.confirm(`Remove the stored ${label}? Payments will stop working until a new one is saved.`)) return;
    setSaving(true);
    try {
      await api.put("/api/admin/donations/config", { currentPassword: password || undefined, [field]: "CLEAR" });
      toast.success(`${label} removed`);
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not remove — re-authentication may be required. Save with your password first.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className={cardCls} aria-label="Payment gateway settings">
      <h3 className="flex items-center gap-2 font-black text-white">
        <CreditCard className="h-4.5 w-4.5 text-[#4ADE80]" /> Payment Gateway Provider
      </h3>
      <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
        Donors pay on the provider&apos;s secure hosted checkout. Card numbers, CVVs, PINs and OTPs are never collected or
        stored by this website. Only the methods your provider account enables appear to donors.
      </p>

      {/* provider selector */}
      <div className="mt-4 grid gap-2.5 sm:grid-cols-3" role="radiogroup" aria-label="Payment gateway provider">
        {[
          { key: "PAYHERE", name: "PayHere", note: "Preferred — Sri Lanka's licensed gateway", badge: "Recommended" },
          { key: "WEBXPAY", name: "WebXPay", note: "Optional — LKR/USD/GBP/AUD + local wallets", badge: "Optional" },
          { key: "NONE", name: "No online payments", note: "Bank transfer donations only", badge: null },
        ].map((p) => (
          <button
            key={p.key}
            type="button"
            role="radio"
            aria-checked={provider === p.key}
            onClick={() => setProvider(p.key)}
            className={`rounded-2xl border p-3.5 text-left transition-all ${
              provider === p.key ? "border-[#22C55E] bg-[#22C55E]/10" : "border-white/10 bg-[#0b1120] hover:border-[#22C55E]/40"
            }`}
          >
            <span className="flex items-center justify-between gap-2">
              <span className="text-sm font-bold text-white">{p.name}</span>
              {p.badge && (
                <span className="rounded-full bg-[#22C55E]/15 px-2 py-0.5 text-[9.5px] font-black uppercase tracking-wide text-[#4ADE80]">{p.badge}</span>
              )}
            </span>
            <span className="mt-1 block text-[11px] leading-relaxed text-slate-400">{p.note}</span>
          </button>
        ))}
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-white/8 bg-[#0b1120] px-4 py-3 sm:col-span-1">
          <input type="checkbox" checked={gatewayEnabled} onChange={(e) => setGatewayEnabled(e.target.checked)} className="h-4 w-4 accent-[#22C55E]" />
          <span className="text-sm font-semibold text-slate-200">Enable gateway checkout</span>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Mode</span>
          <select value={mode} onChange={(e) => setMode(e.target.value)} className={inputCls} aria-label="Gateway mode">
            <option value="sandbox">Sandbox / Staging (test)</option>
            <option value="live">Live (real payments)</option>
          </select>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Checkout currency</span>
          <select value={gatewayCurrency} onChange={(e) => setGatewayCurrency(e.target.value)} className={inputCls} aria-label="Gateway currency">
            {(provider === "WEBXPAY" ? ["LKR", "USD", "GBP", "AUD"] : ["LKR"]).map((c) => (
              <option key={c} value={c}>
                {c}
                {c !== "LKR" ? " (WebXPay)" : ""}
              </option>
            ))}
          </select>
        </label>
      </div>

      {/* PayHere credentials */}
      {provider === "PAYHERE" && (
        <div className="mt-5 rounded-2xl border border-white/8 bg-[#0b1120]/60 p-4">
          <h4 className="flex items-center gap-2 text-sm font-black text-white">
            <KeyRound className="h-4 w-4 text-[#4ADE80]" /> PayHere merchant account
          </h4>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Merchant Account ID</span>
              <input value={payhereMerchantId} onChange={(e) => setPayhereMerchantId(e.target.value)} placeholder="e.g. 1234567" className={inputCls} aria-label="PayHere merchant ID" />
            </label>
            <label className="block">
              <span className="mb-1.5 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
                <span>Merchant secret (write-only)</span>
                {cfg.payhereMerchantSecretSet && (
                  <span className="flex items-center gap-1.5 normal-case text-[#4ADE80]">
                    <ShieldCheck className="h-3.5 w-3.5" /> configured <span className="font-mono text-slate-500">{cfg.payhereMerchantSecretHint}</span>
                  </span>
                )}
              </span>
              <span className="relative block">
                <input
                  type={showPayhereSecret ? "text" : "password"}
                  value={payhereSecret}
                  onChange={(e) => setPayhereSecret(e.target.value)}
                  placeholder={cfg.payhereMerchantSecretSet ? "Type a new secret to replace it" : "Paste the Merchant Secret from PayHere"}
                  className={`${inputCls} pr-11`}
                  aria-label="PayHere merchant secret"
                  autoComplete="off"
                />
                <button
                  type="button"
                  onClick={() => setShowPayhereSecret((v) => !v)}
                  aria-label={showPayhereSecret ? "Hide secret" : "Show secret"}
                  className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-[#4ADE80]"
                >
                  {showPayhereSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </span>
            </label>
          </div>
          <p className="mt-2 text-[11px] text-slate-500">
            Officially supported PayHere methods: <MethodChips methods={["VISA", "MASTERCARD", "AMEX", "EZCASH", "MCASH", "INTERNET_BANKING"]} className="mt-1" /> —
            the checkout page shows exactly what your PayHere account has enabled.
          </p>
          <div className="mt-3 rounded-xl border border-white/8 bg-[#050816] p-3 text-[11px] leading-relaxed text-slate-400">
            <p className="font-bold text-slate-300">PayHere dashboard setup:</p>
            <ol className="mt-1 list-decimal space-y-0.5 pl-4">
              <li>Add your domain in PayHere → Domains &amp; Credentials, then copy the Merchant ID + Merchant Secret here.</li>
              <li>Notify (server-to-server) URL: <span className="break-all font-mono text-[#4ADE80]">{origin}{notifyPaths.payhere}</span></li>
              <li>Return/cancel URLs are handled automatically — donors come back to the donation page and see live status.</li>
            </ol>
          </div>
          {cfg.payhereMerchantSecretSet && (
            <button onClick={() => clearSecret("payhereMerchantSecret", "PayHere merchant secret")} disabled={saving} className="mt-3 inline-flex h-9 items-center gap-1.5 rounded-full border border-red-500/30 px-4 text-xs font-bold text-red-300 hover:bg-red-500/10">
              <Trash2 className="h-3.5 w-3.5" /> Remove stored secret
            </button>
          )}
        </div>
      )}

      {/* WebXPay credentials */}
      {provider === "WEBXPAY" && (
        <div className="mt-5 rounded-2xl border border-white/8 bg-[#0b1120]/60 p-4">
          <h4 className="flex items-center gap-2 text-sm font-black text-white">
            <KeyRound className="h-4 w-4 text-[#4ADE80]" /> WebXPay merchant account (optional provider)
          </h4>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Merchant ID (reference)</span>
              <input value={webxpayMerchantId} onChange={(e) => setWebxpayMerchantId(e.target.value)} placeholder="Your WebXPay merchant reference" className={inputCls} aria-label="WebXPay merchant ID" />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Default gateway ID (optional)</span>
              <input value={webxpayGatewayId} onChange={(e) => setWebxpayGatewayId(e.target.value)} placeholder="e.g. gateway ID from WebXPay's Gateway IDs list" className={inputCls} aria-label="WebXPay gateway ID" />
            </label>
            <label className="block">
              <span className="mb-1.5 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
                <span>Secret key (write-only)</span>
                {cfg.webxpaySecretKeySet && (
                  <span className="flex items-center gap-1.5 normal-case text-[#4ADE80]">
                    <ShieldCheck className="h-3.5 w-3.5" /> configured <span className="font-mono text-slate-500">{cfg.webxpaySecretKeyHint}</span>
                  </span>
                )}
              </span>
              <span className="relative block">
                <input
                  type={showWebxpaySecret ? "text" : "password"}
                  value={webxpaySecretKey}
                  onChange={(e) => setWebxpaySecretKey(e.target.value)}
                  placeholder={cfg.webxpaySecretKeySet ? "Type a new secret key to replace it" : "Provided upon WebXPay registration"}
                  className={`${inputCls} pr-11`}
                  aria-label="WebXPay secret key"
                  autoComplete="off"
                />
                <button
                  type="button"
                  onClick={() => setShowWebxpaySecret((v) => !v)}
                  aria-label={showWebxpaySecret ? "Hide secret key" : "Show secret key"}
                  className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-[#4ADE80]"
                >
                  {showWebxpaySecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </span>
            </label>
            <label className="block">
              <span className="mb-1.5 flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400">
                <span>Public key (write-only)</span>
                {cfg.webxpayPublicKeySet && (
                  <span className="flex items-center gap-1.5 normal-case text-[#4ADE80]">
                    <ShieldCheck className="h-3.5 w-3.5" /> configured <span className="font-mono text-slate-500">{cfg.webxpayPublicKeyHint}</span>
                  </span>
                )}
              </span>
              <textarea
                value={webxpayPublicKey}
                onChange={(e) => setWebxpayPublicKey(e.target.value)}
                placeholder={cfg.webxpayPublicKeySet ? "Paste a new PEM public key to replace it" : "WEBXPAY Dashboard → Settings → public key (full PEM)"}
                rows={3}
                className={`${inputCls} h-auto py-2.5 font-mono text-xs`}
                aria-label="WebXPay public key"
              />
            </label>
          </div>
          <p className="mt-2 text-[11px] text-slate-500">
            Officially supported WebXPay methods: <MethodChips methods={["VISA", "MASTERCARD", "AMEX", "EZCASH", "MCASH", "FRIMI", "GENIE", "UPAY", "DFCC_WALLET", "LANKA_QR", "INTERNET_BANKING"]} className="mt-1" />
          </p>
          <div className="mt-3 rounded-xl border border-white/8 bg-[#050816] p-3 text-[11px] leading-relaxed text-slate-400">
            <p className="font-bold text-slate-300">WebXPay dashboard setup (Redirect Integration):</p>
            <ol className="mt-1 list-decimal space-y-0.5 pl-4">
              <li>Add this Return URL in WEBXPAY Dashboard → Settings → Website Integration: <span className="break-all font-mono text-[#4ADE80]">{origin}{notifyPaths.webxpay}</span></li>
              <li>Copy the Secret Key and the RSA Public Key from the WebXPay dashboard into the fields above.</li>
              <li>Results are verified server-side (RSA signature) before any donation is marked successful.</li>
            </ol>
          </div>
          {(cfg.webxpaySecretKeySet || cfg.webxpayPublicKeySet) && (
            <div className="mt-3 flex flex-wrap gap-2">
              {cfg.webxpaySecretKeySet && (
                <button onClick={() => clearSecret("webxpaySecretKey", "WebXPay secret key")} disabled={saving} className="inline-flex h-9 items-center gap-1.5 rounded-full border border-red-500/30 px-4 text-xs font-bold text-red-300 hover:bg-red-500/10">
                  <Trash2 className="h-3.5 w-3.5" /> Remove secret key
                </button>
              )}
              {cfg.webxpayPublicKeySet && (
                <button onClick={() => clearSecret("webxpayPublicKey", "WebXPay public key")} disabled={saving} className="inline-flex h-9 items-center gap-1.5 rounded-full border border-red-500/30 px-4 text-xs font-bold text-red-300 hover:bg-red-500/10">
                  <Trash2 className="h-3.5 w-3.5" /> Remove public key
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* re-auth + save */}
      {!reauthOpen ? (
        <button onClick={() => dirty() && setReauthOpen(true)} className={`mt-5 ${saveBtn}`}>
          <RefreshCcw className="h-4 w-4" /> Save Payment Settings
        </button>
      ) : (
        <div className="mt-5 rounded-2xl border border-[#22C55E]/30 bg-[#22C55E]/[0.05] p-4">
          <p className="flex items-center gap-2 text-sm font-bold text-white">
            <ShieldCheck className="h-4 w-4 text-[#4ADE80]" /> Confirm your password to save payment settings
          </p>
          <p className="mt-1 text-[11px] text-slate-400">
            Changing how donations are received (provider, credentials or payout account) requires administrator
            re-authentication.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2.5">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && password) save();
              }}
              placeholder="Current admin password"
              className={`${inputCls} max-w-xs flex-1`}
              aria-label="Current admin password"
              autoComplete="current-password"
            />
            <button onClick={() => save()} disabled={saving || !password} className={saveBtn}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />} Confirm &amp; Save
            </button>
            <button
              onClick={() => {
                setReauthOpen(false);
                setPassword("");
              }}
              className="h-11 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

/* ------------------------- payout / Visa section -------------------------- */

function PayoutCard({ cfg, onSaved }: { cfg: PaymentSettingsConfig; onSaved: () => void }) {
  const [payoutBankName, setPayoutBankName] = useState(cfg.payoutBankName);
  const [payoutAccountHolder, setPayoutAccountHolder] = useState(cfg.payoutAccountHolder);
  const [payoutAccountNumber, setPayoutAccountNumber] = useState("");
  const [replaceAccount, setReplaceAccount] = useState(!cfg.payoutAccountNumber);
  const [payoutCurrency, setPayoutCurrency] = useState(cfg.payoutCurrency);

  const [reauthOpen, setReauthOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setPayoutBankName(cfg.payoutBankName);
    setPayoutAccountHolder(cfg.payoutAccountHolder);
    setPayoutCurrency(cfg.payoutCurrency);
    if (!cfg.payoutAccountNumber) setReplaceAccount(true);
  }, [cfg]);

  const save = async () => {
    setSaving(true);
    try {
      await api.put("/api/admin/donations/config", {
        currentPassword: password,
        payoutBankName,
        payoutAccountHolder,
        payoutCurrency,
        ...(replaceAccount && payoutAccountNumber.trim() ? { payoutAccountNumber: payoutAccountNumber.trim() } : {}),
      });
      setPayoutAccountNumber("");
      setPassword("");
      setReauthOpen(false);
      toast.success("Payout settings saved ✓");
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className={cardCls} aria-label="Payout settings">
      <h3 className="flex items-center gap-2 font-black text-white">
        <Landmark className="h-4.5 w-4.5 text-[#4ADE80]" /> Linked Bank Account (payouts)
      </h3>
      <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
        Donation funds are settled by your payment provider into this account according to the provider&apos;s payout rules
        (e.g. PayHere settlement cycle). The account number is stored server-side and always displayed masked.
      </p>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Bank name</span>
          <input value={payoutBankName} onChange={(e) => setPayoutBankName(e.target.value)} placeholder="e.g. Bank of Ceylon" className={inputCls} aria-label="Payout bank name" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Account holder name</span>
          <input value={payoutAccountHolder} onChange={(e) => setPayoutAccountHolder(e.target.value)} placeholder="Exact name on the account" className={inputCls} aria-label="Payout account holder" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Masked account number</span>
          {cfg.payoutAccountNumber && !replaceAccount ? (
            <span className="flex items-center justify-between rounded-xl border border-white/10 bg-[#0b1120] px-4 text-sm">
              <span className="font-mono font-bold text-[#4ADE80]">{cfg.payoutAccountNumberMasked}</span>
              <button type="button" onClick={() => setReplaceAccount(true)} className="text-[11px] font-bold text-slate-400 hover:text-[#4ADE80]">
                Replace
              </button>
            </span>
          ) : (
            <input
              value={payoutAccountNumber}
              onChange={(e) => setPayoutAccountNumber(e.target.value.replace(/[^\dA-Za-z-]/g, ""))}
              placeholder="Account number (only last 4 digits will be shown later)"
              className={inputCls}
              aria-label="Payout account number"
              autoComplete="off"
            />
          )}
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-400">Payout currency</span>
          <select value={payoutCurrency} onChange={(e) => setPayoutCurrency(e.target.value)} className={inputCls} aria-label="Payout currency">
            <option value="LKR">LKR — Sri Lankan Rupee</option>
            <option value="USD">USD — US Dollar (WebXPay)</option>
          </select>
        </label>
      </div>

      {/* Visa Card / Payout Method — transparent info card */}
      <div className="mt-5 rounded-2xl border border-sky-400/20 bg-sky-400/[0.05] p-4">
        <h4 className="flex items-center gap-2 text-sm font-black text-sky-100">
          <Wallet className="h-4 w-4" /> Visa Card / Payout Method
        </h4>
        <ul className="mt-2 space-y-1.5 text-[12px] leading-relaxed text-slate-300">
          <li>
            <strong className="text-white">Donors pay by Visa/Mastercard/Amex</strong> on the provider&apos;s hosted checkout —
            this is supported out of the box once the gateway above is configured.
          </li>
          <li>
            <strong className="text-white">Payouts settle to the linked bank account above.</strong> PayHere and WebXPay settle
            merchant funds to a registered bank account per their payout rules — they do not transfer merchant payouts to a
            card on this website.
          </li>
          <li>
            <strong className="text-white">Card payout onboarding (e.g. Visa-linked payout accounts)</strong> can only be
            arranged inside your provider&apos;s official merchant dashboard if the provider offers it for your account. This
            site deliberately never collects or stores full card numbers, CVVs, PINs or OTPs.
          </li>
        </ul>
      </div>

      {!reauthOpen ? (
        <button onClick={() => setReauthOpen(true)} className={`mt-5 ${saveBtn}`}>
          <RefreshCcw className="h-4 w-4" /> Save Payout Settings
        </button>
      ) : (
        <div className="mt-5 rounded-2xl border border-[#22C55E]/30 bg-[#22C55E]/[0.05] p-4">
          <p className="flex items-center gap-2 text-sm font-bold text-white">
            <ShieldCheck className="h-4 w-4 text-[#4ADE80]" /> Confirm your password to save payout settings
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2.5">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && password) save();
              }}
              placeholder="Current admin password"
              className={`${inputCls} max-w-xs flex-1`}
              aria-label="Current admin password"
              autoComplete="current-password"
            />
            <button onClick={() => save()} disabled={saving || !password} className={saveBtn}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />} Confirm &amp; Save
            </button>
            <button
              onClick={() => {
                setReauthOpen(false);
                setPassword("");
              }}
              className="h-11 rounded-full px-4 text-sm font-semibold text-slate-300 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
