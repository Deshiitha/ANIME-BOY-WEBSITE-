"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Play, Info, Star } from "lucide-react";
import { navigate, type AnimeType } from "@/store/useAppStore";
import { LANGUAGE_LABELS } from "@/lib/client-api";

const BADGE_STYLES: Record<string, string> = {
  SINHALA_DUBBED: "border-[#22C55E]/50 bg-[#22C55E]/15 text-[#4ADE80]",
  SINHALA_SUB: "border-teal-400/40 bg-teal-400/10 text-teal-300",
  ANIME_REVIEW: "border-amber-400/40 bg-amber-400/10 text-amber-300",
};

const BADGE_LABELS: Record<string, string> = {
  SINHALA_DUBBED: "• සිංහල හඬ කැවූ - SINHALA DUBBED",
  SINHALA_SUB: "• සිංහල උපසිරැසි - SINHALA SUB",
  ANIME_REVIEW: "• ANIME REVIEW",
};

const AUTOPLAY_MS = 7000;

export function HeroCarousel({ items }: { items: AnimeType[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchStartX = useRef<number | null>(null);
  const count = items.length;

  const go = useCallback(
    (next: number) => {
      if (count === 0) return;
      setIndex(((next % count) + count) % count);
    },
    [count]
  );

  useEffect(() => {
    if (paused || count <= 1) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % count), AUTOPLAY_MS);
    return () => clearInterval(t);
  }, [paused, count]);

  if (count === 0) return null;

  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    setPaused(true);
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 48) go(index + (dx < 0 ? 1 : -1));
    touchStartX.current = null;
    setPaused(false);
  };

  const item = items[index];
  const upcoming = item.status === "UPCOMING";
  const genres = Array.isArray(item.genres) ? item.genres : [];
  const backdrop = item.backdropUrl || item.posterUrl;

  return (
    <section
      aria-label="Featured anime"
      aria-roledescription="carousel"
      className="relative overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      <div className="relative h-[68vh] min-h-[440px] w-full sm:h-[76vh] lg:h-[82vh] lg:max-h-[720px]">
        {items.map((it, i) => (
          <img
            key={it.id}
            src={it.backdropUrl || it.posterUrl || ""}
            alt={i === index ? `${it.titleEn} backdrop` : ""}
            aria-hidden={i !== index}
            loading={i === 0 ? "eager" : "lazy"}
            fetchPriority={i === 0 ? "high" : "auto"}
            className={`absolute inset-0 h-full w-full object-cover transition-all duration-700 ${
              i === index ? "scale-100 opacity-100" : "scale-105 opacity-0"
            }`}
          />
        ))}

        {/* cinematic gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050816] via-[#050816]/45 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050816]/95 via-[#050816]/55 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#050816] to-transparent" />

        {/* content */}
        <div className="absolute inset-x-0 bottom-0 top-0 mx-auto flex max-w-7xl flex-col justify-end px-4 pb-16 sm:px-6 sm:pb-20 lg:justify-center lg:pb-24">
          <div key={item.id} className="fade-up max-w-xl">
            <span
              className={`inline-flex items-center rounded-full border px-3 py-1.5 text-[11.5px] font-bold backdrop-blur-sm sm:text-xs ${
                BADGE_STYLES[item.languageLabel] || BADGE_STYLES.SINHALA_DUBBED
              }`}
            >
              {BADGE_LABELS[item.languageLabel] || item.languageLabel}
            </span>

            <h1 className="mt-3.5 text-3xl font-black leading-[1.08] text-white drop-shadow-xl sm:text-4xl lg:text-5xl">
              {item.titleEn}
            </h1>
            {item.titleSi && (
              <p className="mt-1.5 text-base font-semibold text-[#4ADE80]/90 sm:text-lg">{item.titleSi}</p>
            )}

            <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
              {typeof item.rating === "number" && (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-[#FACC15]/30 bg-black/40 px-2.5 py-1 font-bold text-white backdrop-blur">
                  <Star className="h-4 w-4 fill-[#FACC15] text-[#FACC15]" /> {item.rating.toFixed(1)}
                </span>
              )}
              {item.releaseYear && (
                <span className="rounded-full border border-white/15 bg-black/30 px-2.5 py-1 font-semibold text-slate-200 backdrop-blur">
                  {item.releaseYear}
                </span>
              )}
              {upcoming && (
                <span className="rounded-full bg-[#F59E0B] px-2.5 py-1 text-[11px] font-black tracking-wider text-[#1c1002]">
                  COMING SOON
                </span>
              )}
              {genres.slice(0, 4).map((g) => (
                <span
                  key={g}
                  className="rounded-full border border-white/15 bg-white/8 px-2.5 py-1 text-[12.5px] font-medium text-slate-200 backdrop-blur"
                >
                  {g}
                </span>
              ))}
            </div>

            {item.descriptionSi && (
              <p className="mt-3.5 line-clamp-3 max-w-lg text-[13.5px] leading-relaxed text-slate-300 sm:text-sm">
                {item.descriptionSi}
              </p>
            )}

            <div className="mt-5 flex flex-wrap items-center gap-3">
              {upcoming ? (
                <button
                  onClick={() => navigate(`/anime/${item.slug}`)}
                  className="inline-flex h-12 items-center gap-2 rounded-full bg-[#F59E0B] px-7 font-bold text-[#1c1002] shadow-lg shadow-[#F59E0B]/25 transition-all hover:bg-[#fbbf24]"
                >
                  <Info className="h-5 w-5" /> Coming {item.releaseYear || "Soon"} — Details
                </button>
              ) : (
                <button
                  onClick={() => navigate(`/watch/${item.slug}`)}
                  className="inline-flex h-12 items-center gap-2 rounded-full bg-[#22C55E] px-7 font-bold text-[#04220f] shadow-lg shadow-[#22C55E]/30 transition-all hover:bg-[#4ADE80] hover:glow-green"
                >
                  <Play className="h-5 w-5 fill-current" /> Watch Now
                </button>
              )}
              <button
                onClick={() => navigate(`/anime/${item.slug}`)}
                className="inline-flex h-12 items-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 font-semibold text-white backdrop-blur-md transition-all hover:border-[#22C55E]/50 hover:bg-white/15"
              >
                <Info className="h-5 w-5" /> More Info
              </button>
              <span className="hidden text-xs font-medium text-slate-400 sm:block">
                {LANGUAGE_LABELS[item.languageLabel]}
              </span>
            </div>
          </div>
        </div>

        {/* arrows */}
        {count > 1 && (
          <>
            <button
              onClick={() => go(index - 1)}
              aria-label="Previous slide"
              className="absolute left-3 top-1/2 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition-all hover:border-[#4ADE80]/60 hover:text-[#4ADE80] md:flex"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button
              onClick={() => go(index + 1)}
              aria-label="Next slide"
              className="absolute right-3 top-1/2 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/40 text-white backdrop-blur transition-all hover:border-[#4ADE80]/60 hover:text-[#4ADE80] md:flex"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </>
        )}

        {/* green slide indicators */}
        <div className="absolute bottom-4 right-5 flex items-center gap-2 sm:bottom-5 sm:right-8" role="tablist" aria-label="Slide indicators">
          {items.map((it, i) => (
            <button
              key={it.id}
              role="tab"
              aria-selected={i === index}
              aria-label={`Go to slide ${i + 1}`}
              onClick={() => go(i)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === index
                  ? "w-8 bg-[#4ADE80] shadow-[0_0_10px_rgba(74,222,128,0.8)]"
                  : "w-4 bg-white/25 hover:bg-white/50"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
