"use client";

import { useEffect, useRef, useState } from "react";
import { Menu, Search, LogOut, LayoutDashboard, Bookmark, UserRound, Heart } from "lucide-react";
import { Logo } from "./Logo";
import { navigate, isRouteActive, useAppStore } from "@/store/useAppStore";
import { api } from "@/lib/client-api";
import { useToast } from "@/hooks/use-toast";

const NAV_LINKS = [
  { label: "Home", hash: "/" },
  { label: "Anime Movies", hash: "/movies" },
  { label: "Anime Series", hash: "/series" },
  { label: "Donghua Movie", hash: "/donghua" },
  { label: "Donghua Series", hash: "/donghua-series" },
  { label: "Others", hash: "/others" },
];

export function Header() {
  const { user, route, mobileMenuOpen, setMobileMenuOpen, setUser } = useAppStore();
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const isActive = (hash: string) => isRouteActive(route.path, hash);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    if (!query) return;
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };

  const signOut = async () => {
    try {
      await api.post("/api/auth/logout");
      setUser(null);
      setUserMenuOpen(false);
      toast({ title: "Signed out", description: "ඔබව සාර්ථකව sign out කර ඇත." });
      navigate("/");
    } catch {
      toast({ title: "Sign out failed", variant: "destructive" });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/5 bg-[#050816]/85 backdrop-blur-xl supports-[backdrop-filter]:bg-[#050816]/70">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <Logo />

        {/* Desktop nav — all six content categories */}
        <nav aria-label="Main navigation" className="ml-4 hidden items-center gap-0 xl:flex">
          {NAV_LINKS.map((l) => (
            <button
              key={l.hash}
              onClick={() => navigate(l.hash)}
              aria-current={isActive(l.hash) ? "page" : undefined}
              className={`whitespace-nowrap rounded-lg px-2.5 py-2 text-sm font-semibold transition-colors ${
                isActive(l.hash)
                  ? "bg-[#22C55E]/12 text-[#4ADE80]"
                  : "text-slate-300 hover:bg-white/5 hover:text-white"
              }`}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex-1" />

        {/* Donate — always visible in the header (heart icon) */}
        <button
          onClick={() => navigate("/support")}
          aria-label="Support ANIME BOY with a donation"
          title="Support ANIME BOY"
          className={`hidden h-10 items-center gap-1.5 rounded-full border border-[#22C55E]/40 bg-[#22C55E]/10 px-3.5 text-sm font-bold text-[#4ADE80] transition-all hover:bg-[#22C55E]/20 sm:flex ${
            isActive("/support") ? "border-[#22C55E] bg-[#22C55E]/20" : ""
          }`}
        >
          <Heart className="h-4 w-4" fill="currentColor" />
          <span>Donate</span>
        </button>

        {/* Desktop search */}
        <form onSubmit={submitSearch} role="search" className="hidden md:block">
          <div className="group relative">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500 transition-colors group-focus-within:text-[#4ADE80]"
              aria-hidden="true"
            />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search anime…"
              aria-label="Search anime by title"
              className="h-10 w-56 rounded-full border border-white/10 bg-white/[0.04] pl-9 pr-4 text-sm text-white placeholder:text-slate-500 outline-none transition-all focus:w-72 focus:border-[#22C55E]/50 focus:bg-white/[0.06] focus:ring-2 focus:ring-[#22C55E]/25"
            />
          </div>
        </form>

        {/* User area */}
        {user ? (
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={userMenuOpen}
              aria-label="Account menu"
              className="flex h-10 items-center gap-2 rounded-full border border-[#22C55E]/35 bg-[#22C55E]/10 px-2.5 text-sm font-semibold text-[#4ADE80] transition-colors hover:bg-[#22C55E]/20"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#22C55E] text-[#052e16]">
                {(user.name || user.email).charAt(0).toUpperCase()}
              </span>
              <span className="hidden max-w-24 truncate sm:block">{user.name || user.email.split("@")[0]}</span>
            </button>
            {userMenuOpen && (
              <div
                role="menu"
                className="absolute right-0 mt-2 w-52 overflow-hidden rounded-xl border border-white/10 bg-[#0b1120] p-1.5 shadow-2xl shadow-black/60"
              >
                <div className="px-3 py-2">
                  <p className="truncate text-sm font-semibold text-white">{user.name || "Viewer"}</p>
                  <p className="truncate text-xs text-slate-400">{user.email}</p>
                </div>
                <div className="my-1 h-px bg-white/8" />
                <button
                  role="menuitem"
                  onClick={() => { setUserMenuOpen(false); navigate("/account"); }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/5"
                >
                  <UserRound className="h-4 w-4 text-[#4ADE80]" /> Account Settings
                </button>
                <button
                  role="menuitem"
                  onClick={() => { setUserMenuOpen(false); navigate("/watchlist"); }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/5"
                >
                  <Bookmark className="h-4 w-4 text-[#4ADE80]" /> My Watchlist
                </button>
                <button
                  role="menuitem"
                  onClick={() => { setUserMenuOpen(false); navigate("/support"); }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/5"
                >
                  <Heart className="h-4 w-4 text-[#4ADE80]" fill="currentColor" /> Support ANIME BOY
                </button>
                {user.role === "ADMIN" && (
                  <button
                    role="menuitem"
                    onClick={() => { setUserMenuOpen(false); navigate("/admin"); }}
                    className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/5"
                  >
                    <LayoutDashboard className="h-4 w-4 text-[#4ADE80]" /> Admin Dashboard
                  </button>
                )}
                <button
                  role="menuitem"
                  onClick={signOut}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-red-300 hover:bg-red-500/10"
                >
                  <LogOut className="h-4 w-4" /> Sign Out
                </button>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={() => navigate("/signin")}
            className="h-10 rounded-full bg-[#22C55E] px-5 text-sm font-bold text-[#052e16] shadow-lg shadow-[#22C55E]/25 transition-all hover:bg-[#4ADE80] hover:shadow-[#4ADE80]/30 hover:glow-green"
          >
            Sign In
          </button>
        )}

        {/* Hamburger (mobile) */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-expanded={mobileMenuOpen}
          aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
          className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-200 transition-colors hover:bg-white/5 xl:hidden"
        >
          {mobileMenuOpen ? <Menu className="h-6 w-6 rotate-90 transition-transform" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

    </header>
  );
}
