import { NextResponse, type NextRequest } from "next/server";

/**
 * Canonical-host proxy (Next.js 16 replacement for middleware).
 *
 * It is activated ONLY by environment variables, so local development and the
 * sandbox preview are never affected:
 *
 *  - SITE_URL               canonical site address, e.g. https://animeboy.com
 *  - REDIRECT_LEGACY_HOSTS  comma-separated hosts that must 308-redirect to
 *                           SITE_URL (e.g. the old preview / vercel.app address)
 *  - ENFORCE_CANONICAL_HOST 1 = also 308-redirect every host that is not the
 *                           canonical one (www <-> apex canonicalisation)
 *
 * Every redirect keeps the exact path + query string, so all existing page
 * URLs (watch, admin, api) keep working when the domain changes.
 */

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "0.0.0.0", "[::1]", "::1"]);

/** Lower-case host without its port ("localhost:3100" -> "localhost"). */
function normalizeHost(raw: string): string {
  const trimmed = raw.trim().toLowerCase();
  if (trimmed.startsWith("[")) {
    const end = trimmed.indexOf("]");
    return end > 0 ? trimmed.slice(0, end + 1) : trimmed;
  }
  const colon = trimmed.lastIndexOf(":");
  return colon > -1 ? trimmed.slice(0, colon) : trimmed;
}

function canonicalOrigin(): { origin: string; host: string } | null {
  const raw = process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
  if (!raw) return null;
  try {
    const url = new URL(raw);
    if (!url.protocol.startsWith("http") || !url.host) return null;
    return { origin: url.origin, host: url.host.toLowerCase() };
  } catch {
    return null;
  }
}

export function proxy(req: NextRequest) {
  const canonical = canonicalOrigin();
  if (!canonical) return NextResponse.next();

  const forwarded = req.headers.get("x-forwarded-host") || "";
  const host = normalizeHost(forwarded.split(",")[0] || req.headers.get("host") || "");
  if (!host || LOCAL_HOSTS.has(host) || host === canonical.host) {
    return NextResponse.next();
  }

  const legacy = (process.env.REDIRECT_LEGACY_HOSTS || "")
    .split(",")
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
  const enforce = process.env.ENFORCE_CANONICAL_HOST === "1";
  if (!legacy.includes(host) && !enforce) return NextResponse.next();

  const target = new URL(req.nextUrl.pathname + req.nextUrl.search, canonical.origin);
  return NextResponse.redirect(target, 308);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
