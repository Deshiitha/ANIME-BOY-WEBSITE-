import { db } from "@/lib/db";
import { ok } from "@/lib/api-helpers";

/** Public site configuration (only non-secret keys). */
export async function GET() {
  const rows = await db.siteConfig.findMany({
    where: { key: { in: ["youtubeChannelUrl", "channelHandle"] } },
  });
  const config: Record<string, string> = {};
  for (const row of rows) config[row.key] = row.value;
  return ok({ config });
}
