import { db } from "@/lib/db";
import { ok, publicAnime } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") || "").trim();
  const type = url.searchParams.get("type"); // MOVIE | SERIES
  const category = url.searchParams.get("category"); // ANIME | DONGHUA | OTHERS
  const genre = url.searchParams.get("genre");
  const year = url.searchParams.get("year");
  const language = url.searchParams.get("language"); // languageLabel
  const status = url.searchParams.get("status"); // RELEASED | UPCOMING
  const sort = url.searchParams.get("sort") || "recent"; // recent | rating | year | title
  const page = Math.max(1, Number(url.searchParams.get("page")) || 1);
  const limit = Math.min(60, Math.max(1, Number(url.searchParams.get("limit")) || 24));

  const where: Record<string, unknown> = { published: true };
  if (type === "MOVIE" || type === "SERIES") where.type = type;
  if (category === "ANIME" || category === "DONGHUA" || category === "OTHERS") where.category = category;
  if (status === "RELEASED" || status === "UPCOMING") where.status = status;
  if (language) where.languageLabel = language;
  if (year) where.releaseYear = Number(year);
  if (genre) where.genres = { contains: genre };
  if (q) {
    where.OR = [
      { titleEn: { contains: q } },
      { titleSi: { contains: q } },
      { genres: { contains: q } },
    ];
  }

  let orderBy: Record<string, string> = { createdAt: "desc" };
  if (sort === "rating") orderBy = { rating: "desc" };
  else if (sort === "year") orderBy = { releaseYear: "desc" };
  else if (sort === "title") orderBy = { titleEn: "asc" };
  else if (sort === "oldest") orderBy = { createdAt: "asc" };

  const [total, rows] = await Promise.all([
    db.anime.count({ where }),
    db.anime.findMany({ where, orderBy, skip: (page - 1) * limit, take: limit }),
  ]);

  return ok({
    items: rows.map(publicAnime),
    total,
    page,
    pages: Math.max(1, Math.ceil(total / limit)),
  });
}
