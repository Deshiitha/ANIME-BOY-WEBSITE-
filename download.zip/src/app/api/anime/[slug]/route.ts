import { db } from "@/lib/db";
import { ok, fail, publicAnime } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";
import { isS3ObjectUrl } from "@/lib/media-validate";
import type { EpisodeRow } from "@/lib/api-helpers";

export async function GET(req: Request, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const anime = await db.anime.findUnique({
    where: { slug },
    include: {
      seasons: {
        orderBy: { number: "asc" },
        include: { episodes: { orderBy: { number: "asc" } } },
      },
    },
  });
  if (!anime) return fail("Anime not found", 404);

  const user = await getSessionFromRequest(req);
  const isAdmin = user?.role === "ADMIN";

  // Unpublished items are only visible to admins (preview).
  if (!anime.published && !isAdmin) return fail("Anime not found", 404);

  const out = publicAnime(anime);

  // Private-bucket object identifiers (s3://bucket/key) stay server-side for
  // visitors — the signed playable/download objects already carry everything
  // the player and the download buttons need, and no credentials ever reach
  // the browser. Admins keep the identifiers so the edit forms can show and
  // replace the sources. The per-item `downloads` summary is computed before
  // scrubbing, so download buttons keep working for visitors.
  if (!isAdmin) {
    const isS3 = (v: unknown) => typeof v === "string" && isS3ObjectUrl(v);
    type Scrubbable = {
      videoUrl: string | null;
      downloadUrl: string | null;
      downloadQualities: unknown;
      subtitleDownloads: unknown;
      altSources?: unknown;
    };
    const scrub = (e: Scrubbable) => {
      if (isS3(e.videoUrl)) e.videoUrl = null;
      if (isS3(e.downloadUrl)) e.downloadUrl = null;
      // Row-level private identifiers never belong in a public payload.
      const dropS3Rows = (rows: unknown) =>
        Array.isArray(rows) ? (rows as { url: string }[]).filter((r) => !isS3(r?.url)) : [];
      e.downloadQualities = dropS3Rows(e.downloadQualities);
      e.subtitleDownloads = dropS3Rows(e.subtitleDownloads);
      // Raw backup-source rows (may contain s3:// keys and admin labels) are
      // admin-only; visitors get the resolved, access-checked `sources` list.
      if ("altSources" in e) e.altSources = [];
    };
    scrub(out);
    for (const season of out.seasons || []) {
      for (const ep of season.episodes as unknown as Scrubbable[]) scrub(ep);
    }
  }

  return ok({ anime: out });
}
