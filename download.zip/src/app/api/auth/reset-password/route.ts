import { createHash } from "crypto";
import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { hashPassword } from "@/lib/auth";
import { validatePassword } from "@/lib/password-policy";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/**
 * Consume a single-use, expiring reset token and set the new password.
 * The raw emailed token is never stored — we look it up by SHA-256 hash.
 * On success every existing session is invalidated via tokenVersion bump.
 */
export async function POST(req: Request) {
  const limiter = rateLimit(`reset:${clientIp(req)}`, 10, 60 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const body = await readJson<{ token?: string; newPassword?: string }>(req);
  const token = (body?.token || "").trim();
  const newPassword = body?.newPassword || "";

  if (!token) return fail("This password reset link is invalid. Please request a new one.");
  const strength = validatePassword(newPassword);
  if (!strength.ok) return fail(strength.message);

  const tokenHash = createHash("sha256").update(token).digest("hex");
  const record = await db.passwordResetToken.findUnique({ where: { tokenHash } });

  if (!record || record.usedAt || record.expiresAt.getTime() < Date.now()) {
    return fail("This password reset link is invalid or has expired. Please request a new one.", 400);
  }

  // Atomically claim the token (single-use): updateMany only succeeds while
  // usedAt is still null, so two concurrent requests can never both win.
  const claimed = await db.passwordResetToken.updateMany({
    where: { id: record.id, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (claimed.count !== 1) {
    return fail("This password reset link has already been used. Please request a new one.");
  }

  const newHash = await hashPassword(newPassword);
  await db.user.update({
    where: { id: record.userId },
    data: { passwordHash: newHash, tokenVersion: { increment: 1 } },
  });

  return ok({
    success: true,
    message: "Password updated. You can now sign in with your new password.",
  });
}
