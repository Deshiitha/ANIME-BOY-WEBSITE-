import { ok } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";

export async function GET(req: Request) {
  const user = await getSessionFromRequest(req);
  return ok({ user });
}
