import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { SESSION_COOKIE, hashPassword, sessionCookieOptions, signSession, sessionPayloadFor } from "@/lib/auth";
import { validatePassword } from "@/lib/password-policy";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";
import { validateUsername } from "@/lib/username-policy";

export async function POST(req: Request) {
  const limiter = rateLimit(`register:${clientIp(req)}`, 6, 60 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const body = await readJson<{ name?: string; email?: string; password?: string }>(req);
  const name = (body?.name || "").trim();
  const email = (body?.email || "").trim().toLowerCase();
  const password = body?.password || "";

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return fail("Please enter a valid email address");
  const pwCheck = validatePassword(password);
  if (!pwCheck.ok) return fail(pwCheck.message);

  // A username (name) is optional at signup, but when provided it must follow
  // the same policy as the Change Username feature — format, reserved names
  // and uniqueness (case-insensitive; the DB unique index backstops races).
  if (name) {
    const nameCheck = validateUsername(name, false);
    if (!nameCheck.ok) return fail(nameCheck.message);
    const rows = await db.user.findMany({ where: { name: { not: null } }, select: { name: true } });
    if (rows.some((r) => (r.name || "").toLowerCase() === nameCheck.value.toLowerCase()))
      return fail("This username is already taken. Please choose another one.", 409);
  }

  const existing = await db.user.findUnique({ where: { email } });
  if (existing) return fail("An account with this email already exists", 409);

  const passwordHash = await hashPassword(password);
  let user;
  try {
    user = await db.user.create({
      data: { email, name: name || null, passwordHash, role: "USER" },
      select: { id: true, email: true, name: true, role: true, tokenVersion: true },
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      const target = (e.meta?.target as string[] | string | undefined) ?? [];
      const targetStr = Array.isArray(target) ? target.join(",") : String(target);
      return fail(
        targetStr.includes("name")
          ? "This username is already taken. Please choose another one."
          : "An account with this email already exists",
        409
      );
    }
    throw e;
  }

  const token = signSession(sessionPayloadFor(user));
  const res = ok({ user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions());
  return res;
}
