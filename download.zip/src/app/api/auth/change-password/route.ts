import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireUser, hashPassword, verifyPassword, SESSION_COOKIE, sessionCookieOptions, signSession, sessionPayloadFor } from "@/lib/auth";
import { validatePassword } from "@/lib/password-policy";
import { rateLimit, tooMany } from "@/lib/rate-limit";

/**
 * Change the signed-in account's own password (works for users and admins —
 * the server always targets the session user, never a client-supplied id).
 *
 * Requires the current password (reauthentication), enforces the strong
 * password policy, bumps tokenVersion so every existing session (including
 * other devices) is signed out, then issues a fresh session for this device.
 */
export async function POST(req: Request) {
  const auth = await requireUser(req);
  if (!auth.ok) return fail(auth.error, 401);
  const me = auth.user;

  const limiter = rateLimit(`chpass:${me.id}`, 10, 15 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const body = await readJson<{ currentPassword?: string; newPassword?: string }>(req);
  const current = body?.currentPassword || "";
  const next = body?.newPassword || "";

  if (!current) return fail("Please enter your current password");
  if (!next) return fail("Please choose a new password");

  const strength = validatePassword(next);
  if (!strength.ok) return fail(strength.message);

  const row = await db.user.findUnique({ where: { id: me.id } });
  if (!row) return fail("Account not found", 404);

  const currentOk = await verifyPassword(current, row.passwordHash);
  if (!currentOk) return fail("Your current password is incorrect", 403);

  const sameAsOld = await verifyPassword(next, row.passwordHash);
  if (sameAsOld) return fail("Your new password must be different from the current one");

  const newHash = await hashPassword(next);
  const updated = await db.user.update({
    where: { id: me.id },
    data: { passwordHash: newHash, tokenVersion: { increment: 1 } },
  });

  // Fresh session for THIS device (tokenVersion now matches); all other
  // devices were signed out by the bump. Changing a password never touches
  // any content, user records or donations — only the auth credential.
  const token = signSession(sessionPayloadFor(updated));
  const res = ok({
    success: true,
    user: { id: updated.id, email: updated.email, name: updated.name, role: updated.role },
  });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions());
  return res;
}
