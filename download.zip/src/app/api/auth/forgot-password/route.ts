import { createHash, randomBytes } from "crypto";
import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { sendPasswordResetEmail, RESET_TOKEN_TTL_MS } from "@/lib/mailer";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/**
 * Request a password reset email. Always responds with a generic message so
 * attackers cannot discover which emails are registered (no enumeration).
 *
 * Tokens: 32 random bytes emailed to the user; only the SHA-256 hash is
 * stored, the row is single-use and expires after 1 hour. Creating a new
 * request invalidates previous unused tokens for the account.
 */
export async function POST(req: Request) {
  const ip = clientIp(req);
  const perIp = rateLimit(`forgot:ip:${ip}`, 5, 60 * 60_000);
  if (!perIp.allowed) return tooMany(perIp.retryAfterSec);

  const body = await readJson<{ email?: string }>(req);
  const email = (body?.email || "").trim().toLowerCase();
  const generic = ok({
    success: true,
    message: "If an account exists for this email, a password reset link has been sent. Please check your inbox (and spam folder).",
  });

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return generic;

  const user = await db.user.findUnique({ where: { email } });
  if (!user) return generic;

  const perAccount = rateLimit(`forgot:acct:${user.id}`, 3, 60 * 60_000);
  if (!perAccount.allowed) return generic; // same generic response, silently throttled

  const rawToken = randomBytes(32).toString("base64url");
  const tokenHash = createHash("sha256").update(rawToken).digest("hex");
  const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MS);

  // Invalidate previous unused tokens, then store the fresh single-use hash.
  await db.passwordResetToken.deleteMany({ where: { userId: user.id, usedAt: null } });
  await db.passwordResetToken.create({ data: { userId: user.id, tokenHash, expiresAt } });

  const origin =
    process.env.SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    `${req.headers.get("x-forwarded-proto") || "http"}://${req.headers.get("x-forwarded-host") || req.headers.get("host") || "localhost:3000"}`;

  try {
    await sendPasswordResetEmail(user.email, rawToken, origin.replace(/\/$/, ""));
  } catch (err) {
    // Never leak whether the account exists — log server-side for diagnosis.
    console.error(`[forgot-password] email delivery failed for a request: ${err instanceof Error ? err.message : err}`);
    if (err instanceof Error && err.message === "SMTP_NOT_CONFIGURED") {
      return fail(
        "Email delivery is not configured yet. An administrator can enable it under Admin Dashboard → Settings → Email (SMTP).",
        503
      );
    }
    return fail("We could not send the reset email right now. Please try again later.", 502);
  }

  return generic;
}
