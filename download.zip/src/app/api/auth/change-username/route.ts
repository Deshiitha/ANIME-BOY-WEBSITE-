import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireUser, verifyPassword, SESSION_COOKIE, sessionCookieOptions, signSession, sessionPayloadFor } from "@/lib/auth";
import { rateLimit, tooMany } from "@/lib/rate-limit";
import { validateUsername } from "@/lib/username-policy";

/**
 * POST /api/auth/change-username   { newUsername, currentPassword? }
 *
 * Change the signed-in account's own username. The server always targets the
 * session user (never a client-supplied id), so a regular user can never
 * change another account — including the admin's.
 *
 *  - Backend validation: 3–20 chars, letters/numbers/underscores, trimmed,
 *    non-empty; reserved names blocked for regular users.
 *  - Unique usernames: case-insensitive check here + a DB-level unique index
 *    on User.name + a P2002 race guard.
 *  - Admin accounts must reauthenticate with their current password
 *    (sensitive profile change). Regular users use their session only.
 *  - Sessions are preserved: tokenVersion is NOT bumped, so watchlist,
 *    requests, donations and admin access all continue to work. This device
 *    simply gets a freshly signed cookie carrying the new name.
 *  - Only User.name changes — no content, no donations, no historical
 *    payment records are touched.
 */
export async function POST(req: Request) {
  const auth = await requireUser(req);
  if (!auth.ok) return fail(auth.error, 401);
  const me = auth.user;

  const limiter = rateLimit(`chuser:${me.id}`, 10, 15 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const body = await readJson<{ newUsername?: string; currentPassword?: string }>(req);
  const requested = (body?.newUsername || "").trim();

  // Same-as-current first (legacy names may predate the format policy).
  if (requested.toLowerCase() === (me.name || "").toLowerCase()) {
    return fail("This is already your current username");
  }

  const check = validateUsername(requested, me.role === "ADMIN");
  if (!check.ok) return fail(check.message);
  const nextName = check.value;

  // Case-insensitive uniqueness against other accounts.
  const rows = await db.user.findMany({ where: { name: { not: null } }, select: { id: true, name: true } });
  const clash = rows.find((r) => r.id !== me.id && (r.name || "").toLowerCase() === nextName.toLowerCase());
  if (clash) {
    return fail("This username is already taken. Please choose another one.", 409);
  }

  // Admin profile changes are sensitive — require password reauthentication.
  if (me.role === "ADMIN") {
    const currentPassword = body?.currentPassword || "";
    if (!currentPassword) return fail("Please enter your current password to confirm this change");
    const row = await db.user.findUnique({ where: { id: me.id } });
    if (!row) return fail("Account not found", 404);
    const passwordOk = await verifyPassword(currentPassword, row.passwordHash);
    if (!passwordOk) return fail("Your current password is incorrect", 403);
  }

  try {
    const updated = await db.user.update({
      where: { id: me.id },
      data: { name: nextName },
      select: { id: true, email: true, name: true, role: true, tokenVersion: true },
    });

    // Freshly signed session for THIS device — same tokenVersion, so every
    // other session (watchlist, donations, admin dashboard) stays valid.
    const token = signSession(sessionPayloadFor(updated));
    const res = ok({
      success: true,
      user: { id: updated.id, email: updated.email, name: updated.name, role: updated.role },
    });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions());
    return res;
  } catch (e) {
    // Race guard: another account claimed the name between check and update.
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      return fail("This username is already taken. Please choose another one.", 409);
    }
    throw e;
  }
}
