import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { SESSION_COOKIE, sessionCookieOptions, signSession, verifyPassword, sessionPayloadFor } from "@/lib/auth";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const body = await readJson<{ email?: string; password?: string }>(req);
  const email = (body?.email || "").trim().toLowerCase();
  const password = body?.password || "";
  if (!email || !password) return fail("Email and password are required");

  // Brute-force protection: per-IP and per-IP+email limits.
  const ip = clientIp(req);
  const perIp = rateLimit(`login:ip:${ip}`, 20, 10 * 60_000);
  const perTarget = rateLimit(`login:acct:${ip}:${email}`, 8, 10 * 60_000);
  const limited = !perIp.allowed ? perIp : !perTarget.allowed ? perTarget : null;
  if (limited) return tooMany(limited.retryAfterSec);

  const user = await db.user.findUnique({ where: { email } });
  if (!user) return fail("Invalid email or password", 401);

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return fail("Invalid email or password", 401);

  const safeUser = { id: user.id, email: user.email, name: user.name, role: user.role };
  const token = signSession(sessionPayloadFor(user));
  const res = ok({ user: safeUser });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions());
  return res;
}
