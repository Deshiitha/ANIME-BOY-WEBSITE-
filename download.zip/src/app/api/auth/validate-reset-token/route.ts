import { createHash } from "crypto";
import { db } from "@/lib/db";
import { ok, readJson } from "@/lib/api-helpers";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/** Check whether a reset token is still valid (used by the reset page before showing the form). */
export async function POST(req: Request) {
  const limiter = rateLimit(`validate-reset:${clientIp(req)}`, 30, 60 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const body = await readJson<{ token?: string }>(req);
  const token = (body?.token || "").trim();
  if (!token) return ok({ valid: false });

  const tokenHash = createHash("sha256").update(token).digest("hex");
  const record = await db.passwordResetToken.findUnique({ where: { tokenHash } });
  const valid = !!record && !record.usedAt && record.expiresAt.getTime() > Date.now();
  return ok({ valid });
}
