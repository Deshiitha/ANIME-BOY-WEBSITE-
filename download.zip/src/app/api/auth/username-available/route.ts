import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";
import { requireUser } from "@/lib/auth";
import { rateLimit, tooMany } from "@/lib/rate-limit";
import { isReservedUsername, reservedUsernameMessage, validateUsernameFormat } from "@/lib/username-policy";

/**
 * GET /api/auth/username-available?u=<name>
 *
 * Live availability indicator for the Profile Settings form. Signed-in only
 * (it is not a public enumeration endpoint) and rate limited. Uniqueness is
 * enforced case-insensitively and never reports the caller's own current
 * username as taken.
 */
export async function GET(req: Request) {
  const auth = await requireUser(req);
  if (!auth.ok) return fail(auth.error, 401);
  const me = auth.user;

  const limiter = rateLimit(`uname-check:${me.id}`, 60, 5 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const url = new URL(req.url);
  const raw = url.searchParams.get("u") ?? "";

  // Own current username (legacy names may predate the format policy) is
  // reported as "current" before any format check — it is already theirs.
  if (raw.trim().toLowerCase() === (me.name || "").toLowerCase()) {
    return ok({ available: true, current: true });
  }

  const format = validateUsernameFormat(raw);
  if (!format.ok) return ok({ available: false, reason: format.message });
  const value = format.value;

  if (isReservedUsername(value, me.role === "ADMIN")) {
    return ok({ available: false, reason: reservedUsernameMessage() });
  }

  // Case-insensitive uniqueness (SQLite's default = comparison is
  // case-sensitive; the account table on this deployment is small so a
  // scanned comparison is the simplest exact guarantee). The DB-level
  // unique index on User.name backstops this against races.
  const rows = await db.user.findMany({ where: { name: { not: null } }, select: { id: true, name: true } });
  const clash = rows.find((r) => r.id !== me.id && (r.name || "").toLowerCase() === value.toLowerCase());
  if (clash) {
    return ok({ available: false, reason: "This username is already taken. Please choose another one." });
  }

  return ok({ available: true });
}
