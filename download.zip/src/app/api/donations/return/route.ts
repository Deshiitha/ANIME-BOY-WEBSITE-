import { NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Browser return target after PayHere checkout. This is a convenience
 * redirect ONLY — the payment status shown here is what the notify webhook
 * has authoritatively recorded. The donor is bounced back to the SPA support
 * page which then polls /api/donations/status.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const donationId = url.searchParams.get("d") || "";
  const cancelled = url.searchParams.get("cancelled") === "1";

  let orderId = "";
  if (donationId) {
    const donation = await db.donation.findUnique({ where: { id: donationId }, select: { orderId: true } });
    orderId = donation?.orderId || "";
  }

  const base = (
    process.env.SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    `${url.protocol}//${url.host}`
  ).replace(/\/$/, "");

  const hash = orderId
    ? `#/support?donation=${encodeURIComponent(orderId)}&result=${cancelled ? "cancelled" : "return"}`
    : "#/support";
  return NextResponse.redirect(`${base}/${hash}`, 302);
}
