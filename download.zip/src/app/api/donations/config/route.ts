import { ok } from "@/lib/api-helpers";
import { getDonationConfig, gatewayReady, providerCurrencies, providerMethods } from "@/lib/donation-config";

/**
 * Public donation page configuration. Contains NO secrets: gateway credentials
 * are never exposed — clients only learn which provider is active, which
 * payment methods and currencies that provider officially supports, and
 * whether checkout is ready. Bank-transfer details are intentionally public
 * (donors need them to deposit).
 */
export async function GET() {
  const cfg = await getDonationConfig();
  const methods = providerMethods(cfg);
  const currencies = providerCurrencies(cfg);
  const currency = currencies.includes(cfg.gatewayCurrency) ? cfg.gatewayCurrency : currencies[0];

  return ok({
    config: {
      donationEnabled: cfg.donationEnabled,
      heading: cfg.donationHeading,
      description: cfg.donationDescription,
      thankYouNote: cfg.donationThankYouNote,
      presets: cfg.donationPresets,
      publicRecognition: cfg.donationPublicRecognition,
      provider: cfg.provider, // PAYHERE | WEBXPAY | NONE
      gatewayReady: gatewayReady(cfg),
      gatewayMode: cfg.gatewayMode,
      gatewayCurrency: currency,
      supportedCurrencies: currencies,
      supportedMethods: methods, // official methods of the configured provider only
      bankEnabled: cfg.donationEnabled && cfg.bankEnabled && !!cfg.bankAccountNumber,
      bank: {
        name: cfg.bankName,
        accountName: cfg.bankAccountName,
        accountNumber: cfg.bankAccountNumber,
        branch: cfg.bankBranch,
        instructions: cfg.bankInstructions,
      },
    },
  });
}
