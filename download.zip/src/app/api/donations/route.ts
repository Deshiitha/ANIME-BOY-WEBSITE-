import { randomBytes } from "crypto";
import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";
import {
  getDonationConfig,
  gatewayReady,
  providerCurrencies,
  type DonationConfig,
} from "@/lib/donation-config";
import {
  PAYHERE_CHECKOUT_URLS,
  buildCheckoutHash,
  formatAmount,
  splitDonorName,
} from "@/lib/payhere";
import { WEBXPAY_CHECKOUT_URLS, encryptPaymentParam } from "@/lib/webxpay";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

type CreateBody = {
  method?: string; // GATEWAY | BANK_TRANSFER
  amount?: number;
  currency?: string;
  donorName?: string;
  donorEmail?: string;
  message?: string;
  anonymous?: boolean;
  reference?: string; // bank transfer reference (optional)
  // WEBXPAY hosted checkout requires donor contact details (official spec):
  phone?: string;
  addressLine1?: string;
  city?: string;
  country?: string;
};

function newOrderId(): string {
  return `AB-${Date.now().toString(36).toUpperCase()}-${randomBytes(4).toString("hex").toUpperCase()}`;
}

function minAmount(currency: string): number {
  // Official gateways: 1 USD / 1 LKR minimums; keep a practical floor of Rs.10
  return currency === "LKR" ? 10 : 1;
}

function maxAmount(currency: string): number {
  return currency === "LKR" ? 1_000_000 : 10_000;
}

function publicOrigin(req: Request): string {
  return (
    process.env.SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    `${req.headers.get("x-forwarded-proto") || "http"}://${req.headers.get("x-forwarded-host") || req.headers.get("host") || "localhost:3000"}`
  ).replace(/\/$/, "");
}

function amountLabel(currency: string): string {
  return currency === "LKR" ? "Rs." : currency;
}

/**
 * Create a donation intent.
 *  - GATEWAY (PayHere or WebXPay): returns the hosted-checkout parameter set
 *    for the browser form POST. Provider secrets needed for checkout travel
 *    only inside the POST payload defined by the provider's official
 *    integration — card data itself is always entered on the provider's
 *    PCI-compliant hosted page, never on this site.
 *  - BANK_TRANSFER: records a PENDING donation the admin verifies manually.
 *
 * No flow ever marks a donation VERIFIED from a frontend response — gateway
 * donations become VERIFIED only via the signed server callback.
 */
export async function POST(req: Request) {
  const limiter = rateLimit(`donate:${clientIp(req)}`, 8, 60 * 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const cfg = await getDonationConfig();
  if (!cfg.donationEnabled) return fail("Donations are currently disabled.", 403);

  const body = await readJson<CreateBody>(req);
  // Gateway rows record the concrete provider (PAYHERE | WEBXPAY) so history
  // and stats stay accurate; bank transfers use BANK_TRANSFER.
  const method =
    body?.method === "BANK_TRANSFER"
      ? "BANK_TRANSFER"
      : body?.method === "GATEWAY"
        ? cfg.provider === "WEBXPAY"
          ? "WEBXPAY"
          : "PAYHERE"
        : null;
  if (!method) return fail("Please choose a payment method.");

  const currencies = providerCurrencies(cfg);
  const currency = currencies.includes((body?.currency || "").toUpperCase()) ? (body?.currency || "").toUpperCase() : currencies[0];

  const amount = Math.round(Number(body?.amount));
  if (!Number.isFinite(amount) || amount < minAmount(currency)) {
    return fail(`Minimum donation amount is ${amountLabel(currency)} ${minAmount(currency)}.`);
  }
  if (amount > maxAmount(currency)) {
    return fail(`Maximum donation amount is ${amountLabel(currency)} ${maxAmount(currency).toLocaleString()}. Please contact us for larger gifts.`);
  }

  const donorName = (body?.donorName || "").trim().slice(0, 60) || null;
  const donorEmail = (body?.donorEmail || "").trim().toLowerCase().slice(0, 120) || null;
  if (donorEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(donorEmail)) return fail("Please enter a valid email address.");
  const message = (body?.message || "").trim().slice(0, 280) || null;
  const anonymous = !!body?.anonymous;
  const reference = (body?.reference || "").trim().slice(0, 80) || null;

  const session = await getSessionFromRequest(req);
  const amountCents = Math.round(amount * 100);
  const orderId = newOrderId();

  if (method === "BANK_TRANSFER") {
    if (!cfg.bankEnabled || !cfg.bankAccountNumber) return fail("Bank transfer donations are not available right now.", 403);
    const donation = await db.donation.create({
      data: {
        orderId,
        userId: session?.id || null,
        method,
        amountCents,
        currency,
        donorName: anonymous ? null : donorName,
        donorEmail,
        message,
        anonymous,
        reference,
        status: "PENDING",
        statusMessage: "Awaiting manual verification by the site owner",
      },
    });
    return ok({
      donation: { orderId: donation.orderId, status: donation.status, method: donation.method },
      next: "BANK_TRANSFER_RECORDED",
    });
  }

  // GATEWAY — the provider must be fully configured by the admin first.
  if (!gatewayReady(cfg)) {
    return fail(
      "Online payments are not available yet — the payment gateway is not configured. Please use the bank transfer option or try again later.",
      503
    );
  }
  if (!donorEmail) {
    return fail("An email address is required for online payments so the receipt can be issued.");
  }

  const donation = await db.donation.create({
    data: {
      orderId,
      userId: session?.id || null,
      method,
      amountCents,
      currency,
      donorName: anonymous ? null : donorName,
      donorEmail,
      message,
      anonymous,
      status: "PENDING",
      statusMessage: "Awaiting payment",
    },
  });

  const base = publicOrigin(req);
  const amountStr = formatAmount(amountCents);
  const { firstName, lastName } = splitDonorName(anonymous ? null : donorName);

  if (cfg.provider === "WEBXPAY") {
    return await webxpayCheckout(cfg, { donation, orderId, amountStr, currency, donorName, donorEmail, body });
  }

  // Default: PayHere hosted checkout.
  const secretRow = await db.siteConfig.findUnique({ where: { key: "payhereMerchantSecret" } });
  const params = {
    merchant_id: cfg.payhereMerchantId,
    return_url: `${base}/api/donations/return?d=${encodeURIComponent(donation.id)}`,
    cancel_url: `${base}/api/donations/return?d=${encodeURIComponent(donation.id)}&cancelled=1`,
    notify_url: `${base}/api/donations/notify`,
    order_id: orderId,
    items: "ANIME BOY — Website Support Donation",
    currency,
    amount: amountStr,
    first_name: firstName,
    last_name: lastName,
    email: donorEmail,
    phone: (body?.phone || "").trim().slice(0, 30) || "N/A",
    address: (body?.addressLine1 || "").trim().slice(0, 120) || "N/A",
    city: (body?.city || "").trim().slice(0, 60) || "N/A",
    country: (body?.country || "").trim().slice(0, 60) || "Sri Lanka",
    custom_1: donation.id,
    custom_2: orderId,
    hash: "",
  };
  params.hash = buildCheckoutHash(params.merchant_id, params.order_id, params.amount, params.currency, secretRow?.value || "");

  return ok({
    donation: { orderId: donation.orderId, status: donation.status, method: donation.method },
    next: "PAYHERE_CHECKOUT",
    payhere: {
      action: PAYHERE_CHECKOUT_URLS[cfg.gatewayMode] || PAYHERE_CHECKOUT_URLS.sandbox,
      params,
    },
  });
}

/**
 * WEBXPAY hosted checkout (official Redirect Integration):
 * browser form POST with the RSA-encrypted payment parameter. The secret key
 * is part of WEBXPAY's documented redirect request; the donor's card data is
 * still entered exclusively on WEBXPAY's page.
 */
async function webxpayCheckout(
  cfg: DonationConfig,
  ctx: {
    donation: { id: string; orderId: string; status: string; method: string };
    orderId: string;
    amountStr: string;
    currency: string;
    donorName: string | null;
    donorEmail: string | null;
    body: CreateBody | null;
  }
) {
  const phone = (ctx.body?.phone || "").trim();
  const addressLine1 = (ctx.body?.addressLine1 || "").trim();
  if (!phone) return fail("A contact number is required by the payment gateway.");
  if (!addressLine1) return fail("An address line is required by the payment gateway.");

  const [secretRow, publicKeyRow] = await Promise.all([
    db.siteConfig.findUnique({ where: { key: "webxpaySecretKey" } }),
    db.siteConfig.findUnique({ where: { key: "webxpayPublicKey" } }),
  ]);
  const secretKey = secretRow?.value || "";
  const publicKey = publicKeyRow?.value || "";
  if (!secretKey || !publicKey) return fail("The payment gateway is not fully configured.", 503);

  let paymentParam: string;
  try {
    paymentParam = encryptPaymentParam(ctx.orderId, ctx.amountStr, publicKey);
  } catch {
    return fail("The stored gateway public key looks invalid — the site owner must re-save the payment settings.", 503);
  }

  const { firstName, lastName } = splitDonorName(ctx.donorName);
  const params: Record<string, string> = {
    first_name: firstName,
    last_name: lastName,
    email: ctx.donorEmail || "",
    contact_number: phone.slice(0, 30),
    address_line_one: addressLine1.slice(0, 120),
    address_line_two: ((ctx.body?.city || "").trim() + "").slice(0, 120),
    city: (ctx.body?.city || "").trim().slice(0, 60) || "N/A",
    country: (ctx.body?.country || "").trim().slice(0, 60) || "Sri Lanka",
    secret_key: secretKey,
    payment: paymentParam,
    cms: "ANIME BOY",
    process_currency: ctx.currency,
    custom_fields: Buffer.from(`${ctx.donation.id}|${ctx.orderId}|${ctx.amountStr}|${ctx.currency}`).toString("base64"),
  };
  if (cfg.webxpayGatewayId.trim()) params.payment_gateway_id = cfg.webxpayGatewayId.trim();

  return ok({
    donation: { orderId: ctx.donation.orderId, status: ctx.donation.status, method: ctx.donation.method },
    next: "WEBXPAY_CHECKOUT",
    webxpay: {
      action: WEBXPAY_CHECKOUT_URLS[cfg.gatewayMode === "live" ? "live" : "staging"],
      params,
    },
  });
}
