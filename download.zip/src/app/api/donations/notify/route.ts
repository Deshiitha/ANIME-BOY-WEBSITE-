import { db } from "@/lib/db";
import { fail, ok, readJson } from "@/lib/api-helpers";
import { getDonationConfig, gatewayReady } from "@/lib/donation-config";
import { notifyStatus, verifyNotifySignature } from "@/lib/payhere";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/**
 * PayHere server-to-server notify (IPN) webhook — the ONLY place a PayHere
 * donation can become VERIFIED. Every request is authenticated by recomputing
 * the md5sig with the merchant secret, which never leaves the server.
 *
 * Webhook idempotency: an already-terminal (VERIFIED) donation is never
 * re-processed — duplicate notifications are acknowledged with 200 and
 * ignored, so totals can never be double-counted. Browser returns
 * (return_url) deliberately cannot change payment status.
 */
export async function POST(req: Request) {
  const limiter = rateLimit(`payhere-notify:${clientIp(req)}`, 120, 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  // PayHere posts application/x-www-form-urlencoded.
  let form: Record<string, string> = {};
  const contentType = req.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    const body = await readJson<Record<string, unknown>>(req);
    if (!body) return fail("Invalid payload");
    for (const [k, v] of Object.entries(body)) form[k] = String(v ?? "");
  } else {
    try {
      form = Object.fromEntries((await req.formData()).entries()) as Record<string, string>;
    } catch {
      return fail("Invalid payload");
    }
  }

  const cfg = await getDonationConfig();
  if (!gatewayReady(cfg) || cfg.provider !== "PAYHERE") return fail("Gateway not configured", 503);

  const merchantSecretRow = await db.siteConfig.findUnique({ where: { key: "payhereMerchantSecret" } });
  const merchantSecret = merchantSecretRow?.value || "";

  // 1) Merchant identity + signature verification (timing-safe).
  if (form.merchant_id !== cfg.payhereMerchantId) return fail("Unknown merchant", 400);
  const sigOk = verifyNotifySignature(
    {
      merchant_id: form.merchant_id,
      order_id: form.order_id,
      payhere_amount: form.payhere_amount,
      payhere_currency: form.payhere_currency,
      status_code: form.status_code,
      md5sig: form.md5sig,
    },
    cfg.payhereMerchantId,
    merchantSecret
  );
  if (!sigOk) return fail("Invalid signature", 403);

  // 2) Find the donation this callback is about.
  const donation = await db.donation.findUnique({ where: { orderId: form.order_id } });
  if (!donation) return fail("Unknown order", 404);

  // 3) Webhook idempotency — VERIFIED is terminal. Repeat notifications
  //    (PayHere retries on timeouts) are acknowledged without side effects.
  if (donation.status === "VERIFIED") {
    return ok({ received: true, duplicate: true });
  }

  // 4) Guard against amount/currency tampering.
  const paidCents = Math.round(Number(form.payhere_amount) * 100);
  if (Number.isFinite(paidCents) && paidCents !== donation.amountCents) {
    await db.donation.update({
      where: { id: donation.id },
      data: { statusMessage: `Gateway amount mismatch (reported ${(paidCents / 100).toFixed(2)} ${donation.currency}) — left unverified` },
    });
    return fail("Amount mismatch", 400);
  }
  if (form.payhere_currency && form.payhere_currency !== donation.currency) {
    await db.donation.update({
      where: { id: donation.id },
      data: { statusMessage: `Gateway currency mismatch (${form.payhere_currency}) — left unverified` },
    });
    return fail("Currency mismatch", 400);
  }

  // 5) Map the gateway status. Success (2) → VERIFIED with the payment id.
  //    A single conditional update keeps concurrent callbacks idempotent too.
  const statusCode = Number(form.status_code);
  const { status, message } = notifyStatus(statusCode);

  const updated = await db.donation.updateMany({
    where: { id: donation.id, status: { not: "VERIFIED" } },
    data: {
      status,
      statusMessage: message,
      providerRef: form.payment_id ? String(form.payment_id) : donation.providerRef,
      paymentMethod: form.method ? String(form.method).toUpperCase().slice(0, 30) : donation.paymentMethod,
    },
  });

  // PayHere expects a 200 with any body.
  return ok({ received: true, processed: updated.count > 0 });
}
