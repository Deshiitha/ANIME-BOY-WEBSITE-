import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, readJson } from "@/lib/api-helpers";
import { getDonationConfig } from "@/lib/donation-config";
import { verifyCallback, mapStatus } from "@/lib/webxpay";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/**
 * WEBXPAY server-to-server callback (official Redirect Integration response
 * handling) — the ONLY place a WEBXPAY donation can become VERIFIED.
 *
 * The `payment` and `signature` form fields are RSA payloads that are
 * decrypted with the merchant public key and must match each other (the
 * anti-man-in-the-middle check required by the WEBXPAY spec). Amounts are
 * re-checked against the stored donation via the custom_fields we sent at
 * checkout.
 *
 * WEBXPAY posts the result to the merchant Return URL in the donor's browser
 * session, so after processing the donor is 302-redirected back to the SPA
 * support page which polls /api/donations/status. Server-side retries (no
 * text/html accept header) get a plain JSON response instead.
 *
 * Webhook idempotency: VERIFIED is terminal — duplicate callbacks are
 * acknowledged and ignored.
 */
function wantsHtml(req: Request): boolean {
  return (req.headers.get("accept") || "").includes("text/html");
}

function donorRedirect(req: Request, orderId: string, result: string): NextResponse | null {
  if (!wantsHtml(req)) return null;
  const url = new URL(req.url);
  const base = (
    process.env.SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    `${url.protocol}//${url.host}`
  ).replace(/\/$/, "");
  const hash = orderId
    ? `#/support?donation=${encodeURIComponent(orderId)}&result=${result}`
    : "#/support";
  return NextResponse.redirect(`${base}/${hash}`, 302);
}
export async function POST(req: Request) {
  const limiter = rateLimit(`webxpay-notify:${clientIp(req)}`, 120, 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  let form: Record<string, string> = {};
  const contentType = req.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    const body = await readJson<Record<string, unknown>>(req);
    if (!body) return fail("Invalid payload");
    for (const [k, v] of Object.entries(body)) form[k] = String(v ?? "");
  } else {
    try {
      form = Object.fromEntries((await req.formData()).entries()) as Record<string, string>;
    } catch {
      return fail("Invalid payload");
    }
  }

  const cfg = await getDonationConfig();
  if (cfg.provider !== "WEBXPAY" || !cfg.webxpayPublicKeySet) return fail("Gateway not configured", 503);

  const publicKeyRow = await db.siteConfig.findUnique({ where: { key: "webxpayPublicKey" } });
  const publicKey = publicKeyRow?.value || "";
  if (!publicKey) return fail("Gateway not configured", 503);

  // 1) RSA verification + parsing per the official spec.
  const result = verifyCallback({ payment: form.payment, signature: form.signature }, publicKey);
  if (!result.ok) return fail(result.reason || "Invalid callback", 403);
  // 2) Find the donation. The decrypted payment's order_id is our unique
  //    order reference; custom_fields (base64 `donationId|orderId|amount|ccy`)
  //    is a secondary match for extra safety.
  let donation = await db.donation.findUnique({ where: { orderId: result.orderId || "" } });
  if (!donation && form.custom_fields) {
    try {
      const parts = Buffer.from(form.custom_fields, "base64").toString("utf8").split("|");
      if (parts[0]) donation = await db.donation.findUnique({ where: { id: parts[0] } });
    } catch {
      /* fall through */
    }
  }
  if (!donation) return fail("Unknown order", 404);

  // 3) Webhook idempotency — never re-process a VERIFIED donation.
  if (donation.status === "VERIFIED") {
    return donorRedirect(req, donation.orderId, "return") || ok({ received: true, duplicate: true });
  }

  // 4) Amount/currency tamper guard using our own signed-in custom fields.
  if (form.custom_fields) {
    try {
      const parts = Buffer.from(form.custom_fields, "base64").toString("utf8").split("|");
      const amountCents = Math.round(Number(parts[2]) * 100);
      if (Number.isFinite(amountCents) && amountCents !== donation.amountCents) {
        await db.donation.update({
          where: { id: donation.id },
          data: { statusMessage: `Gateway amount mismatch (${parts[2]} ${parts[3] || ""}) — left unverified` },
        });
        return fail("Amount mismatch", 400);
      }
      if (parts[3] && parts[3] !== donation.currency) {
        await db.donation.update({
          where: { id: donation.id },
          data: { statusMessage: `Gateway currency mismatch (${parts[3]}) — left unverified` },
        });
        return fail("Currency mismatch", 400);
      }
    } catch {
      /* custom_fields is optional per spec — ignore parse issues */
    }
  }

  // 5) Map the status code (0/00 approved, 15 declined) and update once.
  const { status, message } = mapStatus(result.statusCode || "", result.comment || "");

  const updated = await db.donation.updateMany({
    where: { id: donation.id, status: { not: "VERIFIED" } },
    data: {
      status,
      statusMessage: message,
      providerRef: result.gatewayReference || donation.providerRef,
      paymentMethod: result.gatewayUsed ? `WEBXPAY_GW_${result.gatewayUsed}`.slice(0, 30) : donation.paymentMethod,
    },
  });

  const redirect = donorRedirect(req, donation.orderId, status === "VERIFIED" ? "return" : "return");
  return redirect || ok({ received: true, processed: updated.count > 0 });
}
