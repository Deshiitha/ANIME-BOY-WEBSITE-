import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/**
 * Post-payment status lookup used by the support page after the donor
 * returns from the gateway. Minimal public fields only; the orderId is an
 * unguessable random token. This never marks a donation verified — it only
 * reflects the state set by the notify webhook or admin verification.
 */
export async function GET(req: Request) {
  const limiter = rateLimit(`dstatus:${clientIp(req)}`, 60, 60_000);
  if (!limiter.allowed) return tooMany(limiter.retryAfterSec);

  const orderId = new URL(req.url).searchParams.get("orderId") || "";
  if (!orderId) return fail("Missing order reference");

  const donation = await db.donation.findUnique({
    where: { orderId },
    select: { orderId: true, status: true, method: true, amountCents: true, anonymous: true, donorName: true, createdAt: true },
  });
  if (!donation) return fail("Donation not found", 404);

  return ok({
    donation: {
      orderId: donation.orderId,
      status: donation.status,
      method: donation.method,
      amountCents: donation.amountCents,
      donorLabel: donation.anonymous || !donation.donorName ? "Anonymous" : donation.donorName,
      createdAt: donation.createdAt,
    },
  });
}
