import { db } from "@/lib/db";
import { ok } from "@/lib/api-helpers";
import { getDonationConfig } from "@/lib/donation-config";

/**
 * Public donor recognition wall + verified totals. Only VERIFIED donations
 * are included; anonymous donations show as "Anonymous" with no email.
 */
export async function GET() {
  const cfg = await getDonationConfig();
  if (!cfg.donationEnabled || !cfg.donationPublicRecognition) {
    return ok({ enabled: false, items: [], totalVerifiedCents: 0, countVerified: 0 });
  }

  const [items, agg] = await Promise.all([
    db.donation.findMany({
      where: { status: "VERIFIED" },
      orderBy: { createdAt: "desc" },
      take: 24,
      select: { donorName: true, anonymous: true, amountCents: true, message: true, createdAt: true },
    }),
    db.donation.aggregate({ where: { status: "VERIFIED" }, _sum: { amountCents: true }, _count: true }),
  ]);

  return ok({
    enabled: true,
    items: items.map((d) => ({
      name: d.anonymous ? "Anonymous" : d.donorName || "Anonymous",
      amountCents: d.amountCents,
      message: d.anonymous ? null : d.message,
      createdAt: d.createdAt,
    })),
    totalVerifiedCents: agg._sum.amountCents || 0,
    countVerified: agg._count,
  });
}
