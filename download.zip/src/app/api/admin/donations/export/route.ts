import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";

/** CSV export of donation records honouring the same filters as the list view. */
export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) {
    return new Response(JSON.stringify({ error: auth.error }), { status: 401, headers: { "Content-Type": "application/json" } });
  }

  const url = new URL(req.url);
  const status = url.searchParams.get("status") || "";
  const from = url.searchParams.get("from") || "";
  const to = url.searchParams.get("to") || "";

  const where: Record<string, unknown> = {};
  if (["PENDING", "VERIFIED", "FAILED", "CANCELED", "REJECTED", "REFUNDED"].includes(status)) where.status = status;
  if (from || to) {
    const createdAt: Record<string, Date> = {};
    if (from) {
      const d = new Date(`${from}T00:00:00`);
      if (!Number.isNaN(d.getTime())) createdAt.gte = d;
    }
    if (to) {
      const d = new Date(`${to}T23:59:59.999`);
      if (!Number.isNaN(d.getTime())) createdAt.lte = d;
    }
    if (Object.keys(createdAt).length) where.createdAt = createdAt;
  }

  const rows = await db.donation.findMany({ where, orderBy: { createdAt: "desc" } });

  const esc = (v: unknown): string => {
    const s = v === null || v === undefined ? "" : String(v);
    return `"${s.replace(/"/g, '""').replace(/\r?\n/g, " ")}"`;
  };
  const header = [
    "Date (UTC)", "Order ID", "Method", "Gateway Method", "Status", "Amount", "Currency", "Donor", "Anonymous",
    "Email", "Message", "Bank Reference", "Transaction ID (Gateway)", "Note",
  ];
  const lines = [header.map(esc).join(",")];
  for (const d of rows) {
    lines.push(
      [
        d.createdAt.toISOString(),
        d.orderId,
        d.method,
        d.paymentMethod || "",
        d.status,
        (d.amountCents / 100).toFixed(2),
        d.currency,
        d.anonymous ? "Anonymous" : d.donorName || "",
        d.anonymous ? "yes" : "no",
        d.donorEmail || "",
        d.message || "",
        d.reference || "",
        d.providerRef || "",
        d.statusMessage || "",
      ]
        .map(esc)
        .join(",")
    );
  }

  const stamp = new Date().toISOString().slice(0, 10);
  return new Response(`\uFEFF${lines.join("\n")}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="anime-boy-donations-${stamp}.csv"`,
    },
  });
}
