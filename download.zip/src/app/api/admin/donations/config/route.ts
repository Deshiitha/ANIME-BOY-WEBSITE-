import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin, verifyPassword } from "@/lib/auth";
import {
  getDonationConfig,
  maskAccountNumber,
  maskHint,
  setConfigValues,
} from "@/lib/donation-config";
import { isValidPublicKey } from "@/lib/webxpay";
import { rateLimit, clientIp, tooMany } from "@/lib/rate-limit";

/**
 * Donation payment settings (admin only).
 *
 * Secrets: PayHere merchant secret, WebXPay secret key and WebXPay public key
 * are WRITE-ONLY — GET reports whether each is set plus a masked hint, never
 * the value. Bank/payout account numbers are stored server-side and only ever
 * returned masked (last 4 digits).
 *
 * SECURITY: changing the payment provider, its credentials or the payout
 * account requires the admin to re-authenticate with their current password
 * (`currentPassword`), which is verified server-side against the signed-in
 * administrator account.
 */

type DonationSettingsBody = {
  currentPassword?: string; // required when payment/payout fields are present
  // page/text settings (no re-auth needed)
  donationEnabled?: boolean;
  donationPublicRecognition?: boolean;
  donationHeading?: string;
  donationDescription?: string;
  donationThankYouNote?: string;
  donationPresets?: string | number[];
  // payment settings (re-auth required)
  provider?: string; // PAYHERE | WEBXPAY | NONE
  gatewayEnabled?: boolean;
  gatewayMode?: string;
  gatewayCurrency?: string;
  payhereMerchantId?: string;
  payhereMerchantSecret?: string; // write-only; "CLEAR" removes it
  webxpayMerchantId?: string;
  webxpayGatewayId?: string;
  webxpaySecretKey?: string; // write-only; "CLEAR" removes it
  webxpayPublicKey?: string; // write-only; "CLEAR" removes it
  payoutBankName?: string;
  payoutAccountHolder?: string;
  payoutAccountNumber?: string;
  payoutCurrency?: string;
  // donor-facing manual bank transfer (re-auth: contains account number)
  bankEnabled?: boolean;
  bankName?: string;
  bankAccountName?: string;
  bankAccountNumber?: string;
  bankBranch?: string;
  bankInstructions?: string;
};

const PAYMENT_FIELDS = [
  "provider", "gatewayEnabled", "gatewayMode", "gatewayCurrency",
  "payhereMerchantId", "payhereMerchantSecret",
  "webxpayMerchantId", "webxpayGatewayId", "webxpaySecretKey", "webxpayPublicKey",
  "payoutBankName", "payoutAccountHolder", "payoutAccountNumber", "payoutCurrency",
  "bankEnabled", "bankName", "bankAccountName", "bankAccountNumber", "bankBranch", "bankInstructions",
];

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const cfg = await getDonationConfig();
  const [payhereSecretRow, webxpaySecretRow, webxpayPublicKeyRow] = await Promise.all([
    db.siteConfig.findUnique({ where: { key: "payhereMerchantSecret" } }),
    db.siteConfig.findUnique({ where: { key: "webxpaySecretKey" } }),
    db.siteConfig.findUnique({ where: { key: "webxpayPublicKey" } }),
  ]);

  const missing: string[] = [];
  if (!cfg.gatewayEnabled) missing.push("gateway master switch is off");
  if (cfg.provider === "PAYHERE") {
    if (!cfg.payhereMerchantId) missing.push("PayHere merchant ID");
    if (!cfg.payhereMerchantSecretSet) missing.push("PayHere merchant secret");
  } else if (cfg.provider === "WEBXPAY") {
    if (!cfg.webxpaySecretKeySet) missing.push("WebXPay secret key");
    if (!cfg.webxpayPublicKeySet) missing.push("WebXPay public key");
  } else {
    missing.push("no provider selected");
  }

  return ok({
    config: {
      ...cfg,
      payhereMerchantSecretHint: maskHint(payhereSecretRow?.value || ""),
      webxpaySecretKeyHint: maskHint(webxpaySecretRow?.value || ""),
      webxpayPublicKeyHint: maskHint(webxpayPublicKeyRow?.value || ""),
      payoutAccountNumberMasked: maskAccountNumber(cfg.payoutAccountNumber),
      connectionReady: cfg.gatewayEnabled && missing.length === 0,
      connectionMissing: missing,
    },
    notifyPaths: {
      payhere: "/api/donations/notify",
      webxpay: "/api/donations/webxpay/notify",
    },
  });
}

export async function PUT(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  // Re-auth gate: saving payment/payout settings requires the admin's
  // current password, verified against the signed-in administrator.
  const body = await readJson<DonationSettingsBody>(req);
  if (!body) return fail("Invalid request body");

  const touchesPayment = PAYMENT_FIELDS.some((k) => k in body);
  if (touchesPayment) {
    const limiter = rateLimit(`pay-settings-auth:${clientIp(req)}:${auth.user.id}`, 5, 15 * 60_000);
    if (!limiter.allowed) return tooMany(limiter.retryAfterSec);
    const password = (body.currentPassword || "").trim();
    if (!password) return fail("Re-authentication required — please enter your current password.", 401);
    const admin = await db.user.findUnique({ where: { id: auth.user.id } });
    if (!admin || !(await verifyPassword(password, admin.passwordHash))) {
      return fail("Password re-authentication failed — settings were not saved.", 401);
    }
  }

  const updates: Record<string, string> = {};

  if (body.donationEnabled !== undefined) updates.donationEnabled = body.donationEnabled ? "true" : "false";
  if (body.donationPublicRecognition !== undefined) updates.donationPublicRecognition = body.donationPublicRecognition ? "true" : "false";
  if (body.donationHeading !== undefined) updates.donationHeading = body.donationHeading.trim().slice(0, 120);
  if (body.donationDescription !== undefined) updates.donationDescription = body.donationDescription.trim().slice(0, 400);
  if (body.donationThankYouNote !== undefined) updates.donationThankYouNote = body.donationThankYouNote.trim().slice(0, 600);

  if (body.donationPresets !== undefined) {
    let presets: number[] = [];
    if (Array.isArray(body.donationPresets)) {
      presets = body.donationPresets.map((n) => Math.round(Number(n))).filter((n) => Number.isFinite(n) && n > 0);
    } else {
      presets = String(body.donationPresets)
        .split(/[,\s]+/)
        .map((s) => Math.round(Number(s)))
        .filter((n) => Number.isFinite(n) && n > 0);
    }
    if (presets.length > 12) return fail("Up to 12 preset amounts are supported.");
    for (const p of presets) {
      if (p < 1 || p > 10_000_000) return fail("Preset amounts must be between 1 and 10,000,000.");
    }
    updates.donationPresets = JSON.stringify(presets);
  }

  /* ------------------------- payment settings ------------------------- */
  if (body.provider !== undefined) {
    if (!["PAYHERE", "WEBXPAY", "NONE"].includes(body.provider)) return fail("Unknown payment provider.");
    updates.paymentProvider = body.provider;
  }
  if (body.gatewayEnabled !== undefined) updates.gatewayEnabled = body.gatewayEnabled ? "true" : "false";
  if (body.gatewayMode !== undefined) {
    if (!["sandbox", "live"].includes(body.gatewayMode)) return fail("Gateway mode must be sandbox (staging) or live.");
    updates.gatewayMode = body.gatewayMode;
  }
  if (body.gatewayCurrency !== undefined) {
    const ccy = body.gatewayCurrency.trim().toUpperCase();
    if (!["LKR", "USD", "GBP", "AUD"].includes(ccy)) return fail("Gateway currency must be LKR, USD, GBP or AUD.");
    updates.gatewayCurrency = ccy;
  }

  if (body.payhereMerchantId !== undefined) {
    const id = body.payhereMerchantId.trim();
    if (id && !/^[0-9A-Z]{5,20}$/.test(id)) return fail("PayHere merchant ID looks invalid (usually a numeric ID from your PayHere dashboard).");
    updates.payhereMerchantId = id;
  }
  if (body.payhereMerchantSecret !== undefined) {
    const secret = body.payhereMerchantSecret.trim();
    if (secret === "CLEAR") updates.payhereMerchantSecret = "";
    else if (secret) {
      if (secret.length < 16 || /\s/.test(secret)) return fail("The PayHere merchant secret looks invalid — copy it exactly from PayHere → Domains & Credentials → Merchant Secret.");
      updates.payhereMerchantSecret = secret;
    }
  }

  if (body.webxpayMerchantId !== undefined) updates.webxpayMerchantId = body.webxpayMerchantId.trim().slice(0, 60);
  if (body.webxpayGatewayId !== undefined) updates.webxpayGatewayId = body.webxpayGatewayId.trim().slice(0, 30);
  if (body.webxpaySecretKey !== undefined) {
    const secret = body.webxpaySecretKey.trim();
    if (secret === "CLEAR") updates.webxpaySecretKey = "";
    else if (secret) {
      if (secret.length < 16 || /\s/.test(secret)) return fail("The WebXPay secret key looks invalid — copy it exactly from your WebXPay merchant dashboard.");
      updates.webxpaySecretKey = secret;
    }
  }
  if (body.webxpayPublicKey !== undefined) {
    const key = body.webxpayPublicKey.trim();
    if (key === "CLEAR") updates.webxpayPublicKey = "";
    else if (key) {
      const normalized = key.replace(/\r\n/g, "\n");
      if (!isValidPublicKey(normalized)) {
        return fail("The WebXPay public key looks invalid — paste the full PEM public key from WEBXPAY Dashboard → Settings (including -----BEGIN PUBLIC KEY----- lines).");
      }
      updates.webxpayPublicKey = normalized;
    }
  }

  /* --------------------------- payout account --------------------------- */
  if (body.payoutBankName !== undefined) updates.payoutBankName = body.payoutBankName.trim().slice(0, 120);
  if (body.payoutAccountHolder !== undefined) updates.payoutAccountHolder = body.payoutAccountHolder.trim().slice(0, 120);
  if (body.payoutAccountNumber !== undefined) {
    const acc = body.payoutAccountNumber.trim();
    if (acc && !/^[0-9A-Za-z-]{4,34}$/.test(acc)) return fail("The payout account number looks invalid (digits/letters/dashes only).");
    updates.payoutAccountNumber = acc;
  }
  if (body.payoutCurrency !== undefined) {
    const ccy = body.payoutCurrency.trim().toUpperCase();
    if (!["LKR", "USD"].includes(ccy)) return fail("Payout currency must be LKR or USD for the configured providers.");
    updates.payoutCurrency = ccy;
  }

  /* ------------------- donor-facing bank transfer option ------------------- */
  if (body.bankEnabled !== undefined) updates.bankEnabled = body.bankEnabled ? "true" : "false";
  if (body.bankName !== undefined) updates.bankName = body.bankName.trim().slice(0, 120);
  if (body.bankAccountName !== undefined) updates.bankAccountName = body.bankAccountName.trim().slice(0, 120);
  if (body.bankAccountNumber !== undefined) updates.bankAccountNumber = body.bankAccountNumber.trim().slice(0, 60);
  if (body.bankBranch !== undefined) updates.bankBranch = body.bankBranch.trim().slice(0, 120);
  if (body.bankInstructions !== undefined) updates.bankInstructions = body.bankInstructions.trim().slice(0, 1200);

  await setConfigValues(updates);

  // Return the fresh config so the UI re-renders with new masked values.
  const cfg = await getDonationConfig();
  const [payhereSecretRow, webxpaySecretRow, webxpayPublicKeyRow] = await Promise.all([
    db.siteConfig.findUnique({ where: { key: "payhereMerchantSecret" } }),
    db.siteConfig.findUnique({ where: { key: "webxpaySecretKey" } }),
    db.siteConfig.findUnique({ where: { key: "webxpayPublicKey" } }),
  ]);
  return ok({
    success: true,
    config: {
      ...cfg,
      payhereMerchantSecretHint: maskHint(payhereSecretRow?.value || ""),
      webxpaySecretKeyHint: maskHint(webxpaySecretRow?.value || ""),
      webxpayPublicKeyHint: maskHint(webxpayPublicKeyRow?.value || ""),
      payoutAccountNumberMasked: maskAccountNumber(cfg.payoutAccountNumber),
    },
  });
}
