import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

/** Start of "today" and of the current month in Asia/Colombo (UTC+5:30, no DST). */
function colomboPeriods(): { todayStart: Date; monthStart: Date } {
  const nowUtcMs = Date.now() + 5.5 * 60 * 60_000; // shift into Colombo time
  const shifted = new Date(nowUtcMs);
  const y = shifted.getUTCFullYear();
  const m = shifted.getUTCMonth();
  const d = shifted.getUTCDate();
  const todayStart = new Date(Date.UTC(y, m, d) - 5.5 * 60 * 60_000);
  const monthStart = new Date(Date.UTC(y, m, 1) - 5.5 * 60 * 60_000);
  return { todayStart, monthStart };
}

const STATUSES = ["PENDING", "VERIFIED", "FAILED", "CANCELED", "REJECTED", "REFUNDED"];

/** Admin donation history with filters (status, from, to), dashboard totals. */
export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const url = new URL(req.url);
  const status = url.searchParams.get("status") || "";
  const from = url.searchParams.get("from") || "";
  const to = url.searchParams.get("to") || "";
  const page = Math.max(1, Number(url.searchParams.get("page")) || 1);
  const pageSize = 50;

  const where: Record<string, unknown> = {};
  if (STATUSES.includes(status)) where.status = status;
  if (from || to) {
    const createdAt: Record<string, Date> = {};
    if (from) {
      const d = new Date(`${from}T00:00:00`);
      if (!Number.isNaN(d.getTime())) createdAt.gte = d;
    }
    if (to) {
      const d = new Date(`${to}T23:59:59.999`);
      if (!Number.isNaN(d.getTime())) createdAt.lte = d;
    }
    if (Object.keys(createdAt).length) where.createdAt = createdAt;
  }

  const { todayStart, monthStart } = colomboPeriods();
  const verifiedWhere = { status: "VERIFIED" } as const;

  const [
    items,
    total,
    verifiedAgg,
    pendingCount,
    failedCount,
    canceledCount,
    rejectedCount,
    refundedAgg,
    todayAgg,
    monthAgg,
  ] = await Promise.all([
    db.donation.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: {
        id: true, orderId: true, method: true, amountCents: true, currency: true,
        donorName: true, donorEmail: true, message: true, anonymous: true,
        status: true, providerRef: true, paymentMethod: true, reference: true, statusMessage: true,
        createdAt: true, user: { select: { email: true, name: true } },
      },
    }),
    db.donation.count({ where }),
    db.donation.aggregate({ where: verifiedWhere, _sum: { amountCents: true }, _count: true }),
    db.donation.count({ where: { status: "PENDING" } }),
    db.donation.count({ where: { status: "FAILED" } }),
    db.donation.count({ where: { status: "CANCELED" } }),
    db.donation.count({ where: { status: "REJECTED" } }),
    db.donation.aggregate({ where: { status: "REFUNDED" }, _sum: { amountCents: true }, _count: true }),
    db.donation.aggregate({ where: { ...verifiedWhere, createdAt: { gte: todayStart } }, _sum: { amountCents: true }, _count: true }),
    db.donation.aggregate({ where: { ...verifiedWhere, createdAt: { gte: monthStart } }, _sum: { amountCents: true }, _count: true }),
  ]);

  return ok({
    items,
    total,
    page,
    pageSize,
    summary: {
      verifiedTotalCents: verifiedAgg._sum.amountCents || 0,
      verifiedCount: verifiedAgg._count,
      todayTotalCents: todayAgg._sum.amountCents || 0,
      todayCount: todayAgg._count,
      monthTotalCents: monthAgg._sum.amountCents || 0,
      monthCount: monthAgg._count,
      pendingCount,
      failedCount,
      canceledCount,
      rejectedCount,
      refundedCount: refundedAgg._count,
      refundedTotalCents: refundedAgg._sum.amountCents || 0,
    },
  });
}
