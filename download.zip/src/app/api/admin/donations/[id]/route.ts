import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

/**
 * Admin action on a donation. Manual verification is ONLY permitted for
 * BANK_TRANSFER donations (the site owner confirming the money arrived in
 * their bank account). Gateway donations can only become VERIFIED through
 * the provider's signed callback — an admin button can never mark a gateway
 * payment as successful.
 *
 * "refund" is a bookkeeping action for already-VERIFIED donations: it flags
 * the record REFUNDED so dashboard totals stay accurate. The actual money
 * movement is done in the payment provider's dashboard (PayHere/WebXPay
 * refund tools) — this site never moves funds itself.
 */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const { id } = await ctx.params;
  const body = await readJson<{ action?: string }>(req);
  const action = body?.action || "";

  const donation = await db.donation.findUnique({ where: { id } });
  if (!donation) return fail("Donation not found", 404);

  if (action === "verify" || action === "reject") {
    if (donation.method !== "BANK_TRANSFER") {
      return fail(
        "Only bank-transfer donations can be verified manually. Gateway payments are verified automatically by the payment provider's signed callback.",
        400
      );
    }
    if (donation.status !== "PENDING") {
      return fail(`This donation is already ${donation.status.toLowerCase()}.`, 400);
    }
    const updated = await db.donation.update({
      where: { id },
      data: {
        status: action === "verify" ? "VERIFIED" : "REJECTED",
        statusMessage:
          action === "verify"
            ? "Bank transfer confirmed by the site owner"
            : "Bank transfer rejected by the site owner",
      },
    });
    return ok({ donation: { id: updated.id, status: updated.status } });
  }

  if (action === "refund") {
    if (donation.status !== "VERIFIED") {
      return fail("Only verified donations can be marked as refunded.", 400);
    }
    const updated = await db.donation.update({
      where: { id },
      data: {
        status: "REFUNDED",
        statusMessage: "Refund recorded by the site owner — processed in the payment provider dashboard",
      },
    });
    return ok({ donation: { id: updated.id, status: updated.status } });
  }

  return fail("Unknown action");
}
