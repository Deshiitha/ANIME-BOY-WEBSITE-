import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  const body = await readJson<{ status?: string }>(req);
  const status = body?.status;
  if (!status || !["PENDING", "APPROVED", "REJECTED"].includes(status))
    return fail("Invalid request status");
  try {
    const item = await db.animeRequest.update({ where: { id }, data: { status } });
    return ok({ request: item });
  } catch {
    return fail("Request not found", 404);
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  try {
    await db.animeRequest.delete({ where: { id } });
    return ok({ success: true });
  } catch {
    return fail("Request not found", 404);
  }
}
