import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const where = status ? { status } : {};
  const items = await db.animeRequest.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { user: { select: { email: true, name: true } } },
  });
  return ok({ items });
}
