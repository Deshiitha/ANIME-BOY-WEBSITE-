import { db } from "@/lib/db";
import { ok, fail, readJson, publicEpisode } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import {
  isS3ObjectUrl,
  validateDirectMediaUrl,
  validateEmbedUrl,
  validateSubtitleUrl,
  normalizeSelfFileUrl,
} from "@/lib/media-validate";
import {
  downloadConfigErrors,
  normalizeAltSourceList,
  normalizeDownloadQualityList,
  normalizeSubtitleDownloadList,
} from "@/lib/media-source";
import type { AltSource, QualityTrack, SubtitleTrack, VideoSourceKind } from "@/lib/media-types";

type EpisodeBody = {
  seasonId?: string;
  number?: number | string;
  title?: string;
  videoUrl?: string;
  videoSource?: string;
  embedUrl?: string;
  videoQualities?: QualityTrack[];
  subtitleTracks?: SubtitleTrack[];
  altSources?: AltSource[];
  subtitleUrl?: string;
  thumbnailUrl?: string;
  durationSec?: number | string;
  description?: string;
  downloadEnabled?: boolean;
  downloadUrl?: string;
  downloadQualities?: QualityTrack[];
  subtitleDownloadEnabled?: boolean;
  subtitleDownloads?: SubtitleTrack[];
};

const SOURCE_TYPES: VideoSourceKind[] = ["upload", "external", "embed"];

function normalizeSource(kind: unknown): VideoSourceKind {
  return SOURCE_TYPES.includes(kind as VideoSourceKind) ? (kind as VideoSourceKind) : "upload";
}

function validateSource(body: EpisodeBody, videoSource: VideoSourceKind): string | null {
  if (videoSource === "embed") {
    const parsed = validateEmbedUrl((body.embedUrl || "").trim());
    if ("error" in parsed) return parsed.error;
    return null;
  }
  if (videoSource === "external") {
    const raw = (body.videoUrl || "").trim();
    if (!raw) return "A video URL is required for the External URL source.";
    const problem = validateDirectMediaUrl(raw);
    if (problem?.startsWith("share:")) return problem.slice("share:".length);
    if (problem && !problem.startsWith("warn:")) return `Video URL: ${problem}`;
    return null;
  }
  return null;
}

function normalizeQualityList(
  input: QualityTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: QualityTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateDirectMediaUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Quality "${row?.label || "?"}": ${problem}` };
    if (isS3ObjectUrl(url))
      return { value: null, error: `Quality "${row?.label || "?"}": s3:// keys cannot be used as a quality variant.` };
    clean.push({ label: (row?.label || "").trim() || "Auto", url });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

function normalizeSubtitleList(
  input: SubtitleTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: SubtitleTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateSubtitleUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Subtitle "${row?.label || "?"}": ${problem}` };
    clean.push({
      label: (row?.label || "").trim() || "Subtitles",
      lang: (row?.lang || "si").trim() || "si",
      url,
      // preserve the admin availability switch (absent = enabled)
      ...(row?.enabled === false ? { enabled: false } : {}),
    });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

function parseEpisodeFields(body: EpisodeBody) {
  const videoSource = normalizeSource(body.videoSource);
  const sourceError = validateSource(body, videoSource);
  const qualities = normalizeQualityList(body.videoQualities);
  const subtitles = normalizeSubtitleList(body.subtitleTracks);
  const altSources = normalizeAltSourceList(body.altSources);

  let embedUrl: string | null = null;
  let videoProvider: string | null = null;
  if (videoSource === "embed") {
    const parsed = validateEmbedUrl((body.embedUrl || "").trim());
    if (!("error" in parsed)) {
      embedUrl = parsed.embedUrl;
      videoProvider = parsed.provider;
    }
  }

  const downloadEnabled = !!body.downloadEnabled;
  const downloadUrl = normalizeSelfFileUrl((body.downloadUrl || "").trim());
  const downloadQualities = normalizeDownloadQualityList(body.downloadQualities);
  const subtitleDownloadEnabled = !!body.subtitleDownloadEnabled;
  const subtitleDownloads = normalizeSubtitleDownloadList(body.subtitleDownloads);
  const downloadErrors = downloadConfigErrors(
    {
      downloadEnabled,
      downloadUrl: downloadUrl || null,
      downloadQualities: downloadQualities.value,
      subtitleDownloadEnabled,
      subtitleDownloads: subtitleDownloads.value,
    },
    { downloadUrl }
  );

  return {
    videoSource,
    sourceError,
    qualitiesError: qualities.error,
    subtitlesError: subtitles.error,
    altSourcesError: altSources.error,
    downloadErrors,
    data: {
      videoSource,
      videoUrl: (body.videoUrl || "").trim() || null,
      embedUrl,
      videoProvider,
      videoQualities: qualities.value,
      subtitleTracks: subtitles.value,
      altSources: altSources.value,
      subtitleUrl: (body.subtitleUrl || "").trim() || null,
      thumbnailUrl: (body.thumbnailUrl || "").trim() || null,
      downloadEnabled,
      downloadUrl: downloadUrl || null,
      downloadQualities: downloadQualities.value,
      subtitleDownloadEnabled,
      subtitleDownloads: subtitleDownloads.value,
    },
  };
}

export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const body = await readJson<EpisodeBody>(req);
  if (!body) return fail("Invalid request body");

  const seasonId = body.seasonId;
  const number = Math.floor(Number(body.number));
  if (!seasonId) return fail("seasonId is required");
  if (!number || number < 1) return fail("A valid episode number is required");

  const parsed = parseEpisodeFields(body);
  const firstError =
    parsed.sourceError ||
    parsed.qualitiesError ||
    parsed.subtitlesError ||
    parsed.altSourcesError ||
    parsed.downloadErrors[0];
  if (firstError) return fail(firstError);

  const season = await db.season.findUnique({ where: { id: seasonId } });
  if (!season) return fail("Season not found", 404);

  const clash = await db.episode.findUnique({
    where: { seasonId_number: { seasonId: season.id, number } },
  });
  if (clash) return fail(`Episode ${number} already exists in this season`, 409);

  const episode = await db.episode.create({
    data: {
      seasonId,
      number,
      title: (body.title || "").trim() || null,
      durationSec: body.durationSec ? Number(body.durationSec) : null,
      description: (body.description || "").trim() || null,
      ...parsed.data,
    },
  });
  return ok({ episode: publicEpisode(episode) }, 201);
}
