import { db } from "@/lib/db";
import { ok, fail, readJson, publicEpisode } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import {
  isS3ObjectUrl,
  validateDirectMediaUrl,
  validateEmbedUrl,
  validateSubtitleUrl,
  normalizeSelfFileUrl,
} from "@/lib/media-validate";
import {
  downloadConfigErrors,
  normalizeAltSourceList,
  normalizeDownloadQualityList,
  normalizeSubtitleDownloadList,
} from "@/lib/media-source";
import type { AltSource, QualityTrack, SubtitleTrack, VideoSourceKind } from "@/lib/media-types";

const SOURCE_TYPES: VideoSourceKind[] = ["upload", "external", "embed"];

type PatchBody = {
  number?: number | string;
  seasonId?: string;
  title?: string;
  videoUrl?: string;
  videoSource?: string;
  embedUrl?: string;
  videoQualities?: QualityTrack[];
  subtitleTracks?: SubtitleTrack[];
  altSources?: AltSource[];
  subtitleUrl?: string;
  thumbnailUrl?: string;
  durationSec?: number | string;
  description?: string;
  downloadEnabled?: boolean;
  downloadUrl?: string;
  downloadQualities?: QualityTrack[];
  subtitleDownloadEnabled?: boolean;
  subtitleDownloads?: SubtitleTrack[];
};

function normalizeQualityList(
  input: QualityTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: QualityTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateDirectMediaUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Quality "${row?.label || "?"}": ${problem}` };
    if (isS3ObjectUrl(url))
      return { value: null, error: `Quality "${row?.label || "?"}": s3:// keys cannot be used as a quality variant.` };
    clean.push({ label: (row?.label || "").trim() || "Auto", url });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

function normalizeSubtitleList(
  input: SubtitleTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: SubtitleTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateSubtitleUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Subtitle "${row?.label || "?"}": ${problem}` };
    clean.push({
      label: (row?.label || "").trim() || "Subtitles",
      lang: (row?.lang || "si").trim() || "si",
      url,
      // preserve the admin availability switch (absent = enabled)
      ...(row?.enabled === false ? { enabled: false } : {}),
    });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  const body = await readJson<PatchBody>(req);
  if (!body) return fail("Invalid request body");

  const data: Record<string, unknown> = {};

  /* ------------------- season move + episode renumber ------------------- */
  // Numbers are unique per season (`seasonId, number`), so a renumber onto a
  // taken slot inside the SAME season swaps the two episodes (reordering).
  // Moving to a DIFFERENT season of the same series is allowed; a number
  // collision in the target season is rejected with a clear 409 instead.
  if (body.number !== undefined || body.seasonId !== undefined) {
    const current = await db.episode.findUnique({ where: { id } });
    if (!current) return fail("Episode not found", 404);

    const targetNumber = body.number !== undefined ? Math.floor(Number(body.number)) : current.number;
    if (!targetNumber || targetNumber < 1) return fail("Invalid episode number");

    const movingSeason = body.seasonId !== undefined && String(body.seasonId) !== current.seasonId;
    if (movingSeason) {
      const targetSeason = await db.season.findUnique({ where: { id: String(body.seasonId) } });
      if (!targetSeason) return fail("Season not found", 404);
      const currentSeason = await db.season.findUnique({ where: { id: current.seasonId } });
      if (!currentSeason || currentSeason.animeId !== targetSeason.animeId)
        return fail("An episode can only be moved between seasons of the same series");
      data.seasonId = targetSeason.id;
    }

    if (targetNumber !== current.number || movingSeason) {
      const clash = await db.episode.findUnique({
        where: {
          seasonId_number: { seasonId: (data.seasonId as string) || current.seasonId, number: targetNumber },
        },
      });
      if (clash && clash.id !== current.id) {
        if (!movingSeason) {
          // Same-season renumber onto a taken slot → swap the two episodes.
          // A temporary negative number keeps every intermediate state unique,
          // so a move can never fail with a constraint violation.
          await db.$transaction([
            db.episode.update({ where: { id: clash.id }, data: { number: -current.number } }),
            db.episode.update({ where: { id: current.id }, data: { number: targetNumber } }),
            db.episode.update({ where: { id: clash.id }, data: { number: current.number } }),
          ]);
        } else {
          return fail(`Episode ${targetNumber} already exists in the target season`, 409);
        }
      } else {
        data.number = targetNumber;
      }
    }
  }
  if (body.title !== undefined) data.title = (body.title || "").trim() || null;

  /* ------------------------- video source fields ------------------------ */
  if (body.videoSource !== undefined) {
    const src = SOURCE_TYPES.includes(body.videoSource as VideoSourceKind)
      ? body.videoSource
      : "upload";
    data.videoSource = src;
    if (src === "embed") {
      const parsed = validateEmbedUrl((body.embedUrl || "").trim());
      if ("error" in parsed) return fail(parsed.error);
      data.embedUrl = parsed.embedUrl;
      data.videoProvider = parsed.provider;
    } else if (src === "external") {
      const raw = (body.videoUrl || "").trim();
      if (!raw) return fail("A video URL is required for the External URL source.");
      const problem = validateDirectMediaUrl(raw);
      if (problem?.startsWith("share:")) return fail(problem.slice("share:".length));
      if (problem && !problem.startsWith("warn:")) return fail(`Video URL: ${problem}`);
    }
  }
  if (body.embedUrl !== undefined && data.videoSource !== "embed") {
    const raw = (body.embedUrl || "").trim();
    if (!raw) {
      // Empty embed URL alongside a non-embed source — just clear it.
      data.embedUrl = null;
      if (!data.videoProvider) data.videoProvider = null;
    } else {
      const parsed = validateEmbedUrl(raw);
      if ("error" in parsed) return fail(parsed.error);
      data.embedUrl = parsed.embedUrl;
      data.videoProvider = parsed.provider;
      if (!data.videoSource) data.videoSource = "embed";
    }
  }
  if (body.videoUrl !== undefined) data.videoUrl = (body.videoUrl || "").trim() || null;
  if (body.videoQualities !== undefined) {
    const q = normalizeQualityList(body.videoQualities);
    if (q.error) return fail(q.error);
    data.videoQualities = q.value;
  }
  if (body.subtitleTracks !== undefined) {
    const s = normalizeSubtitleList(body.subtitleTracks);
    if (s.error) return fail(s.error);
    data.subtitleTracks = s.value;
  }
  if (body.altSources !== undefined) {
    const alt = normalizeAltSourceList(body.altSources);
    if (alt.error) return fail(alt.error);
    data.altSources = alt.value;
  }
  if (body.subtitleUrl !== undefined) data.subtitleUrl = (body.subtitleUrl || "").trim() || null;
  if (body.thumbnailUrl !== undefined) data.thumbnailUrl = (body.thumbnailUrl || "").trim() || null;

  /* ------------------------------ downloads ------------------------------ */
  if (
    "downloadEnabled" in body ||
    "downloadUrl" in body ||
    "downloadQualities" in body ||
    "subtitleDownloadEnabled" in body ||
    "subtitleDownloads" in body
  ) {
    if (body.downloadEnabled !== undefined) data.downloadEnabled = !!body.downloadEnabled;
    if (body.subtitleDownloadEnabled !== undefined)
      data.subtitleDownloadEnabled = !!body.subtitleDownloadEnabled;
    if (body.downloadUrl !== undefined) data.downloadUrl = normalizeSelfFileUrl((body.downloadUrl || "").trim()) || null;
    if (body.downloadQualities !== undefined) {
      const dq = normalizeDownloadQualityList(body.downloadQualities);
      if (dq.error) return fail(dq.error);
      data.downloadQualities = dq.value;
    }
    if (body.subtitleDownloads !== undefined) {
      const sd = normalizeSubtitleDownloadList(body.subtitleDownloads);
      if (sd.error) return fail(sd.error);
      data.subtitleDownloads = sd.value;
    }

    // Consistency check against the resulting config (existing row + patch).
    // NOTE: `"key" in body` (not ??) — an explicit null must not fall back to the old value.
    const current = await db.episode.findUnique({ where: { id } });
    if (current) {
      const merged = {
        downloadEnabled:
          "downloadEnabled" in body ? !!body.downloadEnabled : current.downloadEnabled,
        downloadUrl:
          "downloadUrl" in body
            ? normalizeSelfFileUrl(String(body.downloadUrl || "").trim()) || null
            : current.downloadUrl,
        downloadQualities:
          "downloadQualities" in body
            ? (data.downloadQualities as string | null)
            : current.downloadQualities,
        subtitleDownloadEnabled:
          "subtitleDownloadEnabled" in body
            ? !!body.subtitleDownloadEnabled
            : current.subtitleDownloadEnabled,
        subtitleDownloads:
          "subtitleDownloads" in body
            ? (data.subtitleDownloads as string | null)
            : current.subtitleDownloads,
      };
      const dlErrors = downloadConfigErrors(merged, {
        downloadUrl: body.downloadUrl !== undefined ? String(body.downloadUrl || "") : undefined,
      });
      if (dlErrors.length) return fail(dlErrors[0]);
    }
  }

  if (body.durationSec !== undefined)
    data.durationSec = body.durationSec ? Number(body.durationSec) : null;
  if (body.description !== undefined) data.description = (body.description || "").trim() || null;

  try {
    const episode = await db.episode.update({ where: { id }, data });
    return ok({ episode: publicEpisode(episode) });
  } catch {
    return fail("Episode not found", 404);
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  try {
    await db.episode.delete({ where: { id } });
    return ok({ success: true });
  } catch {
    return fail("Episode not found", 404);
  }
}
