import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

/**
 * Update a season's number and/or title.
 *
 * Reordering seasons means changing season numbers, and numbers are unique per
 * series — so when the target number is already taken by another season of the
 * same series the two seasons SWAP numbers inside a transaction. A temporary
 * negative number keeps every intermediate state unique, so the move can never
 * fail with a constraint violation and no season is ever lost.
 */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  const body = await readJson<{ title?: string; number?: number | string }>(req);
  if (!body) return fail("Invalid request body");

  const season = await db.season.findUnique({ where: { id } });
  if (!season) return fail("Season not found", 404);

  try {
    if (body.number !== undefined) {
      const target = Math.floor(Number(body.number));
      if (!target || target < 1) return fail("Season number must be 1 or higher");
      if (target !== season.number) {
        const clash = await db.season.findUnique({
          where: { animeId_number: { animeId: season.animeId, number: target } },
        });
        if (clash && clash.id !== season.id) {
          // Swap positions: clash steps aside to a temporary negative number
          // (unique, since real season numbers are always positive), this
          // season takes the freed number, then the clash takes the old one.
          await db.$transaction([
            db.season.update({ where: { id: clash.id }, data: { number: -season.number } }),
            db.season.update({ where: { id: season.id }, data: { number: target } }),
            db.season.update({ where: { id: clash.id }, data: { number: season.number } }),
          ]);
        } else {
          await db.season.update({ where: { id: season.id }, data: { number: target } });
        }
      }
    }

    const updated = await db.season.update({
      where: { id },
      data: {
        title: body.title !== undefined ? (body.title || "").trim() || null : undefined,
      },
      include: { episodes: { orderBy: { number: "asc" } } },
    });
    return ok({ season: updated });
  } catch {
    return fail("Could not update the season", 400);
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  try {
    await db.season.delete({ where: { id } });
    return ok({ success: true });
  } catch {
    return fail("Season not found", 404);
  }
}
