import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const body = await readJson<{ animeId?: string; number?: number | string; title?: string }>(req);
  const animeId = body?.animeId;
  if (!animeId) return fail("animeId is required");

  const anime = await db.anime.findUnique({ where: { id: animeId } });
  if (!anime) return fail("Anime not found", 404);
  if (anime.type !== "SERIES") return fail("Seasons can only be added to series");

  // Season number is OPTIONAL for playlist uploads — custom-named seasons
  // ("Final Season", "Special Season"…) may omit it. When omitted, the next
  // free number is assigned automatically so ordering, watch URLs (?s=) and
  // the per-series unique constraint keep working unchanged.
  let number = Number(body?.number);
  if (!number || number < 1) {
    const last = await db.season.findFirst({
      where: { animeId },
      orderBy: { number: "desc" },
      select: { number: true },
    });
    number = (last?.number ?? 0) + 1;
  }

  const existing = await db.season.findUnique({ where: { animeId_number: { animeId, number } } });
  if (existing) return fail(`Season ${number} already exists`, 409);

  // A plain "Season N" name that matches the resolved number carries no extra
  // information — store it as the absence of a custom name so the UI shows a
  // single clean "Season N" label instead of "Season N — Season N". Genuine
  // custom names ("Final Season", "Special Season"…) are kept as-is.
  const rawTitle = (body?.title || "").trim();
  const plainMatch = /^season\s*(\d+)$/i.exec(rawTitle);
  const title = plainMatch && Number(plainMatch[1]) === number ? null : rawTitle || null;

  const season = await db.season.create({
    data: { animeId, number, title },
    include: { episodes: true },
  });
  return ok({ season }, 201);
}
