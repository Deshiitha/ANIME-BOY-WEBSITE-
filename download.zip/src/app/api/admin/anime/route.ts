import { db } from "@/lib/db";
import { ok, fail, readJson, slugify, publicAnime } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import {
  isS3ObjectUrl,
  validateDirectMediaUrl,
  validateEmbedUrl,
  validateSubtitleUrl,
  normalizeSelfFileUrl,
} from "@/lib/media-validate";
import {
  downloadConfigErrors,
  normalizeAltSourceList,
  normalizeDownloadQualityList,
  normalizeSubtitleDownloadList,
} from "@/lib/media-source";
import type { AltSource, QualityTrack, SubtitleTrack, VideoSourceKind } from "@/lib/media-types";

type AnimeBody = {
  titleEn?: string;
  titleSi?: string;
  descriptionSi?: string;
  descriptionEn?: string;
  genres?: string[] | string;
  releaseYear?: number | string;
  rating?: number | string;
  languageLabel?: string;
  availability?: string;
  status?: string;
  type?: string;
  category?: string;
  seasonNumber?: number | string;
  episodeNumber?: number | string;
  posterUrl?: string;
  backdropUrl?: string;
  videoUrl?: string;
  videoSource?: string;
  embedUrl?: string;
  videoQualities?: QualityTrack[];
  subtitleTracks?: SubtitleTrack[];
  altSources?: AltSource[];
  videoThumb?: string;
  subtitleUrl?: string;
  downloadEnabled?: boolean;
  downloadUrl?: string;
  downloadQualities?: QualityTrack[];
  subtitleDownloadEnabled?: boolean;
  subtitleDownloads?: SubtitleTrack[];
  featured?: boolean;
  featuredOrder?: number | string;
  homeRank?: number | string;
  published?: boolean;
};

const SOURCE_TYPES: VideoSourceKind[] = ["upload", "external", "embed"];

function normalizeSource(kind: unknown): VideoSourceKind {
  return SOURCE_TYPES.includes(kind as VideoSourceKind) ? (kind as VideoSourceKind) : "upload";
}

/**
 * Optional positive-integer fields (Others category season/episode labels).
 * Empty / null / missing → null. Anything else must be a whole number ≥ 1.
 */
function parseOptionalPositiveInt(input: unknown): { value: number | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const raw = String(input).trim();
  if (!/^\d+$/.test(raw) || Number(raw) < 1)
    return { value: null, error: "must be a positive whole number (1, 2, 3, 4, 5 …) or left empty" };
  return { value: Number(raw), error: null };
}

/** Validate + canonicalise the optional per-quality / per-language lists. */
function normalizeQualityList(
  input: QualityTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: QualityTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateDirectMediaUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Quality "${row?.label || "?"}": ${problem}` };
    if (isS3ObjectUrl(url))
      return { value: null, error: `Quality "${row?.label || "?"}": s3:// keys cannot be used as a quality variant.` };
    clean.push({ label: (row?.label || "").trim() || "Auto", url });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

function normalizeSubtitleList(
  input: SubtitleTrack[] | string | undefined
): { value: string | null; error: string | null } {
  if (input == null || input === "") return { value: null, error: null };
  const rows = Array.isArray(input) ? input : [];
  const clean: SubtitleTrack[] = [];
  for (const row of rows) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateSubtitleUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Subtitle "${row?.label || "?"}": ${problem}` };
    clean.push({
      label: (row?.label || "").trim() || "Subtitles",
      lang: (row?.lang || "si").trim() || "si",
      url,
      // preserve the admin availability switch (absent = enabled)
      ...(row?.enabled === false ? { enabled: false } : {}),
    });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

export function normalizeAnimeInput(body: AnimeBody) {
  const errors: string[] = [];
  const titleEn = (body.titleEn || "").trim();
  const type = body.type === "SERIES" ? "SERIES" : "MOVIE";
  // Three content categories: ANIME, DONGHUA and the flexible OTHERS bucket.
  const category = ["ANIME", "DONGHUA", "OTHERS"].includes(body.category || "")
    ? (body.category as string)
    : "ANIME";

  // Optional season/episode labels (used by the Others category; ignored elsewhere).
  const seasonNumber = parseOptionalPositiveInt(body.seasonNumber);
  if (seasonNumber.error) errors.push(`Season number ${seasonNumber.error}`);
  const episodeNumber = parseOptionalPositiveInt(body.episodeNumber);
  if (episodeNumber.error) errors.push(`Episode number ${episodeNumber.error}`);
  const status = body.status === "UPCOMING" ? "UPCOMING" : "RELEASED";
  const languageLabel = ["SINHALA_DUBBED", "SINHALA_SUB", "ANIME_REVIEW"].includes(
    body.languageLabel || ""
  )
    ? body.languageLabel!
    : "SINHALA_DUBBED";
  const genres = Array.isArray(body.genres)
    ? body.genres.join(",")
    : (body.genres || "")
        .split(",")
        .map((g) => g.trim())
        .filter(Boolean)
        .join(",");

  if (titleEn.length < 1) errors.push("English title is required");
  if (body.releaseYear && (isNaN(Number(body.releaseYear)) || Number(body.releaseYear) < 1900))
    errors.push("Release year looks invalid");
  if (body.rating && (isNaN(Number(body.rating)) || Number(body.rating) < 0 || Number(body.rating) > 10))
    errors.push("Rating must be between 0 and 10");

  /* ---------------------------- video source ---------------------------- */
  const videoSource = normalizeSource(body.videoSource);
  const rawVideoUrl = (body.videoUrl || "").trim();
  let embedUrl: string | null = null;
  let videoProvider: string | null = null;

  if (videoSource === "embed") {
    const parsed = validateEmbedUrl((body.embedUrl || "").trim());
    if ("error" in parsed) errors.push(parsed.error);
    else {
      embedUrl = parsed.embedUrl;
      videoProvider = parsed.provider;
    }
  } else if (videoSource === "external" && rawVideoUrl) {
    const problem = validateDirectMediaUrl(rawVideoUrl);
    if (problem && !problem.startsWith("warn:") && !problem.startsWith("share:"))
      errors.push(`Video URL: ${problem}`);
    else if (problem?.startsWith("share:")) errors.push(problem.slice("share:".length));
  }

  const qualities = normalizeQualityList(body.videoQualities);
  if (qualities.error) errors.push(qualities.error);
  const subtitles = normalizeSubtitleList(body.subtitleTracks);
  if (subtitles.error) errors.push(subtitles.error);
  const altSources = normalizeAltSourceList(body.altSources);
  if (altSources.error) errors.push(altSources.error);

  /* ------------------------------ downloads ------------------------------ */
  const downloadEnabled = !!body.downloadEnabled;
  const downloadUrl = normalizeSelfFileUrl((body.downloadUrl || "").trim());
  const downloadQualities = normalizeDownloadQualityList(body.downloadQualities);
  if (downloadQualities.error) errors.push(downloadQualities.error);
  const subtitleDownloadEnabled = !!body.subtitleDownloadEnabled;
  const subtitleDownloads = normalizeSubtitleDownloadList(body.subtitleDownloads);
  if (subtitleDownloads.error) errors.push(subtitleDownloads.error);
  errors.push(
    ...downloadConfigErrors(
      {
        downloadEnabled,
        downloadUrl: downloadUrl || null,
        downloadQualities: downloadQualities.value,
        subtitleDownloadEnabled,
        subtitleDownloads: subtitleDownloads.value,
      },
      { downloadUrl }
    )
  );

  return {
    errors,
    data: {
      titleEn,
      titleSi: (body.titleSi || "").trim() || null,
      descriptionSi: (body.descriptionSi || "").trim() || null,
      descriptionEn: (body.descriptionEn || "").trim() || null,
      genres,
      releaseYear: body.releaseYear ? Number(body.releaseYear) : null,
      rating: body.rating !== "" && body.rating != null ? Number(body.rating) : null,
      languageLabel,
      availability: (body.availability || "").trim() || null,
      status,
      type,
      category,
      seasonNumber: seasonNumber.value,
      episodeNumber: episodeNumber.value,
      posterUrl: (body.posterUrl || "").trim() || null,
      backdropUrl: (body.backdropUrl || "").trim() || null,
      videoUrl: rawVideoUrl || null,
      videoSource,
      embedUrl,
      videoProvider,
      videoQualities: qualities.value,
      subtitleTracks: subtitles.value,
      altSources: altSources.value,
      videoThumb: (body.videoThumb || "").trim() || null,
      subtitleUrl: (body.subtitleUrl || "").trim() || null,
      downloadEnabled,
      downloadUrl: downloadUrl || null,
      downloadQualities: downloadQualities.value,
      subtitleDownloadEnabled,
      subtitleDownloads: subtitleDownloads.value,
      featured: !!body.featured,
      featuredOrder: Number(body.featuredOrder) || 0,
      homeRank: Number(body.homeRank) || 0,
      published: body.published !== false,
    },
  };
}

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const url = new URL(req.url);
  const q = (url.searchParams.get("q") || "").trim();
  const category = url.searchParams.get("category"); // ANIME | DONGHUA | OTHERS
  const type = url.searchParams.get("type"); // MOVIE | SERIES
  const where: Record<string, unknown> = {};
  if (q) {
    where.OR = [{ titleEn: { contains: q } }, { titleSi: { contains: q } }];
  }
  if (category === "ANIME" || category === "DONGHUA" || category === "OTHERS") where.category = category;
  if (type === "MOVIE" || type === "SERIES") where.type = type;
  const rows = await db.anime.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { seasons: { include: { episodes: true } } },
  });
  return ok({ items: rows.map((r) => ({ ...publicAnime(r), seasonCount: r.seasons.length })) });
}

export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const body = await readJson<AnimeBody>(req);
  if (!body) return fail("Invalid request body");
  const { data, errors } = normalizeAnimeInput(body);
  if (errors.length) return fail(errors.map((e) => e.replace(/\.+$/, "")).join(". "));

  let slug = slugify(data.titleEn);
  const clash = await db.anime.findUnique({ where: { slug } });
  if (clash) slug = `${slug}-${Date.now().toString(36).slice(-4)}`;

  const anime = await db.anime.create({ data: { ...data, slug } });
  return ok({ anime: publicAnime(anime) }, 201);
}
