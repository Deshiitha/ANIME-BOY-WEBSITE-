import { db } from "@/lib/db";
import { ok, fail, readJson, publicAnime } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { normalizeAnimeInput } from "../route";
import {
  isS3ObjectUrl,
  validateDirectMediaUrl,
  validateEmbedUrl,
  validateSubtitleUrl,
  normalizeSelfFileUrl,
} from "@/lib/media-validate";
import {
  downloadConfigErrors,
  normalizeAltSourceList,
  normalizeDownloadQualityList,
  normalizeSubtitleDownloadList,
} from "@/lib/media-source";
import type { AltSource, QualityTrack, SubtitleTrack } from "@/lib/media-types";

/** Fields that may be updated alone (video-source replacement without the full form). */
const SOURCE_FIELDS = [
  "videoSource",
  "videoUrl",
  "embedUrl",
  "videoQualities",
  "subtitleTracks",
  "altSources",
  "videoThumb",
  "videoKey",
  "subtitleUrl",
  "downloadEnabled",
  "downloadUrl",
  "downloadQualities",
  "subtitleDownloadEnabled",
  "subtitleDownloads",
];

function normalizeQualityList(rows: QualityTrack[] | string | undefined) {
  if (rows == null || rows === "") return { value: null as string | null, error: null as string | null };
  const clean: QualityTrack[] = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateDirectMediaUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Quality "${row?.label || "?"}": ${problem}` };
    if (isS3ObjectUrl(url))
      return { value: null, error: `Quality "${row?.label || "?"}": s3:// keys cannot be used as a quality variant.` };
    clean.push({ label: (row?.label || "").trim() || "Auto", url });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

function normalizeSubtitleList(rows: SubtitleTrack[] | string | undefined) {
  if (rows == null || rows === "") return { value: null as string | null, error: null as string | null };
  const clean: SubtitleTrack[] = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const url = normalizeSelfFileUrl((row?.url || "").trim());
    if (!url) continue;
    const problem = validateSubtitleUrl(url);
    if (problem && !problem.startsWith("warn:"))
      return { value: null, error: `Subtitle "${row?.label || "?"}": ${problem}` };
    clean.push({
      label: (row?.label || "").trim() || "Subtitles",
      lang: (row?.lang || "si").trim() || "si",
      url,
      // preserve the admin availability switch (absent = enabled)
      ...(row?.enabled === false ? { enabled: false } : {}),
    });
  }
  return { value: clean.length ? JSON.stringify(clean) : null, error: null };
}

/**
 * Video-source-only update: add / edit / replace the video of an existing
 * entry without touching (or re-sending) any of the other fields.
 */
async function normalizeSourcePatch(body: Record<string, unknown>, id: string) {
  const data: Record<string, unknown> = {};
  const errors: string[] = [];

  // Only normalise the playback source when the patch actually mentions it —
  // a download-only patch must never reset the existing video.
  const touchesPlayback = ["videoSource", "videoUrl", "embedUrl"].some((k) => k in body);
  if (touchesPlayback) {
    const src = String(body.videoSource || "upload").toLowerCase();
    data.videoSource = ["upload", "external", "embed"].includes(src) ? src : "upload";

    if (data.videoSource === "embed") {
      const parsed = validateEmbedUrl(String(body.embedUrl || "").trim());
      if ("error" in parsed) errors.push(parsed.error);
      else {
        data.embedUrl = parsed.embedUrl;
        data.videoProvider = parsed.provider;
        data.videoUrl = null;
      }
    } else {
      const raw = String(body.videoUrl || "").trim();
      // Only external URLs are validated as public HTTPS media. Upload sources
      // use site-served paths (/api/files/…) or previously stored absolute URLs.
      if (data.videoSource === "external" && "videoUrl" in body && raw) {
        const problem = validateDirectMediaUrl(raw);
        if (problem?.startsWith("share:")) errors.push(problem.slice("share:".length));
        else if (problem && !problem.startsWith("warn:")) errors.push(`Video URL: ${problem}`);
      }
      data.videoUrl = raw || null;
      data.embedUrl = null;
      data.videoProvider = null;
    }

    if (data.videoSource === "external" && !data.videoUrl) {
      errors.push("A video URL is required for the External URL source.");
    }
  }

  if (body.videoQualities !== undefined) {
    const q = normalizeQualityList(body.videoQualities as QualityTrack[] | undefined);
    if (q.error) errors.push(q.error);
    else data.videoQualities = q.value;
  }

  if (body.subtitleTracks !== undefined) {
    const s = normalizeSubtitleList(body.subtitleTracks as SubtitleTrack[] | undefined);
    if (s.error) errors.push(s.error);
    else data.subtitleTracks = s.value;
  }

  if (body.altSources !== undefined) {
    const alt = normalizeAltSourceList(body.altSources as AltSource[] | undefined);
    if (alt.error) errors.push(alt.error);
    else data.altSources = alt.value;
  }

  if ("videoThumb" in body) data.videoThumb = String(body.videoThumb || "").trim() || null;
  if ("videoKey" in body) data.videoKey = String(body.videoKey || "").trim() || null;
  if ("subtitleUrl" in body) data.subtitleUrl = String(body.subtitleUrl || "").trim() || null;

  /* ------------------------------ downloads ------------------------------ */
  if (
    "downloadEnabled" in body ||
    "downloadUrl" in body ||
    "downloadQualities" in body ||
    "subtitleDownloadEnabled" in body ||
    "subtitleDownloads" in body
  ) {
    const downloadEnabled = body.downloadEnabled !== undefined ? !!body.downloadEnabled : undefined;
    const downloadUrl = body.downloadUrl !== undefined ? normalizeSelfFileUrl(String(body.downloadUrl || "").trim()) : undefined;
    const dq = normalizeDownloadQualityList(body.downloadQualities as QualityTrack[] | undefined);
    if (dq.error) errors.push(dq.error);
    else if (body.downloadQualities !== undefined) data.downloadQualities = dq.value;
    const sd = normalizeSubtitleDownloadList(body.subtitleDownloads as SubtitleTrack[] | undefined);
    if (sd.error) errors.push(sd.error);
    else if (body.subtitleDownloads !== undefined) data.subtitleDownloads = sd.value;
    if (downloadEnabled !== undefined) data.downloadEnabled = downloadEnabled;
    if (body.subtitleDownloadEnabled !== undefined) data.subtitleDownloadEnabled = !!body.subtitleDownloadEnabled;
    if (downloadUrl !== undefined) data.downloadUrl = downloadUrl || null;

    // Consistency check against the full resulting config (existing row + patch).
    // NOTE: `"key" in body` (not ??) — an explicit null must not fall back to the old value.
    const current = await db.anime.findUnique({ where: { id } });
    if (current) {
      const merged = {
        downloadEnabled:
          "downloadEnabled" in body ? !!body.downloadEnabled : current.downloadEnabled,
        downloadUrl:
          "downloadUrl" in body
            ? normalizeSelfFileUrl(String(body.downloadUrl || "").trim()) || null
            : current.downloadUrl,
        downloadQualities:
          "downloadQualities" in body
            ? (data.downloadQualities as string | null)
            : current.downloadQualities,
        subtitleDownloadEnabled:
          "subtitleDownloadEnabled" in body
            ? !!body.subtitleDownloadEnabled
            : current.subtitleDownloadEnabled,
        subtitleDownloads:
          "subtitleDownloads" in body
            ? (data.subtitleDownloads as string | null)
            : current.subtitleDownloads,
      };
      errors.push(...downloadConfigErrors(merged, { downloadUrl }));
    }
  }

  return { data, errors };
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;

  const body = await readJson<Record<string, unknown>>(req);
  if (!body) return fail("Invalid request body");

  // Partial update: publish/unpublish or featured toggles may send only flags.
  const keys = Object.keys(body);
  const isFlagsOnly =
    keys.every((k) => ["published", "featured", "featuredOrder", "homeRank"].includes(k)) &&
    keys.length > 0;
  // Video-source-only update: replace the video without re-sending the form.
  const isSourceOnly =
    !isFlagsOnly && keys.length > 0 && keys.every((k) => SOURCE_FIELDS.includes(k));

  let data: Record<string, unknown>;
  if (isFlagsOnly) {
    data = {};
    if ("published" in body) data.published = !!body.published;
    if ("featured" in body) data.featured = !!body.featured;
    if ("featuredOrder" in body) data.featuredOrder = Number(body.featuredOrder) || 0;
    if ("homeRank" in body) data.homeRank = Number(body.homeRank) || 0;
  } else if (isSourceOnly) {
    const { data: d, errors } = await normalizeSourcePatch(body, id);
    if (errors.length) return fail(errors.map((e) => e.replace(/\.+$/, "")).join(". "));
    data = d;
  } else {
    const { data: d, errors } = normalizeAnimeInput(body as never);
    if (errors.length) return fail(errors.map((e) => e.replace(/\.+$/, "")).join(". "));
    data = d;
  }

  try {
    const anime = await db.anime.update({ where: { id }, data });
    return ok({ anime: publicAnime(anime) });
  } catch {
    return fail("Anime not found", 404);
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const { id } = await ctx.params;
  try {
    await db.anime.delete({ where: { id } });
    return ok({ success: true });
  } catch {
    return fail("Anime not found", 404);
  }
}
