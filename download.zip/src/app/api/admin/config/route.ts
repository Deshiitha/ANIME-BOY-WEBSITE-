import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";

const ALLOWED_KEYS = ["youtubeChannelUrl", "channelHandle"];

export async function PUT(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const body = await readJson<Record<string, string>>(req);
  if (!body) return fail("Invalid request body");

  for (const key of Object.keys(body)) {
    if (!ALLOWED_KEYS.includes(key)) return fail(`Unknown config key: ${key}`);
    const value = (body[key] || "").trim();
    if (key === "youtubeChannelUrl" && value && !/^https:\/\/(www\.)?youtube\.com\/[\w/@:=-]+$/.test(value))
      return fail("Channel URL must be a valid https://youtube.com/... link");
    await db.siteConfig.upsert({
      where: { key },
      update: { value },
      create: { key, value },
    });
  }
  return ok({ success: true });
}
