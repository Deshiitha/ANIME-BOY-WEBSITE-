import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { getSmtpConfig, maskHint, setConfigValues } from "@/lib/donation-config";

/**
 * Admin SMTP (email) settings — used by password-reset emails. The password
 * is write-only: GET reports whether it is set with a masked hint; PUT with
 * "CLEAR" removes it. Environment variables (SMTP_*) act as fallback.
 */

type SmtpBody = {
  smtpHost?: string;
  smtpPort?: string;
  smtpUser?: string;
  smtpPass?: string; // write-only; "CLEAR" removes
  smtpFrom?: string;
  smtpSecure?: boolean;
};

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const cfg = await getSmtpConfig();
  const passRow = await db.siteConfig.findUnique({ where: { key: "smtpPass" } });
  return ok({ config: { ...cfg, smtpPassHint: maskHint(passRow?.value || "") }, envConfigured: !!process.env.SMTP_HOST });
}

export async function PUT(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);
  const body = await readJson<SmtpBody>(req);
  if (!body) return fail("Invalid request body");

  const updates: Record<string, string> = {};

  if (body.smtpHost !== undefined) {
    const host = body.smtpHost.trim();
    if (host && !/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(host)) return fail("SMTP host looks invalid — e.g. smtp.gmail.com");
    updates.smtpHost = host;
  }
  if (body.smtpPort !== undefined) {
    const port = body.smtpPort.trim();
    if (port && !/^\d{1,5}$/.test(port)) return fail("SMTP port must be a number (587 or 465 are common).");
    updates.smtpPort = port;
  }
  if (body.smtpUser !== undefined) updates.smtpUser = body.smtpUser.trim().slice(0, 200);
  if (body.smtpPass !== undefined) {
    const pass = body.smtpPass;
    if (pass === "CLEAR") updates.smtpPass = "";
    else if (pass) updates.smtpPass = pass;
  }
  if (body.smtpFrom !== undefined) {
    const from = body.smtpFrom.trim();
    if (from && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(from)) return fail('Sender address must be an email like "no-reply@yourdomain.com"');
    updates.smtpFrom = from;
  }
  if (body.smtpSecure !== undefined) updates.smtpSecure = body.smtpSecure ? "true" : "false";

  await setConfigValues(updates);
  return ok({ success: true });
}
