import { fail, ok, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { createSignedPlaybackUrl, S3_SIGN_TTL_SEC } from "@/lib/media-source";
import { getS3Config } from "@/lib/storage";
import { parseS3Url } from "@/lib/media-validate";

/**
 * Admin-only helper for the "Preview Video" dialog: turns an s3://bucket/key
 * identifier into a short-lived signed URL so admins can test private-bucket
 * playback before publishing. Keys are minted on demand — never stored.
 */
export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const cfg = getS3Config();
  if (!cfg) return fail("Object storage is not configured (S3_* environment variables).", 400);

  const body = await readJson<{ url?: string; key?: string }>(req);
  const parsed = body?.url ? parseS3Url(body.url) : null;
  const key = parsed?.key || (body?.key || "").replace(/^\/+/, "");
  if (!key) return fail('Provide an s3://bucket/key URL or an object key.');

  try {
    const signed = await createSignedPlaybackUrl(parsed?.bucket || cfg.bucket, key);
    return ok({ ...signed, ttlSec: S3_SIGN_TTL_SEC });
  } catch {
    return fail("Could not generate a preview URL. Check the object storage configuration.", 500);
  }
}
