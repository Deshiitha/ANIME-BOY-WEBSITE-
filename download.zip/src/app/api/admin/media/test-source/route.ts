import { HeadObjectCommand } from "@aws-sdk/client-s3";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import {
  detectSharePage,
  extractGdriveFileId,
  isS3ObjectUrl,
  looksLikeHls,
  parseS3Url,
  safeUrl,
  validateEmbedUrl,
} from "@/lib/media-validate";
import { isTeraBoxHost } from "@/lib/media-types";
import { probeMediaUrl } from "@/lib/ssrf";
import { getS3Config } from "@/lib/storage";

/**
 * Admin "Test Video Source" — the authoritative pre-publish playback check.
 *
 * For any pasted URL (provider share/embed link, TeraBox share link, direct
 * MP4/HLS/DASH URL or private-bucket key) it reports exactly six things:
 *   Video Provider · Source Type · Playback Compatibility · Embed Support ·
 *   Error Details · Recommended Fix
 *
 * `playableInSite` is ONLY true when browser playback was actually verified
 * (official embed of a trusted provider, a probe-confirmed direct media
 * stream with range support, or a signed private-bucket object). TeraBox
 * share links are never reported as playable in-site — TeraBox offers no
 * permitted public iframe embed; the result instead confirms the honest
 * "Watch on TeraBox" fallback and verifies the admin's separate authorized
 * streaming URL when one is provided.
 *
 * No scraping, no invented streaming URLs, no provider bypasses.
 */
export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const body = await readJson<{ url?: string; directUrl?: string }>(req);
  const raw = (body?.url || "").trim();
  const directUrl = (body?.directUrl || "").trim();
  if (!raw && !directUrl) return fail("Paste a video URL first.");

  /* ------------------------- authorized direct URL ------------------------- */
  // A TeraBox entry (or any entry) may also carry an authorized direct stream;
  // when only that URL is supplied, verify it on its own.
  if (!raw) return ok(await testDirectUrl(directUrl, "Authorized streaming URL"));

  // Site uploads (/api/files/…) are served by this website itself — same-origin
  // (no CORS needed) with HTTP range support, so playback is guaranteed.
  if (raw.startsWith("/api/files/")) {
    return ok({
      ok: true,
      playableInSite: true,
      provider: "This site (upload)",
      sourceType: "Site upload — streamed by ANIME BOY",
      embedUrl: null,
      embedSupport: "—",
      compatibility: "Same-origin upload — no CORS needed, served with byte-range (seeking) support.",
      errorDetails: null,
      recommendedFix: null,
      fallbackAvailable: false,
    });
  }

  const u = safeUrl(raw);
  if (!u) return fail("That is not a valid URL.");

  const converted = validateEmbedUrl(raw);
  const isEmbedProvider = !("error" in converted);

  /* ---------------------- trusted provider embed/share ---------------------- */
  if (isEmbedProvider) {
    const { embedUrl, provider } = converted as { embedUrl: string; provider: string };

    if (provider === "terabox") {
      const probe = await probeMediaUrl(embedUrl);
      const reachable = !!probe.ok || !!probe.finalUrl;
      const base = {
        provider: "TeraBox",
        sourceType: "Share page (HTML) — not a video file",
        embedUrl,
        embedSupport: "None — TeraBox does not offer a permitted public iframe embed",
        externalFallback: embedUrl,
      };
      if (!reachable) {
        return ok({
          ok: false,
          playableInSite: false,
          ...base,
          compatibility: `Share link unreachable${probe.status ? ` (HTTP ${probe.status})` : ""}.`,
          errorDetails: probe.error || "TeraBox did not respond to the link check.",
          recommendedFix:
            "The share link may be deleted, expired or region-blocked. Re-copy the link from TeraBox, or remove this source.",
          fallbackAvailable: false,
        });
      }
      // Share page verified. In-site playback then depends on an authorized
      // streaming URL — verify it when the admin provided one.
      if (directUrl) {
        const direct = await testDirectUrl(directUrl, "Authorized streaming URL");
        return ok({
          ...direct,
          provider: "TeraBox + authorized stream",
          sourceType: direct.playableInSite
            ? `Share page + ${direct.sourceType}`
            : "Share page (HTML) — authorized stream failed verification",
          embedUrl,
          embedSupport: base.embedSupport,
          externalFallback: embedUrl,
          fallbackAvailable: true,
          recommendedFix: direct.playableInSite
            ? null
            : direct.recommendedFix ||
              "Provide an HTTPS MP4/HLS URL (or s3://bucket/key) that you are authorized to stream. TeraBox share pages themselves cannot be played in-site.",
        });
      }
      return ok({
        ok: true, // the entry itself is valid — playback happens on TeraBox
        playableInSite: false, // …but NOT inside the site player
        ...base,
        compatibility: `Share link verified and reachable${probe.status ? ` (HTTP ${probe.status})` : ""}.`,
        errorDetails: null,
        recommendedFix:
          "Visitors will see a “Watch on TeraBox” button. To play this video INSIDE ANIME BOY, add an authorized direct streaming URL (MP4/HLS you host or are licensed to stream) or another provider source — TeraBox share pages cannot be embedded.",
        fallbackAvailable: true,
      });
    }

    if (provider === "gdrive") {
      const fileId = extractGdriveFileId(raw) || extractGdriveFileId(embedUrl);
      if (!fileId) return fail("Could not extract the Google Drive file ID from that link.");
      const probe = await probeMediaUrl(
        `https://drive.google.com/uc?export=download&id=${encodeURIComponent(fileId)}`
      );
      const bouncedToSignin = !!probe.finalUrl && /accounts\.google\.com/i.test(probe.finalUrl);
      if (bouncedToSignin || probe.status === 403 || (!probe.ok && probe.status === 401)) {
        return ok({
          ok: false,
          playableInSite: false,
          provider: "Google Drive",
          sourceType: "Provider embed (iframe)",
          embedUrl,
          embedSupport: "Yes — official Google Drive /preview embed",
          compatibility: `Permission check failed${probe.status ? ` (HTTP ${probe.status})` : ""}.`,
          errorDetails: "The Drive file appears to be PRIVATE (Google bounced the check to sign-in).",
          recommendedFix:
            "In Google Drive set Sharing → “Anyone with the link” → Viewer, then test again. Private files cannot be embedded or streamed.",
          fallbackAvailable: false,
        });
      }
      const reachable = probe.ok || probe.status === 416;
      return ok({
        ok: reachable,
        playableInSite: reachable,
        provider: "Google Drive",
        sourceType: "Provider embed (iframe)",
        embedUrl,
        embedSupport: "Yes — official Google Drive /preview embed",
        compatibility: reachable
          ? "File is publicly reachable and the official /preview embed URL was generated."
          : `File could not be verified${probe.status ? ` (HTTP ${probe.status})` : ""}. ${probe.error || ""}`.trim(),
        errorDetails: reachable
          ? null
          : "Drive reported the file as unavailable (deleted, quota-limited or blocked).",
        recommendedFix: reachable
          ? null
          : "Re-upload the file or re-check sharing. Drive-only limits (download quota) can still appear on Google's side.",
        fallbackAvailable: false,
      });
    }

    // YouTube / Vimeo / Dailymotion / Streamable — official embeds.
    return ok({
      ok: true,
      playableInSite: true,
      provider: provider.charAt(0).toUpperCase() + provider.slice(1),
      sourceType: "Provider embed (iframe)",
      embedUrl,
      embedSupport: "Yes — official provider iframe embed",
      compatibility:
        "Official embed URL generated; playback runs inside the ANIME BOY player (provider controls apply).",
      errorDetails: null,
      recommendedFix: null,
      fallbackAvailable: false,
    });
  }

  /* ------------------------------ direct URLs ------------------------------ */
  const shareHint = detectSharePage(raw);
  if (shareHint?.startsWith("share:")) {
    return ok({
      ok: false,
      playableInSite: false,
      provider: u.hostname.replace(/^www\./, ""),
      sourceType: "Share page (HTML) — not a video file",
      embedUrl: null,
      embedSupport: "—",
      compatibility: "That URL serves an HTML page, not video bytes.",
      errorDetails: shareHint.slice("share:".length),
      recommendedFix:
        "Use the Provider embed tab (it converts share links automatically) or paste a direct HTTPS media URL.",
      fallbackAvailable: false,
    });
  }
  return ok(
    await testDirectUrl(
      raw,
      directUrl ? "Primary direct source" : "Direct source",
      directUrl || undefined
    )
  );
}

/**
 * Verify a direct streaming URL: probe it server-side (SSRF-safe), confirm it
 * returns media bytes with range support, and derive honest compatibility.
 */
async function testDirectUrl(rawUrl: string, role: string, _extraDirect?: string) {
  const clean = rawUrl.trim();
  const providerLabel = role.startsWith("Authorized") ? "Authorized direct stream" : "Direct file";

  // Site uploads are same-origin — always playable, nothing to probe.
  if (clean.startsWith("/api/files/")) {
    return {
      ok: true,
      playableInSite: true,
      provider: "This site (upload)",
      sourceType: "Site upload — streamed by ANIME BOY",
      embedUrl: null,
      embedSupport: "—",
      compatibility: "Same-origin upload — no CORS needed, served with byte-range (seeking) support.",
      errorDetails: null,
      recommendedFix: null,
      fallbackAvailable: false,
    };
  }

  if (isS3ObjectUrl(clean)) {
    const parsed = parseS3Url(clean);
    if (!parsed) {
      return {
        ok: false,
        playableInSite: false,
        provider: "Private S3 bucket",
        sourceType: "Private-bucket object (signed)",
        embedUrl: null,
        embedSupport: "—",
        compatibility: "Not verified.",
        errorDetails: "Use the format s3://bucket-name/path/to/video.mp4.",
        recommendedFix: "Correct the s3:// key format and test again.",
        fallbackAvailable: false,
      };
    }
    const cfg = getS3Config();
    if (!cfg) {
      return {
        ok: false,
        playableInSite: false,
        provider: "Private S3 bucket",
        sourceType: "Private-bucket object (signed)",
        embedUrl: null,
        embedSupport: "—",
        compatibility: "Not verified — storage is not configured.",
        errorDetails: "Object storage is not configured on this server (S3_* environment variables).",
        recommendedFix: "Configure the S3_* environment variables, or use a direct HTTPS URL instead.",
        fallbackAvailable: false,
      };
    }
    try {
      const { S3Client } = await import("@aws-sdk/client-s3");
      const client = new S3Client({
        endpoint: cfg.endpoint,
        region: cfg.region,
        forcePathStyle: true,
        credentials: { accessKeyId: cfg.accessKeyId, secretAccessKey: cfg.secretAccessKey },
      });
      const head = await client.send(new HeadObjectCommand({ Bucket: parsed.bucket, Key: parsed.key }));
      const type = head.ContentType || "unknown";
      const isMedia =
        type.startsWith("video/") ||
        type.startsWith("audio/") ||
        type.includes("mpegurl") ||
        type.includes("dash");
      return {
        ok: isMedia,
        playableInSite: isMedia,
        provider: "Private S3 bucket",
        sourceType: "Private-bucket object (signed playback URL)",
        embedUrl: null,
        embedSupport: "—",
        compatibility: `Object verified: ${type}${
          head.ContentLength ? ` · ${(Number(head.ContentLength) / 1024 / 1024).toFixed(1)} MB` : ""
        } · signed URL minted OK · byte-range supported by S3.`,
        errorDetails: isMedia ? null : `The object's Content-Type ("${type}") is not a video/playlist type.`,
        recommendedFix: isMedia ? null : "Re-upload the correct video file to that key.",
        fallbackAvailable: false,
      };
    } catch (e) {
      const name = e instanceof Error ? e.name : "";
      return {
        ok: false,
        playableInSite: false,
        provider: "Private S3 bucket",
        sourceType: "Private-bucket object (signed)",
        embedUrl: null,
        embedSupport: "—",
        compatibility: "Object could not be verified.",
        errorDetails:
          name === "NotFound" || name === "NoSuchKey" || name === "NoSuchBucket"
            ? "The object does not exist at that bucket/key."
            : e instanceof Error
              ? e.message
              : "HEAD request failed.",
        recommendedFix: "Check the bucket/key and the server's S3 credentials, then test again.",
        fallbackAvailable: false,
      };
    }
  }

  const isHls = looksLikeHls(clean);
  const isDash = /\.mpd(\?|$)/i.test(clean) || /format=mpd/i.test(clean);
  const probe = await probeMediaUrl(clean);
  const finalHost = probe.finalUrl ? safeUrl(probe.finalUrl)?.hostname ?? "" : "";
  if (isTeraBoxHost(finalHost)) {
    return {
      ok: false,
      playableInSite: false,
      provider: "TeraBox",
      sourceType: "Share page (HTML) — not a video file",
      embedUrl: null,
      embedSupport: "None — TeraBox does not offer a permitted public iframe embed",
      compatibility: `The URL redirects to TeraBox (${probe.finalUrl}).`,
      errorDetails:
        "TeraBox share links serve an HTML page, never video bytes. No direct stream was invented and none was extracted.",
      recommendedFix:
        "Save this link in the Provider embed tab (visitors get “Watch on TeraBox”), and add an authorized MP4/HLS URL for in-site playback.",
      fallbackAvailable: false,
    };
  }

  const contentType = (probe.contentType || "").toLowerCase();
  const isHtml = contentType.includes("text/html");
  const mediaTypeOk =
    contentType.startsWith("video/") ||
    contentType.startsWith("audio/") ||
    contentType.includes("mpegurl") ||
    contentType.includes("dash") ||
    isHls ||
    isDash;

  const compatBits = [
    probe.status ? `HTTP ${probe.status}` : null,
    probe.contentType || null,
    probe.contentLength ? `${(Number(probe.contentLength) / 1024 / 1024).toFixed(1)} MB` : null,
    probe.acceptRanges ? `byte-range: ${probe.acceptRanges}` : "byte-range: not advertised",
    probe.cors ? `CORS: ${probe.cors}` : "CORS: not advertised",
  ].filter(Boolean) as string[];

  if (!probe.ok || !probe.status) {
    return {
      ok: false,
      playableInSite: false,
      provider: providerLabel,
      sourceType: isHls ? "HLS stream (.m3u8)" : isDash ? "DASH manifest (.mpd)" : "Direct file (MP4/WebM…)",
      embedUrl: null,
      embedSupport: "—",
      compatibility: compatBits.join(" · ") || "The server could not be reached.",
      errorDetails: probe.error || `The server replied${probe.status ? ` HTTP ${probe.status}` : " with an error"}.`,
      recommendedFix:
        probe.status === 403
          ? "The host returned 403 Forbidden — the file may be private or the URL expiring. Use a public, non-expiring HTTPS URL."
          : probe.status === 404
            ? "404 Not Found — the file does not exist at that URL. Re-upload or re-copy the link."
            : "Check the URL, make sure it is publicly reachable over HTTPS, and test again.",
      fallbackAvailable: false,
    };
  }

  if (isHtml) {
    return {
      ok: false,
      playableInSite: false,
      provider: providerLabel,
      sourceType: "Web page (HTML) — not a video file",
      embedUrl: null,
      embedSupport: "—",
      compatibility: compatBits.join(" · "),
      errorDetails: "That URL returned an HTML page, not video bytes.",
      recommendedFix:
        "Do not save this as a video source. Paste the direct media file URL (…/video.mp4, …/stream.m3u8) or use the Provider embed tab for share links.",
      fallbackAvailable: false,
    };
  }

  if (!mediaTypeOk) {
    return {
      ok: false,
      playableInSite: false,
      provider: providerLabel,
      sourceType: `Unknown content type (${probe.contentType || "none"})`,
      embedUrl: null,
      embedSupport: "—",
      compatibility: compatBits.join(" · "),
      errorDetails:
        "The host did not report a video/playlist Content-Type, so browser playback cannot be confirmed.",
      recommendedFix:
        "Serve the file with Content-Type video/mp4 (or application/vnd.apple.mpegurl for HLS). Most CDNs/S3 do this automatically for real media files.",
      fallbackAvailable: false,
    };
  }

  const seekOk = probe.acceptRanges === "bytes";
  const corsOk = !!probe.cors;
  const needsCors = isHls || isDash; // hls.js / dash.js fetch segments via XHR/fetch → CORS required
  const verified = seekOk && (!needsCors || corsOk);
  return {
    ok: verified,
    playableInSite: verified,
    provider: providerLabel,
    sourceType: isHls
      ? "HLS stream (.m3u8)"
      : isDash
        ? "DASH manifest (.mpd — dash.js)"
        : "Direct file (MP4/WebM…)",
    embedUrl: null,
    embedSupport: "—",
    compatibility: compatBits.join(" · "),
    errorDetails: verified
      ? null
      : seekOk
        ? `${needsCors ? "HLS/DASH playback needs CORS" : "Playback verified but CORS subtitles may be blocked"} — the host did not send the required ${seekOk ? "Access-Control-Allow-Origin" : "Accept-Ranges: bytes"} header.`
        : "The host did not advertise byte-range support, so seeking may not work.",
    recommendedFix: verified
      ? null
      : seekOk
        ? "Enable CORS (Access-Control-Allow-Origin) on the storage host/CDN for HLS/DASH playback, or serve the video as a progressive MP4."
        : "Use a host that supports HTTP range requests (S3, R2, most CDNs) so seeking works.",
    fallbackAvailable: false,
  };
}
