import { ok, fail, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { extractGdriveFileId, validateEmbedUrl } from "@/lib/media-validate";
import { probeMediaUrl } from "@/lib/ssrf";

/**
 * Admin "Test Video" for provider embeds. Validates the pasted link, builds
 * the official embed URL and runs a best-effort reachability/permission check:
 *
 *  - Google Drive: probes the export endpoint; a bounce to accounts.google.com
 *    or an HTTP 403 means the file is private → clear admin guidance.
 *  - TeraBox: confirms the share link resolves. TeraBox offers no permitted
 *    public iframe embed, so the result explains the "Watch on TeraBox"
 *    fallback and the optional authorized streaming URL.
 *  - Other providers: report the generated official embed URL.
 *
 * No invented streaming URLs, no provider bypasses — supported methods only.
 */
export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const body = await readJson<{ url?: string }>(req);
  const raw = (body?.url || "").trim();
  if (!raw) return fail("Paste a provider share link first.");

  const converted = validateEmbedUrl(raw);
  if ("error" in converted) return fail(converted.error);
  const { embedUrl, provider } = converted;

  if (provider === "gdrive") {
    const fileId = extractGdriveFileId(raw) || extractGdriveFileId(embedUrl);
    if (!fileId) return fail("Could not extract the Google Drive file ID from that link.");

    // Best-effort permission probe of the export endpoint.
    const probe = await probeMediaUrl(`https://drive.google.com/uc?export=download&id=${encodeURIComponent(fileId)}`);
    const bouncedToSignin = !!probe.finalUrl && /accounts\.google\.com/i.test(probe.finalUrl);

    if (bouncedToSignin || probe.status === 403 || (!probe.ok && probe.status === 401)) {
      return ok({
        ok: false,
        provider,
        embedUrl,
        canIframe: true,
        message:
          "This Drive file appears to be PRIVATE (Google bounced the check to sign-in). In Google Drive set Sharing → “Anyone with the link” → Viewer, then test again. Private files cannot be embedded or streamed.",
      });
    }
    // 416 (Range Not Satisfiable) still proves the file exists and is served —
    // Drive's export endpoint commonly rejects ranged probes for public files.
    const reachable = probe.ok || probe.status === 416;
    if (!reachable) {
      return ok({
        ok: false,
        provider,
        embedUrl,
        canIframe: true,
        message: `The Drive file could not be verified${probe.status ? ` (HTTP ${probe.status})` : ""}. It may have been deleted, quota-limited or blocked. ${probe.error || ""}`.trim(),
      });
    }
    return ok({
      ok: true,
      provider,
      embedUrl,
      canIframe: true,
      message:
        "Google Drive file is publicly reachable and the official /preview embed URL was generated. Visitors will watch it right inside ANIME BOY. (Drive-only limits such as download quota exhaustion can still appear on Google's side.)",
    });
  }

  if (provider === "terabox") {
    const probe = await probeMediaUrl(embedUrl);
    if (!probe.ok && !probe.finalUrl) {
      return ok({
        ok: false,
        provider,
        embedUrl,
        canIframe: false,
        message: `The TeraBox link could not be reached (${probe.error || "network error"}). It may be deleted, expired or region-blocked. ${probe.status ? `HTTP ${probe.status}.` : ""}`.trim(),
      });
    }
    return ok({
      ok: true,
      provider,
      embedUrl,
      canIframe: false,
      message:
        "TeraBox link is valid and reachable. TeraBox does not permit in-site iframe embedding, so visitors will get a clearly labelled “Watch on TeraBox” button — or add an authorized direct streaming URL below to play it inside ANIME BOY.",
    });
  }

  // YouTube / Vimeo / Dailymotion / Streamable — official embeds.
  return ok({
    ok: true,
    provider,
    embedUrl,
    canIframe: true,
    message: `Official ${provider} embed URL generated. Playback happens inside the ANIME BOY player (provider controls apply).`,
  });
}
