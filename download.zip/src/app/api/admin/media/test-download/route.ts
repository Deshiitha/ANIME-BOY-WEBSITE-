import { stat } from "fs/promises";
import path from "path";
import { fail, ok, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { parseS3Url } from "@/lib/media-validate";
import { isTeraBoxHost } from "@/lib/media-types";
import { createSignedDownloadUrl, formatSizeLabel } from "@/lib/media-source";
import { probeMediaUrl } from "@/lib/ssrf";
import { UPLOAD_ROOT } from "@/lib/storage";

/**
 * Admin "Test Download" verifier — proves a configured download/subtitle file
 * is actually accessible and downloadable BEFORE it is published. Works for
 * every storage kind the download system accepts:
 *  - /api/files/…   → the file is stat-ed on this server (existence + size)
 *  - s3://bucket/key → a HEAD on the object (existence + size) plus a signed
 *                      download URL mint to prove credentials/permissions work
 *  - https://…      → SSRF-safe probe: status, Content-Type, size and whether
 *                     the host forces downloads (Content-Disposition) — with
 *                     provider-aware verdicts for Drive / TeraBox / generic CDNs.
 */
export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const body = await readJson<{ url?: string }>(req);
  const url = (body?.url || "").trim();
  if (!url) return fail("A download URL is required");

  /* --------------------- site-hosted upload (/api/files/) ------------------- */
  if (url.startsWith("/api/files/")) {
    const key = url.replace(/^\/api\/files\//, "").split(/[?#]/)[0];
    const safeRel = path.normalize(key).replace(/^(\.\.([\/\\]|$))+/, "");
    const full = path.join(UPLOAD_ROOT, safeRel);
    if (!full.startsWith(UPLOAD_ROOT)) return fail("Invalid file path.");
    const info = await stat(full).catch(() => null);
    if (!info || !info.isFile()) {
      return ok({
        ok: false,
        kind: "site",
        error: "The file does not exist on this server (it may have been deleted). Re-upload it.",
      });
    }
    return ok({
      ok: true,
      kind: "site",
      sizeBytes: info.size,
      sizeLabel: formatSizeLabel(info.size),
      downloadable: "forced" as const,
      verdict: `✓ File exists on this server (${formatSizeLabel(info.size)}) and downloads with the correct filename (Content-Disposition: attachment).`,
    });
  }

  /* ------------------------- private bucket (s3://) ------------------------- */
  if (url.toLowerCase().startsWith("s3://")) {
    const parsed = parseS3Url(url);
    if (!parsed) return fail("Use the full s3://bucket/key form for private-bucket objects.");
    try {
      const signed = await createSignedDownloadUrl(parsed.bucket, parsed.key, "test.bin");
      return ok({
        ok: true,
        kind: "s3",
        sizeBytes: signed.sizeBytes,
        sizeLabel: formatSizeLabel(signed.sizeBytes),
        downloadable: "forced" as const,
        verdict: `✓ Object exists in the private bucket${signed.sizeBytes ? ` (${formatSizeLabel(signed.sizeBytes)})` : ""} and a signed download URL was minted successfully — visitors will get a temporary attachment link.`,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      if (msg === "NOT_FOUND")
        return ok({
          ok: false,
          kind: "s3",
          error: "The object does not exist in the bucket (404). Check the bucket/key.",
        });
      if (/not configured/i.test(msg))
        return ok({
          ok: false,
          kind: "s3",
          error: "Object storage is not configured on this server (S3_* environment variables).",
        });
      return ok({ ok: false, kind: "s3", error: "Could not reach the object. Check the S3 credentials/endpoint." });
    }
  }

  /* ----------------- external https URL (storage host / CDN) ---------------- */
  if (!/^https?:\/\//i.test(url)) return fail("Enter an https:// file URL, a /api/files/ path or s3://bucket/key.");

  const probe = await probeMediaUrl(url);
  if (!probe.ok) {
    return ok({
      ok: false,
      kind: "external",
      status: probe.status,
      error:
        probe.status === 404
          ? "File not found at the storage host (404). The link may be wrong or the file was moved."
          : probe.status === 403
            ? "Access refused (403). The file may be private, expired or region-locked."
            : probe.error || "The link could not be reached from the server.",
    });
  }

  const ct = (probe.contentType || "").toLowerCase();
  const isHtml = ct.includes("text/html") || !!probe.isHtml;
  const disposition = (probe.contentDisposition || "").toLowerCase();
  const forced = disposition.startsWith("attachment");
  const size = probe.contentLength ? Number(probe.contentLength) : undefined;

  let host = "";
  try {
    host = new URL(probe.finalUrl || url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {}

  const provider = isTeraBoxHost(host) ? "terabox" : /drive\.google\.com$|docs\.google\.com$/.test(host) ? "gdrive" : "generic";

  if (isHtml) {
    return ok({
      ok: false,
      kind: "external",
      status: probe.status,
      isHtml: true,
      provider,
      error:
        provider === "terabox"
          ? "This is the TeraBox share PAGE, not a file. Save it as the download URL only if visitors should continue on TeraBox's official page — a direct MP4 cannot be generated from a TeraBox share link."
          : "That URL returns a web page (HTML), not a downloadable file. Paste a direct file link (…/file.mp4, Google Drive “export=download”, etc.).",
    });
  }

  const subtitlesOk = /\.(srt|vtt|ass|ssa|sub)(\?|$)/i.test(url.split(/[?#]/)[0]) || ct.includes("text/") || ct.includes("subtitle");
  const verdict = forced
    ? `✓ File is accessible and downloadable${size ? ` (${formatSizeLabel(size)})` : ""} — the host forces the download, so visitors save it directly.${subtitlesOk ? " Subtitle file confirmed." : ""}`
    : provider === "terabox"
      ? "TeraBox hosts the file — the download continues on TeraBox's official page. Visitors get a clear “Open Download Link” handoff; this site never fakes a TeraBox direct MP4 link."
      : provider === "gdrive"
        ? "Google Drive's official download endpoint responded. Large files may show Drive's virus-scan/confirm page — the file's sharing permissions decide the download."
        : `File is accessible${size ? ` (${formatSizeLabel(size)})` : ""}, but the host did not send Content-Disposition: attachment — visitors get the “Open Download Link” fallback and may need to save the file from the player/tab.`;

  return ok({
    ok: true,
    kind: "external",
    status: probe.status,
    contentType: probe.contentType,
    sizeBytes: Number.isFinite(size) ? size : undefined,
    sizeLabel: formatSizeLabel(Number.isFinite(size) ? size : undefined),
    contentDisposition: probe.contentDisposition || undefined,
    acceptRanges: probe.acceptRanges,
    provider,
    downloadable: forced ? ("forced" as const) : ("fallback" as const),
    verdict,
  });
}
