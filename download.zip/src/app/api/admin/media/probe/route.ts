import { fail, ok, readJson } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { probeMediaUrl } from "@/lib/ssrf";

/**
 * Admin-only URL inspection used by the "Preview / Check" button: verifies the
 * host is public (SSRF guard), the server responds, the Content-Type is a
 * media type and byte-range seeking is advertised.
 */
export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const body = await readJson<{ url?: string }>(req);
  const url = (body?.url || "").trim();
  if (!url) return fail("A URL is required");
  if (!/^https?:\/\//i.test(url))
    return fail("Only http(s) URLs can be inspected (s3:// keys are checked at playback time).");

  const result = await probeMediaUrl(url);
  if (!result.ok) return ok({ ...result, ok: false });

  const ct = (result.contentType || "").toLowerCase();
  const isMedia =
    ct.startsWith("video/") ||
    ct.includes("mpegurl") ||
    ct.startsWith("audio/") ||
    ct === "application/octet-stream" ||
    ct === "binary/octet-stream";
  const isHtml = ct.includes("text/html");

  return ok({
    ...result,
    isHtml,
    verdict: isHtml
      ? "That URL returns an HTML page, not a video file. A share-page link cannot be played directly — use a direct media URL or a provider embed."
      : isMedia
        ? result.acceptRanges === "bytes"
          ? "OK — direct media with byte-range support (seeking will work)."
          : "Playable, but the server does not advertise byte-range support; seeking may be slow or broken on this host."
        : `Unusual Content-Type "${ct || "unknown"}". Playback may still work if the file is a real video stream.`,
  });
}
