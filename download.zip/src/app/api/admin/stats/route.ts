import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";
import { requireAdmin } from "@/lib/auth";
import { getS3Config } from "@/lib/storage";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return fail(auth.error, 401);

  const [animeTotal, movies, series, upcoming, episodes, users, pendingRequests, published, donghuaMovies, donghuaSeries, others] =
    await Promise.all([
      db.anime.count(),
      db.anime.count({ where: { category: "ANIME", type: "MOVIE" } }),
      db.anime.count({ where: { category: "ANIME", type: "SERIES" } }),
      db.anime.count({ where: { status: "UPCOMING" } }),
      db.episode.count(),
      db.user.count(),
      db.animeRequest.count({ where: { status: "PENDING" } }),
      db.anime.count({ where: { published: true } }),
      db.anime.count({ where: { category: "DONGHUA", type: "MOVIE" } }),
      db.anime.count({ where: { category: "DONGHUA", type: "SERIES" } }),
      db.anime.count({ where: { category: "OTHERS" } }),
    ]);

  return ok({
    stats: { animeTotal, movies, series, upcoming, episodes, users, pendingRequests, published, donghuaMovies, donghuaSeries, others },
    storage: getS3Config() ? "s3" : "local",
  });
}
