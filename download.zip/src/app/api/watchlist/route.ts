import { db } from "@/lib/db";
import { ok, fail, readJson, publicAnime } from "@/lib/api-helpers";
import { requireUser } from "@/lib/auth";

export async function GET(req: Request) {
  const auth = await requireUser(req);
  if (!auth.ok) return fail(auth.error, 401);
  const items = await db.watchlistItem.findMany({
    where: { userId: auth.user.id },
    orderBy: { createdAt: "desc" },
    include: { anime: true },
  });
  return ok({ items: items.map((i) => publicAnime(i.anime)) });
}

export async function POST(req: Request) {
  const auth = await requireUser(req);
  if (!auth.ok) return fail(auth.error, 401);
  const body = await readJson<{ animeId?: string; action?: "add" | "remove" | "toggle" }>(req);
  const animeId = body?.animeId;
  if (!animeId) return fail("animeId is required");

  const anime = await db.anime.findUnique({ where: { id: animeId } });
  if (!anime) return fail("Anime not found", 404);

  const existing = await db.watchlistItem.findUnique({
    where: { userId_animeId: { userId: auth.user.id, animeId } },
  });

  const action = body?.action || "toggle";
  if (existing && (action === "remove" || action === "toggle")) {
    await db.watchlistItem.delete({ where: { id: existing.id } });
    return ok({ inWatchlist: false });
  }
  if (!existing) {
    await db.watchlistItem.create({ data: { userId: auth.user.id, animeId } });
  }
  return ok({ inWatchlist: true });
}
