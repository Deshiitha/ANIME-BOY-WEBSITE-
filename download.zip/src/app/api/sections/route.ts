import { db } from "@/lib/db";
import { ok, publicAnime } from "@/lib/api-helpers";

const TAKE = 20;

export async function GET() {
  const base = { published: true } as const;

  const [
    featuredRaw,
    recentMovies,
    comingSoonMovies,
    recentSeries,
    latestEpisodesRaw,
    comingSoonSeries,
    topRated,
    recentDonghua,
    recentDonghuaSeries,
    recentOthers,
    recentMoviesCount,
    comingSoonMoviesCount,
    recentSeriesCount,
    episodesCount,
    comingSoonSeriesCount,
    topRatedCount,
    recentDonghuaCount,
    recentDonghuaSeriesCount,
    recentOthersCount,
  ] = await Promise.all([
    db.anime.findMany({
      where: { ...base, featured: true },
      orderBy: [{ featuredOrder: "asc" }, { createdAt: "desc" }],
      take: 8,
    }),
    db.anime.findMany({
      where: { ...base, category: "ANIME", type: "MOVIE", status: "RELEASED" },
      orderBy: [{ homeRank: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.findMany({
      where: { ...base, category: "ANIME", type: "MOVIE", status: "UPCOMING" },
      orderBy: [{ releaseYear: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.findMany({
      where: { ...base, category: "ANIME", type: "SERIES", status: "RELEASED" },
      orderBy: [{ homeRank: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.episode.findMany({
      where: { season: { anime: { published: true, status: "RELEASED" } } },
      orderBy: { createdAt: "desc" },
      take: TAKE,
      include: {
        season: { include: { anime: { select: { slug: true, titleEn: true, posterUrl: true, type: true, category: true, rating: true } } } },
      },
    }),
    db.anime.findMany({
      where: { ...base, category: "ANIME", type: "SERIES", status: "UPCOMING" },
      orderBy: [{ releaseYear: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.findMany({
      where: { ...base, rating: { not: null } },
      orderBy: [{ rating: "desc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.findMany({
      where: { ...base, category: "DONGHUA", type: "MOVIE", status: "RELEASED" },
      orderBy: [{ homeRank: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.findMany({
      where: { ...base, category: "DONGHUA", type: "SERIES", status: "RELEASED" },
      orderBy: [{ homeRank: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.findMany({
      // Others: the flexible category — any video type, so no type filter.
      where: { ...base, category: "OTHERS", status: "RELEASED" },
      orderBy: [{ homeRank: "asc" }, { createdAt: "desc" }],
      take: TAKE,
    }),
    db.anime.count({ where: { ...base, category: "ANIME", type: "MOVIE", status: "RELEASED" } }),
    db.anime.count({ where: { ...base, category: "ANIME", type: "MOVIE", status: "UPCOMING" } }),
    db.anime.count({ where: { ...base, category: "ANIME", type: "SERIES", status: "RELEASED" } }),
    db.episode.count({ where: { season: { anime: { published: true, status: "RELEASED" } } } }),
    db.anime.count({ where: { ...base, category: "ANIME", type: "SERIES", status: "UPCOMING" } }),
    db.anime.count({ where: { ...base, rating: { not: null } } }),
    db.anime.count({ where: { ...base, category: "DONGHUA", type: "MOVIE", status: "RELEASED" } }),
    db.anime.count({ where: { ...base, category: "DONGHUA", type: "SERIES", status: "RELEASED" } }),
    db.anime.count({ where: { ...base, category: "OTHERS", status: "RELEASED" } }),
  ]);

  const featured = featuredRaw.map(publicAnime);

  const latestEpisodes = latestEpisodesRaw.map((e) => ({
    id: e.id,
    number: e.number,
    seasonNumber: e.season.number,
    title: e.title,
    durationSec: e.durationSec,
    createdAt: e.createdAt,
    anime: e.season.anime,
  }));

  return ok({
    featured,
    recentMovies: { items: recentMovies.map(publicAnime), total: recentMoviesCount },
    comingSoonMovies: { items: comingSoonMovies.map(publicAnime), total: comingSoonMoviesCount },
    recentSeries: { items: recentSeries.map(publicAnime), total: recentSeriesCount },
    latestEpisodes: { items: latestEpisodes, total: episodesCount },
    comingSoonSeries: { items: comingSoonSeries.map(publicAnime), total: comingSoonSeriesCount },
    topRated: { items: topRated.map(publicAnime), total: topRatedCount },
    recentDonghua: { items: recentDonghua.map(publicAnime), total: recentDonghuaCount },
    recentDonghuaSeries: { items: recentDonghuaSeries.map(publicAnime), total: recentDonghuaSeriesCount },
    recentOthers: { items: recentOthers.map(publicAnime), total: recentOthersCount },
  });
}
