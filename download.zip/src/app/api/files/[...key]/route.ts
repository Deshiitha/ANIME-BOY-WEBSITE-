import { stat } from "fs/promises";
import { createReadStream } from "fs";
import path from "path";
import { Readable } from "stream";
import { UPLOAD_ROOT } from "@/lib/storage";

const MIME: Record<string, string> = {
  mp4: "video/mp4",
  webm: "video/webm",
  ogv: "video/ogg",
  mov: "video/quicktime",
  mkv: "video/x-matroska",
  m3u8: "application/vnd.apple.mpegurl",
  mpd: "application/dash+xml",
  ts: "video/mp2t",
  m4s: "video/iso.segment",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  avif: "image/avif",
  gif: "image/gif",
  vtt: "text/vtt",
  srt: "text/plain",
};

function notFound() {
  return new Response("Not found", { status: 404 });
}

/** Attachment-safe filename for forced downloads (?download=1&name=…). */
function safeDispositionName(raw: string | null, fallback: string): string {
  const name = (raw || fallback).replace(/[\r\\"]+/g, "").trim();
  return name || fallback;
}

export async function GET(req: Request, ctx: { params: Promise<{ key: string[] }> }) {
  const { key } = await ctx.params;
  const rel = key.join("/");
  // Path traversal protection
  const safeRel = path.normalize(rel).replace(/^(\.\.([\/\\]|$))+/, "");
  const full = path.join(UPLOAD_ROOT, safeRel);
  if (!full.startsWith(UPLOAD_ROOT)) return notFound();

  const info = await stat(full).catch(() => null);
  if (!info || !info.isFile()) return notFound();

  const ext = path.extname(full).slice(1).toLowerCase();
  const mime = MIME[ext] || "application/octet-stream";
  const range = req.headers.get("range");
  const downloadParams = new URL(req.url).searchParams;
  const forceDownload = downloadParams.get("download") === "1";
  const disposition = forceDownload
    ? `attachment; filename="${safeDispositionName(downloadParams.get("name"), path.basename(full))}"`
    : null;

  const baseHeaders: Record<string, string> = {
    "Content-Type": mime,
    "Accept-Ranges": "bytes",
    "Cache-Control": forceDownload ? "no-store" : "public, max-age=31536000, immutable",
  };
  if (disposition) baseHeaders["Content-Disposition"] = disposition;

  if (range) {
    const match = /bytes=(\d*)-(\d*)/.exec(range);
    if (match) {
      let start = match[1] ? parseInt(match[1], 10) : 0;
      let end = match[2] ? parseInt(match[2], 10) : info.size - 1;
      if (isNaN(start) || start < 0) start = 0;
      if (isNaN(end) || end >= info.size) end = info.size - 1;
      if (start > end) start = Math.max(0, end);
      const chunkSize = end - start + 1;
      const stream = createReadStream(full, { start, end });
      return new Response(Readable.toWeb(stream) as ReadableStream, {
        status: 206,
        headers: {
          ...baseHeaders,
          "Content-Range": `bytes ${start}-${end}/${info.size}`,
          "Content-Length": String(chunkSize),
        },
      });
    }
  }

  const stream = createReadStream(full);
  return new Response(Readable.toWeb(stream) as ReadableStream, {
    status: 200,
    headers: { ...baseHeaders, "Content-Length": String(info.size) },
  });
}
