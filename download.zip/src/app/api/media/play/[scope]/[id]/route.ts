import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { fail } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";
import { createSignedPlaybackUrl, parseJsonArray, resolveObjectKey } from "@/lib/media-source";
import { parseS3Url } from "@/lib/media-validate";

/**
 * Mints a short-lived signed playback URL for a private-bucket object after
 * checking the viewer's access. Storage credentials never leave the server;
 * the database only stores the stable s3://bucket/key identifier.
 *
 * `?src=<altId>` (optional) selects one admin-configured BACKUP source from
 * the item's altSources JSON instead of the primary video — this is how the
 * watch-page source switcher plays private-bucket backup sources. Only s3://
 * rows are signable; everything else streams directly from its own origin.
 */
export async function GET(
  req: Request,
  ctx: { params: Promise<{ scope: string; id: string }> }
) {
  const { scope, id } = await ctx.params;
  if (scope !== "anime" && scope !== "episode") return fail("Unknown media scope", 404);

  const item =
    scope === "anime"
      ? await db.anime.findUnique({ where: { id } })
      : await db.episode.findUnique({
          where: { id },
          include: { season: { include: { anime: true } } },
        });

  if (!item) return fail("Media not found", 404);

  // Access check: unpublished content is admin-preview only. For episodes the
  // parent anime's published flag decides visibility.
  let published = true;
  if (scope === "anime") {
    published = (item as { published: boolean }).published;
  } else {
    published = (item as unknown as { season: { anime: { published: boolean } } }).season.anime
      .published;
  }
  if (!published) {
    const user = await getSessionFromRequest(req);
    if (user?.role !== "ADMIN") return fail("Media not found", 404);
  }

  const altId = new URL(req.url).searchParams.get("src");
  let object: { bucket: string; key: string } | null = null;

  if (altId) {
    // Backup source signing: find the row, require it to be a private-bucket
    // object. Share pages / http URLs are never signed — they either stream
    // from their own origin or are not streams at all.
    const rows = parseJsonArray<{ id: string; sourceType: string; url?: string | null }>(
      (item as { altSources: string | null }).altSources
    );
    const row = rows.find((r) => r.id === altId && r.sourceType === "external");
    if (!row?.url) return fail("That backup source does not exist on this media.", 404);
    object = parseS3Url(row.url);
    if (!object)
      return fail("This backup source streams directly from its own host and needs no signed URL.", 400);
  } else {
    object = resolveObjectKey({
      id,
      videoUrl: (item as { videoUrl: string | null }).videoUrl,
      videoKey: (item as { videoKey: string | null }).videoKey,
    });
  }

  if (!object) return fail("This media is not configured for private-bucket playback.", 400);

  try {
    const signed = await createSignedPlaybackUrl(object.bucket, object.key);
    return NextResponse.json(signed, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Could not sign the playback URL.";
    return fail(
      /not configured/i.test(msg)
        ? "Private object storage is not configured on this server (S3_* environment variables)."
        : "Could not generate a playback URL. Check the object storage configuration.",
      500
    );
  }
}
