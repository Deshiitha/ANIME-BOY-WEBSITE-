import { stat } from "fs/promises";
import path from "path";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { fail } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";
import {
  buildDownloadFilename,
  createSignedDownloadUrl,
  formatSizeLabel,
  pickDownloadOption,
} from "@/lib/media-source";
import { parseS3Url } from "@/lib/media-validate";
import {
  downloadProviderFromHost,
  driveDirectDownloadUrl,
  formatFromContentType,
} from "@/lib/media-types";
import { probeMediaUrl } from "@/lib/ssrf";
import { UPLOAD_ROOT } from "@/lib/storage";

/**
 * Resolves one download option for the current viewer. The database keeps only
 * stable identifiers; large files are NEVER proxied through this server — the
 * response tells the browser where the storage provider / CDN serves the file:
 *  - s3://bucket/key  → short-lived signed URL with Content-Disposition: attachment
 *  - /api/files/…     → same-origin URL with ?download=1 (this server hosts it, small files)
 *  - https://…        → verified with a SSRF-safe 1-byte probe; the browser is
 *                       sent straight to the provider (mode "direct" when the
 *                       provider forces downloads, otherwise the client shows
 *                       a provider-aware download dialog that hands off to
 *                       Google Drive / TeraBox / the storage host).
 */
export async function GET(
  req: Request,
  ctx: { params: Promise<{ scope: string; id: string }> }
) {
  const { scope, id } = await ctx.params;
  if (scope !== "anime" && scope !== "episode") return fail("Unknown media scope", 404);

  const url = new URL(req.url);
  const kind = url.searchParams.get("kind") === "subtitle" ? "subtitle" : "video";
  const index = Number(url.searchParams.get("index") || "0");
  if (!Number.isInteger(index) || index < 0 || index > 50) return fail("Invalid download option.", 400);

  const item =
    scope === "anime"
      ? await db.anime.findUnique({ where: { id } })
      : await db.episode.findUnique({
          where: { id },
          include: { season: { include: { anime: true } } },
        });
  if (!item) return fail("Media not found", 404);

  // Access check mirrors playback: unpublished content is admin-preview only.
  let published = true;
  let titleEn: string;
  let seasonNumber: number | null = null;
  let episodeNumber: number | null = null;
  if (scope === "anime") {
    const row = item as { published: boolean; titleEn: string };
    published = row.published;
    titleEn = row.titleEn;
  } else {
    const ep = item as unknown as {
      number: number;
      season: { number: number; anime: { published: boolean; titleEn: string } };
    };
    published = ep.season.anime.published;
    titleEn = ep.season.anime.titleEn;
    seasonNumber = ep.season.number;
    episodeNumber = ep.number;
  }
  if (!published) {
    const user = await getSessionFromRequest(req);
    if (user?.role !== "ADMIN") return fail("Media not found", 404);
  }

  const picked = pickDownloadOption(item, kind, index);
  if (!picked) return fail("That download option is not available.", 404);

  const filename = buildDownloadFilename({
    titleEn,
    seasonNumber,
    episodeNumber,
    label: kind === "video" ? picked.label : undefined,
    lang: picked.lang,
    url: picked.url,
    format: picked.format,
  });
  const notStore = { headers: { "Cache-Control": "no-store" } };

  /* ------------------------- private bucket (s3://) ------------------------ */
  if (picked.url.startsWith("s3://")) {
    const parsed = parseS3Url(picked.url);
    if (!parsed) return fail("The stored download identifier is not a valid s3://bucket/key object.", 500);
    try {
      const signed = await createSignedDownloadUrl(parsed.bucket, parsed.key, filename);
      return NextResponse.json(
        {
          mode: "direct" as const,
          url: signed.url,
          filename,
          format: picked.format,
          sizeBytes: signed.sizeBytes,
          sizeLabel: formatSizeLabel(signed.sizeBytes),
        },
        notStore
      );
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      if (msg === "NOT_FOUND")
        return fail("The download file no longer exists in the private bucket (404). Re-upload it or pick another file.", 404);
      if (/not configured/i.test(msg))
        return fail("Private object storage is not configured on this server (S3_* environment variables).", 500);
      return fail("Could not generate a download link. Check the object storage configuration.", 500);
    }
  }

  /* --------------------- site-hosted upload (/api/files/) ------------------- */
  if (picked.url.startsWith("/api/files/")) {
    const key = picked.url.replace(/^\/api\/files\//, "");
    const safeRel = path.normalize(key).replace(/^(\.\.([\/\\]|$))+/, "");
    const full = path.join(UPLOAD_ROOT, safeRel);
    let sizeBytes: number | undefined;
    if (full.startsWith(UPLOAD_ROOT)) {
      const info = await stat(full).catch(() => null);
      if (!info || !info.isFile())
        return fail("This download file no longer exists on the server (404). It may have been removed.", 404);
      sizeBytes = info.size;
    }
    const sep = picked.url.includes("?") ? "&" : "?";
    return NextResponse.json(
      {
        mode: "direct" as const,
        url: `${picked.url}${sep}download=1&name=${encodeURIComponent(filename)}`,
        filename,
        format: picked.format,
        sizeBytes,
        sizeLabel: formatSizeLabel(sizeBytes),
      },
      notStore
    );
  }

  /* ----------------- external https URL (storage host / CDN) ---------------- */
  if (!/^https?:\/\//i.test(picked.url))
    return fail("The stored download URL is not a direct file link.", 500);

  // Identity of the storage provider — taken from the ADMIN-CONFIGURED URL
  // (not the redirect target) so the dialog always describes the true source.
  let originalHost = "";
  try {
    originalHost = new URL(picked.url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {}
  const provider = downloadProviderFromHost(originalHost);

  // Google Drive: normalise whatever form the admin stored (share link
  // /file/d/…/view, open?id=…, uc?export=download&id=…) into the canonical
  // direct-download endpoint drive.usercontent.google.com/download?id=…
  // &export=download&confirm=t — built ONLY from the file id already stored,
  // never hardcoded and never replacing the stored link. That endpoint answers
  // with Content-Disposition: attachment, so a browser navigation saves the
  // file straight away: no Drive preview page, no virus-scan interstitial and
  // no hand-off to the Google Drive app on Android. The probe targets this
  // endpoint so the response describes exactly what the visitor will get.
  const driveDirect = provider === "googledrive" ? driveDirectDownloadUrl(picked.url) : null;

  const probe = await probeMediaUrl(driveDirect ?? picked.url);
  if (!probe.ok) {
    if (probe.status === 404)
      return fail("This download file no longer exists at the storage host (404 Not Found). The link may have expired or the file was moved.", 404);
    if (probe.status === 403)
      return fail("The storage host refused access (403 Forbidden). The link may be private, expired or region-locked.", 403);
    if (probe.status === 410)
      return fail("This download link has expired (410 Gone). Ask the admin to refresh the file URL.", 410);
    return fail(probe.error || "The download link could not be reached.", 502);
  }

  const disposition = (probe.contentDisposition || "").toLowerCase();
  const forcesDownload = disposition.startsWith("attachment");

  // Hand-off URL: for Google Drive the direct-download endpoint (what the
  // dialog's primary button navigates to); for every other host the verified
  // final URL, as before. The "Copy Download Link" button always receives the
  // ORIGINAL admin-configured URL (copyUrl) — the stored link is never
  // replaced or rewritten anywhere.
  const handoffUrl = driveDirect ?? (probe.finalUrl || picked.url);

  // When the stored URL carries no usable file extension (Google Drive links
  // never do), derive the format label from the probe's content-type so the
  // dialog shows "MP4" and the suggested filename ends with the right
  // extension.
  const probeFormat = picked.format === "FILE" ? formatFromContentType(probe.contentType) : null;
  const resolvedFormat = probeFormat ?? picked.format;
  const resolvedFilename = probeFormat
    ? buildDownloadFilename({
        titleEn,
        seasonNumber,
        episodeNumber,
        label: kind === "video" ? picked.label : undefined,
        lang: picked.lang,
        url: picked.url,
        format: probeFormat,
      })
    : filename;

  // A text/html probe response means the host answered with an interstitial
  // page (e.g. Drive's virus-scan confirm), not the file — reporting the HTML
  // page's byte size as the video size would be wrong, so omit it.
  const probeIsHtml = (probe.contentType || "").toLowerCase().startsWith("text/html");
  const sizeBytes = probeIsHtml ? undefined : probe.contentLength ? Number(probe.contentLength) : undefined;

  // Provider-aware handoff notes: when the host cannot serve the bytes as a
  // forced download, the visitor must know exactly what happens next —
  // especially for cloud providers where the download continues off-site.
  // (The branded download dialog on the client carries the friendly wording
  // for Google Drive; the notes below stay provider-specific for every other
  // consumer of this API.)
  const genericNote =
    "This file is hosted on an external storage server that opens files in the browser instead of saving them straight away. Use “Open Download Link” — the file opens in a new tab, where you can save it to your device.";
  const note = forcesDownload
    ? undefined
    : provider === "terabox"
      ? `This file is hosted on TeraBox — the download must continue on TeraBox’s official page. Click “Open Download Link”, then press Download there (TeraBox may require an account or its app for large files). This site never bypasses TeraBox’s own download process.`
      : provider === "googledrive"
        ? "This file is served by Google Drive’s official direct-download endpoint. Your browser saves it straight away — if Drive ever shows a confirmation for a large file, confirm it there to continue."
        : genericNote;

  return NextResponse.json(
    {
      // Google Drive always keeps the branded download dialog in the flow; the
      // dialog's primary button then saves the file directly in the browser.
      mode: provider === "googledrive" ? ("open" as const) : forcesDownload ? ("direct" as const) : ("open" as const),
      url: handoffUrl,
      copyUrl: picked.url,
      filename: resolvedFilename,
      format: resolvedFormat,
      sizeBytes: Number.isFinite(sizeBytes) ? sizeBytes : undefined,
      sizeLabel: formatSizeLabel(Number.isFinite(sizeBytes) ? sizeBytes : undefined),
      note,
      provider,
    },
    notStore
  );
}
