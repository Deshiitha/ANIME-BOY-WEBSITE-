import { db } from "@/lib/db";
import { ok, fail, readJson } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";

export async function POST(req: Request) {
  const body = await readJson<{ title?: string; type?: string; message?: string }>(req);
  const title = (body?.title || "").trim();
  const type = body?.type === "SERIES" ? "SERIES" : "MOVIE";
  const message = (body?.message || "").trim() || null;

  if (title.length < 2) return fail("Please enter the anime title");
  if (title.length > 200) return fail("Title is too long");
  if (message && message.length > 2000) return fail("Message is too long");

  const user = await getSessionFromRequest(req);
  const request = await db.animeRequest.create({
    data: { title, type, message, userId: user?.id || null },
  });
  return ok({ request: { id: request.id, status: request.status } }, 201);
}
