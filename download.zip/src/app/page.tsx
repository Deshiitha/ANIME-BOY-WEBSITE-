'use client';

import { AppShell } from '@/components/animeboy/AppShell';

export default function Home() {
  return <AppShell />;
}
