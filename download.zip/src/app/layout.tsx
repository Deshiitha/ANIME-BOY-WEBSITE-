import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

// Canonical site address — set SITE_URL (e.g. https://animeboy.com) on the
// hosting provider so canonical/OG URLs follow the custom domain.
const siteUrlRaw = process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || "";
let siteUrl: URL | undefined;
try {
  siteUrl = siteUrlRaw ? new URL(siteUrlRaw) : undefined;
} catch {
  siteUrl = undefined;
}

export const metadata: Metadata = {
  metadataBase: siteUrl,
  alternates: siteUrl ? { canonical: "/" } : undefined,
  title: "ANIME BOY — Sinhala Anime Streaming",
  description:
    "ANIME BOY — Watch Sinhala dubbed & subbed anime movies and series, latest episodes, reviews and more from the ANIME BOY community.",
  keywords: ["anime", "sinhala dub", "sinhala sub", "anime movies", "anime series", "ANIME BOY"],
  applicationName: "ANIME BOY",
  icons: {
    icon: "/logo-mark.svg",
  },
  openGraph: {
    title: "ANIME BOY — Sinhala Anime Streaming",
    description: "Sinhala dubbed & subbed anime movies, series and reviews.",
    siteName: "ANIME BOY",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#050816",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* Outfit for Latin display type, Noto Sans Sinhala for සිංහල text.
            next/font is avoided here so Sinhala glyphs always load client-side. */}
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Noto+Sans+Sinhala:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased bg-[#050816] text-foreground min-h-screen flex flex-col">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
