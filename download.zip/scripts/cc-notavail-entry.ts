/** Temp entry: HTML5 video, NO subtitles — verifies the "Subtitles Not Available" CC state. */
import { PrismaClient } from "@prisma/client";

const p = new PrismaClient();
const SLUG = "cc-notavail-test";

if (process.argv[2] === "create") {
  await p.anime.upsert({
    where: { slug: SLUG },
    update: { videoSource: "upload", videoUrl: "/api/files/videos/blade-of-the-emerald-dawn-720p.mp4", subtitleTracks: null, embedUrl: null, videoProvider: null },
    create: {
      slug: SLUG,
      titleEn: "CC NotAvailable Test (temp)",
      type: "MOVIE",
      category: "ANIME",
      languageLabel: "SINHALA_SUB",
      status: "RELEASED",
      published: true,
      videoSource: "upload",
      videoUrl: "/api/files/videos/blade-of-the-emerald-dawn-720p.mp4",
    },
  });
  console.log("created", SLUG);
} else if (process.argv[2] === "delete") {
  await p.anime.deleteMany({ where: { slug: SLUG } });
  console.log("deleted", SLUG);
}
await p.$disconnect();
