#!/bin/bash
# Generate original ANIME BOY demo artwork (AI-generated, license-safe placeholders)
cd /home/z/my-project/public/art

STYLE="modern anime key visual, cinematic lighting, vibrant colors, highly detailed, high quality digital anime art"

declare -a JOBS=(
  "poster-blade-dawn.png|768x1344|young female samurai warrior holding a glowing emerald green katana, cherry blossom petals swirling, dark night background with neon green energy, $STYLE"
  "poster-sky-ronin.png|768x1344|lone ronin warrior riding a giant flying sky whale above clouds at sunset, epic adventure anime, $STYLE"
  "poster-neon-sakura.png|768x1344|cyberpunk anime girl with pink hair in neon Tokyo street at night, glowing signs, cherry blossoms, $STYLE"
  "poster-fox-spirit.png|768x1344|mystical white nine-tailed fox spirit with emerald green flames in an enchanted forest, lanterns, magical atmosphere, $STYLE"
  "poster-crimson-horizon.png|768x1344|steampunk airship pirate crew on deck of a flying ship, crimson sunset sky, adventurous anime scene, $STYLE"
  "poster-alchemist.png|768x1344|young alchemist boy in a magical greenhouse full of glowing potion plants, warm cozy fantasy anime, $STYLE"
  "poster-star-voyager.png|768x1344|anime space explorer girl with star map hologram on a spaceship bridge, nebula outside window, $STYLE"
  "poster-ocean-song.png|768x1344|anime girl singing underwater surrounded by glowing fish and coral, deep blue ocean, dreamy, $STYLE"
  "poster-emerald-final.png|768x1344|battle-worn samurai standing on a cliff with emerald green glowing sword, storm clouds, dramatic epic finale, $STYLE"
  "poster-dragon-tide.png|768x1344|massive sea dragon rising from ocean waves beside a small boat, epic scale fantasy anime, $STYLE"
  "poster-emerald-chronicles.png|768x1344|team of three young warriors with emerald green magic weapons, forest temple background, action pose, $STYLE"
  "poster-moonlit-academy.png|768x1344|anime students in uniforms at a mysterious academy under a huge full moon, gothic school building, $STYLE"
  "poster-spirit-hunter.png|768x1344|anime boy with a spirit compass hunting a shadow monster in a dark alley, green spirit energy, $STYLE"
  "poster-ronin-high.png|768x1344|comedic anime scene of a samurai student in school uniform with wooden sword on school rooftop, bright cheerful, $STYLE"
  "poster-neon-zero.png|768x1344|cyberpunk android girl awakening with glowing green circuits, dark laboratory, dramatic anime, $STYLE"
  "poster-dragon-legacy.png|768x1344|young dragon rider girl hugging a baby dragon, sunrise over mountains, heartwarming fantasy anime, $STYLE"
  "backdrop-blade-dawn.png|1440x720|wide cinematic anime scene, samurai warrior with glowing emerald katana facing an army at night, cherry blossoms, epic composition, $STYLE"
  "backdrop-sky-ronin.png|1440x720|wide cinematic anime scene, ronin flying on giant sky whale through golden sunset clouds, epic landscape, $STYLE"
  "backdrop-emerald-chronicles.png|1440x720|wide cinematic anime scene, three heroes standing before an ancient glowing forest temple, emerald magic particles, $STYLE"
  "backdrop-fox-spirit.png|1440x720|wide cinematic anime scene, giant white nine-tailed fox spirit in moonlit enchanted forest with green flames and torii gates, $STYLE"
)

gen() {
  local out="$1" size="$2" prompt="$3"
  if [ -s "$out" ]; then echo "SKIP $out"; return; fi
  for attempt in 1 2 3; do
    if z-ai image -p "$prompt" -o "./$out" -s "$size" >/dev/null 2>&1 && [ -s "$out" ]; then
      echo "OK   $out"; return
    fi
    echo "RETRY($attempt) $out"; sleep 2
  done
  echo "FAIL $out"
}

# run with concurrency 4
running=0
for job in "${JOBS[@]}"; do
  IFS='|' read -r out size prompt <<< "$job"
  gen "$out" "$size" "$prompt" &
  running=$((running+1))
  if [ $running -ge 4 ]; then wait -n; running=$((running-1)); fi
done
wait
echo "DONE $(ls *.png 2>/dev/null | wc -l) images"
