import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const email = "others-verify@animeboy-test.local";
const existing = await db.user.findUnique({ where: { email } });
if (existing) {
  await db.user.delete({ where: { email } });
}
const passwordHash = await bcrypt.hash("OthersVerify-2026!", 10);
const admin = await db.user.create({
  data: { email, name: "Others Verify Admin", passwordHash, role: "ADMIN" },
});
console.log("CREATED", admin.email, admin.role);
await db.$disconnect();
