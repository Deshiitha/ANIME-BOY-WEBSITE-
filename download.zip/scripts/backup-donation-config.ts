/** Backup donation-related SiteConfig rows before testing. */
import { PrismaClient } from "@prisma/client";
import { writeFileSync } from "fs";

const db = new PrismaClient();
const KEYS = [
  "donationEnabled", "donationHeading", "donationDescription", "donationThankYouNote", "donationPresets", "donationPublicRecognition",
  "paymentProvider", "gatewayEnabled", "gatewayMode", "gatewayCurrency",
  "payhereMerchantId", "payhereMerchantSecret", "webxpayMerchantId", "webxpayGatewayId", "webxpaySecretKey", "webxpayPublicKey",
  "payoutBankName", "payoutAccountHolder", "payoutAccountNumber", "payoutCurrency",
  "bankEnabled", "bankName", "bankAccountName", "bankAccountNumber", "bankBranch", "bankInstructions",
];

async function main() {
  const rows = await db.siteConfig.findMany({ where: { key: { in: KEYS } } });
  const map: Record<string, string> = {};
  for (const k of KEYS) map[k] = rows.find((r) => r.key === k)?.value ?? "";
  writeFileSync("/home/z/my-project/scripts/donation-config-backup.json", JSON.stringify(map, null, 2));
  console.log("backup saved:", JSON.stringify(map));
}

main().finally(() => db.$disconnect());
