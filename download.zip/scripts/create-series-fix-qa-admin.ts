import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

/**
 * QA-only admin for browser verification of the Series video-source fix.
 * Idempotent: recreates the same account each run. Delete after testing.
 */
const db = new PrismaClient();
const email = "series-fix-qa@animeboy-test.local";
const existing = await db.user.findUnique({ where: { email } });
if (existing) {
  await db.user.delete({ where: { email } });
}
const passwordHash = await bcrypt.hash("SeriesFix-2026!", 10);
const admin = await db.user.create({
  data: { email, name: "Series Fix QA", passwordHash, role: "ADMIN" },
});
console.log("CREATED", admin.email, admin.role);
await db.$disconnect();
