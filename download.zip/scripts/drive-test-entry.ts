/**
 * Temporary Google Drive test entry for verifying subtitle ON/OFF with an
 * actual Drive video source. Created with a fixed slug so the verification
 * script can find it; deleted again after testing (cleanup script below).
 *
 * Usage:
 *   bun scripts/drive-test-entry.ts create
 *   bun scripts/drive-test-entry.ts delete
 */
import { PrismaClient } from "@prisma/client";

const p = new PrismaClient();
const SLUG = "drive-subtitle-test";

const SUBS = JSON.stringify([
  { label: "සිංහල", lang: "si", url: "/api/files/subtitles/blade-of-the-emerald-dawn-si.srt", enabled: true },
  { label: "English", lang: "en", url: "/api/files/subtitles/blade-of-the-emerald-dawn-en.vtt", enabled: true },
]);

if (process.argv[2] === "create") {
  await p.anime.upsert({
    where: { slug: SLUG },
    update: {
      videoSource: "embed",
      videoProvider: "gdrive",
      embedUrl: "https://drive.google.com/file/d/1qc_FuGp8bszKFTiZDuOkHS_SaIrcwDuo/preview",
      subtitleTracks: SUBS,
    },
    create: {
      slug: SLUG,
      titleEn: "Drive Subtitle Test (temp)",
      type: "MOVIE",
      category: "ANIME",
      languageLabel: "SINHALA_SUB",
      status: "RELEASED",
      published: true,
      videoSource: "embed",
      videoProvider: "gdrive",
      embedUrl: "https://drive.google.com/file/d/1qc_FuGp8bszKFTiZDuOkHS_SaIrcwDuo/preview",
      subtitleTracks: SUBS,
    },
  });
  console.log("created", SLUG);
} else if (process.argv[2] === "delete") {
  await p.anime.deleteMany({ where: { slug: SLUG } });
  console.log("deleted", SLUG);
} else {
  console.log("usage: create | delete");
}
await p.$disconnect();
