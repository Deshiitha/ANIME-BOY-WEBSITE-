#!/bin/bash
# Create small branded sample episode videos for demo content (offline-safe)
mkdir -p /home/z/my-project/db/uploads/videos
cd /home/z/my-project/db/uploads/videos
FONT=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf

make_ep () {
  local out="$1" label="$2"
  if [ -s "$out" ]; then echo "SKIP $out"; return; fi
  ffmpeg -y -f lavfi -i "gradients=s=640x360:d=14:speed=0.06:nb_colors=3:c0=0x050816:c1=0x0d3b1e:c2=0x101827" \
    -vf "drawtext=fontfile=$FONT:text='ANIME BOY':fontcolor=0x22C55E:fontsize=52:x=(w-text_w)/2:y=(h-text_h)/2-34,drawtext=fontfile=$FONT:text='$label':fontcolor=0xE2E8F0:fontsize=26:x=(w-text_w)/2:y=(h-text_h)/2+26,drawtext=fontfile=$FONT:text='Demo clip — replace with your video':fontcolor=0x94A3B8:fontsize=16:x=(w-text_w)/2:y=h-40" \
    -c:v libx264 -preset veryfast -pix_fmt yuv420p -movflags +faststart "$out" 2>/dev/null && echo "OK $out" || echo "FAIL $out"
}

make_ep sample-ep-1.mp4 "Sample Episode 1"
make_ep sample-ep-2.mp4 "Sample Episode 2"
make_ep sample-ep-3.mp4 "Sample Episode 3"
ls -la
