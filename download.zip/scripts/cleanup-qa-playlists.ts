/**
 * Remove the QA playlists created during this session's end-to-end test
 * (QA Playlist Alpha + QA Others Mix). Only touches records whose slug
 * starts with "qa-" — real content is never matched.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const targets = await db.anime.findMany({
    where: { slug: { startsWith: "qa-" } },
    select: { id: true, slug: true },
  });
  for (const t of targets) {
    await db.anime.delete({ where: { id: t.id } }); // cascades seasons + episodes
    console.log("deleted:", t.slug);
  }
  if (!targets.length) console.log("nothing to clean");
  const counts = {
    anime: await db.anime.count(),
    seasons: await db.season.count(),
    episodes: await db.episode.count(),
  };
  console.log("remaining counts:", JSON.stringify(counts));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
