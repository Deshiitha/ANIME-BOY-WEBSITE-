/** Removes the temporary browser-verification admin created for this task. */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const del = await db.user.deleteMany({
    where: { email: { endsWith: "@animeboy-test.local" } },
  });
  console.log("deleted test admins:", del.count);
}

main().finally(() => db.$disconnect());
