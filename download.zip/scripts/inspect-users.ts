/* One-off: inspect users + detect duplicate usernames (case-insensitive). */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const users = await db.user.findMany({ select: { id: true, email: true, name: true, role: true, createdAt: true } });
console.log("users:", users.length);
for (const u of users) console.log(" -", u.role.padEnd(5), JSON.stringify(u.name), u.email, u.createdAt.toISOString());
const byLower = new Map<string, number>();
for (const u of users) if (u.name) byLower.set(u.name.toLowerCase(), (byLower.get(u.name.toLowerCase()) || 0) + 1);
const dupes = [...byLower.entries()].filter(([, c]) => c > 1);
console.log("case-insensitive duplicate usernames:", dupes.length ? dupes : "none");
await db.$disconnect();
