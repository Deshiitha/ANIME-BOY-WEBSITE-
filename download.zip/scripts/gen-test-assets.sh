#!/bin/bash
# Generate REAL, title-matched media assets for the download-system test:
#  - per-quality MP4 files for "Blade of the Emerald Dawn" (movie)
#  - an S01E01 MP4 for "Emerald Blade Chronicles" (series episode)
#  - genuine Sinhala SRT + English VTT subtitle files for both
# Unlike the old seed clips, files are named after their title (never
# "Sample Episode N") so the player and every download carry the correct name.
set -u
V=/home/z/my-project/db/uploads/videos
S=/home/z/my-project/db/uploads/subtitles
FONT=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf
mkdir -p "$V" "$S"

make_video () { # out width height title sub
  local out="$1" w="$2" h="$3" title="$4" sub="$5" fs1 fs2 fs3
  fs1=$(( h / 9 )); fs2=$(( h / 15 )); fs3=$(( h / 24 ))
  if [ -s "$out" ]; then echo "SKIP $(basename "$out")"; return; fi
  ffmpeg -y -f lavfi -i "gradients=s=${w}x${h}:d=12:speed=0.06:nb_colors=3:c0=0x050816:c1=0x0d3b1e:c2=0x101827" \
    -vf "drawtext=fontfile=$FONT:text='ANIME BOY':fontcolor=0x22C55E:fontsize=${fs1}:x=(w-text_w)/2:y=(h-text_h)/2-${fs2},drawtext=fontfile=$FONT:text='${title}':fontcolor=0xE2E8F0:fontsize=${fs2}:x=(w-text_w)/2:y=(h-text_h)/2+${fs3},drawtext=fontfile=$FONT:text='${sub}':fontcolor=0x94A3B8:fontsize=${fs3}:x=(w-text_w)/2:y=h-${fs3}*2" \
    -c:v libx264 -preset veryfast -pix_fmt yuv420p -movflags +faststart "$out" 2>/dev/null \
    && echo "OK $(basename "$out")" || echo "FAIL $(basename "$out")"
}

# Movie: Blade of the Emerald Dawn — one real file per quality
make_video "$V/blade-of-the-emerald-dawn-480p.mp4"  854  480 "Blade of the Emerald Dawn" "480p"
make_video "$V/blade-of-the-emerald-dawn-720p.mp4" 1280  720 "Blade of the Emerald Dawn" "720p"
make_video "$V/blade-of-the-emerald-dawn-1080p.mp4" 1920 1080 "Blade of the Emerald Dawn" "1080p"
# Series episode: Emerald Blade Chronicles S01E01
make_video "$V/emerald-blade-chronicles-s01e01.mp4" 1280  720 "Emerald Blade Chronicles" "S01E01 - නව ගමනක් මුල"

# --- Movie subtitles (real content, correct formats) ---
cat > "$S/blade-of-the-emerald-dawn-si.srt" <<'EOF'
1
00:00:00,500 --> 00:00:03,500
මෙය මිනිස් ලෝකයට වඩා ගැඹුරු කතාවක්...

2
00:00:04,000 --> 00:00:07,500
මැණික් කතුර අවදි වන රාත්‍රිය ළඟා වී ඇත!

3
00:00:08,000 --> 00:00:11,500
මාව නවත්වන්න බැහැ — මම පොරොන්දු වුණා!

4
00:00:12,000 --> 00:00:14,000
ANIME BOY · සිංහල උපසිරැසි
EOF

cat > "$S/blade-of-the-emerald-dawn-en.vtt" <<'EOF'
WEBVTT

1
00:00:00.500 --> 00:00:03.500
This story runs deeper than the human world…

2
00:00:04.000 --> 00:00:07.500
The night of the Emerald Blade's awakening is here!

3
00:00:08.000 --> 00:00:11.500
You cannot stop me — I made a promise!

4
00:00:12.000 --> 00:00:14.000
ANIME BOY · English subtitles
EOF

# --- Episode subtitles ---
cat > "$S/emerald-blade-chronicles-s01e01-si.srt" <<'EOF'
1
00:00:00,500 --> 00:00:03,500
නව ගමනක් මුල — එය හැමවිටම පහසු නොවේ.

2
00:00:04,000 --> 00:00:07,500
පන්සියය අවුරුද්දකට පසු කතුර නැවත දිලිසෙනවා!

3
00:00:08,000 --> 00:00:11,500
ඔබට ශක්තිය තේරුම් ගන්න පුළුවන් වෙයි…

4
00:00:12,000 --> 00:00:14,000
ANIME BOY · සිංහල උපසිරැසි · S01E01
EOF

cat > "$S/emerald-blade-chronicles-s01e01-en.vtt" <<'EOF'
WEBVTT

1
00:00:00.500 --> 00:00:03.500
The beginning of a new journey is never easy.

2
00:00:04.000 --> 00:00:07.500
After five hundred years, the blade glows again!

3
00:00:08.000 --> 00:00:11.500
You will learn what the power truly means…

4
00:00:12.000 --> 00:00:14.000
ANIME BOY · English subtitles · S01E01
EOF

echo "--- files ---"
ls -la "$V" "$S"
