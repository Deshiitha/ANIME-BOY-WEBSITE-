/**
 * Cross-session resume e2e: upload a 40s sample, publish a temp movie with it,
 * print the slug/id. (Playback itself is driven by the browser.)
 */
const BASE = "http://localhost:3000";
let cookie = "";

async function req(method, path, body, isForm) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      ...(body && !isForm ? { "Content-Type": "application/json" } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });
  const setC = res.headers.get("set-cookie");
  if (setC) cookie = setC.split(";")[0];
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

const fs = await import("node:fs");

const login = await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" });
if (login.status !== 200) { console.log("LOGIN FAIL"); process.exit(1); }

const buf = fs.readFileSync("/tmp/resume-test.mp4");
const form = new FormData();
form.append("file", new Blob([buf], { type: "video/mp4" }), "resume-test.mp4");
form.append("kind", "video");
const up = await req("POST", "/api/admin/upload", form, true);
console.log("upload:", up.status, up.data?.url || up.data?.error);
if (!up.data?.url) process.exit(1);

const stamp = Date.now().toString(36);
const movie = await req("POST", "/api/admin/anime", {
  titleEn: `Resume Probe ${stamp}`,
  type: "MOVIE",
  languageLabel: "SINHALA_SUB",
  published: true,
  videoSource: "upload",
  videoUrl: up.data.url,
  videoQualities: [],
  subtitleTracks: [],
  videoThumb: "",
  subtitleUrl: "",
  downloadEnabled: false,
  downloadUrl: "",
  downloadQualities: [],
  subtitleDownloadEnabled: false,
  subtitleDownloads: [],
});
console.log("movie:", movie.status, movie.data?.anime?.slug || movie.data?.error);
if (movie.status !== 201) process.exit(1);
console.log(JSON.stringify({ slug: movie.data.anime.slug, id: movie.data.anime.id }));
