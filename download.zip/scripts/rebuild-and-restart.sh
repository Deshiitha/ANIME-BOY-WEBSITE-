#!/bin/bash
# Rebuild ANIME BOY (Next.js standalone) and restart the production server
# with the correct environment:
#   - UPLOAD_DIR points at the real upload volume (db/uploads). The standalone
#     server.js process.chdir()s into .next/standalone, so without UPLOAD_DIR
#     uploaded files would resolve against a stale copy and downloads 404.
#   - DATABASE_URL is absolute in .env and unaffected.
set -u
cd /home/z/my-project

echo "=== 1/4 build ==="
bun run build || { echo "BUILD FAILED"; exit 1; }

echo "=== 2/4 stop old server ==="
pkill -f "bun .next/standalone/server.js" 2>/dev/null && sleep 1 || echo "no old server"

echo "=== 3/4 start production server (port 3000) ==="
( setsid env NODE_ENV=production UPLOAD_DIR=/home/z/my-project/db/uploads \
    bun .next/standalone/server.js > /home/z/my-project/server.log 2>&1 < /dev/null & )

echo "=== 4/4 wait for HTTP 200 ==="
for i in $(seq 1 30); do
  code=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ || true)
  if [ "$code" = "200" ]; then
    echo "server up (attempt $i) — http 200 ✓"
    echo "UPLOAD_DIR check:"
    curl -s -o /dev/null -w "  /api/files/videos probe: %{http_code}\n" "http://localhost:3000/api/files/videos/blade-of-the-emerald-dawn-720p.mp4"
    exit 0
  fi
  sleep 1
done
echo "SERVER DID NOT COME UP — check server.log"
tail -20 /home/z/my-project/server.log
exit 1
