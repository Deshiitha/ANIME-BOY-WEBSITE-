/** Regression: local-file direct download — no dialog, toast + download event. */
import { chromium } from "playwright";

const browser = await chromium.launch();
const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1280, height: 800 } });
const page = await context.newPage();
await page.goto("http://localhost:3000/#/watch/blade-of-the-emerald-dawn", { waitUntil: "networkidle" });

// 3 options (Original/480p/1080p) → the button opens a menu first (by design).
await page.getByRole("button", { name: /Download Video/ }).first().click();
const menuItem = page.getByRole("menuitem", { name: /Original/ });
const [download] = await Promise.all([
  page.waitForEvent("download", { timeout: 30000 }),
  menuItem.isVisible().catch(() => false)
    ? menuItem.click()
    : page.getByRole("button", { name: /Download Video/ }).first().click(),
]);
console.log("PASS  download event fired (direct local file)");
console.log("      suggested filename:", download.suggestedFilename());
console.log("      url:", download.url());

const dialog = await page.locator('[aria-label="Download your video"]').count();
console.log(dialog === 0 ? "PASS  no dialog for direct files" : `FAIL  dialog appeared (${dialog})`);

const toast = await page
  .locator("[data-sonner-toast]")
  .first()
  .textContent({ timeout: 5000 })
  .catch(() => null);
console.log(toast ? `PASS  toast: ${toast.trim().slice(0, 80)}` : "INFO  toast not captured (may have expired)");

await browser.close();
