/** Final targeted cleanup: remove leftover verification records by slug/email. */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const a = await db.anime.deleteMany({ where: { slug: { contains: "donghua" } } });
  const u = await db.user.deleteMany({
    where: { email: { contains: "animeboy-test.local" } },
  });
  console.log("deleted anime rows:", a.count, "| deleted users:", u.count);
  console.log("remaining donghua:", await db.anime.count({ where: { category: "DONGHUA" } }));
  console.log("total titles:", await db.anime.count());
  const users = await db.user.findMany({ select: { email: true, role: true } });
  console.log("users:", users.map((u) => `${u.email}(${u.role})`).join(", "));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
