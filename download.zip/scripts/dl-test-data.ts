/**
 * Temporary Google Drive download test data for verifying the download-button
 * fix. `set-drive` snapshots the current download fields of the test movie +
 * episode to dl-test-snapshot.json and points them at the real public Drive
 * file; `restore` puts the exact previous values back. Nothing else changes.
 *
 * Usage:
 *   bun scripts/dl-test-data.ts show
 *   bun scripts/dl-test-data.ts set-drive
 *   bun scripts/dl-test-data.ts restore
 */
import { PrismaClient } from "@prisma/client";
import { existsSync, readFileSync, writeFileSync } from "fs";
import path from "path";

const p = new PrismaClient();
const SNAP_PATH = path.join(import.meta.dir, "dl-test-snapshot.json");

const MOVIE_ID = "cmvuksui50002vfkh1ov16f5v"; // Blade of the Emerald Dawn
const EP_ID = "cmvuktalq000gvfm6q3jobfgy"; // Emerald Blade Chronicles #1
const FILE_ID = "1qc_FuGp8bszKFTiZDuOkHS_SaIrcwDuo"; // public 187MB MP4
const DRIVE_SHARE = `https://drive.google.com/file/d/${FILE_ID}/view?usp=sharing`;
const DRIVE_UC = `https://drive.google.com/uc?export=download&id=${FILE_ID}`;

const cmd = process.argv[2] ?? "show";

if (cmd === "show") {
  const movie = await p.anime.findUnique({
    where: { id: MOVIE_ID },
    select: { slug: true, downloadEnabled: true, downloadUrl: true, downloadQualities: true },
  });
  const ep = await p.episode.findUnique({
    where: { id: EP_ID },
    select: { downloadEnabled: true, downloadUrl: true, downloadQualities: true },
  });
  console.log(JSON.stringify({ movie, ep }, null, 2));
} else if (cmd === "set-drive") {
  const movie = await p.anime.findUnique({
    where: { id: MOVIE_ID },
    select: { downloadEnabled: true, downloadUrl: true, downloadQualities: true },
  });
  const ep = await p.episode.findUnique({
    where: { id: EP_ID },
    select: { downloadEnabled: true, downloadUrl: true, downloadQualities: true },
  });
  if (!movie || !ep) throw new Error("test rows missing");
  writeFileSync(SNAP_PATH, JSON.stringify({ movie, ep }, null, 2));
  // Movie: Drive SHARE form (/file/d/FILE_ID/view) as the main download URL.
  await p.anime.update({
    where: { id: MOVIE_ID },
    data: { downloadEnabled: true, downloadUrl: DRIVE_SHARE, downloadQualities: null },
  });
  // Episode: Drive uc form as a per-quality download option.
  await p.episode.update({
    where: { id: EP_ID },
    data: {
      downloadEnabled: true,
      downloadUrl: null,
      downloadQualities: JSON.stringify([{ label: "720p", url: DRIVE_UC }]),
    },
  });
  console.log("drive test data set; snapshot at", SNAP_PATH);
} else if (cmd === "restore") {
  if (!existsSync(SNAP_PATH)) throw new Error("no snapshot found; run set-drive first");
  const snap = JSON.parse(readFileSync(SNAP_PATH, "utf8"));
  await p.anime.update({ where: { id: MOVIE_ID }, data: snap.movie });
  await p.episode.update({ where: { id: EP_ID }, data: snap.ep });
  console.log("restored:", JSON.stringify(snap));
} else {
  console.log("usage: show | set-drive | restore");
}
await p.$disconnect();
