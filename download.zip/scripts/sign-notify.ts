/** Generate a valid PayHere notify md5sig for webhook testing (sandbox secret). */
import { createHash } from "crypto";
const [,, orderId, amount, currency, statusCode, secret] = process.argv;
const md5Upper = (s: string) => createHash("md5").update(s).digest("hex").toUpperCase();
const sig = md5Upper(`TESTMERCHANT1${orderId}${amount}${currency}${statusCode}${md5Upper(secret)}`);
console.log(sig);
