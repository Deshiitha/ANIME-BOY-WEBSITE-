/** E2E check of the subtitle `enabled` flag pipeline: admin PATCH → public API. */
const BASE = "http://localhost:3000";

async function main() {
  // 1. admin login
  const login = await fetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "admin@animeboy.lk", password: "AnimeBoy@2024" }),
  });
  const setCookie = login.headers.get("set-cookie") || "";
  const cookie = setCookie.split(";")[0];
  console.log("login:", login.status, cookie ? "cookie ok" : "NO COOKIE");

  // 2. fetch current blade movie row via admin endpoint (find id)
  const list = await fetch(`${BASE}/api/admin/anime`, { headers: { cookie } });
  const listJson = await list.json();
  const items = listJson.anime || listJson.items || listJson;
  const blade = (Array.isArray(items) ? items : []).find((a: { slug: string }) => a.slug === "blade-of-the-emerald-dawn");
  console.log("blade found:", !!blade, "id:", blade?.id);

  // 3. PATCH: disable the English track
  const subs = [
    { label: "සිංහල", lang: "si", url: "/api/files/subtitles/blade-of-the-emerald-dawn-si.srt", enabled: true },
    { label: "English", lang: "en", url: "/api/files/subtitles/blade-of-the-emerald-dawn-en.vtt", enabled: false },
  ];
  const patch = await fetch(`${BASE}/api/admin/anime/${blade.id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", cookie },
    body: JSON.stringify({ subtitleTracks: subs }),
  });
  console.log("patch(en disabled):", patch.status, JSON.stringify(await patch.json()).slice(0, 120));

  // 4. public API should only expose the si track in video.subtitles
  const pub = await fetch(`${BASE}/api/anime/blade-of-the-emerald-dawn`);
  const pubJson = await pub.json();
  const videoSubs = pubJson.anime?.video?.subtitles || [];
  console.log("public subtitles after disable:", JSON.stringify(videoSubs));

  // 5. restore both enabled
  const subsRestored = subs.map((s) => ({ ...s, enabled: true }));
  const patch2 = await fetch(`${BASE}/api/admin/anime/${blade.id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", cookie },
    body: JSON.stringify({ subtitleTracks: subsRestored }),
  });
  console.log("patch(restore):", patch2.status);
  const pub2 = await fetch(`${BASE}/api/anime/blade-of-the-emerald-dawn`);
  const pub2Json = await pub2.json();
  console.log("public subtitles after restore:", JSON.stringify((pub2Json.anime?.video?.subtitles || []).map((s: { lang: string; enabled?: boolean }) => ({ lang: s.lang, enabled: s.enabled ?? true }))));
}
main().catch((e) => {
  console.error("E2E FAILED:", e);
  process.exit(1);
});
