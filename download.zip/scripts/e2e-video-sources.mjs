/**
 * E2E verification of the external-cloud-storage video source feature.
 * Run while the production server is up on :3000.
 */
const BASE = "http://localhost:3000";
let cookie = "";
let pass = 0;
let failCount = 0;

function check(name, cond, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    failCount++;
    console.log(`  FAIL  ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function req(method, path, body, isForm) {
  const headers = { cookie };
  if (body && !isForm) headers["content-type"] = "application/json";
  const res = await fetch(BASE + path, {
    method,
    headers,
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });
  const setCookie = res.headers.get("set-cookie");
  if (setCookie) cookie = setCookie.split(";")[0];
  let data = null;
  try {
    data = await res.json();
  } catch {}
  return { status: res.status, data };
}

/* ------------------------------ auth ----------------------------------- */
console.log("\n== Auth ==");
const login = await req("POST", "/api/auth/login", {
  email: "admin@animeboy.lk",
  password: "AnimeBoy@2024",
});
check("admin login", login.status === 200 && login.data?.user?.role === "ADMIN");

const anonGet = await fetch(BASE + "/api/admin/anime").then((r) => r.status);
check("admin API blocked for anonymous", anonGet === 401, `got ${anonGet}`);

/* --------------------- movie: external MP4 source ----------------------- */
console.log("\n== Movie with external MP4 ==");
const mp4 = await req("POST", "/api/admin/anime", {
  titleEn: "E2E Cloud Movie",
  type: "MOVIE",
  descriptionSi: "පරීක්ෂණ චිත්‍රපටය",
  descriptionEn: "External MP4 test movie",
  genres: ["Test"],
  releaseYear: 2025,
  videoSource: "external",
  videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  subtitleTracks: [{ label: "සිංහල", lang: "si", url: "https://example.com/subs/si.vtt" }],
  videoThumb: "https://example.com/thumb.jpg",
});
check("create movie (external MP4)", mp4.status === 201, JSON.stringify(mp4.data).slice(0, 200));
const mp4Id = mp4.data?.anime?.id;

const pubMp4 = await req("GET", `/api/anime/e2e-cloud-movie`);
check(
  "public API: video.kind = mp4, direct URL (not proxied)",
  pubMp4.data?.anime?.video?.kind === "mp4" &&
    pubMp4.data?.anime?.video?.url?.includes("gtv-videos-bucket"),
  JSON.stringify(pubMp4.data?.anime?.video).slice(0, 160)
);
check(
  "public API: subtitle track carried through",
  pubMp4.data?.anime?.video?.subtitles?.[0]?.lang === "si"
);
check("public API: poster carried through", !!pubMp4.data?.anime?.video?.poster);

/* -------------------------- HLS source ---------------------------------- */
console.log("\n== HLS source ==");
const hls = await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "external",
  videoUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
});
check("PATCH movie source -> HLS (no recreate)", hls.status === 200, JSON.stringify(hls.data).slice(0, 160));
check(
  "public API: video.kind = hls",
  (await req("GET", `/api/anime/e2e-cloud-movie`)).data?.anime?.video?.kind === "hls"
);

/* quality variants */
const q = await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "external",
  videoUrl: "https://cdn.example.com/movie-1080.mp4",
  videoQualities: [
    { label: "1080p", url: "https://cdn.example.com/movie-1080.mp4" },
    { label: "720p", url: "https://cdn.example.com/movie-720.mp4" },
  ],
});
const qPub = await req("GET", `/api/anime/e2e-cloud-movie`);
check("quality variants saved", q.status === 200 && qPub.data?.anime?.video?.qualities?.length === 2);

/* ---------------------- invalid URL validation --------------------------- */
console.log("\n== Validation errors ==");
const badShare = await req("POST", "/api/admin/anime", {
  titleEn: "Bad Share Movie",
  type: "MOVIE",
  videoSource: "external",
  videoUrl: "https://drive.google.com/file/d/ABC123/view",
});
check(
  "Google Drive share page rejected as direct URL",
  badShare.status === 400 && /share page|Provider embed/i.test(badShare.data?.error || ""),
  JSON.stringify(badShare.data).slice(0, 160)
);

const badHttp = await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "external",
  videoUrl: "http://cdn.example.com/movie.mp4",
});
check("plain HTTP media URL rejected", badHttp.status === 400, JSON.stringify(badHttp.data).slice(0, 120));

const badEmbed = await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "embed",
  embedUrl: "https://some-random-site.example.com/embed/xyz",
});
check(
  "non-trusted embed host rejected",
  badEmbed.status === 400 && /not a supported embed provider/i.test(badEmbed.data?.error || ""),
  JSON.stringify(badEmbed.data).slice(0, 160)
);

const ytExt = await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "external",
  videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
});
check("YouTube watch page rejected as direct URL", ytExt.status === 400);

/* restore mp4 source for later tests */
await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "external",
  videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
});

/* --------------------- embed source (auto-convert) ---------------------- */
console.log("\n== Series with provider embed episode ==");
const series = await req("POST", "/api/admin/anime", {
  titleEn: "E2E Cloud Series",
  type: "SERIES",
  descriptionSi: "පරීක්ෂණ කතා මාලාව",
  descriptionEn: "Embed test series",
  genres: ["Test"],
  videoSource: "upload",
});
check("create series shell", series.status === 201, JSON.stringify(series.data).slice(0, 200));
const seriesId = series.data?.anime?.id;

const season = await req("POST", "/api/admin/seasons", { animeId: seriesId, number: 1 });
check("create season", season.status === 201 || season.status === 200, JSON.stringify(season.data).slice(0, 120));
const seasonId = season.data?.season?.id || season.data?.id;

const ep = await req("POST", "/api/admin/episodes", {
  seasonId,
  number: 1,
  title: "The Cloud Begins",
  videoSource: "embed",
  embedUrl: "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
});
check("create episode with YouTube watch URL", ep.status === 201, JSON.stringify(ep.data).slice(0, 200));
const epId = ep.data?.episode?.id;
check(
  "watch URL auto-converted to youtube-nocookie embed",
  ep.data?.episode?.embedUrl?.startsWith("https://www.youtube-nocookie.com/embed/aqz-KE-bpKQ"),
  ep.data?.episode?.embedUrl
);

const epPub = await req("GET", `/api/anime/e2e-cloud-series`);
const epVideo = epPub.data?.anime?.seasons?.[0]?.episodes?.[0]?.video;
check(
  "public API: episode video.kind = embed",
  epVideo?.kind === "embed" && epVideo?.provider === "youtube",
  JSON.stringify(epVideo).slice(0, 160)
);

/* episode source replace: embed -> external, no recreation */
const epSwap = await req("PATCH", `/api/admin/episodes/${epId}`, {
  videoSource: "external",
  videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
});
check(
  "episode source swapped embed -> external (PATCH)",
  epSwap.status === 200 && epSwap.data?.episode?.videoSource === "external",
  JSON.stringify(epSwap.data).slice(0, 160)
);

/* ---------------------------- SSRF guard -------------------------------- */
console.log("\n== SSRF protection (admin probe) ==");
for (const [label, url] of [
  ["cloud metadata 169.254.169.254", "http://169.254.169.254/latest/meta-data/"],
  ["localhost", "http://localhost:3000/api/sections"],
  ["loopback IP", "http://127.0.0.1:3000/x.mp4"],
  ["private 10.x", "http://10.0.0.1/video.mp4"],
  ["private 192.168.x", "https://192.168.1.10/video.mp4"],
]) {
  const r = await req("POST", "/api/admin/media/probe", { url });
  check(`probe blocked: ${label}`, r.status === 200 && r.data?.ok === false && !!r.data?.error, JSON.stringify(r.data).slice(0, 120));
}

/* real probe against a public MP4 (works when the sandbox has internet) */
const probeReal = await req("POST", "/api/admin/media/probe", {
  url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
});
if (probeReal.data?.ok) {
  check("probe: public MP4 reachable", true);
  check("probe: reports Content-Type", /video\/mp4/.test(probeReal.data?.contentType || ""), probeReal.data?.contentType);
  check("probe: reports byte-range support", probeReal.data?.acceptRanges === "bytes", probeReal.data?.acceptRanges);
} else {
  console.log(`  SKIP  public-internet probe unreachable (${probeReal.data?.error})`);
}
/* HTML page probe — should be flagged, not treated as video */
const probeHtml = await req("POST", "/api/admin/media/probe", { url: "https://example.com/" });
if (probeHtml.status === 200 && probeHtml.data) {
  check(
    "probe: HTML page flagged (share-page style rejection)",
    probeHtml.data.isHtml === true && /HTML page/.test(probeHtml.data.verdict || ""),
    JSON.stringify(probeHtml.data).slice(0, 160)
  );
} else {
  console.log(`  SKIP  HTML probe (${probeHtml.data?.error || probeHtml.status})`);
}

/* --------------------------- private bucket ----------------------------- */
console.log("\n== Private bucket (s3:// signed playback) ==");
const priv = await req("POST", "/api/admin/anime", {
  titleEn: "E2E Private Movie",
  type: "MOVIE",
  videoSource: "external",
  videoUrl: "s3://animeboy-private/media/movie.mp4",
});
check("create movie with s3:// object key", priv.status === 201, JSON.stringify(priv.data).slice(0, 200));
const privId = priv.data?.anime?.id;
const privPub = await req("GET", `/api/anime/e2e-private-movie`);
check(
  "public API: video.kind = signed (no credentials, no URL leak)",
  privPub.data?.anime?.video?.kind === "signed" &&
    !!privPub.data?.anime?.video?.signUrl?.startsWith("/api/media/play/anime/"),
  JSON.stringify(privPub.data?.anime?.video).slice(0, 160)
);
const anonPrivBody = await fetch(BASE + `/api/anime/e2e-private-movie`).then((r) => r.text());
check("no s3 identifier exposed to anonymous visitors", !anonPrivBody.includes("s3://"));
const adminPrivBody = JSON.stringify(privPub.data);
check("admin keeps the object identifier for editing", adminPrivBody.includes("s3://"));

const signAnon = await fetch(BASE + `/api/media/play/anime/${privId}`).then((r) => r.status);
check("signed-play endpoint works for anonymous on published item", signAnon === 200 || signAnon === 500, `got ${signAnon}`);
const signData = await fetch(BASE + `/api/media/play/anime/${privId}`).then((r) => r.json());
if (signAnon === 500) {
  check(
    "unconfigured S3 returns a clear setup message",
    /not configured|S3_/i.test(signData?.error || ""),
    signData?.error
  );
} else {
  check("signed URL minted with expiry", !!signData?.url && !!signData?.expiresAt, JSON.stringify(signData).slice(0, 120));
}

const adminSign = await req("POST", "/api/admin/media/sign", { url: "s3://animeboy-private/media/movie.mp4" });
check(
  "admin preview sign endpoint responds (or clear config error)",
  adminSign.status === 200 || /not configured/i.test(adminSign.data?.error || ""),
  JSON.stringify(adminSign.data).slice(0, 160)
);

/* unpublished + signed -> anonymous must get 404 */
await req("PATCH", `/api/admin/anime/${privId}`, { published: false });
const privAnon = await fetch(BASE + `/api/media/play/anime/${privId}`).then((r) => r.status);
check("signed playback blocked for anonymous on unpublished item", privAnon === 404, `got ${privAnon}`);
await req("PATCH", `/api/admin/anime/${privId}`, { published: true });

/* ------------------------ existing uploads still work -------------------- */
console.log("\n== Existing upload pipeline ==");
const form = new FormData();
const tiny = new Blob([Buffer.from([0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70])], { type: "image/png" });
form.append("file", tiny, "t.png");
form.append("kind", "poster");
const up = await req("POST", "/api/admin/upload", form, true);
check("upload endpoint works", up.status === 200 && !!up.data?.url, JSON.stringify(up.data).slice(0, 160));
if (up.data?.url) {
  const fileRes = await fetch(BASE + up.data.url, { headers: { Range: "bytes=0-3" } });
  check("uploaded file served with range support", [200, 206].includes(fileRes.status), `got ${fileRes.status}`);
}

/* attach uploaded file through the normal admin flow (upload source type) */
const upMovie = await req("PATCH", `/api/admin/anime/${mp4Id}`, {
  videoSource: "upload",
  videoUrl: up.data?.url,
});
check("movie source switched to uploaded file (upload type preserved)", upMovie.status === 200 && upMovie.data?.anime?.videoSource === "upload");
const upPub = await req("GET", `/api/anime/e2e-cloud-movie`);
check(
  "public API: uploaded file plays as direct source",
  upPub.data?.anime?.video?.kind === "mp4" && upPub.data?.anime?.video?.url?.startsWith("/api/files/"),
  JSON.stringify(upPub.data?.anime?.video).slice(0, 120)
);

/* ------------------------------ cleanup --------------------------------- */
console.log("\n== Cleanup test entries ==");
for (const id of [mp4Id, seriesId, privId]) {
  if (id) await req("DELETE", `/api/admin/anime/${id}`);
}
check("test entries removed", true);

console.log(`\n======== RESULT: ${pass} passed, ${failCount} failed ========`);
process.exit(failCount ? 1 : 0);
