import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const rows = await db.anime.findMany({
  select: { id: true, slug: true, type: true, category: true, titleEn: true, published: true, featured: true, seasons: { select: { number: true, _count: { select: { episodes: true } } } } },
  orderBy: { createdAt: "asc" },
});

console.log(JSON.stringify(rows, null, 2));
console.log("total:", rows.length);
await db.$disconnect();
