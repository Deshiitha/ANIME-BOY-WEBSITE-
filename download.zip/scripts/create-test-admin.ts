/** Creates a temporary admin for donation-system verification (deleted on restore). */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const suffix = Date.now().toString(36).slice(-5);
  const passwordHash = await bcrypt.hash("PayTest-2026!", 10);
  const admin = await db.user.create({
    data: { email: `pay-verify-${suffix}@animeboy-test.local`, name: "Pay Verify Admin", passwordHash, role: "ADMIN" },
  });
  console.log("ADMIN_EMAIL=" + admin.email);
}

main().finally(() => db.$disconnect());
