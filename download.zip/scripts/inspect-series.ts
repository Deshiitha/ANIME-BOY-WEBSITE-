import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const all = await db.anime.findMany({
    orderBy: { createdAt: "asc" },
    select: { id: true, slug: true, type: true, category: true, titleEn: true, published: true, videoUrl: true, _count: { select: { seasons: true } } },
  });
  console.log("=== ANIME ===");
  for (const a of all) {
    console.log(`${a.type} [${a.category}] ${a.titleEn} (${a.slug}) id=${a.id} published=${a.published} seasons=${a._count.seasons} videoUrl=${a.videoUrl?.slice(0, 50) ?? "-"}`);
    if (a.type === "SERIES") {
      const seasons = await db.season.findMany({
        where: { animeId: a.id },
        orderBy: { number: "asc" },
        include: { episodes: { orderBy: { number: "asc" }, select: { id: true, number: true, title: true, videoUrl: true, thumbnailUrl: true } } },
      });
      for (const s of seasons) {
        console.log(`  S${s.number}${s.title ? ` "${s.title}"` : ""} id=${s.id}`);
        for (const e of s.episodes) {
          console.log(`    E${e.number}${e.title ? ` "${e.title}"` : ""} id=${e.id} video=${e.videoUrl?.slice(0, 60) ?? "NONE"} thumb=${e.thumbnailUrl ? "yes" : "no"}`);
        }
      }
    }
  }
  const users = await db.user.findMany({ where: { role: "ADMIN" }, select: { email: true, name: true } });
  console.log("=== ADMINS ===", users);
}

main().finally(() => db.$disconnect());
