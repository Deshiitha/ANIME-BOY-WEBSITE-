/**
 * Remove demo/placeholder media references from published content.
 *
 * The seed data pointed movies and episodes at ffmpeg-generated demo clips
 * ("ANIME BOY Sample Episode N") and a demo subtitle (demo-si.vtt). Per the
 * download-fix spec the site must never play or serve placeholder files:
 *  - every stored URL that references a demo file is stripped (string fields
 *    nulled, JSON arrays filtered);
 *  - download / subtitle-download toggles are recomputed so a title with no
 *    real file reports honestly "not available" instead of offering a demo.
 *
 * Idempotent: running it twice changes nothing the second time.
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const DEMO_MARKERS = ["sample-ep-", "demo-si"];

function isDemoRef(value: unknown): boolean {
  if (typeof value !== "string") return false;
  const v = value.toLowerCase();
  return DEMO_MARKERS.some((m) => v.includes(m));
}

/** Filter a JSON array column, dropping rows whose url/embedUrl is a demo ref. */
function filterJsonArray(raw: string | null, urlKeys: string[]): string | null {
  if (!raw) return null;
  let rows: Record<string, unknown>[];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return null;
    rows = parsed as Record<string, unknown>[];
  } catch {
    return null;
  }
  const kept = rows.filter((row) => row && !urlKeys.some((k) => isDemoRef(row[k])));
  return kept.length ? JSON.stringify(kept) : null;
}

type Report = { model: string; id: string; title: string; cleared: string[]; kept: string[] };

async function cleanAnime(): Promise<Report[]> {
  const rows = await db.anime.findMany();
  const out: Report[] = [];
  for (const row of rows) {
    const cleared: string[] = [];
    const data: Record<string, unknown> = {};

    for (const field of ["videoUrl", "downloadUrl", "subtitleUrl", "videoThumb", "embedUrl"] as const) {
      if (isDemoRef(row[field])) {
        data[field] = null;
        cleared.push(field);
      }
    }

    const arrays: [string, string[]][] = [
      ["videoQualities", ["url"]],
      ["downloadQualities", ["url"]],
      ["subtitleTracks", ["url"]],
      ["subtitleDownloads", ["url"]],
      ["altSources", ["url", "embedUrl"]],
    ];
    for (const [field, keys] of arrays) {
      const raw = row[field] as string | null;
      if (!raw) continue;
      let hadDemo = false;
      try {
        const parsed = JSON.parse(raw);
        hadDemo = Array.isArray(parsed) && parsed.some((r) => r && keys.some((k) => isDemoRef(r[k])));
      } catch {
        hadDemo = false;
      }
      if (!hadDemo) continue;
      const next = filterJsonArray(raw, keys);
      data[field] = next;
      cleared.push(field);
    }

    if (!cleared.length) {
      out.push({ model: "Anime", id: row.id, title: row.titleEn, cleared: [], kept: ["(untouched)"] });
      continue;
    }

    // Recompute the toggles so no button claims availability without a file.
    const nextDownloadUrl = "downloadUrl" in data ? (data.downloadUrl as string | null) : row.downloadUrl;
    const nextDq =
      "downloadQualities" in data ? (data.downloadQualities as string | null) : row.downloadQualities;
    const hasDownloadFile = !!nextDownloadUrl || !!(nextDq && JSON.parse(nextDq).length > 0);
    if (row.downloadEnabled && !hasDownloadFile) {
      data.downloadEnabled = false;
      cleared.push("downloadEnabled→false");
    }
    const nextSd =
      "subtitleDownloads" in data ? (data.subtitleDownloads as string | null) : row.subtitleDownloads;
    if (row.subtitleDownloadEnabled && !(nextSd && JSON.parse(nextSd).length > 0)) {
      data.subtitleDownloadEnabled = false;
      cleared.push("subtitleDownloadEnabled→false");
    }

    await db.anime.update({ where: { id: row.id }, data });
    out.push({ model: "Anime", id: row.id, title: row.titleEn, cleared, kept: [] });
  }
  return out;
}

async function cleanEpisodes(): Promise<Report[]> {
  const rows = await db.episode.findMany({ include: { season: { select: { animeId: true } } } });
  const out: Report[] = [];
  for (const row of rows) {
    const cleared: string[] = [];
    const data: Record<string, unknown> = {};

    for (const field of ["videoUrl", "downloadUrl", "subtitleUrl", "videoThumb"] as const) {
      if (isDemoRef(row[field])) {
        data[field] = null;
        cleared.push(field);
      }
    }

    const arrays: [string, string[]][] = [
      ["videoQualities", ["url"]],
      ["downloadQualities", ["url"]],
      ["subtitleTracks", ["url"]],
      ["subtitleDownloads", ["url"]],
      ["altSources", ["url", "embedUrl"]],
    ];
    for (const [field, keys] of arrays) {
      const raw = row[field] as string | null;
      if (!raw) continue;
      let hadDemo = false;
      try {
        const parsed = JSON.parse(raw);
        hadDemo = Array.isArray(parsed) && parsed.some((r) => r && keys.some((k) => isDemoRef(r[k])));
      } catch {
        hadDemo = false;
      }
      if (!hadDemo) continue;
      const next = filterJsonArray(raw, keys);
      data[field] = next;
      cleared.push(field);
    }

    if (!cleared.length) continue;

    const nextDownloadUrl = "downloadUrl" in data ? (data.downloadUrl as string | null) : row.downloadUrl;
    const nextDq =
      "downloadQualities" in data ? (data.downloadQualities as string | null) : row.downloadQualities;
    const hasDownloadFile = !!nextDownloadUrl || !!(nextDq && JSON.parse(nextDq).length > 0);
    if (row.downloadEnabled && !hasDownloadFile) {
      data.downloadEnabled = false;
      cleared.push("downloadEnabled→false");
    }
    const nextSd =
      "subtitleDownloads" in data ? (data.subtitleDownloads as string | null) : row.subtitleDownloads;
    if (row.subtitleDownloadEnabled && !(nextSd && JSON.parse(nextSd).length > 0)) {
      data.subtitleDownloadEnabled = false;
      cleared.push("subtitleDownloadEnabled→false");
    }

    await db.episode.update({ where: { id: row.id }, data });
    const seasonNo = row.season?.animeId ? "" : "";
    out.push({ model: "Episode", id: row.id, title: `${row.title}${seasonNo}`, cleared, kept: [] });
  }
  return out;
}

async function main() {
  console.log("=== Scanning Anime + Episode rows for demo media references ===");
  const animeReports = await cleanAnime();
  const epReports = await cleanEpisodes();

  let touched = 0;
  for (const r of [...animeReports, ...epReports]) {
    if (r.cleared.length) {
      touched++;
      console.log(`CLEANED ${r.model} "${r.title}" (${r.id}): ${r.cleared.join(", ")}`);
    }
  }
  console.log(`\nRows scanned: ${animeReports.length} anime, ${epReports.length} episodes`);
  console.log(`Rows cleaned: ${touched}`);

  // Safety scan: no demo reference may remain anywhere in either table.
  const animes = await db.anime.findMany();
  const eps = await db.episode.findMany();
  const leftovers: string[] = [];
  const scan = (model: string, id: string, row: Record<string, unknown>) => {
    for (const [k, v] of Object.entries(row)) {
      if (typeof v === "string" && isDemoRef(v)) leftovers.push(`${model}/${id}/${k}`);
      if (v !== null && typeof v === "object") {
        const s = JSON.stringify(v);
        if (isDemoRef(s)) leftovers.push(`${model}/${id}/${k} (json)`);
      }
    }
  };
  animes.forEach((a) => scan("Anime", a.id, a as unknown as Record<string, unknown>));
  eps.forEach((e) => scan("Episode", e.id, e as unknown as Record<string, unknown>));

  if (leftovers.length) {
    console.error("LEFTOVER demo references:", leftovers);
    process.exit(1);
  }
  console.log("Verify pass: no demo media references remain in Anime/Episode rows ✓");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
