/**
 * Phase 4 verification: "Download buttons below the video player".
 * Run while the server is up on :3000. Covers:
 *  - admin download config (toggles, main URL, per-quality files, per-language subtitle files)
 *  - public download metadata without leaking URLs
 *  - anonymous download resolution (direct / open fallback / errors)
 *  - per-episode downloads match the currently selected episode
 *  - error handling: disabled option, bad index, dead link, missing file
 *  - /api/files/ uploads, s3:// private bucket, HLS-as-download rejection
 */
const BASE = "http://localhost:3000";
let cookie = "";
let pass = 0;
let failCount = 0;

function check(name, cond, detail = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    failCount++;
    console.log(`  FAIL  ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function req(method, path, body, isForm) {
  const headers = { cookie };
  if (body && !isForm) headers["content-type"] = "application/json";
  const res = await fetch(BASE + path, {
    method,
    headers,
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });
  const setCookie = res.headers.get("set-cookie");
  if (setCookie) cookie = setCookie.split(";")[0];
  let data = null;
  try {
    data = await res.json();
  } catch {}
  return { status: res.status, data };
}

const MP4_A = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4";
const MP4_B = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_2MB.mp4";
const DEAD_URL = "https://test-videos.co.uk/vids/definitely-missing-file-404.mp4";
// Absolute same-origin URL on purpose: exercises the self-hosted /api/files/ normalisation.
const VTT_URL = `${BASE}/api/files/subtitles/demo-si.vtt`;

console.log("\n== Auth ==");
const login = await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" });
check("admin login", login.status === 200 && login.data?.user?.role === "ADMIN");

const created = []; // { kind: "anime"|"season"|"episode", id }

/* ------------------------- movie with downloads ------------------------- */
console.log("\n== Movie: full download config ==");
const movie = await req("POST", "/api/admin/anime", {
  titleEn: "E2E Download Movie",
  type: "MOVIE",
  descriptionSi: "බාගැනීම් පරීක්ෂණය",
  genres: ["Test"],
  releaseYear: 2025,
  videoSource: "external",
  videoUrl: MP4_B,
  downloadEnabled: true,
  downloadUrl: MP4_A,
  downloadQualities: [
    { label: "1080p", url: MP4_B },
    { label: "360p", url: MP4_A },
  ],
  subtitleDownloadEnabled: true,
  subtitleDownloads: [
    { label: "සිංහල", lang: "si", url: VTT_URL },
    { label: "English", lang: "en", url: VTT_URL },
  ],
});
check("create movie with video+subtitle downloads", movie.status === 201, JSON.stringify(movie.data).slice(0, 200));
const movieId = movie.data?.anime?.id;
if (movieId) created.push({ kind: "anime", id: movieId });

const pubMovie = await req("GET", "/api/anime/e2e-download-movie");
const mv = pubMovie.data?.anime;
check("public API: downloads.video.enabled", mv?.downloads?.video?.enabled === true, JSON.stringify(mv?.downloads).slice(0, 200));
check("public API: 3 video download options (Original + 2 qualities)", mv?.downloads?.video?.options?.length === 3, JSON.stringify(mv?.downloads?.video?.options));
check("public API: subtitle options carry lang but never URLs", mv?.downloads?.subtitles?.options?.length === 2 && JSON.stringify(mv.downloads.subtitles.options).includes('"lang":"si"') && !JSON.stringify(mv.downloads).includes(MP4_A), JSON.stringify(mv?.downloads?.subtitles?.options));

console.log("\n== Anonymous download resolution ==");
const anon = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=0`);
check("resolve main video download (200)", anon.status === 200, JSON.stringify(anon.data).slice(0, 200));
check("resolution points at the storage host, not this site", typeof anon.data?.url === "string" && /^https?:\/\//.test(anon.data.url), anon.data?.url);
check("mode is direct|open", ["direct", "open"].includes(anon.data?.mode), anon.data?.mode);
check("meaningful filename", /E2E-Download-Movie/i.test(anon.data?.filename || ""), anon.data?.filename);
check("format detected as MP4", anon.data?.format === "MP4", anon.data?.format);

const q1 = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=2`);
check("per-quality option resolves (360p)", q1.status === 200 && q1.data?.url === MP4_A, JSON.stringify({ url: q1.data?.url, status: q1.status }));

const sub = await req("GET", `/api/media/download/anime/${movieId}?kind=subtitle&index=0`);
check("subtitle download resolves", sub.status === 200 && /\.vtt|\.srt/.test(sub.data?.filename || ""), JSON.stringify(sub.data).slice(0, 160));
check("subtitle filename carries language", /-si\./i.test(sub.data?.filename || ""), sub.data?.filename);

const badIdx = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=9`);
check("invalid index rejected with clear error", badIdx.status === 404 && !!badIdx.data?.error, JSON.stringify(badIdx.data));
const badKind = await req("GET", `/api/media/download/anime/${movieId}?kind=playlist&index=0`);
check("unknown kind treated as video (or 404), no crash", badKind.status === 200 || badKind.status === 404);

/* --------------------------- episode downloads -------------------------- */
console.log("\n== Series: per-episode download files ==");
const series = await req("POST", "/api/admin/anime", {
  titleEn: "E2E Download Series",
  type: "SERIES",
  descriptionSi: "බාගැනීම් පරීක්ෂණ කතාමාලාව",
  genres: ["Test"],
  releaseYear: 2025,
});
const seriesId = series.data?.anime?.id;
if (seriesId) created.push({ kind: "anime", id: seriesId });
const season = await req("POST", "/api/admin/seasons", { animeId: seriesId, number: 1 });
const seasonId = season.data?.season?.id || season.data?.id;

const ep1 = await req("POST", "/api/admin/episodes", {
  seasonId,
  number: 1,
  title: "One",
  videoSource: "external",
  videoUrl: MP4_A,
  downloadEnabled: true,
  downloadUrl: MP4_A,
  subtitleDownloadEnabled: true,
  subtitleDownloads: [{ label: "සිංහල", lang: "si", url: VTT_URL }],
});
const ep1Id = ep1.data?.episode?.id;
check("create E1 with its own download file", ep1.status === 201 && !!ep1Id, JSON.stringify(ep1.data).slice(0, 160));

const ep2 = await req("POST", "/api/admin/episodes", {
  seasonId,
  number: 2,
  title: "Two",
  videoSource: "external",
  videoUrl: MP4_B,
  downloadEnabled: true,
  downloadUrl: MP4_B,
});
const ep2Id = ep2.data?.episode?.id;
check("create E2 with a different download file", ep2.status === 201 && !!ep2Id, JSON.stringify(ep2.data).slice(0, 160));
if (ep1Id) created.push({ kind: "episode", id: ep1Id });
if (ep2Id) created.push({ kind: "episode", id: ep2Id });

const r1 = await req("GET", `/api/media/download/episode/${ep1Id}?kind=video&index=0`);
const r2 = await req("GET", `/api/media/download/episode/${ep2Id}?kind=video&index=0`);
check("E1 download resolves to E1's file", r1.status === 200 && r1.data?.url === MP4_A, r1.data?.url);
check("E2 download resolves to E2's file (current-episode matching)", r2.status === 200 && r2.data?.url === MP4_B, r2.data?.url);
check("episode filenames carry S01E01 / S01E02", /S01E01/.test(r1.data?.filename || "") && /S01E02/.test(r2.data?.filename || ""), `${r1.data?.filename} | ${r2.data?.filename}`);

const pubSeries = await req("GET", "/api/anime/e2e-download-series");
const eps = pubSeries.data?.anime?.seasons?.[0]?.episodes || [];
check("public series API: downloads are per-episode", eps?.[0]?.downloads?.video?.enabled === true && eps?.[1]?.downloads?.video?.enabled === true, JSON.stringify(eps?.map((e) => e.downloads?.video?.enabled)));
check("E2 (no subtitles configured) hides subtitle button", eps?.[1]?.downloads?.subtitles?.enabled === false, JSON.stringify(eps?.[1]?.downloads?.subtitles));

/* ------------------------------ error states ---------------------------- */
console.log("\n== Error handling ==");
const dead = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=-1`);
check("negative index rejected", dead.status === 400 || dead.status === 404, `${dead.status}`);

// dead link: temporarily add a 404 file as an extra quality, then resolve it
const addDead = await req("PATCH", `/api/admin/anime/${movieId}`, {
  downloadQualities: [{ label: "dead", url: DEAD_URL }],
});
check("admin can save a (later-dead) quality file", addDead.status === 200, JSON.stringify(addDead.data).slice(0, 120));
const deadRes = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=1`);
check("dead external file → 404 with clear message", deadRes.status === 404 && /no longer exists|expired|moved/i.test(deadRes.data?.error || ""), JSON.stringify(deadRes.data));

const rmDead = await req("PATCH", `/api/admin/anime/${movieId}`, { downloadQualities: [] });
check("remove dead file again", rmDead.status === 200);

/* ------------------------ toggle off + validation ----------------------- */
console.log("\n== Toggle off & validation ==");
const off = await req("PATCH", `/api/admin/anime/${movieId}`, { downloadEnabled: false, subtitleDownloadEnabled: false });
const pubOff = await req("GET", "/api/anime/e2e-download-movie");
check("toggles off → public API hides download options", pubOff.data?.anime?.downloads?.video?.enabled === false && pubOff.data?.anime?.downloads?.subtitles?.enabled === false, JSON.stringify(pubOff.data?.anime?.downloads));
const offResolve = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=0`);
check("resolve after toggle-off → 404 (button hidden client-side too)", offResolve.status === 404, JSON.stringify(offResolve.data));

const hlsDl = await req("PATCH", `/api/admin/anime/${movieId}`, { downloadEnabled: true, downloadUrl: "https://cdn.example.com/stream/master.m3u8" });
check("HLS playlist rejected as a download file", hlsDl.status === 400 && /HLS|m3u8|streaming manifest/i.test(hlsDl.data?.error || ""), JSON.stringify(hlsDl.data));
const embedDl = await req("PATCH", `/api/admin/anime/${movieId}`, { downloadUrl: "https://www.youtube.com/watch?v=abc" });
check("provider page rejected as a download file", embedDl.status === 400, JSON.stringify(embedDl.data));

const enabledNoUrl = await req("POST", "/api/admin/anime", {
  titleEn: "E2E Bad Dl",
  type: "MOVIE",
  downloadEnabled: true,
});
check("enable download without URL → validation error", enabledNoUrl.status === 400 && /download URL/i.test(enabledNoUrl.data?.error || ""), JSON.stringify(enabledNoUrl.data));

/* ------------------------ site-hosted upload file ----------------------- */
console.log("\n== Site-hosted upload as download ==");
const up = await req("POST", "/api/admin/upload", (() => {
  const f = new FormData();
  f.append("file", new Blob(["WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nhi\n"], { type: "text/vtt" }), "dl-test.vtt");
  f.append("kind", "subtitle");
  return f;
})(), true);
check("upload subtitle file", up.status === 200 && !!up.data?.url, JSON.stringify(up.data).slice(0, 120));
if (up.data?.url) {
  const on = await req("PATCH", `/api/admin/anime/${movieId}`, { subtitleDownloadEnabled: true, subtitleDownloads: [{ label: "සිංහල", lang: "si", url: up.data.url }] });
  const upRes = await req("GET", `/api/media/download/anime/${movieId}?kind=subtitle&index=0`);
  check("upload-based subtitle download resolves same-origin with ?download=1", upRes.status === 200 && upRes.data?.url?.includes("download=1") && typeof upRes.data?.sizeBytes === "number", JSON.stringify(upRes.data).slice(0, 200));
}

/* --------------------------- private bucket s3:// ----------------------- */
console.log("\n== Private bucket download identifier ==");
const s3Save = await req("PATCH", `/api/admin/anime/${movieId}`, { downloadEnabled: true, downloadUrl: "s3://anime-media/e2e/movie.mp4" });
check("s3:// download identifier accepted at save time", s3Save.status === 200, JSON.stringify(s3Save.data).slice(0, 120));
// Check scrubbing as an anonymous visitor (admins intentionally keep identifiers for editing)
cookie = "";
const pubS3 = await req("GET", "/api/anime/e2e-download-movie");
const s3Str = JSON.stringify(pubS3.data) || "";
const s3At = s3Str.indexOf("s3://");
check(
  "public payload never exposes the s3:// identifier",
  s3At === -1,
  `context: ${s3At >= 0 ? s3Str.slice(Math.max(0, s3At - 200), s3At + 120) : "-"}`
);
const s3Res = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=0`);
check("s3:// resolve → signed link or clear setup message (no crash)", (s3Res.status === 200 && /^https?:/.test(s3Res.data?.url || "")) || (s3Res.status >= 400 && /configured|S3_/i.test(s3Res.data?.error || "")), JSON.stringify(s3Res.data).slice(0, 200));

/* --------------------------- anonymous security ------------------------- */
console.log("\n== Security ==");
cookie = "";
const anonPatch = await req("PATCH", `/api/admin/anime/${movieId}`, { downloadEnabled: true });
check("anonymous cannot change download settings", anonPatch.status === 401, `${anonPatch.status}`);
const anonRes = await req("GET", `/api/media/download/anime/${movieId}?kind=video&index=0`);
check(
  "anonymous CAN resolve downloads of published items",
  anonRes.status === 200 || anonRes.status === 404 || (anonRes.status === 500 && /configured|S3_/i.test(anonRes.data?.error || "")),
  `${anonRes.status} ${JSON.stringify(anonRes.data).slice(0, 120)}`
);

/* ------------------------------ cleanup --------------------------------- */
console.log("\n== Cleanup ==");
cookie = (await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" }), "");
await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" });
for (const it of created.reverse()) {
  const r = it.kind === "anime"
    ? await req("DELETE", `/api/admin/anime/${it.id}`)
    : await req("DELETE", `/api/admin/episodes/${it.id}`);
  check(`cleanup ${it.kind} ${it.id.slice(-6)}`, r.status === 200 || r.status === 204, `${r.status}`);
}

console.log(`\n======== RESULT: ${pass} passed, ${failCount} failed ========`);
process.exit(failCount ? 1 : 0);
