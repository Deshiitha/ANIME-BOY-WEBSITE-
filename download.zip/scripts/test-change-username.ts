/**
 * Live API test — Change Username feature (run against the dev server).
 * Covers: auth gating, availability rules, user rename, case-insensitive
 * uniqueness, reserved names, admin password reauthentication, session
 * preservation, relationship integrity (watchlist by userId), registration
 * policy, admin dashboard access after rename. Restores original state.
 */
const BASE = "http://localhost:3000";
const ADMIN = { email: "admin@animeboy.lk", password: "AnimeBoy@2024" };
const ADMIN_NAME = "ANIME BOY Admin";
const VIEWER = { email: "viewer@animeboy.lk", password: "anime1234" };
const VIEWER_NAME = "Chathura (Demo)";

let passed = 0;
let failed = 0;
function check(label: string, cond: boolean, extra = "") {
  if (cond) {
    passed++;
    console.log(`  ✔ ${label}`);
  } else {
    failed++;
    console.log(`  ✘ ${label} ${extra}`);
  }
}

type Jar = { cookie: string };
async function call(jar: Jar | null, method: string, path: string, body?: unknown, ip?: string) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(jar?.cookie ? { cookie: jar.cookie } : {}),
      ...(ip ? { "x-forwarded-for": ip } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const setCookie = res.headers.get("set-cookie");
  if (setCookie && jar) jar.cookie = setCookie.split(";")[0];
  let data: any = null;
  try {
    data = await res.json();
  } catch {}
  return { status: res.status, data };
}
async function login(jar: Jar, email: string, password: string) {
  return call(jar, "POST", "/api/auth/login", { email, password });
}

// ---------- 1. unauthenticated access is blocked ----------
console.log("\n[1] Auth gating");
{
  const r1 = await call(null, "GET", "/api/auth/username-available?u=NewName");
  check("availability endpoint requires sign-in (401)", r1.status === 401);
  const r2 = await call(null, "POST", "/api/auth/change-username", { newUsername: "NewName" });
  check("change-username endpoint requires sign-in (401)", r2.status === 401);
}

// ---------- 2. viewer availability checks ----------
console.log("\n[2] Availability rules (signed-in viewer)");
const vJar: Jar = { cookie: "" };
{
  const login1 = await login(vJar, VIEWER.email, VIEWER.password);
  check("viewer login works", login1.status === 200 && login1.data?.user?.email === VIEWER.email, JSON.stringify(login1.data));

  const ok1 = await call(vJar, "GET", "/api/auth/username-available?u=Chathura_99");
  check("valid name → available", ok1.status === 200 && ok1.data?.available === true, JSON.stringify(ok1.data));

  const ok2 = await call(vJar, "GET", `/api/auth/username-available?u=${encodeURIComponent(VIEWER_NAME)}`);
  check("own legacy current name → current (before format check)", ok2.status === 200 && ok2.data?.current === true, JSON.stringify(ok2.data));

  const ok3 = await call(vJar, "GET", `/api/auth/username-available?u=${encodeURIComponent(ADMIN_NAME.toLowerCase())}`);
  check("admin's name (case variant) → taken", ok3.status === 200 && ok3.data?.available === false, JSON.stringify(ok3.data));

  const ok4 = await call(vJar, "GET", "/api/auth/username-available?u=admin");
  check("reserved 'admin' → blocked", ok4.status === 200 && ok4.data?.available === false && /reserved/i.test(ok4.data?.reason || ""), JSON.stringify(ok4.data));

  const ok5 = await call(vJar, "GET", "/api/auth/username-available?u=admin2");
  check("'admin2' (reserved prefix) → blocked", ok5.status === 200 && ok5.data?.available === false, JSON.stringify(ok5.data));

  const ok6 = await call(vJar, "GET", "/api/auth/username-available?u=ab");
  check("too short → rejected with clear message", ok6.status === 200 && ok6.data?.available === false && /3.*20/.test(ok6.data?.reason || ""), JSON.stringify(ok6.data));

  const ok7 = await call(vJar, "GET", "/api/auth/username-available?u=" + encodeURIComponent("has space"));
  check("space → rejected (letters/numbers/underscores only)", ok7.status === 200 && ok7.data?.available === false, JSON.stringify(ok7.data));

  const ok8 = await call(vJar, "GET", "/api/auth/username-available?u=" + encodeURIComponent("bad!name"));
  check("special char → rejected", ok8.status === 200 && ok8.data?.available === false, JSON.stringify(ok8.data));

  const ok9 = await call(vJar, "GET", "/api/auth/username-available?u=" + encodeURIComponent("   Chathura_99   "));
  check("whitespace trimmed → available", ok9.status === 200 && ok9.data?.available === true, JSON.stringify(ok9.data));
}

// ---------- 3. viewer changes own username ----------
console.log("\n[3] Viewer changes own username");
{
  // watchlist relationship integrity: add item BEFORE rename
  const anime = await (await fetch(BASE + "/api/anime")).json();
  const slug = anime.items?.[0]?.slug || anime[0]?.slug;
  const detail = await (await fetch(`${BASE}/api/anime/${slug}`)).json();
  const animeId = (detail.item || detail.anime || detail)?.id;
  const add = await call(vJar, "POST", "/api/watchlist", { animeId });
  check("watchlist item added before rename", add.status === 200 || add.status === 201, JSON.stringify(add.data));

  const bad1 = await call(vJar, "POST", "/api/auth/change-username", { newUsername: "admin" });
  check("rename to reserved → 400", bad1.status === 400, JSON.stringify(bad1.data));

  const badX = await call(vJar, "POST", "/api/auth/change-username", { newUsername: ADMIN_NAME.toUpperCase() });
  check("case-variant of legacy admin name → format 400 (spaces not allowed)", badX.status === 400, JSON.stringify(badX.data));

  const bad3 = await call(vJar, "POST", "/api/auth/change-username", { newUsername: "" });
  check("empty username → 400", bad3.status === 400, JSON.stringify(bad3.data));

  const bad4 = await call(vJar, "POST", "/api/auth/change-username", { newUsername: VIEWER_NAME });
  check("rename to own (legacy) current name → 'already current' 400", bad4.status === 400 && /already your current/i.test(bad4.data?.error || ""), JSON.stringify(bad4.data));

  const good = await call(vJar, "POST", "/api/auth/change-username", { newUsername: "  Chathura_Demo  " });
  check("valid rename → 200 (trimmed)", good.status === 200 && good.data?.user?.name === "Chathura_Demo", JSON.stringify(good.data));
  check("session cookie re-issued (still signed in)", !!vJar.cookie);

  const me = await call(vJar, "GET", "/api/auth/me");
  check("/api/auth/me returns NEW username (session preserved)", me.status === 200 && me.data?.user?.name === "Chathura_Demo", JSON.stringify(me.data));

  const wl = await call(vJar, "GET", "/api/watchlist");
  const wlItems = wl.data?.items ?? wl.data ?? [];
  check("watchlist intact after rename (userId relationship)", wl.status === 200 && Array.isArray(wlItems) && wlItems.length >= 1, JSON.stringify(wl.data).slice(0, 120));

  // regular user cannot touch the admin account: the endpoint only ever
  // targets the session user — verify admin's name is untouched.
  const aJar0: Jar = { cookie: "" };
  await login(aJar0, ADMIN.email, ADMIN.password);
  const adminMe = await call(aJar0, "GET", "/api/auth/me");
  check("admin account untouched by viewer's rename", adminMe.data?.user?.name === ADMIN_NAME, `got: ${adminMe.data?.user?.name}`);

  // restore viewer name (legacy name is grandfathered — restored via DB in cleanup)
  const restore = await call(vJar, "POST", "/api/auth/change-username", { newUsername: "Chathura_User" });
  check("viewer renamed to a second conforming name", restore.status === 200, JSON.stringify(restore.data));

  // remove the watchlist item we added
  const wlNow = await call(vJar, "GET", "/api/watchlist");
  const items = wlNow.data?.items ?? wlNow.data ?? [];
  for (const it of items as any[]) {
    await call(vJar, "DELETE", `/api/watchlist?animeId=${it.animeId ?? it.id}`);
  }
}

// ---------- 4. admin rename with reauthentication ----------
console.log("\n[4] Admin rename (password reauthentication)");
{
  const aJar: Jar = { cookie: "" };
  const lg = await login(aJar, ADMIN.email, ADMIN.password);
  check("admin login works", lg.status === 200);

  const noPw = await call(aJar, "POST", "/api/auth/change-username", { newUsername: "AnimeBoyOwner" });
  check("no password → 400 (reauthentication required)", noPw.status === 400, JSON.stringify(noPw.data));

  // viewer now holds the conforming name "Chathura_User" — a case-variant
  // rename must be rejected as taken (case-insensitive uniqueness)
  const takenVariant = await call(aJar, "POST", "/api/auth/change-username", { newUsername: "CHATHURA_USER", currentPassword: ADMIN.password });
  check("case-variant of another user's username → 409 taken", takenVariant.status === 409, JSON.stringify(takenVariant.data));

  const wrongPw = await call(aJar, "POST", "/api/auth/change-username", { newUsername: "AnimeBoyOwner", currentPassword: "WrongPass1" });
  check("wrong password → 403", wrongPw.status === 403, JSON.stringify(wrongPw.data));

  const good = await call(aJar, "POST", "/api/auth/change-username", { newUsername: "AnimeBoyOwner", currentPassword: ADMIN.password });
  check("admin rename with correct password → 200", good.status === 200 && good.data?.user?.name === "AnimeBoyOwner", JSON.stringify(good.data));

  const stats = await call(aJar, "GET", "/api/admin/stats");
  check("admin dashboard API still works after rename (privileges unchanged)", stats.status === 200, JSON.stringify(stats.data).slice(0, 80));

  const users = await call(aJar, "GET", "/api/admin/users");
  const list = users.data?.users ?? [];
  check("admin list shows renamed admin + original roles", users.status === 200 && list.some((u: any) => u.name === "AnimeBoyOwner" && u.role === "ADMIN"), JSON.stringify(list).slice(0, 160));

  // reserved allowed for the admin (own site identity), then restore
  const reserved = await call(aJar, "GET", `/api/auth/username-available?u=admin`);
  check("reserved names allowed for ADMIN role", reserved.status === 200 && reserved.data?.available === true, JSON.stringify(reserved.data));

  const restore2 = await call(aJar, "POST", "/api/auth/change-username", { newUsername: "AnimeBoyOwner2", currentPassword: ADMIN.password });
  check("admin renamed to a second conforming name", restore2.status === 200, JSON.stringify(restore2.data));
}

// ---------- 5. registration policy ----------
console.log("\n[5] Registration username policy");
{
  const r1 = await call(null, "POST", "/api/auth/register", { name: "ab", email: "testname1@example.com", password: "TestPass123" }, "203.0.113.11");
  check("short username rejected at signup", r1.status === 400, JSON.stringify(r1.data));

  const r2 = await call(null, "POST", "/api/auth/register", { name: "system", email: "testname2@example.com", password: "TestPass123" }, "203.0.113.12");
  check("reserved username rejected at signup", r2.status === 400, JSON.stringify(r2.data));

  const r3 = await call(null, "POST", "/api/auth/register", { name: "CHATHURA_USER", email: "testname3@example.com", password: "TestPass123" }, "203.0.113.13");
  check("taken username (case variant of viewer's conforming name) rejected", r3.status === 409, JSON.stringify(r3.data));

  const r4 = await call(null, "POST", "/api/auth/register", { name: "Test_User_01", email: "testname4@example.com", password: "TestPass123" }, "203.0.113.14");
  check("valid unique username accepted at signup", r4.status === 200 && r4.data?.user?.name === "Test_User_01", JSON.stringify(r4.data));

  const r5 = await call(null, "POST", "/api/auth/register", { email: "testname5@example.com", password: "TestPass123" }, "203.0.113.15");
  check("signup without username still works (optional)", r5.status === 200, JSON.stringify(r5.data));
}

// ---------- cleanup test users + restore legacy usernames ----------
console.log("\n[cleanup] removing test accounts, restoring original usernames");
const { PrismaClient } = await import("@prisma/client");
const db = new PrismaClient();
const del = await db.user.deleteMany({ where: { email: { contains: "testname" } } });
console.log(`  deleted ${del.count} test users`);
await db.user.update({ where: { email: VIEWER.email }, data: { name: VIEWER_NAME } });
await db.user.update({ where: { email: ADMIN.email }, data: { name: ADMIN_NAME } });
console.log(`  restored: viewer="${VIEWER_NAME}", admin="${ADMIN_NAME}" (legacy names grandfathered)`);
await db.$disconnect();

console.log(`\n===== RESULT: ${passed} passed, ${failed} failed =====`);
process.exit(failed ? 1 : 0);
