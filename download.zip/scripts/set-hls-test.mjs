// Temporarily set episode 3 of emerald-blade-chronicles to the local HLS source (for browser playback verification).
const BASE = "http://localhost:3000";
let cookie = "";
async function req(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: { cookie, ...(body ? { "content-type": "application/json" } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const sc = res.headers.get("set-cookie");
  if (sc) cookie = sc.split(";")[0];
  return res.json();
}
(async () => {
  await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" });
  const det = await req("GET", "/api/anime/emerald-blade-chronicles");
  const ep = det.anime.seasons[0].episodes[2];
  const prev = { videoSource: ep.videoSource, videoUrl: ep.videoUrl };
  const r = await req("PATCH", `/api/admin/episodes/${ep.id}`, {
    videoSource: "external",
    videoUrl: "/api/files/videos/hls-demo/master.m3u8",
  });
  console.log("HLS test:", r.episode?.videoSource, r.episode?.videoUrl);
  console.log("previous:", JSON.stringify(prev));
})();
