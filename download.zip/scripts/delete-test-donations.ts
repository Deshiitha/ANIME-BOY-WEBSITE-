/** Final donation-test cleanup: delete the 4 donations created during payment verification. */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const TEST_ORDER_IDS = [
  "AB-MVV73O34-424CF953", // Rs.250 VERIFIED → REFUNDED
  "AB-MVV77O41-4A6ECCB9", // Rs.1000 FAILED
  "AB-MVV77O99-BDB5DF81", // Rs.500 bank transfer VERIFIED
  "AB-MVV78EQV-D3361DD7", // Rs.750 WebXPay VERIFIED
];

async function main() {
  const del = await db.donation.deleteMany({ where: { orderId: { in: TEST_ORDER_IDS } } });
  console.log("deleted test donations:", del.count);
  console.log("remaining donations:", await db.donation.count());
  const left = await db.donation.findMany({ select: { orderId: true, status: true, createdAt: true } });
  console.log("remaining rows:", JSON.stringify(left));
}

main().finally(() => db.$disconnect());
