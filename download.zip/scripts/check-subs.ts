/** Check current video source + subtitle data in DB. */
import { PrismaClient } from "@prisma/client";

const p = new PrismaClient();

const animeSel = {
  slug: true,
  type: true,
  videoSource: true,
  videoProvider: true,
  videoUrl: true,
  embedUrl: true,
  subtitleTracks: true,
  subtitleUrl: true,
  subtitleDownloadEnabled: true,
  subtitleDownloads: true,
};
const epsSel = {
  number: true,
  videoSource: true,
  videoProvider: true,
  videoUrl: true,
  embedUrl: true,
  subtitleTracks: true,
  subtitleUrl: true,
  subtitleDownloadEnabled: true,
  subtitleDownloads: true,
  season: { select: { number: true, anime: { select: { slug: true } } } },
};

const rows = await p.anime.findMany({ select: animeSel });
console.log("=== ANIME ===");
for (const r of rows) {
  console.log(JSON.stringify(r));
}
const eps = await p.episode.findMany({ select: epsSel });
console.log("=== EPISODES ===");
for (const r of eps) {
  console.log(JSON.stringify(r));
}
await p.$disconnect();
