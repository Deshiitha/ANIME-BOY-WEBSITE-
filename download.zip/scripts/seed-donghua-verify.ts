/**
 * TEMPORARY verification seed for the Donghua categories feature.
 * Creates: 1 donghua movie + 1 donghua series (with season + episode) + a temp admin user.
 * Everything created here is deleted by seed-donghua-cleanup.ts.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const suffix = Date.now().toString(36).slice(-5);

  // Temp admin (deleted after verification)
  const passwordHash = await bcrypt.hash("Verify-Donghua-2026!", 10);
  const admin = await db.user.create({
    data: {
      email: `donghua-verify-${suffix}@animeboy-test.local`,
      name: "Donghua Verify Admin",
      passwordHash,
      role: "ADMIN",
    },
  });
  console.log("ADMIN_ID=" + admin.id);
  console.log("ADMIN_EMAIL=" + admin.email);
  console.log("ADMIN_PASSWORD=Verify-Donghua-2026!");

  // Donghua movie
  const movie = await db.anime.create({
    data: {
      slug: `verify-donghua-movie-${suffix}`,
      type: "MOVIE",
      category: "DONGHUA",
      titleEn: "Verify Donghua Movie",
      titleSi: "වෙරිෆිකේෂන් ඩොන්ගුවා චිත්‍රපටය",
      descriptionEn: "Temporary verification record — will be deleted.",
      descriptionSi: "තාවකාලික වෙරිෆිකේෂන් වාර්තාවක් — පසුව මකා දමනු ලැබේ.",
      genres: "Action,Fantasy",
      releaseYear: 2025,
      rating: 8.2,
      languageLabel: "SINHALA_DUBBED",
      availability: "සිංහල හඬ කැවූ",
      status: "RELEASED",
      posterUrl: "https://picsum.photos/seed/donghua-movie/300/450",
      backdropUrl: "https://picsum.photos/seed/donghua-movie-bd/1280/720",
      videoSource: "embed",
      embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
      videoProvider: "youtube",
      published: true,
      homeRank: -10,
    },
  });
  console.log("MOVIE_ID=" + movie.id);

  // Donghua series with season + episode
  const series = await db.anime.create({
    data: {
      slug: `verify-donghua-series-${suffix}`,
      type: "SERIES",
      category: "DONGHUA",
      titleEn: "Verify Donghua Series",
      titleSi: "වෙරිෆිකේෂන් ඩොන්ගුවා කතා මාලාව",
      descriptionEn: "Temporary verification series — will be deleted.",
      genres: "Action,Adventure",
      releaseYear: 2024,
      rating: 9.0,
      languageLabel: "SINHALA_SUB",
      availability: "සිංහල උපසිරැසි",
      status: "RELEASED",
      posterUrl: "https://picsum.photos/seed/donghua-series/300/450",
      published: true,
      homeRank: -10,
      seasons: {
        create: {
          number: 1,
          title: "Season 1",
          episodes: {
            create: {
              number: 1,
              title: "The First Awakening",
              videoSource: "embed",
              embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
              videoProvider: "youtube",
              thumbnailUrl: "https://picsum.photos/seed/donghua-ep1/640/360",
            },
          },
        },
      },
    },
  });
  console.log("SERIES_ID=" + series.id);

  const counts = {
    donghuaMovies: await db.anime.count({ where: { category: "DONGHUA", type: "MOVIE" } }),
    donghuaSeries: await db.anime.count({ where: { category: "DONGHUA", type: "SERIES" } }),
  };
  console.log("COUNTS=" + JSON.stringify(counts));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
