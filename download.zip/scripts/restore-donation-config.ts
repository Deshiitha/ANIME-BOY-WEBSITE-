/** Restore donation-related SiteConfig rows from the backup + delete temp test data. */
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";

const db = new PrismaClient();

async function main() {
  const backup = JSON.parse(readFileSync("/home/z/my-project/scripts/donation-config-backup.json", "utf8")) as Record<string, string>;
  for (const [key, value] of Object.entries(backup)) {
    await db.siteConfig.upsert({ where: { key }, update: { value }, create: { key, value } });
  }
  console.log("config restored");

  // Delete test donations (identified by the test order prefix) + temp admins.
  const delDon = await db.donation.deleteMany({ where: { orderId: { contains: "AB-TEST" } } });
  const delUsers = await db.user.deleteMany({ where: { email: { contains: "animeboy-test.local" } } });
  console.log(`deleted ${delDon.count} test donations, ${delUsers.count} temp users`);
  console.log("remaining donations:", await db.donation.count());
  console.log("users:", (await db.user.findMany({ select: { email: true } })).map((u) => u.email).join(", "));
}

main().finally(() => db.$disconnect());
