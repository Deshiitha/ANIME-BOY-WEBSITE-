/**
 * E2E verification of the Cloud Video Manager flows (Add / Edit / Publish /
 * Unpublish / Delete for movies + series episodes) against the dev server.
 */
const BASE = "http://localhost:3000";
let cookie = "";

async function req(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const setC = res.headers.get("set-cookie");
  if (setC) cookie = setC.split(";")[0];
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

const MP4 = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4";
const MP4_720 = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_2MB.mp4";
let failures = 0;

function check(label, cond, extra = "") {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}${extra ? ` — ${extra}` : ""}`);
  if (!cond) failures++;
}

/* 1. login */
const login = await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" });
check("admin login", login.status === 200, login.data?.error || login.data?.user?.email);

/* 2. Add Cloud Video → new movie (exactly the payload the form sends) */
const stamp = Date.now().toString(36);
const movie = await req("POST", "/api/admin/anime", {
  titleEn: `CVM Test Movie ${stamp}`,
  titleSi: "පරීක්ෂණ චිත්‍රපටය",
  descriptionSi: "Cloud Video Manager e2e පරීක්ෂණය",
  descriptionEn: "Temporary test entry",
  releaseYear: "2026",
  languageLabel: "SINHALA_DUBBED",
  posterUrl: "",
  type: "MOVIE",
  published: true,
  videoSource: "external",
  videoUrl: MP4,
  embedUrl: "",
  videoQualities: [{ label: "360p", url: MP4 }, { label: "720p", url: MP4_720 }],
  subtitleTracks: [{ label: "සිංහල", lang: "si", url: "/api/files/subtitles/demo-si.vtt" }],
  videoThumb: "",
  subtitleUrl: "",
  downloadEnabled: true,
  downloadUrl: MP4,
  downloadQualities: [{ label: "360p", url: MP4 }],
  subtitleDownloadEnabled: true,
  subtitleDownloads: [{ label: "සිංහල SRT", lang: "si", url: "/api/files/subtitles/demo-si.vtt" }],
});
check("create movie with cloud URL", movie.status === 201, movie.data?.error);
const movieId = movie.data?.anime?.id;

/* 3. manager inventory sees it with source fields */
const list = await req("GET", "/api/admin/anime");
const row = (list.data?.items || []).find((a) => a.id === movieId);
check(
  "inventory row: external source + 2 qualities + 1 sub",
  !!row && row.videoSource === "external" && row.videoQualities.length === 2 && row.subtitleTracks.length === 1 && row.published === true
);

/* 4. share-page guard: Dropbox link must be rejected */
const bad = await req("PATCH", `/api/admin/anime/${movieId}`, {
  videoSource: "external",
  videoUrl: "https://www.dropbox.com/s/abcxyz/video.mp4?dl=0",
  videoQualities: [],
  subtitleTracks: [],
  videoThumb: "",
  subtitleUrl: "",
});
check("Dropbox share page rejected", bad.status === 400, bad.data?.error?.slice(0, 80));

/* 5. edit dialog → source-only PATCH replaces URL + provider embed switch */
const edit = await req("PATCH", `/api/admin/anime/${movieId}`, {
  videoSource: "embed",
  embedUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  videoQualities: [],
  subtitleTracks: [],
  videoThumb: "",
  subtitleUrl: "",
  downloadEnabled: false,
  downloadUrl: "",
  downloadQualities: [],
  subtitleDownloadEnabled: false,
  subtitleDownloads: [],
});
check(
  "edit → provider embed (YouTube)",
  edit.status === 200 && edit.data?.anime?.videoSource === "embed" && edit.data?.anime?.videoProvider === "youtube",
  edit.data?.error || edit.data?.anime?.video?.embedUrl?.slice(0, 60)
);
check("edit kept title (partial patch)", edit.data?.anime?.titleEn === `CVM Test Movie ${stamp}`);

const revert = await req("PATCH", `/api/admin/anime/${movieId}`, {
  videoSource: "external",
  videoUrl: MP4,
  videoQualities: [{ label: "360p", url: MP4 }],
  subtitleTracks: [],
  videoThumb: "",
  subtitleUrl: "",
  downloadEnabled: false,
  downloadUrl: "",
  downloadQualities: [],
  subtitleDownloadEnabled: false,
  subtitleDownloads: [],
});
check("edit → back to direct MP4", revert.status === 200 && revert.data?.anime?.video?.kind === "mp4", revert.data?.error);

/* 6. unpublish / publish toggle */
const unpub = await req("PATCH", `/api/admin/anime/${movieId}`, { published: false });
const pub = await req("PATCH", `/api/admin/anime/${movieId}`, { published: true });
check("unpublish + publish toggles", unpub.status === 200 && pub.status === 200 && pub.data?.anime?.published === true);

/* 7. new series + season + episode flow */
const series = await req("POST", "/api/admin/anime", {
  titleEn: `CVM Test Series ${stamp}`,
  type: "SERIES",
  languageLabel: "SINHALA_SUB",
  published: true,
});
check("create series shell", series.status === 201, series.data?.error);
const seriesId = series.data?.anime?.id;
const slug = series.data?.anime?.slug;
const detail = await req("GET", `/api/anime/${slug}`);
check("series detail has no seasons yet", (detail.data?.anime?.seasons || []).length === 0);

const season = await req("POST", "/api/admin/seasons", { animeId: seriesId, number: 1 });
check("create season 1", season.status === 201, season.data?.error);
const seasonId = season.data?.season?.id;

const episode = await req("POST", "/api/admin/episodes", {
  seasonId,
  number: 1,
  title: "Pilot",
  videoSource: "external",
  videoUrl: MP4,
  embedUrl: "",
  videoQualities: [{ label: "360p", url: MP4 }],
  subtitleTracks: [],
  videoThumb: "",
  subtitleUrl: "",
  downloadEnabled: false,
  downloadUrl: "",
  downloadQualities: [],
  subtitleDownloadEnabled: false,
  subtitleDownloads: [],
});
check("create episode with cloud URL", episode.status === 201, episode.data?.error);
const episodeId = episode.data?.episode?.id;

/* 8. episode edit dialog → PATCH episode source */
const epEdit = await req("PATCH", `/api/admin/episodes/${episodeId}`, {
  videoSource: "external",
  videoUrl: MP4_720,
  embedUrl: "",
  videoQualities: [{ label: "720p", url: MP4_720 }],
  subtitleTracks: [{ label: "English", lang: "en", url: "/api/files/subtitles/demo-si.vtt" }],
  videoThumb: "",
  subtitleUrl: "",
  downloadEnabled: true,
  downloadUrl: MP4_720,
  downloadQualities: [],
  subtitleDownloadEnabled: false,
  subtitleDownloads: [],
});
check(
  "episode source edit → HLS-less mp4 + download enabled",
  epEdit.status === 200 && epEdit.data?.episode?.videoUrl === MP4_720 && epEdit.data?.episode?.downloadEnabled === true,
  epEdit.data?.error
);

/* 9. play endpoint is private-bucket-only: direct MP4 must be refused there (graceful),
      the playable source travels in the public payload instead (checked below) */
const playMovie = await req("GET", `/api/media/play/anime/${movieId}`);
const playEp = await req("GET", `/api/media/play/episode/${episodeId}`);
check("play resolver refuses non-signed media (by design)", playMovie.status === 400 && playEp.status === 400);

/* 10. download resolver returns direct/open with filename */
const dl = await req("GET", `/api/media/download/episode/${episodeId}?index=0`);
check("download resolver (episode video)", dl.status === 200 && !!dl.data?.url, dl.data?.error || dl.data?.url?.slice(0, 60));

/* 11. public detail reflects episode source for the watch page */
const detail2 = await req("GET", `/api/anime/${slug}`);
const ep1 = detail2.data?.anime?.seasons?.[0]?.episodes?.[0];
check("public episode payload has playable source", ep1?.video?.kind === "mp4", ep1?.video?.kind);
check("public episode payload exposes download options", ep1?.downloads?.video?.enabled === true);

/* 12. cleanup */
const delEp = await req("DELETE", `/api/admin/episodes/${episodeId}`);
const delSeason = await req("DELETE", `/api/admin/seasons/${seasonId}`);
const delSeries = await req("DELETE", `/api/admin/anime/${seriesId}`);
const delMovie = await req("DELETE", `/api/admin/anime/${movieId}`);
check("cleanup deletes", delEp.status === 200 && delSeason.status === 200 && delSeries.status === 200 && delMovie.status === 200);

const after = await req("GET", "/api/admin/anime");
check("test entries removed from inventory", !(after.data?.items || []).some((a) => a.id === movieId || a.id === seriesId));

console.log(failures === 0 ? "\nALL CHECKS PASSED ✓" : `\n${failures} CHECK(S) FAILED ✗`);
process.exit(failures === 0 ? 0 : 1);
