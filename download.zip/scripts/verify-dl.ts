/**
 * End-to-end verification of the fixed Google Drive download button in a
 * REAL browser context (Playwright, downloads enabled).
 *
 * Asserts, for both the movie (Drive share-link stored) and the episode
 * (Drive uc-link stored):
 *  1. "Download Video" opens the branded dialog (design preserved).
 *  2. Clicking "Download from Google Drive" fires a real DOWNLOAD event in
 *     the browser (the browser saves the file directly from Drive's
 *     direct-download endpoint).
 *  3. The watch page itself NEVER navigates away (SPA stays in place) and no
 *     new tab/popup is opened (no Drive app / preview / interstitial pages).
 *  4. "Copy Download Link" copies the ORIGINAL admin-stored URL.
 */
import { chromium, type Browser } from "playwright";

const MOVIE = "http://localhost:3000/#/watch/blade-of-the-emerald-dawn";
const SERIES = "http://localhost:3000/#/watch/emerald-blade-chronicles";

let failures = 0;
function check(name: string, ok: boolean, detail = "") {
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? ` — ${detail}` : ""}`);
  if (!ok) failures++;
}

async function driveFlow(
  browser: Browser,
  url: string,
  viewport: { width: number; height: number },
  label: string,
  expectedCopyUrl: string
) {
  console.log(`\n===== ${label} (${viewport.width}x${viewport.height}) =====`);
  const context = await browser.newContext({
    acceptDownloads: true,
    viewport,
  });
  await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: "http://localhost:3000" });
  const page = await context.newPage();
  await page.goto(url, { waitUntil: "networkidle" });
  const beforeUrl = page.url();
  const pagesBefore = context.pages().length;

  await page.getByRole("button", { name: /Download Video/ }).first().click();
  const dialog = page.locator('[aria-label="Download your video"]');
  await dialog.waitFor({ state: "visible", timeout: 20000 });
  check(`[${label}] branded dialog opens`, true);

  const [download] = await Promise.all([
    page.waitForEvent("download", { timeout: 90000 }),
    page.getByRole("button", { name: "Download from Google Drive" }).click(),
  ]);
  check(`[${label}] browser starts a real DOWNLOAD`, true, `suggested file: ${download.suggestedFilename()}`);
  check(
    `[${label}] download comes from Drive's direct endpoint`,
    /drive\.usercontent\.google\.com\/download\?id=.+&export=download&confirm=t/.test(download.url()),
    download.url()
  );
  check(`[${label}] watch page stays in place (no navigation)`, page.url() === beforeUrl, page.url());
  check(`[${label}] no new tab/popup opened`, context.pages().length === pagesBefore);
  check(`[${label}] dialog still present after click`, await dialog.isVisible());

  // Copy button: must copy the ORIGINAL stored URL.
  await page.getByRole("button", { name: "Copy Download Link" }).click();
  await dialog.getByText("Download link copied successfully!").waitFor({ timeout: 5000 });
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  check(`[${label}] copy button copies ORIGINAL stored URL`, clip === expectedCopyUrl, clip);

  await context.close();
}

const browser = await chromium.launch();

await driveFlow(
  browser,
  MOVIE,
  { width: 1280, height: 800 },
  "movie",
  "https://drive.google.com/file/d/1qc_FuGp8bszKFTiZDuOkHS_SaIrcwDuo/view?usp=sharing"
);
await driveFlow(
  browser,
  SERIES,
  { width: 1280, height: 800 },
  "episode",
  "https://drive.google.com/uc?export=download&id=1qc_FuGp8bszKFTiZDuOkHS_SaIrcwDuo"
);
await driveFlow(
  browser,
  MOVIE,
  { width: 390, height: 844 },
  "movie-mobile",
  "https://drive.google.com/file/d/1qc_FuGp8bszKFTiZDuOkHS_SaIrcwDuo/view?usp=sharing"
);

await browser.close();
console.log(failures === 0 ? "\nALL CHECKS PASSED" : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
