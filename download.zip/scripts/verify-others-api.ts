/**
 * End-to-end API verification for the new "Others" category.
 * Creates test content, verifies DB persistence + validation + editing,
 * then deletes everything it created. Safe to re-run.
 */
const BASE = "http://localhost:3000";
let cookie = "";

async function api(method: string, path: string, body?: unknown) {
  const res = await fetch(BASE + path, {
    method,
    headers: { "Content-Type": "application/json", cookie },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const setCookie = res.headers.get("set-cookie");
  if (setCookie) cookie = setCookie.split(";")[0];
  let json: any = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

let failures = 0;
function check(name: string, cond: boolean, detail?: unknown) {
  if (cond) console.log(`  ✓ ${name}`);
  else { failures++; console.log(`  ✗ FAIL: ${name}`, detail !== undefined ? JSON.stringify(detail) : ""); }
}

/* 1. login as temp admin */
const login = await api("POST", "/api/auth/login", { email: "others-verify@animeboy-test.local", password: "OthersVerify-2026!" });
check("admin login", login.status === 200 && login.json?.user?.role === "ADMIN", login);

/* 2. create Others content with optional S/E + video + download */
const marker = `Others Test ${Date.now().toString(36)}`;
const created = await api("POST", "/api/admin/anime", {
  titleEn: marker,
  descriptionEn: "Test description for Others category",
  category: "OTHERS",
  type: "MOVIE",
  seasonNumber: "2",
  episodeNumber: "7",
  posterUrl: "/art/poster-emerald-final.png",
  videoSource: "external",
  videoUrl: "https://example.com/video/others-test.mp4",
  downloadEnabled: true,
  downloadUrl: "https://example.com/download/others-test-1080p.mp4",
  published: true,
});
check("create Others content", created.status === 201, created);
const othersId = created.json?.anime?.id;
check("category stored as OTHERS", created.json?.anime?.category === "OTHERS");
check("seasonNumber=2 stored", created.json?.anime?.seasonNumber === 2);
check("episodeNumber=7 stored", created.json?.anime?.episodeNumber === 7);
check("videoUrl preserved", created.json?.anime?.videoUrl === "https://example.com/video/others-test.mp4");
check("download preserved", created.json?.anime?.downloadUrl === "https://example.com/download/others-test-1080p.mp4");
check("type stored as MOVIE", created.json?.anime?.type === "MOVIE");

/* 3. validation: bad season number rejected */
const badSeason = await api("POST", "/api/admin/anime", {
  titleEn: `${marker} bad`, category: "OTHERS", seasonNumber: "0",
});
check("seasonNumber=0 rejected", badSeason.status === 400 && /Season number/.test(badSeason.json?.error || ""), badSeason);
const badEp = await api("POST", "/api/admin/anime", {
  titleEn: `${marker} bad`, category: "OTHERS", episodeNumber: "abc",
});
check("episodeNumber=abc rejected", badEp.status === 400 && /Episode number/.test(badEp.json?.error || ""), badEp);
const badEp2 = await api("POST", "/api/admin/anime", {
  titleEn: `${marker} bad`, category: "OTHERS", episodeNumber: "1.5",
});
check("episodeNumber=1.5 rejected", badEp2.status === 400, badEp2);
/* empty strings = optional = allowed */
const noSE = await api("POST", "/api/admin/anime", {
  titleEn: `${marker} nose`, category: "OTHERS", seasonNumber: "", episodeNumber: "",
});
check("empty S/E allowed (optional)", noSE.status === 201 && noSE.json?.anime?.seasonNumber === null, noSE);

/* 4. public listing: Others filter */
const pub = await api("GET", "/api/anime?category=OTHERS");
check("public /api/anime?category=OTHERS shows new item", pub.json?.items?.some((i: any) => i.id === othersId), pub.json?.total);
check("public Others item carries S/E", pub.json?.items?.find((i: any) => i.id === othersId)?.seasonNumber === 2);

/* 5. existing categories unaffected */
for (const [cat, type] of [["ANIME","MOVIE"],["ANIME","SERIES"],["DONGHUA","MOVIE"],["DONGHUA","SERIES"]] as const) {
  const r = await api("GET", `/api/anime?category=${cat}&type=${type}`);
  check(`existing listing ${cat}/${type} untouched`, (r.json?.total ?? 0) > 0 && !r.json.items.some((i: any) => i.category === "OTHERS"), r.json?.total);
}
const allPublic = await api("GET", "/api/anime");
check("Others item NOT in Anime/Donghua listings",
  !allPublic.json.items.some((i: any) => i.category === "OTHERS" && (i.category === "ANIME" || i.category === "DONGHUA")));

/* 6. admin library filter for Others */
const adminOthers = await api("GET", "/api/admin/anime?category=OTHERS");
check("admin library Others filter", adminOthers.json?.items?.some((i: any) => i.id === othersId), adminOthers.json?.total);

/* 7. edit: load + change category, preserve everything else */
const fetched = await api("GET", `/api/admin/anime?q=${encodeURIComponent(marker)}`);
const row = fetched.json?.items?.find((i: any) => i.id === othersId);
check("admin search finds created row", !!row);
const edited = await api("PATCH", `/api/admin/anime/${othersId}`, {
  titleEn: row.titleEn,
  titleSi: "",
  descriptionSi: "",
  descriptionEn: row.descriptionEn || "",
  genres: row.genres,
  languageLabel: row.languageLabel,
  availability: row.availability || "",
  status: row.status,
  type: "MOVIE",
  category: "ANIME",            // admin switches category Others → Anime Movie
  seasonNumber: row.seasonNumber ?? "",
  episodeNumber: row.episodeNumber ?? "",
  posterUrl: row.posterUrl || "",
  backdropUrl: row.backdropUrl || "",
  videoSource: row.videoSource,
  videoUrl: row.videoUrl || "",
  downloadEnabled: row.downloadEnabled,
  downloadUrl: row.downloadUrl || "",
  published: true,
});
check("category change saved (OTHERS→ANIME)", edited.json?.anime?.category === "ANIME", edited.json?.anime?.category);
check("video preserved after category change", edited.json?.anime?.videoUrl === "https://example.com/video/others-test.mp4");
check("download preserved after category change", edited.json?.anime?.downloadUrl === "https://example.com/download/others-test-1080p.mp4");
check("poster preserved after category change", edited.json?.anime?.posterUrl === "/art/poster-emerald-final.png");
check("S/E preserved after category change", edited.json?.anime?.seasonNumber === 2 && edited.json?.anime?.episodeNumber === 7);

/* switch back to OTHERS and update S/E values */
const edited2 = await api("PATCH", `/api/admin/anime/${othersId}`, {
  ...edited.json.anime, category: "OTHERS", seasonNumber: "3", episodeNumber: "12",
});
check("switch back to OTHERS + S/E updated", edited2.json?.anime?.category === "OTHERS" && edited2.json?.anime?.seasonNumber === 3 && edited2.json?.anime?.episodeNumber === 12);

/* 8. flags-only patch must not touch category */
const flagOnly = await api("PATCH", `/api/admin/anime/${othersId}`, { published: false });
check("flags-only patch keeps category", flagOnly.json?.anime?.category === "OTHERS" && flagOnly.json?.anime?.published === false);
await api("PATCH", `/api/admin/anime/${othersId}`, { published: true });

/* 9. cleanup everything created */
const cleanupIds = [othersId, noSE.json?.anime?.id].filter(Boolean);
for (const id of cleanupIds) {
  const del = await api("DELETE", `/api/admin/anime/${id}`);
  check(`cleanup delete ${id}`, del.status === 200);
}
const after = await api("GET", "/api/anime?category=OTHERS");
check("Others listing empty after cleanup", after.json?.total === 0, after.json?.total);

console.log(failures === 0 ? "\nALL API CHECKS PASSED" : `\n${failures} CHECKS FAILED`);
process.exit(failures === 0 ? 0 : 1);
