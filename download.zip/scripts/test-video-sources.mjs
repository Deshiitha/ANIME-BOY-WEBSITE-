/**
 * End-to-end API verification of the external video source feature.
 * Uses the running dev server on port 3000.
 */
const BASE = "http://localhost:3000";
let cookie = "";

function pretty(label, obj) {
  console.log(`\n== ${label} ==`);
  console.log(JSON.stringify(obj, null, 1).slice(0, 800));
}

async function req(method, path, body, isForm) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      ...(body && !isForm ? { "Content-Type": "application/json" } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });
  const setC = res.headers.get("set-cookie");
  if (setC) cookie = setC.split(";")[0];
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, data };
}

const MOVIE_ID = "cmvuksui50002vfkh1ov16f5v"; // Blade of the Emerald Dawn
const EP1_ID = "cmvuktalq000gvfm6q3jobfgy"; // Emerald Blade Chronicles S1E1
const MP4 = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4";

// 1. Login as admin
const login = await req("POST", "/api/auth/login", { email: "admin@animeboy.lk", password: "AnimeBoy@2024" });
pretty("1. Admin login", { status: login.status, user: login.data?.user?.email || login.data?.error });

// 2. Upload via the restored /api/admin/upload route
const form = new FormData();
const vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nආයුබෝවන්! Test cue.\n";
form.append("file", new Blob([vtt], { type: "text/vtt" }), "test-si.vtt");
form.append("kind", "subtitle");
const up = await req("POST", "/api/admin/upload", form, true);
pretty("2. Upload subtitle via /api/admin/upload", { status: up.status, url: up.data?.url, storage: up.data?.storage });
if (up.data?.url) {
  const f = await fetch(BASE + up.data.url);
  console.log("2b. GET uploaded file:", f.status, f.headers.get("content-type"));
}

// 3. Source-only PATCH: external MP4 (no title re-sent → partial path)
const patchMp4 = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "external",
  videoUrl: MP4,
  videoQualities: [{ label: "360p", url: MP4 }],
  subtitleTracks: [],
  videoThumb: "",
});
pretty("3. Source-only PATCH movie → external MP4", {
  status: patchMp4.status,
  video: patchMp4.data?.anime?.video,
  error: patchMp4.data?.error,
});

// 4. Public API returns the playable source with quality variants
const pub = await req("GET", "/api/anime/blade-of-the-emerald-dawn");
pretty("4. Public GET → playable source", { status: pub.status, video: pub.data?.anime?.video });

// 5. HLS URL
const patchHls = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "external",
  videoUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
});
pretty("5. PATCH movie → HLS", { status: patchHls.status, video: patchHls.data?.anime?.video, error: patchHls.data?.error });

// 6. Validation: http:// rejected
const badProto = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "external",
  videoUrl: "http://insecure.example.com/movie.mp4",
});
pretty("6. PATCH → http:// URL rejected", { status: badProto.status, error: badProto.data?.error });

// 7. Validation: cloud share page rejected
const dropbox = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "external",
  videoUrl: "https://www.dropbox.com/s/abc123/movie.mp4",
});
pretty("7. PATCH → Dropbox share page rejected", { status: dropbox.status, error: dropbox.data?.error });

// 8. Embed: YouTube watch URL converts to official nocookie embed
const yt = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "embed",
  embedUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
});
pretty("8. PATCH → YouTube embed conversion", { status: yt.status, video: yt.data?.anime?.video, error: yt.data?.error });

// 9. Validation: untrusted embed host rejected
const badEmbed = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "embed",
  embedUrl: "https://random-iframe-site.example.com/embed/123",
});
pretty("9. PATCH → untrusted embed host rejected", { status: badEmbed.status, error: badEmbed.data?.error });

// 10. Episode source editing: S1E1 → external MP4 with subtitle
const epPatch = await req("PATCH", `/api/admin/episodes/${EP1_ID}`, {
  videoSource: "external",
  videoUrl: MP4,
  subtitleTracks: [{ label: "සිංහල", lang: "si", url: "/api/files/subtitles/demo-si.vtt" }],
});
pretty("10. PATCH episode S1E1 → external MP4 + subtitle", {
  status: epPatch.status,
  video: epPatch.data?.episode?.video,
  error: epPatch.data?.error,
});

// 10b. Public series API reflects episode change
const pubS = await req("GET", "/api/anime/emerald-blade-chronicles");
const s1e1 = pubS.data?.anime?.seasons?.[0]?.episodes?.[0];
pretty("10b. Public GET series → E1 playable", { status: pubS.status, video: s1e1?.video });

// 11. Restore episode to original upload
const epRestore = await req("PATCH", `/api/admin/episodes/${EP1_ID}`, {
  videoSource: "upload",
  videoUrl: "/api/files/videos/sample-ep-1.mp4",
  subtitleTracks: [],
});
pretty("11. Restore episode upload source", { status: epRestore.status, video: epRestore.data?.episode?.video, error: epRestore.data?.error });

// 12. Probe endpoint (SSRF guard): public URL vs private IP
const probeOk = await req("POST", "/api/admin/media/probe", { url: MP4 });
pretty("12a. Probe public MP4", { status: probeOk.status, verdict: probeOk.data?.verdict, ct: probeOk.data?.contentType, ranges: probeOk.data?.acceptRanges });
const probePrivate = await req("POST", "/api/admin/media/probe", { url: "http://169.254.169.254/latest/meta-data/" });
pretty("12b. Probe cloud-metadata IP (SSRF blocked)", { status: probePrivate.status, error: probePrivate.data?.error });
const probeLocalhost = await req("POST", "/api/admin/media/probe", { url: "http://localhost:3000/api/config" });
pretty("12c. Probe localhost (SSRF blocked)", { status: probeLocalhost.status, error: probeLocalhost.data?.error });

// 13. Restore movie to original upload source
const restore = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, {
  videoSource: "upload",
  videoUrl: "/api/files/videos/sample-ep-1.mp4",
  videoQualities: [],
  subtitleTracks: [],
  embedUrl: "",
});
pretty("13. Restore movie upload source", { status: restore.status, video: restore.data?.anime?.video, error: restore.data?.error });

// 14. Anonymous PATCH rejected
cookie = "";
const anon = await req("PATCH", `/api/admin/anime/${MOVIE_ID}`, { videoSource: "embed", embedUrl: "https://www.youtube.com/watch?v=x" });
pretty("14. Anonymous PATCH rejected", { status: anon.status, error: anon.data?.error });

console.log("\nDONE");
