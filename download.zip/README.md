# ANIME BOY — Sinhala Anime Streaming Website

A complete, responsive anime streaming website for the **ANIME BOY** Sinhala anime
YouTube channel. Emerald-green cinematic dark theme, Sinhala + English content,
hero carousel, poster rows, episode player, watchlists, anime requests and a
protected admin dashboard — all running on Next.js 16 (App Router), TypeScript,
Tailwind CSS 4, shadcn/ui, Prisma (SQLite) and TanStack Query.

---

## 1. What is included

| Area | Details |
| --- | --- |
| Home | Featured hero carousel (autoplay, swipe, arrows, green indicators) + 6 rows: Recently Added Movies, Coming Soon Movies, Recently Added Series, Latest Episodes, Coming Soon Series, Top Rated |
| Posters | 2:3 portrait cards, rating pill (gold star), Movie/Series badge, COMING SOON overlay, hover/tap overlay with Watch + More Info, lazy-loaded |
| Listings | `/movies`, `/series`, search with title search, Movie/Series filter, genre, year, language, status, sorting (recently added / top rated / newest / A→Z), pagination |
| Details | Backdrop + poster, Sinhala & English synopsis, genres, year, language, rating, availability, season selector, numbered episode list |
| Watching | Custom player: direct MP4/WebM, HLS (.m3u8 — native on Safari/iOS, hls.js elsewhere), trusted provider embeds (YouTube / Vimeo / Dailymotion / Google Drive / Streamable), multi-language subtitles, playback speed, quality menu, previous/next episode, keyboard ←/→, episode sidebar, HTTP Range streaming, "coming soon" guard |
| External video | Movies and individual episodes can stream from external cloud storage/CDN (direct HTTPS MP4/WebM/HLS or private-bucket `s3://` keys with server-signed URLs) or provider embeds — files are **never** copied to this website's storage |
| Users | Sign up / sign in / sign out (bcrypt + HMAC-signed httpOnly session cookie), personal watchlist, anime request form (guest or signed-in) |
| Admin | Protected dashboard: stats, content CRUD, publish/unpublish, hero-carousel placement, seasons & episodes manager, file uploads with progress bar, request moderation, user list, YouTube channel setting |

**Server-side authorization:** every `/api/admin/*` route verifies the session
and the `ADMIN` role before touching data. Unauthenticated or non-admin calls
receive `401 Admin authorization required` — verified end-to-end.

## 2. Default accounts (created by the seed)

> Change these immediately in any real deployment.

| Account | Email | Password |
| --- | --- | --- |
| Administrator | `admin@animeboy.lk` | `AnimeBoy@2024` |
| Demo viewer | `viewer@animeboy.lk` | `anime1234` |

Override at seed time with `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `DEMO_EMAIL`,
`DEMO_PASSWORD` environment variables, then run `bun prisma/seed.ts`.

## 3. Managing content (no code needed)

1. Sign in with the admin account → avatar menu → **Admin Dashboard**.
2. **Content → Add Anime** — fill English/Sinhala titles, descriptions, genres,
   year, rating, language label, availability, status (Released / Coming soon).
3. Upload a **poster** (portrait) and **backdrop** (wide) — or paste hosted URLs.
   For movies, pick a **Video Source**: upload a file, paste a **direct HTTPS
   media URL** (MP4 / WebM / HLS `.m3u8`, or `s3://bucket/key` for private
   buckets), or paste a **provider link** (YouTube / Vimeo / Dailymotion / Drive
   / Streamable — converted to the official embed automatically). Add optional
   quality variants, subtitle tracks and a poster frame, then use **Preview
   Video** (checks the URL and reports Content-Type + byte-range support)
   before saving.
4. Toggle **star** to place a title in the hero carousel (order field controls
   position) and **eye** to publish/unpublish.
5. For series, open the list icon on its row → **Add Season → Add Episode**;
   each episode has the same **Video Source** editor.
6. **Requests** tab — approve/reject viewer requests. **Settings** — paste your
   real YouTube channel URL; the footer Subscribe button appears automatically.

## 4. File storage

Uploads work out of the box on the server's local disk (`db/uploads/…`) and are
streamed through `/api/files/...` **with HTTP Range support** (verified: video
seeking works).

To use S3-compatible object storage instead, set these environment variables and
restart — every upload then goes to the bucket automatically:

```bash
S3_ENDPOINT=https://your-endpoint.example.com   # e.g. Cloudflare R2 / MinIO / AWS S3
S3_REGION=auto
S3_BUCKET=animeboy-media
S3_ACCESS_KEY_ID=...            # keep secret — server-side only, never in frontend code
S3_SECRET_ACCESS_KEY=...
# optional: S3_PUBLIC_BASE_URL=https://cdn.example.com  (public base for the bucket)
```

Limits & validation (both client and server): videos ≤ 512 MB (override with
`MAX_VIDEO_MB`), images ≤ 10 MB, subtitles ≤ 2 MB; types restricted to
MP4/WebM/MOV/MKV, JPG/PNG/WebP/AVIF, VTT/SRT. Failed uploads show a clear
error and never fake success.

### Private buckets & signed playback

Set `S3_PRIVATE_BUCKET=1` and uploads hand the admin a stable
`s3://bucket/key` identifier instead of a public URL. At playback time the
server checks the viewer's access (published title / admin preview) and mints a
short-lived signed GET URL — **storage credentials never leave the server** and
expiring URLs are never stored in the database. The player silently re-signs
when a URL expires so seeking keeps working. Tune the lifetime with
`S3_SIGN_TTL_SEC` (default 14400 = 4 h). Related endpoints:
`/api/media/play/anime/<id>` and `/api/media/play/episode/<id>` (public,
access-checked) and `/api/admin/media/sign` (admin preview only).

## 4b. External cloud video sources

The **Video Source** editor accepts three kinds of sources per movie / episode:

1. **Upload** — the existing pipeline (local disk or object storage).
2. **External URL** — direct HTTPS media streamed straight from your storage or
   CDN: `https://cdn.example.com/movie.mp4`, a WebM, or an HLS playlist
   `https://…/stream.m3u8` (native on Safari/iOS, hls.js everywhere else with a
   native→hls.js fallback). `s3://bucket/key` enables private-bucket signing.
   Share-page links (Google Drive `/view`, Dropbox, MEGA, WeTransfer, OneDrive…)
   are rejected with an explanation — they serve HTML, not video bytes.
3. **Provider embed** — paste a normal watch/share link and it is converted to
   the official embed: YouTube (`youtube-nocookie`), Vimeo, Dailymotion,
   Google Drive `/preview`, Streamable. Arbitrary iframe HTML is never accepted
   and untrusted hosts are rejected server-side. Controls/ads/quality belong to
   the provider; the video always stays on the provider.

**Storage requirements for direct playback** (checked by the admin
**Preview Video** probe, `POST /api/admin/media/probe` — SSRF-guarded: private,
loopback and cloud-metadata IPs are refused):

- **HTTPS** — browsers block plain-HTTP media on a secure site.
- **Correct Content-Type** — `video/mp4`, `application/vnd.apple.mpegurl` (HLS), …
- **Byte-range support** (`Accept-Ranges: bytes`) — required for reliable MP4
  seeking; S3/R2/CDNs send it by default.
- **CORS** — needed for HLS playback (hls.js fetches playlists/segments via
  XHR/fetch) and for cross-origin subtitle files. Example for S3/R2:
  `AllowedOrigins: https://your-site.com`, `AllowedMethods: GET`,
  `AllowedHeaders: Range, Origin`.
- **HLS** — playlist, media segments and any encryption keys must all be
  reachable by the viewer's browser.

Environment variables relevant to external sources: the `S3_*` set above,
`S3_PRIVATE_BUCKET`, `S3_SIGN_TTL_SEC`, `MAX_VIDEO_MB`. The database stores only
metadata (source type, URL or stable object key, provider, quality/subtitle
lists) — never credentials, never expiring URLs.

## 5. Security configuration

- `AUTH_SECRET` — HMAC key for session cookies. A development fallback is used
  when unset; **set a long random value in production.**
- Credentials are never exposed to the frontend; passwords are bcrypt-hashed;
  session cookies are httpOnly + SameSite=Lax.
- All admin mutations are authorized on the server (not just hidden in the UI).

## 6. Common commands

```bash
bun run dev          # dev server on :3000 (managed by the platform)
bun run lint         # ESLint
bun run db:push      # push prisma/schema.prisma to SQLite (db/custom.db)
bun prisma/seed.ts   # (re)seed admin, demo user, 16-title demo library
```

## 7. Demo content

16 original demo titles (8 movies, 4 series with 23 episodes, 4 upcoming) with
Sinhala descriptions, AI-generated original artwork (`public/art/`), branded
sample clips (`db/uploads/videos/sample-ep-*.mp4`) and a Sinhala VTT subtitle
file. Replace them from the admin dashboard at any time — nothing is hard-coded.

## 8. Notes for the real deployment

- Point your domain at the app, set `AUTH_SECRET`, change the admin password,
  optionally configure S3 storage (public or private bucket — see §4).
- The site is a single-page app under `/` with hash routes
  (`/#/movies`, `/#/anime/<slug>`, `/#/watch/<slug>`, `/#/admin`, …) so deep
  links survive reloads and can be shared.
- Embedding your real YouTube videos? Use the **Provider embed** source with
  any `youtube.com/watch` or `youtu.be` link — it plays inside the site in the
  official privacy-enhanced embed. For self-hosted cloud files use the
  **External URL** source with the direct media link your storage/CDN gives.

## 9. How to host this website (deployment)

The app is a standard Next.js (App Router) server — it needs a Node/Bun
process (not static hosting). Two practical options:

### Option A — VPS / dedicated server (recommended, plays best with SQLite)

1. Copy the project to the server (`git clone` or upload), then install deps:
   `bun install` (or `npm install`).
2. Create `.env` next to `package.json`:
   ```bash
   DATABASE_URL="file:./db/custom.db"
   AUTH_SECRET="<long-random-string>"          # openssl rand -hex 32
   NODE_ENV="production"
   # optional object storage for uploads / private playback:
   S3_ENDPOINT=...
   S3_REGION=auto
   S3_BUCKET=...
   S3_ACCESS_KEY_ID=...
   S3_SECRET_ACCESS_KEY=...
   # S3_PUBLIC_BASE_URL=https://cdn.example.com
   # S3_PRIVATE_BUCKET=1        # signed playback, credentials stay server-side
   # S3_SIGN_TTL_SEC=14400
   # MAX_VIDEO_MB=512
   ```
3. `bun run db:push` then `bun prisma/seed.ts` (first time only) — or copy the
   existing `db/` folder to keep the current content.
4. `bun run build && bun run start` (serves on port 3000 by default).
5. Keep it running with a process manager (`pm2 start bun -- start` or a
   systemd unit) and put a reverse proxy (Caddy/Nginx) in front for HTTPS on
   your domain. Caddy gets HTTPS automatically: `yourdomain.com { reverse_proxy localhost:3000 }`.

### Option B — Vercel / Netlify

Deployable, but SQLite needs a managed database (e.g. switch Prisma to
Postgres) because serverless functions have no persistent disk. Large video
uploads should then go directly to object storage/CDN and be attached via the
**External URL** source — which this site is designed for.

### Videos

- **Uploaded files**: stored on the server (`db/uploads/`) or in the configured
  S3 bucket. Back that folder/bucket up — it is your only stateful data besides
  the SQLite file.
- **Cloud-hosted videos**: nothing is stored on the web host at all. Attach
  them in the admin dashboard via **External URL** (`https://…mp4/m3u8`) or
  **Provider embed** (YouTube/Vimeo/Dailymotion/Drive/Streamable) and they
  stream straight from your storage/CDN/provider to the viewer — see §4b for
  the required bucket settings (HTTPS, Content-Type, byte-range, CORS).
